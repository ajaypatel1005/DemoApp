<?php
$resources = [
    'car_stage',
    'car_type',
    'brand',
    'model',
    'variant',
    'specification_category',
    'specification',
    'feature',
    'feature_option',
    'feature_value',
    'banner_category',
    'banner',
    'car_graphic_type',
    'car_graphic',
    'car_listing',
    'car_listing_data',
    'country',
    'state',
    'city',
    'ev_station',
    'fuel_station',
    'service_station',
    'all_tax',
    'price_entry',
    'page_content',
    'manager_language',
    'managers',
    'standard_unit',
    'user_visit',
    'users',
    'roles',
    'log_view',
    'car_warning_light',
    'icon',
    'post_category_type',
    'post',
    'additional_features',
    'book_test_drive',
    'buy_now',
    'ticket',
    'ticket_category',
    'instant_message',
];

$actions = ['create', 'edit', 'delete', 'view'];

// Dynamically generate CRUD translations
$crudTranslations = [];
foreach ($resources as $resource) {
    foreach ($actions as $action) {
        $key = $action . '_' . $resource;
        $value = ucfirst($action) . ' ' . ucfirst(str_replace('_', ' ', $resource));
        $crudTranslations[$key] = $value;
    }
}

// Return the entire language array
return array_merge(
    [
        'car_type' => 'Car Type',
        'brand' => 'Brand',
        'model' => 'Model',
        'variant' => 'Variant',
        'specification_category' => 'Specification Category',
        'specification' => 'Specification',
        'feature' => 'Feature',
        'feature_option' => 'Feature Option',
        'feature_value' => 'Feature Value',
        'banner_category' => 'Banner Category',
        'banner' => 'Banner',
        'car_graphic_type' => 'Car Graphic Type',
        'car_graphic' => 'Car Graphic',
        'car_listing' => 'Car Listing',
        'car_listing_data' => 'Car Listing Data',
        'country' => 'Country',
        'state' => 'State',
        'city' => 'City',
        'ev_station' => 'Ev Station',
        'fuel_station' => 'Fuel Station',
        'service_station' => 'Service Station',
        'all_tax' => 'All Tax',
        'price_entry' => 'Price Entry',
        'page_content' => 'Page Content',
        'manager_language' => 'Manager Language',
        'managers' => 'Managers',
        'standard_unit' => 'Standard Unit',
        'user_visit' => 'User Visit',
        'users' => 'Users',
        'roles' => 'Roles',
        'log_view' => 'Log View',
        'imports' => 'Imports',
        'car_warning_light' => 'Car Warning Light',
        'icon' => 'Icon',
        'post_category_type' => 'Post Category Type',
        'post' => 'Post',
        'additional_features' => 'Additional Features',
        'book_test_drive' => 'Book Test Drive',
        'buy_now' => 'Buy Now',
        'ticket' => 'Ticket',
        'ticket_category' => 'Ticket Category',
        'instant_message' => 'Instant Message',
    ],
    $crudTranslations
);
