<x-app-layout>
    @section('title', 'All Tax')
    <div class="row">
        @php
            $create_class = $view_class = '';
            if (auth()->user()->can('view_all_tax') && auth()->user()->can('create_all_tax')) {
                $create_class = 'col-md-6';
                $view_class = 'col-md-6';
            } elseif (auth()->user()->can('view_all_tax') && !auth()->user()->can('create_all_tax')) {
                $create_class = $view_class = 'col-md-12';
            } elseif (!auth()->user()->can('view_all_tax') && auth()->user()->can('create_all_tax')) {
                $create_class = $view_class = 'col-md-12';
            }
        @endphp
        @can('create_all_tax')
            <div class="{{ $create_class }}">
                <!--begin::Card-->
                <div class="card">
                    <!--begin::Card header-->
                    <form method="post" id="allTaxFrm" action="{{ route('all_tax.store') }}" enctype="multipart/form-data">
                        @csrf
                        <div class="card-header border-0 pt-6">
                            <!--begin::Card title-->
                            <div class="card-title text-center w-100 d-flex justify-content-between">
                                <!--begin::Search-->
                                <div class="d-flex align-items-center position-relative my-1">
                                    <h2 class="card-title fs-2 fw-6">Tax</h2>
                                </div>
                                <div class="form-check form-switch form-check-custom form-check-success form-check-solid ">
                                    <label class="form-check-label text-black mt-4" for="kt_flexSwitchCustomDefault_1_1">
                                        <b>Visibility:</b>
                                    </label>
                                    <input class="form-check-input mt-6 ms-5" name="status" type="checkbox" value=""
                                        checked />

                                </div>
                                <!--end::Search-->
                            </div>
                            <!--begin::Card title-->
                            <!--begin::Card toolbar-->
                            <div class="card-toolbar">
                                <!--begin::Toolbar-->
                                <div class="d-flex justify-content-end" data-kt-customer-table-toolbar="base">


                                </div>
                                <!--end::Toolbar-->
                                <!--begin::Group actions-->
                                <div class="d-flex justify-content-end align-items-center d-none"
                                    data-kt-customer-table-toolbar="selected">

                                </div>

                                <!--end::Group actions-->
                            </div>
                            <!--end::Card toolbar-->
                        </div>
                        <!--end::Card header-->
                        <!--begin::Card body-->
                        <div class="card-body pt-0">

                            <div class="form-group mt-6">
                                <label for="tax_name" class="required mb-2">Tax Name:</label>
                                <input type="text" id="tax_name" class="form-control" name="tax_name"
                                    placeholder="Enter Tax Name" value="{{ old('tax_name') }}" />
                                @if ($errors->has('tax_name'))
                                    <span class="text-danger">{{ $errors->first('tax_name') }}</span>
                                @endif
                            </div>
                            <div class="form-group mt-6">
                                <label for="display_name" class="required mb-2">Display Name:</label>
                                <input type="text" id="display_name" class="form-control" name="display_name"
                                    placeholder="Enter Display Name" value="{{ old('display_name') }}" />
                                @if ($errors->has('display_name'))
                                    <span class="text-danger">{{ $errors->first('display_name') }}</span>
                                @endif
                            </div>
                            <div class="form-group  mt-4">
                                <div class="form-group mb-6">
                                    <label for="city_id" class=" mb-2">City:</label>
                                    <select class="form-select" aria-label="Select example" name="city_id"
                                        data-control="select2" id="city_id">
                                        <option value="" selected>Select City</option>
                                        @foreach ($city as $data)
                                            <option value="{{ $data->city_id }}"
                                                {{ old('city_id') == $data->city_id ? 'selected' : '' }}>
                                                {{ $data->city_name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('city_id'))
                                        <span class="text-danger">{{ $errors->first('city_id') }}</span>
                                    @endif
                                </div>

                            </div>
                            <div class="form-group  mt-4" >
                                <div class="form-group mb-6">
                                    <label for="condition_status" class="required mb-2">Select Condition Status:</label>
                                    <select class="form-select" aria-label="Select example" name="condition_status"
                                        data-control="select2" id="condition_status">
                                        <option selected hidden disabled>Select</option>
                                        <option {{ old('condition_status') == '1' ? 'selected' : '' }} value="1">
                                            Condition</option>
                                        <option {{ old('condition_status') == '0' ? 'selected' : '' }} value="0"
                                            >No
                                            condition</option>


                                    </select>
                                    @if ($errors->has('condition_status'))
                                        <span class="text-danger">{{ $errors->first('condition_status') }}</span>
                                    @endif
                                </div>

                            </div>

                            <div class="form-group mt-6 tax_percent "
                                style="{{ old('condition_status') != null ? (old('condition_status') == '0' ? '' : 'display:none;') : 'display:none;' }}">
                                <label for="tax_percent" class="required mb-2">Tax Percent:</label>
                                <input class="form-control required-field" name="percent" value="{{ old('percent') }}"
                                    placeholder="Enter Tax %" onkeypress="return validatePercent(event)">
                                @if ($errors->has('percent'))
                                    <span class="text-danger">{{ $errors->first('percent') }}</span>
                                @endif
                            </div>
                            <div class="form-group mt-6 tax_percent "
                                style="{{ old('condition_status') != null ? (old('condition_status') == '0' ? '' : 'display:none;') : 'display:none;' }}" >
                                <label for="value" class="required mb-2">Tax Value:</label>
                                <input class="form-control required-field" type="number" name="value" value="{{ old('value') }}"
                                    placeholder="Enter Tax Value">
                                @if ($errors->has('value'))
                                    <span class="text-danger">{{ $errors->first('value') }}</span>
                                @endif
                            </div>

                            <div class="form-group mt-6 condition_check"
                                style="{{ old('condition_status') != null ? (old('condition_status') == '1' ? '' : 'display:none;') : 'display:none;' }}">
                                <label for="display_name" class="required mb-2">Enter tax percent with conditions:</label>
                                <input type="number" id="amount" class="form-control" name="amount"
                                    placeholder="Enter Amount" value="{{ old('amount') }}" />
                                @if ($errors->has('amount'))
                                    <span class="text-danger">{{ $errors->first('amount') }}</span>
                                @endif

                                <div id="infoContainer">
                                    <div class="row mt-4" id="input-field">
                                        <div class="col-md-6">
                                            <select class="form-select required-field condition-dropdown"
                                                aria-label="Select example" name="condition1">
                                                <option selected hidden value=" ">Select Condition</option>
                                                <option {{ old('condition1') == '>' ? 'selected' : '' }} value=">">
                                                    Greater than</option>
                                                <option {{ old('condition1') == '>=' ? 'selected' : '' }} value=">=">
                                                    Greater than or equal to</option>
                                            </select>
                                            @if ($errors->has('condition1'))
                                                <span class="text-danger">{{ $errors->first('condition1') }}</span>
                                            @endif
                                        </div>
                                        <div class="col-md-6">
                                            <input class="form-control required-field" name="percent1"
                                                value="{{ old('percent1') }}" placeholder="Enter Tax %"
                                                onkeypress="return validatePercent(event)">
                                            @if ($errors->has('percent1'))
                                                <span class="text-danger">{{ $errors->first('percent1') }}</span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="row mt-4" id="input-field">
                                        <div class="col-md-6">
                                            <select class="form-select required-field condition-dropdown"
                                                aria-label="Select example" name="condition2">
                                                <option selected hidden value=" ">Select Condition</option>
                                                <option {{ old('condition2') == '<' ? 'selected' : '' }} value="<">
                                                    Less than</option>
                                                <option {{ old('condition2') == '<=' ? 'selected' : '' }} value="<=">
                                                    Less than or equal to</option>
                                            </select>
                                            @if ($errors->has('condition2'))
                                                <span class="text-danger">{{ $errors->first('condition2') }}</span>
                                            @endif
                                        </div>
                                        <div class="col-md-6">
                                            <input class="form-control required-field" name="percent2"
                                                value="{{ old('percent2') }}" placeholder="Enter Tax %"
                                                onkeypress="return validatePercent(event)">
                                            @if ($errors->has('percent2'))
                                                <span class="text-danger">{{ $errors->first('percent2') }}</span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-start gap-5">
                                <button type="submit" class="btn btn-primary mt-6">Submit</button>

                            </div>
                        </div>
                    </form>


                    {{--   view page  --}}
                </div>
            </div>
        @endcan
        @include('all_tax.list')
    </div>



    <!--end::Card-->


    @section('script')
        <script>
            $(document).ready(function() {
                $('input[name="percent"]').on('input', function() {
            // Check if percent field has any value
            if ($(this).val().trim() !== '') {
                // If percent field has value, disable the value field and clear its value
                $('input[name="value"]').prop('disabled', true).val('');
            } else {
                // If percent field is empty, enable the value field
                $('input[name="value"]').prop('disabled', false);
            }
        });

        // Add change event listener to the value input field
        $('input[name="value"]').on('input', function() {
            // Check if value field has any value
            if ($(this).val().trim() !== '') {
                // If value field has value, disable the percent field and clear its value
                $('input[name="percent"]').prop('disabled', true).val('');
            } else {
                // If value field is empty, enable the percent field
                $('input[name="percent"]').prop('disabled', false);
            }
        });
                $('.condition-dropdown').on('change', function() {
                    var selectedValue = $(this).val();
                    var siblingDropdown = $(this).closest('.row').siblings('.row').find('.condition-dropdown');
                    var readonlyInput = $(this).closest('.row').siblings('.row').find('.readonly-input');
                    siblingDropdown.find('option').show();
                    if (selectedValue == ">") {
                        siblingDropdown.val("<=");
                        siblingDropdown.find('option[value="<"]').hide();
                        siblingDropdown.find('option[value="<="]').hide();
                        readonlyInput.prop('readonly', true);
                    } else if (selectedValue == ">=") {
                        siblingDropdown.val("<");
                        siblingDropdown.find('option[value="<"]').hide();
                        siblingDropdown.find('option[value="<="]').hide();
                        readonlyInput.prop('readonly', true);
                    } else if (selectedValue == "<") {
                        siblingDropdown.val(">=");
                        siblingDropdown.find('option[value=">"]').hide();
                        siblingDropdown.find('option[value=">="]').hide();
                        readonlyInput.prop('readonly', true);
                    } else if (selectedValue == "<=") {
                        siblingDropdown.val(">");
                        siblingDropdown.find('option[value=">"]').hide();
                        siblingDropdown.find('option[value=">="]').hide();
                        readonlyInput.prop('readonly', true);
                    } else {
                        readonlyInput.prop('readonly', false);
                    }
                });
            });


            $(document).ready(function() {
                var conditionStatusSelect = $("#condition_status");
                var conditionCheckDiv = $(".condition_check");
                var taxPercent = $(".tax_percent");

                // Initially hide the condition_check div

                // Add change event listener to conditionStatusSelect
                conditionStatusSelect.on("change", function() {
                    if (conditionStatusSelect.val() === "1") {
                        conditionCheckDiv.show();
                        taxPercent.hide(); // Show condition_check div if "Condition" is selected
                    } else {

                        conditionCheckDiv.hide(); // Hide condition_check div if "No condition" is selected
                        taxPercent.show();
                    }
                });
            });
        </script>

        </script>

        <script type="text/javascript">
            $(document).on('click', '#status', function() {
                var id = this.value;
                // alert(id);
                $.ajax({
                    type: "POST",
                    url: "{{ route('all_tax.status') }}", // Use the named route
                    data: {
                        id: id,
                        _token: '{{ csrf_token() }}' // Add CSRF token for security
                    },
                    success: function(data) {
                        // console.log('hello');
                    },

                });
            });


            function validatePercent(evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if (charCode != 46 && charCode != 8 && (charCode < 48 || charCode > 57)) {
                    return false;
                }
                var currentValue = evt.target.value;
                if (charCode == 46) {
                    if (currentValue.indexOf('.') !== -1) {
                        return false;
                    }
                } else if (currentValue.indexOf('.') !== -1) {
                    var decimalPart = currentValue.split('.')[1];
                    if (decimalPart.length >= 2) {
                        return false;
                    }
                }
                var inputValue = parseFloat(evt.target.value + String.fromCharCode(charCode));
                if (inputValue >= 100) {
                    return false;
                }
                return true;
            }
        </script>

    @endsection

</x-app-layout>
