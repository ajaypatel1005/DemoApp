<x-app-layout>

    <a href="{{ route('all_tax.create') }}" class="btn btn-primary pull-right" data-bs-toggle="tooltip">
        <i class="ki-duotone ki-plus fs-2"></i>
        Add Tax</a>


    <table id="kt_datatable_dom_positioning" class="table table-striped table-row-bordered gy-5 gs-7 border rounded">
        <thead>
            <tr class="fw-bold fs-6 text-gray-800 px-7">
                <th>Sr No</th>
                <th>Tax Name </th>
                <th>Tax Value</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($all_tax_view as $data)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $data->tax_name }}</td>
                    <td>{{ $data->tax_value }}</td>

                    <td>
                        <input class="form-check-input mt-4 ms-5" name="status" type="checkbox"
                            value="{{ $data['tax_id'] }}" @if ($data['status'] == 1) checked @endif
                            id="status" />

                    </td>
                    <td> <a href=" {{ route('all_tax.edit', encrypt($data->tax_id)) }}"
                            class="btn btn-icon btn-warning">
                            <i class="bi bi-pencil-fill fs-4 me-2"></i>
                            <!-- Bootstrap "pencil" icon -->
                        </a></td>


                </tr>
            @endforeach
        </tbody>

    </table>

    <script type="text/javascript">
        $(document).on('click', '#status', function() {
            var id = this.value;
            $.ajax({
                type: "POST",
                url: "{{ route('all_tax.status') }}", // Use the named route
                data: {
                    id: id,
                    _token: '{{ csrf_token() }}' // Add CSRF token for security
                },
                success: function(data) {
                    // console.log('hello');
                },

            });
        });
    </script>
</x-app-layout>
