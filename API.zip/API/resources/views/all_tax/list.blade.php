<!--end::Card body-->
@can('view_all_tax')
    <div class="{{ $view_class }}">
        <!--begin::Card-->
        <div class="card">
            <!--begin::Card header-->
            <div class="card-header border-0 pt-6">
                <!--begin::Card title-->
                <div class="card-title text-center d-flex justify-content-between w-100">
                    <!--begin::Search-->
                    <h2 class="card-title fs-2 fw-6"> Tax View</h2>
                    <!--end::Search-->
                </div>
                <!--begin::Card title-->
            </div>
            <!--end::Card header-->
            <!--begin::Card body-->
            <div class="card-body pt-0">
                {{--   view page  --}}
                <div class="view-page">
                    <table id="kt_datatable_dom_positioning"
                        class="table table-striped table-row-bordered gs-7 border rounded">
                        <thead>
                            <tr class="fw-bold fs-6 text-gray-800 px-7">
                                <th>Sr No</th>
                                <th>Tax Name</th>
                                <th id>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($all_tax_view as $data)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $data->tax_name }}</td>
                                    <td>
                                        <div
                                            class="form-check form-switch form-check-custom form-check-success form-check-solid">
                                            <input class="form-check-input" name="status" type="checkbox"
                                                value="{{ $data->tax_id }}" @if ($data['status'] == 1) checked @endif
                                                id="status" {{ !auth()->user()->can('edit_all_tax')? 'disabled': '' }} />
                                        </div>
                                    </td>
                                    <td>
                                        @can('edit_all_tax')
                                            <a href=" {{ route('all_tax.edit', encrypt($data->tax_id)) }}" class=" btn-primary">
                                                <i class="fas fa-pen fs-4 text-primary"></i><!-- Bootstrap "pencil" icon -->
                                            </a>
                                        @endcan
                                        @can('delete_all_tax')
                                            <a href="javascript:void(0)"
                                                data-href="{{ route('all_tax.delete', encrypt($data->tax_id)) }}"
                                                class="delete_record btn-danger">
                                                <i class="fas fa-trash fs-4 text-danger"></i>
                                                <!-- Bootstrap "pencil" icon -->
                                            </a>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--end::Card body-->
    </div>
@endcan
