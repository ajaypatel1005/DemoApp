<x-app-layout>
    @section('title', 'Additional Features')

    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <div class="card">
            <!--begin::Card header-->
            <div class="card-header border-0 pt-6">
                <form method="post" id="form" action="">
                    @csrf
                    @method('POST')
                    <!--begin::Card title-->
                    <div class="card-title d-flex justify-content-between w-100 mt-5">
                        <!--begin::Search-->
                        <h2 class="card-title fs-2 fw-6 m-0">Additional Features</h2>
                        <div class="form-check form-switch form-check-custom form-check-success form-check-solid">
                            <label class="form-check-label text-black" for="kt_flexSwitchCustomDefault_1_1">
                                <b>Visibility:</b>
                            </label>
                            <input class="form-check-input ms-5" name="status" type="checkbox" value="" checked
                                id="status" />
                        </div>

                        <!--end::Search-->
                    </div>
                    <!--begin::Card title-->
                    <!--begin::Card toolbar-->
                    <div class="card-toolbar">
                        <!--begin::Toolbar-->
                        <div class="d-flex justify-content-end" data-kt-customer-table-toolbar="base">


                        </div>
                        <!--end::Toolbar-->
                        <!--begin::Group actions-->
                        <div class="d-flex justify-content-end align-items-center d-none"
                            data-kt-customer-table-toolbar="selected">

                        </div>

                        <!--end::Group actions-->
                    </div>
                    <!--end::Card toolbar-->
            </div>
            <!--end::Card header-->
            <!--begin::Card body-->
            <div class="card-body pt-0">
                <div class="row">
                    <div class="col-md-6">

                        <div class="mb-3">
                            <label class="form-label required" for="exampleFormControlSelect17">Select
                                Brand</label>
                            <select style="width: 500px" class="form-select input-air-primary digits" id="brand_id"
                                name="brand_id" data-control="select2" required>
                                <option value="" selected disabled>Select Brand</option>
                                @foreach ($brands as $data)
                                    <option value="{{ $data->brand_id }}"
                                        {{ old('brand_id') == $data->brand_id ? 'selected' : '' }}>
                                        {{ $data->brand_name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        @if ($errors->has('brand_id'))
                            <span class="text-danger">
                                {{ $errors->first('brand_id') }}
                            </span>
                        @endif

                        <div class="mb-3">
                            <label class="form-label required" for="exampleFormControlSelect17">Select
                                Model</label>
                            <select style="width: 500px" class="form-select input-air-primary digits" id="model_id"
                                name="model_id" data-control="select2" required>
                                <option value="" selected disabled>Select Model</option>
                            </select>
                        </div>

                        @if ($errors->has('model_id'))
                            <span class="text-danger">
                                {{ $errors->first('model_id') }}
                            </span>
                        @endif

                        <div class="mb-3">
                            <label class="form-label required" for="exampleFormControlSelect17">Select
                                Variant</label>
                            <select style="width: 500px" class="form-select input-air-primary digits" id="variant_id"
                                data-control="select2" name="variant_id" required>
                                <option value="" selected disabled>Select Variant</option>
                            </select>
                        </div>

                        @if ($errors->has('variant_id'))
                            <span class="text-danger">
                                {{ $errors->first('variant_id') }}
                            </span>
                        @endif
                        <div>
                            <label class="form-label required" id = "descriptionLabel"for="description"
                                style="display: none;">Description</label>
                            <div id="description">
                            </div>

                            <button class="btn btn-sm btn-success" id="addBtn" type="button"
                                style="display: none; margin: 10px 0;">Add
                                Field</button>
                        </div>
                        <button class="btn btn btn-primary" id="submit" name="submit" type="button">Submit</button>
                        <button class="btn btn-warning" id= "reset" name="reset" type= "button">Refresh</button>

                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>

    @section('script')
        <script>
            $(document).ready(function() {
                $('#brand_id').on('change', function() {
                    var brand_id = $('#brand_id').val();
                    $.ajax({
                        url: '{{ url('additional_features/fetchModels') }}',
                        type: "POST",
                        data: {
                            brand_id: brand_id,
                            _token: '{{ csrf_token() }}'
                        },
                        dataType: 'json',
                        success: function(result) {
                            $('#model_id').html(
                                '<option value="" disabled selected>Select Model</option>');
                            $.each(result.models, function(key, value) {
                                $("#model_id").append('<option value="' + value.model_id +
                                    '">' + value
                                    .model_name +
                                    '</option>');
                            });
                        }

                    })
                })
                $('#model_id').on('change', function() {
                    var model_id = $('#model_id').val();
                    $.ajax({
                        url: '{{ url('additional_features/fetchVariants') }}',
                        type: "post",
                        data: {
                            model_id: model_id,
                            _token: '{{ csrf_token() }}'
                        },
                        dataType: 'json',
                        success: function(result) {
                            $('#variant_id').html(
                                '<option value="" disabled selected>Select Variant</option>');
                            $.each(result.variants, function(key, value) {
                                $("#variant_id").append('<option value="' + value
                                    .variant_id +
                                    '">' + value
                                    .variant_name +
                                    '</option>');
                            });
                        }
                    })
                })

                $('#variant_id').on('change', function() {
                    var variant_id = $('#variant_id').val();
                    $.ajax({
                        url: "{{ url('additional_features/fetchAFValue') }}",
                        type: "post",
                        data: {
                            variant_id: variant_id,
                            _token: '{{ csrf_token() }}'
                        },
                        dataType: 'json',
                        success: function(result) {
                            $('#brand_id').prop('disabled', true);
                            $('#model_id').prop('disabled', true);
                            $('#description').html("");
                            //status toggle
                            var status = result.status;
                            if (status == 1) {
                                $('#status').prop('checked', true);
                            } else if (status == 0) {
                                $('#status').prop('checked', false);
                            } else {}
                            var afvalues = result.afvalue;
                            if (afvalues.length > 0 || afvalues != null) {

                                $.each(afvalues, function(key, value) {

                                    $('#description').append(
                                        '<div class="input-field" style="display: flex;align-items: center;gap: 10px;  margin-bottom: 10px;"><input type="text" name="description[]" value="' +
                                        value +
                                        '" class="form-control  required-field"> <span class="text-danger" style="display: none">This field is required</span><i class="fa  fa-trash text-danger delete_item deleteBtn"></i> </div>'
                                    );
                                });
                            } else {
                                $('#addBtn').click();

                            }
                            $('#descriptionLabel').show();
                            $('#addBtn').show()
                        }
                    })
                });
                //Dynamic FIeld
                $("#addBtn").on('click', function() {
                    // Append input field and delete button
                    $('#description').append(
                        '<div class="input-field" style="display: flex;align-items: center;gap: 10px;""><input type="text" name="description[]" class="form-control  required-field">  <span class="text-danger" style="display: none">This field is required</span><i class="fa fa-trash text-danger delete_item deleteBtn"></i></div>'
                    );
                });

                $('#description').on('click', '.deleteBtn', function() {
                    var descriptionDivs = $('#description').find('.input-field');
                    // if ($descriptionDivs.length > 1) {
                        $(document).on("click", ".delete_item", function() {
                            Swal.fire({
                                title: "Are you sure?",
                                text: "Once deleted you can't retrieve this record.",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#DD6B55",
                                confirmButtonText: "Yes",
                                cancelButtonText: "No",
                                closeOnConfirm: false,
                                closeOnCancel: false
                            }).then((willDelete) => {
                                if (willDelete.isConfirmed) {
                                    // Swal.fire("Deleted!", "Your record has been deleted.", "success");
                                    $(this).parent('.input-field').remove();
                                }
                            });
                        });
                    // } else {


                        // $(".required-field").each(function(index) {
                        //     var _this = $(this);
                        //     let dataVal = _this.val();
                        //     let tagName = _this.prop("tagName");
                        //     _this.next(".text-danger").show();
                        // });
                        // $(document).on("click", ".delete_item", function() {
                        //     Swal.fire({
                        //         text: "One record is mandatory!",
                        //         icon: "warning",
                        //         buttonsStyling: false,
                        //         confirmButtonText: "Ok, got it!",
                        //         customClass: {
                        //             confirmButton: "btn btn-warning"
                        //         }
                        //     });
                        // });
                    // }
                });

                $("#submit").on("click", function(event) {
                    event.preventDefault();
                    $('#brand_id').prop('disabled', false);
                    $('#model_id').prop('disabled', false);
                    var formData = $('#form').serializeArray();
                    let desc = $("input[name='description[]']").map(function() {
                        return this.value;
                    }).get();
                    formData.push({
                        name: 'description',
                        value: desc
                    });
                    var err = 0;
                    $(".required-field").next(".text-danger").hide();
                    $(".required-field").each(function(index) {
                        var _this = $(this);
                        let dataVal = _this.val();
                        let tagName = _this.prop("tagName");
                        if ((tagName == "INPUT" && dataVal.trim() === "") || dataVal == null) {
                            _this.focus();
                            _this.next(".text-danger").show();
                            err++;
                        }
                    });
                    if (err == 0) {

                        $.ajax({
                            type: "POST", // Specify request method
                            url: "{{ route('additional_features.store') }}", // Specify URL to submit the form data
                            data: formData, // Pass serialized form data
                            success: function(response) {
                                window.location.replace('{{ url('additional_features/create') }}')
                            },
                            error: function(xhr, status, error) {
                                // Handle error here
                            }
                        });
                    }
                })

                // Refresh Button
                $('#reset').on('click', function() {
                    window.location.href = '{{ route('additional_features.create') }}';
                });

            });
        </script>


    @endsection
</x-app-layout>
