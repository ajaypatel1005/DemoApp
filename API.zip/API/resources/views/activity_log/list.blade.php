<x-app-layout>
@section('title','Log View')
    <div class="row">
        <div class="col-md-12">
            <!--begin::Card-->
            <div class="card">
                <!--begin::Card header-->
                <div class="card-header border-0 pt-6">
                    <!--begin::Card title-->
                    <div class="card-title text-center d-flex justify-content-between w-100">
                        <!--begin::Search-->

                        <h2 class="card-title fs-2 fw-6"> Activity Log</h2>
                        <!--end::Search-->
                    </div>
                    <!--begin::Card title-->
                    <!--begin::Card toolbar-->
                    <div class="card-toolbar">

                        <div class="row">
                            <div class="form-group col-lg-3">
                                <label for="filter_from_date" class="form-label mb-2">From Date</label>
                                <input type="date" name="filter_from_date" id="filter_from_date" class="form-control" placeholder="Date" />
                            </div>
                            <div class="form-group col-lg-3">
                                <label for="filter_to_date" class="form-label mb-2">To Date</label>
                                <input type="date" name="filter_to_date" id="filter_to_date" class="form-control" placeholder="Date" />
                            </div>
                            <div class="form-group col-lg-3">
                                <label for="filter_event" class="form-label">Select Event</label>
                                <select class="form-select" name="filter_event" id="filter_event" data-control="select2">
                                <option value="">None</option>
                                    <option value="created">Create</option>
                                    <option value="updated">Update</option>
                                    <option value="deleted">Delete</option>
                                    <option value="login">Login/Logout</option>
                                    <option value="password_change">Change Password</option>
                                </select>
                            </div>
                            <div class="form-group col-lg-3">

                                <label for="filter_subject" class="form-label">Select Subject</label>
                                <select class="form-select" name="filter_subject" id="filter_subject" data-control="select2">
                                <option value="">None</option>

                                @foreach($logTypes as $logType)
                                    <option value="{{$logType->model_name}}">{{$logType->log_name}}</option>
                                    @endforeach
                                    <!-- <option value="User">User</option>
                                    <option value="CarStage">Car Stage</option>
                                    <option value="CarType">Car Type</option>
                                    <option value="Brand">Brand</option>
                                    <option value="Model">Model</option>
                                    <option value="Variant">Variant</option>
                                    <option value="Color">Color</option>
                                    <option value="SpecificationCategory">Specification Category</option>
                                    <option value="Specification">Specification</option>
                                    <option value="Feature">Feature</option>
                                    <option value="FeatureOption">Feature Option</option>
                                    <option value="FeatureValue">Feature Value</option>
                                    <option value="BannerCategory">Banner Category</option>
                                    <option value="Banner">Banner</option>
                                    <option value="CarGraphicType">Car Graphic Type</option>
                                    <option value="CarGraphic">Car Graphic</option>
                                    <option value="CarListing">Car Listing</option>
                                    <option value="CarListingData">Car Listing data</option>
                                    <option value="Country">Country</option>
                                    <option value="State">State</option>
                                    <option value="City">City</option>
                                    <option value="EvStation">EV Station</option>
                                    <option value="ServiceStation">Service Station</option>
                                    <option value="FuelStation">Fuel Station</option>
                                    <option value="AllTax">All Tax</option>
                                    <option value="PriceEntry">Price Entry</option>
                                    <option value="PageContent">Page Content</option>
                                    <option value="ManagerLanguage">Manager Language</option>
                                    <option value="Manager">Manager</option>
                                    <option value="StandardUnit">Standard Unit</option>
                                    <option value="UserVisit">User Visit</option> -->

                                </select>
                            </div>
                        </div>

                    </div>
                    <!--end::Card toolbar-->
                </div>
                <!--end::Card header-->
                <!--begin::Card body-->
                <div class="card-body pt-0">

                    {{-- view page  --}}
                    <div class="view-page">
                        <!-- begin::list data -->
                        <div class="table-responsive">
                            <table id="kt_datatable_dom_positioning2" class="table table-striped table-row-bordered gs-7 border rounded">
                                <thead>
                                    <tr class="fw-bold fs-6 text-gray-800 px-7">
                                        <th>Sr No</th>
                                        <th>Date </th>
                                        <th>Log Name </th>
                                        <th>Description</th>
                                        <th>Subject Type</th>
                                        <th>Event</th>
                                        <th>Causer Type</th>
                                        <th>Causer By</th>
                                        <th>Properties</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>

                            </table>
                            <!-- end::list data -->
                        </div>
                    </div>


                </div>
            </div>
            <!--end::Card body-->
        </div>
    </div>


</x-app-layout>

@section('script')
<script>

// var draw = 1; // Initialize draw counter
$(document).ready(function () {
    var dataTable = $("#kt_datatable_dom_positioning2").DataTable({ // Note the change from dataTable to DataTable
        "dom": 'frtip',
        serverSide: true,
        processing: true, // Show processing indicator
        ajax: {
            url: "{{ url('activity_log/filter-log') }}",
            type: "POST",
            data: function (d) {
                return $.extend({}, d, {
                    filter_from_date: $("#filter_from_date").val(),
                    filter_to_date: $("#filter_to_date").val(),
                    filter_event: $("#filter_event").val(),
                    filter_subject: $("#filter_subject").val(),
                    _token: '{{ csrf_token() }}',
                    // draw: draw // Pass the draw counter
                });
            },
            dataSrc: function (json) {
                return json.data;
            }
        },
        columns: [{
                "data": "sr_no"
            },
            {
                "data": "created_at",
                "render": function(data, type, row) {
                    // Format the date using moment.js
                    return moment(data).format('YYYY-MM-DD hh:mm:s a');
                }
            },
            {
                "data": "log_name"
            },
            {
                "data": "description"
            },
            {
                "data": "subject_type"
            },
            {
                "data": "event"
            },
            {
                "data": "causer_type"
            },
            {
                "data": "user_name",
                "render": function(data, type, row) {
                    // Customize the HTML formatting for user_name
                    if (data === null || data === undefined) {
                        return '-';
                    }
                    return '<div class="custom-div">' + row.user_name + '<br>' + row.user_email + '</div>';
                }
            },
            {
                "data": "properties",
                "render": function(data) {
                    // Format the data with indentation
                    return JSON.stringify(data, null, 2);
                }
            },
        ],
        // Handle pagination click event
        "initComplete": function () {
            $("#kt_datatable_dom_positioning2").on("click", ".paginate_button", function () {
                dataTable.ajax.reload(); // Reload data with updated draw counter
            });
        }
    });
});




    // var dataTable = $('#kt_datatable_dom_positioning21').DataTable({
    //     "dom": 'frtip',
    //     "language": {
    //         "lengthMenu": "Show _MENU_",
    //     },
       
    //     "data": [] // Initialize with an empty array
    // });

    // function filterRecord() {
    //     $.ajax({
    //         url: "{{ url('activity_log/filter-log') }}",
    //         type: "POST",
    //         data: {
    //             filter_from_date: $("#filter_from_date").val(),
    //             filter_to_date: $("#filter_to_date").val(),
    //             filter_event: $("#filter_event").val(),
    //             filter_subject: $("#filter_subject").val(),
    //             _token: '{{ csrf_token() }}'
    //         },
    //         dataType: 'json',
    //         success: function(result) {
    //             // Update the data in the DataTable
    //             // result.data.forEach(function(log, index) {
    //             //    log.sr_no = index + 1;
    //             // });

    //             dataTable.clear().rows.add(result.data).draw();
    //             console.log(dataTable._iRecordsTotal);
    //             // dataTable.draw(result);
    //         }
    //     });
    // }

    $('#filter_from_date,#filter_to_date, #filter_event, #filter_subject').on('change', function() {
        dataTable.ajax.reload();
        // filterRecord();
    });
    // filterRecord();
</script>
@endScript
