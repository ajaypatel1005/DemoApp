<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        DB::unprepared('
            CREATE FUNCTION getBaseVariantId(modelId INT) 
            RETURNS INT
            BEGIN
                DECLARE base_variant_id INT;
                SELECT cop_pe_ms.variant_id INTO base_variant_id 
                FROM cop_pe_ms 
                WHERE cop_pe_ms.model_id = modelId 
                ORDER BY cop_pe_ms.ex_showroom_price ASC 
                LIMIT 1;
                RETURN base_variant_id;
            END
        ');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        DB::unprepared('DROP FUNCTION IF EXISTS getBaseVariantId');
    }
};
