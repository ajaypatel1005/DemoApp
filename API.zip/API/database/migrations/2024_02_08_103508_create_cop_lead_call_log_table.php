<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_lead_call_log', function (Blueprint $table) {
            //
            $table->id('lcl_id');
            $table->unsignedBigInteger('lead_id');
            $table->unsignedBigInteger('lco_id');
            $table->text('call_remarks')->nullable();
            $table->datetime('call_date');
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();

            $table->foreign('lead_id')->references('lead_id')->on('cop_leads')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('lco_id')->references('lco_id')->on('cop_lead_call_outcome_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_lead_call_log', function (Blueprint $table) {
            //
        });
    }
};
