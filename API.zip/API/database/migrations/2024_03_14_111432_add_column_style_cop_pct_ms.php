<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_pct_ms',function (Blueprint $table){
            $table->tinyInteger('style')->default(1)->after('status');
            $table->string('slug')->after('post_cat_type');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_pct_ms', function (Blueprint $table) {
            $table->dropColumn('style');
            $table->dropColumn('slug');
        });
    }
};
