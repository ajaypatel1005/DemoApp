<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasTable('cop_book_test_drives')) {

            Schema::create('cop_book_test_drives', function (Blueprint $table) {
                $table->id('btest_id');
                $table->unsignedBigInteger('customer_id');
                $table->unsignedBigInteger('brand_id');
                $table->unsignedBigInteger('model_id');
                $table->string('fuel_types');
                $table->text('additional_notes')->nullable();
                $table->string('btest_date');
                $table->string('btest_time');
                $table->tinyInteger('status')->default(1);
                $table->timestamps();
                $table->foreign('brand_id')->references('brand_id')->on('cop_brands_ms')->onDelete('cascade')->onUpdate('cascade');
                $table->foreign('model_id')->references('model_id')->on('cop_models')->onDelete('cascade')->onUpdate('cascade');
                $table->foreign('customer_id')->references('customer_id')->on('cop_customers')->onDelete('cascade')->onUpdate('cascade');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (!Schema::hasTable('cop_book_test_drives')) {
            Schema::dropIfExists('cop_book_test_drives');
        }
    }
};
