<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_manager_ms', function (Blueprint $table) {
            $table->dropForeign(['lang_id']);
            $table->dropIndex('cop_manager_ms_lang_id_foreign');
        });
        Schema::table('cop_manager_ms', function (Blueprint $table) {
            $table->string('lang_id')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_manager_ms', function (Blueprint $table) {
                  //
            $table->unsignedBigInteger('lang_id')->change();
            $table->foreign('lang_id')->references('lang_id')->on('cop_ml_ms')->onDelete('cascade')->onUpdate('cascade');
        });
    }
};
