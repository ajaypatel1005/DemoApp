<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_book_test_drives',function(Blueprint $table){
            $table->unsignedBigInteger('manager_id')->nullable();
            $table->unsignedBigInteger('city_id')->nullable();
            $table->unsignedBigInteger('country_id')->nullable();
            $table->unsignedBigInteger('state_id')->nullable();

            $table->foreign('manager_id')->references('manager_id')->on('cop_manager_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('city_id')->references('city_id')->on('cop_city_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('state_id')->references('state_id')->on('cop_state_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('country_id')->references('country_id')->on('cop_country_ms')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_book_test_drives', function (Blueprint $table) {
            // Drop the foreign key constraints
            $table->dropForeign(['manager_id']);
            $table->dropForeign(['city_id']);
            $table->dropForeign(['country_id']);
            $table->dropForeign(['state_id']);

            // Drop the columns
            $table->dropColumn('manager_id');
            $table->dropColumn('city_id');
            $table->dropColumn('state_id');
            $table->dropColumn('country_id');
        });
    }
};
