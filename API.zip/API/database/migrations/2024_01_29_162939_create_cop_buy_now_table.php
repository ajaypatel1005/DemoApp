<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_buy_now', function (Blueprint $table) {
            $table->id('buynow_id');
            $table->unsignedBigInteger('model_id');
            $table->unsignedBigInteger('variant_id');
            $table->unsignedBigInteger('price_id');
            $table->unsignedBigInteger('manager_id');
            $table->unsignedBigInteger('customer_id');
            $table->unsignedBigInteger('city_id')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();

            $table->foreign('model_id')->references('model_id')->on('cop_models')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('variant_id')->references('variant_id')->on('cop_variants')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('price_id')->references('pe_id')->on('cop_pe_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('manager_id')->references('manager_id')->on('cop_manager_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('customer_id')->references('customer_id')->on('cop_customers')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('city_id')->references('city_id')->on('cop_city_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');


        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_buy_now');
    }
};
