<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Permission;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table("cop_buy_now", function (Blueprint $table) {
            $table->unsignedBigInteger("brand_id")->nullable();
            $table->unsignedBigInteger("state_id")->nullable();
            $table->unsignedBigInteger("country_id")->nullable();
            $table->string("delivery_date")->nullable();

            $table->foreign("brand_id")->references("brand_id")->on("cop_brands_ms")->onDelete("cascade")->onUpdate("cascade");
            $table->foreign("country_id")->references("country_id")->on("cop_country_ms")->onDelete("cascade")->onUpdate("cascade");
            $table->foreign("state_id")->references("state_id")->on("cop_state_ms")->onDelete("cascade")->onUpdate("cascade");
        });
        Permission::updateorCreate(['name'=>'book_test_drive'],['guard_name'=>'web']);
        Permission::updateOrcreate(['name' => 'buy_now'],['guard_name' => 'web']);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table("cop_buy_now", function (Blueprint $table) {
            $table->dropForeign(["brand_id"]);
            $table->dropForeign(["country_id"]);
            $table->dropForeign(["state_id"]);
            $table->dropColumn(["state_id", "country_id", "delivery_date","brand_id"]);
        });
        Permission::where('name','LIKE','book_test_drive')->delete();
        Permission::where("name","LIKE","buy_now")->delete();
    }
};
