<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_rto_ms', function (Blueprint $table) {
            $table->id('rto_id');
            $table->unsignedBigInteger('state_id');
            $table->enum('rto_type',['I','C'])->comment('I=Indivisual,C=Corporation');
            $table->string('pre_condition')->nullable();
            $table->integer('pre_amount')->nullable();
            $table->string('post_condition')->nullable();
            $table->integer('post_amount')->nullable();
            $table->decimal('percentage');
            $table->enum('fuel_type',['Petrol','Diesel','CNG','EV','Hybrid'])->nullable();
            $table->enum('cc', ['1', '0'])->nullable();
            $table->timestamps();

            $table->foreign('state_id')->references('state_id')->on('cop_state_ms')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_rto_ms');
    }
};
