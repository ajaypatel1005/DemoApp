<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_banners', function (Blueprint $table) {

            $table->unsignedBigInteger('variant_id')->nullable();
            $table->foreign('variant_id')->references('variant_id')->on('cop_variants')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_banners', function (Blueprint $table) {
            $table->dropForeign(['variant_id']);
            $table->dropIndex('cop_banners_variant_id_foreign');
            $table->dropColumn('variant_id');
        });
    }
};
