<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use App\Models\User;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $permissionIds = [];
        $permission = [
            ['guard_name' => 'web', 'name' => 'create_ticket'],
            ['guard_name' => 'web', 'name' => 'edit_ticket'],
            ['guard_name' => 'web', 'name' => 'delete_ticket'],
            ['guard_name' => 'web', 'name' => 'view_ticket'],
            ['guard_name' => 'web', 'name' => 'create_ticket_category'],
            ['guard_name' => 'web', 'name' => 'edit_ticket_category'],
            ['guard_name' => 'web', 'name' => 'view_ticket_category'],
            ['guard_name' => 'web', 'name' => 'delete_ticket_category'],
            ['guard_name' => 'web', 'name' => 'create_instant_message'],
            ['guard_name' => 'web', 'name' => 'edit_instant_message'],
            ['guard_name' => 'web', 'name' => 'view_instant_message'],
            ['guard_name' => 'web', 'name' => 'delete_instant_message'],
        ];
        foreach($permission as $per){
            $permissionModel =  Permission::updateOrCreate([
                'name' => $per['name']
            ],[
                'guard_name' => $per['guard_name']
            ]);
            // Store the ID of the permission
            $permissionIds[] = $permissionModel->id;
        }
        $permissions = Permission::pluck('name')->all();
        $admin = User::where("email" ,'LIKE', "admin@admin.com")->first();
        if(!empty($admin)){
            $admin->syncPermissions($permissions);
        }

        $role = Role::updateOrCreate(['name' => 'Agent'],[
            'guard_name' => 'web'
        ]);
        if(!empty($role)) {
            if(!empty($permissionIds)){
                $ticketModulePermission = Permission::whereIn('id', $permissionIds)->get()->pluck('name');
                if(!empty($ticketModulePermission)){
                    $role->syncPermissions($ticketModulePermission);
                }
            }
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
    }
};
