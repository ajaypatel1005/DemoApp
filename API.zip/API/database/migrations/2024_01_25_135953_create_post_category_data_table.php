<?php
use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Permission;
return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_post', function (Blueprint $table) {
            $table->id('post_id');
            $table->unsignedBigInteger('post_cat_id');
            $table->string('title');
            $table->text('content');
            $table->string('post_image')->nullable();
            $table->string('author');
            $table->string('author_image')->nullable();
            $table->string('post_date')->nullable();

            $table->tinyInteger('status')->default(1);
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->foreign('post_cat_id')->references('post_cat_id')->on('cop_pct_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
        });

        $permission = [
            ['guard_name' => 'web', 'name' => 'create_post_category_type'],
            ['guard_name' => 'web', 'name' => 'edit_post_category_type'],
            ['guard_name' => 'web', 'name' => 'delete_post_category_type'],
            ['guard_name' => 'web', 'name' => 'view_post_category_type'],
            ['guard_name' => 'web', 'name' => 'create_post'],
            ['guard_name' => 'web', 'name' => 'edit_post'],
            ['guard_name' => 'web', 'name' => 'view_post'],
            ['guard_name' => 'web', 'name' => 'delete_post'],
        ];
        foreach($permission as $per){
            Permission::updateOrCreate([
                'name' => $per['name']
            ],[
                'guard_name' => $per['guard_name']
            ]);
        }
        // DB::table('permissions')->insert($permission);
        $permissions = Permission::pluck('id', 'id')->all();
        $admin = User::where("email" ,'LIKE', "admin@admin.com")->first();
        if(!empty($admin)){
            $admin->syncPermissions($permissions);
        }

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_post');
    }
};
