<?php

use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Permission;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Permission::updateOrcreate(['name' => 'create_icon'],['guard_name' => 'web']);
        Permission::create(['name' => 'edit_icon'],['guard_name' => 'web',]);
        Permission::create(['name' => 'delete_icon'],['guard_name' => 'web',]);
        Permission::create(['name' => 'view_icon'],['guard_name' => 'web',]);
        $permissions = Permission::pluck('id', 'id')->all();
        $admin = User::where("email", 'LIKE', "admin@admin.com")->first();
        if (!empty($admin)) {
            $admin->syncPermissions($permissions);
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
