<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;


return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        DB::unprepared("
            CREATE PROCEDURE getVariantIds(IN min_price INT, IN max_price INT, OUT variant_ids LONGTEXT)
            BEGIN
                SET @sql_query = CONCAT('SELECT GROUP_CONCAT(DISTINCT variant_id) INTO @variant_ids FROM cop_pe_ms WHERE ex_showroom_price BETWEEN ', min_price, ' AND ', max_price);
                PREPARE stmt FROM @sql_query;
                EXECUTE stmt;
                DEALLOCATE PREPARE stmt;
                SET variant_ids = @variant_ids;
            END
        ");

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS getVariantIds');
    }
};
