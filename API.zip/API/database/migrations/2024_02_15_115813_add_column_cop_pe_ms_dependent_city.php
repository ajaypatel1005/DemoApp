<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_pe_ms', function (Blueprint $table) {
            $table->unsignedBigInteger('against_city_id')->nullable()->after('ut_id');
            
            $table->foreign('against_city_id')->references('city_id')->on('cop_city_ms')->onDelete('cascade')->onUpdate('cascade');
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_pe_ms', function (Blueprint $table) {
            $table->dropForeign(['against_city_id']);

            $table->dropColumn('against_city_id');
        });
    }
};
