<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_pc', function (Blueprint $table) {
            $table->id('pc_id');
            $table->string('pc_name');
            $table->string('pc_title')->nullable();
            $table->string('pc_sub_title')->nullable();
            $table->text('pc_description')->nullable();
            $table->string('pc_m_title')->nullable();
            $table->string('pc_m_sub_title')->nullable();
            $table->text('pc_m_description')->nullable();
            $table->string('pc_b_text')->nullable();
            $table->string('pc_b_link')->nullable();
            $table->string('pc_b_type')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
              $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_pc');
    }
};
