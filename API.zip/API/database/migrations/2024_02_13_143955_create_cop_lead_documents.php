<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_lead_documents', function (Blueprint $table) {
            $table->id('lead_doc_id');
            $table->unsignedBigInteger('lead_id');
            $table->unsignedBigInteger('dt_id')->nullable();
            $table->string('lead_documents')->nullable();
            $table->timestamps();
 
            $table->foreign('lead_id')->references('lead_id')->on('cop_leads')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('dt_id')->references('dt_id')->on('cop_document_type_ms')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_lead_documents');
    }
};
