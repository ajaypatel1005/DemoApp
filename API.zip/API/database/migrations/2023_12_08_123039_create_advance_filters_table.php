<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_asf', function (Blueprint $table) {
            $table->id('filter_id');
            $table->string('filter_name');
            $table->string('filter_category');
            $table->string('filter_value');

            $table->tinyInteger('status')->default(1);
            $table->string('created_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_asf');
    }
};
