<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;


return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_variants', function (Blueprint $table) {
            $table->string('slug')->after('status');
        });

        DB::table('cop_variants')->update([
            'slug' => DB::raw("LOWER(REGEXP_REPLACE(LOWER(REPLACE(variant_name, ' ', '-')), '[^a-zA-Z0-9-]+', ''))")
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_variants', function (Blueprint $table) {
            $table->dropColumn('slug');
        });
    }
};
