<?php

namespace Database\Seeders;

// Database/Seeders/PriceEntrySeeder.php

use Illuminate\Database\Seeder;
use App\Models\PriceEntry;

class PriceEntrySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        PriceEntry::factory()->count(2)->create();
    }

}
