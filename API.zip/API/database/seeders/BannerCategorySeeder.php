<?php

namespace Database\Seeders;

use App\Models\BannerCategory;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BannerCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $banner_categoryData = [
            'Head Banner',
            'Upcoming Banner',
            'Footer Banner Right',
            'Footer Banner Left',
            'EV Banner',
        ];

        foreach ($banner_categoryData as $banner_categoryName) {
            BannerCategory::create([
                'bc_name' => $banner_categoryName, // Replace with the actual cartype name.
//                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }
    }
}
