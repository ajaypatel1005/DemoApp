<?php

namespace Database\Seeders;

use App\Models\CRM\ActivityType;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LeadActivityTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        $ActivityTypes = [
            'Call',
            'Deadline',
            'Email',
            'Meeting',
            'Task',
        ];

        ActivityType::query()->delete();
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        ActivityType::truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        foreach ($ActivityTypes as $ActivityType) {
            ActivityType::create([
                'at_name' => $ActivityType,
                'status' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
