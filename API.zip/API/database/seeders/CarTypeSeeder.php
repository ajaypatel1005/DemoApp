<?php

namespace Database\Seeders;

use App\Models\CarType;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;


class CarTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */


    public function run(): void
    {

//        $cartypeData = [
//            'SUV',
//            'MUV',
//            'Sedan',
//            'Sports',
//            'Hatchback',
//
//        ];

         $cartypeData = [
             'SUV' => 'path/to/suv_image.jpg',
             'MUV' => 'path/to/muv_image.jpg',
             'Sedan' => 'path/to/sedan_image.jpg',
             'Sports' => 'path/to/sports_image.jpg',
             'Hatchback' => 'path/to/hatchback_image.jpg',
         ];

        foreach ($cartypeData as $cartypeName => $cartypeImagePath) {
            CarType::create([
                'ct_name' => $cartypeName, // Replace with the actual cartype name.
                 'ct_image' => $cartypeImagePath, // Replace with the actual path to the cartype image.
//                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }
    }
}
