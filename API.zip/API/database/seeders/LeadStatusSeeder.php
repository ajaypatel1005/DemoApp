<?php

namespace Database\Seeders;

use App\Models\CRM\LeadStatus;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LeadStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        $leadStatuses = [
            'Win',
            'Lost',
            'On Hold',
            'Reopen',
        ];

        LeadStatus::query()->delete();
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        LeadStatus::truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        foreach ($leadStatuses as $leadStatus) {
            LeadStatus::create([
                'ls_status_name' => $leadStatus,
                'status' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
