<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $modules = ['car_stage', 'car_type', 'brand', 'model', 'variant', 'specification_category', 'specification', 'feature', 'feature_option', 'feature_value', 'banner_category', 'banner', 'car_graphic_type', 'car_graphic', 'car_listing', 'car_listing_data', 'country', 'state', 'city', 'ev_station', 'fuel_station', 'service_station', 'all_tax', 'price_entry', 'page_content', 'manager_language', 'managers', 'standard_unit', 'user_visit', 'users', 'roles', 'log_view', 'car_warning_light'];
        $actions = ['create', 'edit', 'delete', 'view'];
        foreach ($modules as $module) {
            foreach ($actions as $action) {
                Permission::create(['name' => $action . '_' . $module]);
            }
        }
        Permission::create(['name' => 'imports']);
    }
}
