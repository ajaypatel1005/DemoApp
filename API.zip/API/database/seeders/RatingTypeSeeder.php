<?php

namespace Database\Seeders;

use App\Models\RatingType;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class RatingTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {


        $ratingData = [
            'NCAP',
            'BCAP',
        ];

        foreach ($ratingData as $ratingName) {
            RatingType::create([
                'rating_type_name' => $ratingName, // Replace with the actual cartype name.
                // 'car_type_image' => $cartypeImagePath, // Replace with the actual path to the cartype image.
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }

    }
}
