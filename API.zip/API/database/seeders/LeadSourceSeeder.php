<?php

namespace Database\Seeders;

use App\Models\CRM\LeadSource;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LeadSourceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        $leadSources = [
            'Buy Now',
            'Book a Test Drive',
            'Social Media',
            'Tele Caller',
            'Sales Team',
            'WhatsApp',
            'Email',
            'Excel Sheet',
        ];

        LeadSource::query()->delete();
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        LeadSource::truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        foreach ($leadSources as $leadSource) {
            LeadSource::create([
                'ls_name' => $leadSource,
                'status' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
