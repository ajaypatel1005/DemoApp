<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roles = ["Superadmin", "Admin", "Developer", "Data Entry", "Testing"];
        foreach ($roles as $role) {
            Role::updateOrcreate(['name' => $role]);
        }
        $admin = User::updateOrcreate([
            "email" => "admin@admin.com"
        ], [
            "name" => "admin",
            "password" => Hash::make('admin@123'),
            "created_at" => date('Y-m-d H:i:s'),
            "updated_at" => date('Y-m-d H:i:s')
        ]);
        $permissions = Permission::pluck('id', 'id')->all();
        $admin->assignRole('Superadmin');
        $admin->syncPermissions($permissions);
    }
}
