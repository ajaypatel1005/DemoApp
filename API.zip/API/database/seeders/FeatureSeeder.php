<?php

namespace Database\Seeders;

use App\Models\Feature;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FeatureSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */

    public function run(): void
    {
        $engineData = [
            'Type of Engine',
            'Displacement',
            'No. Of Cylinders',
            'Power',
            'Torque',
            'Turbo Charger',
            'Valves Per Cylinder',
            'Valve Configuration',
        ];

        foreach ($engineData as $engineName) {
            Feature::create([
                'features_name' => $engineName,
                'fuel_type' => 0,
                'features_image' => null,
                'spec_id' => 1,
                'fo_id' => 1,
                
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $fuelData = [
            'Type of Fuel',
            'Fuel Tank Capacity',
            'Fuel Supply System',
            'Mileage',
            'Engine Auto Start/Stop',
            'Emission Norms',
        ];

        foreach ($fuelData as $fuelName) {
            Feature::create([
                'features_name' => $fuelName,
                'fuel_type' => 0,
                'features_image' => null,
                'spec_id' => 2, // interior
                'fo_id' => 1, // Replace with the actual fo_id.
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $transmissionData = [
            'Type of Transmission',
            'Gear Box',
            'Drivetrain',
            'Clutch Type',
            'Drive modes',
        ];

        foreach ($transmissionData as $transmissionName) {
            Feature::create([
                'features_name' => $transmissionName,
                'fuel_type' => 0,
                'features_image' => null,
                'spec_id' => 3, // interior
                'fo_id' => 1, // Replace with the actual fo_id.


                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $performanceData = [
            'Top Speed',
            '0-100 km/h',
            'Terrain Response Mode',
            'Active Aerodynamics',
            'Exhaust System/ Type',
            'Rear Axle Steering',
        ];

        foreach ($performanceData as $performanceName) {
            Feature::create([
                'features_name' => $performanceName,
                'features_image' => null,
                'fuel_type' => 0,
                'spec_id' => 4, // interior
                'fo_id' => 1, // Replace with the actual fo_id.
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $suspensionData = [
            'Front Suspension',
            'Rear Suspension',
            'Shock Absorbers Type',
            'Type of Steering',
            'Steering Column',
            'Steering Gear Type',
            'Turning Radius',
        ];

        foreach ($suspensionData as $suspensionName) {
            Feature::create([
                'features_name' => $suspensionName,
                'features_image' => null,
                'fuel_type' => 2,
                'spec_id' => 5, // interior
                'fo_id' => 1, // Replace with the actual fo_id.

                
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $wheelsData = [
            'Front Brake',
            'Rear Brake',
            'Braking (80-0 kmph)',
            'Tyre Type',
            'Tyre Size',
            'Alloy Wheel Size',
        ];

        foreach ($wheelsData as $wheelsName) {
            Feature::create([
                'features_name' => $wheelsName,
                'features_image' => null,
                'spec_id' => 6, // interior
                'fo_id' => 1, // Replace with the actual fo_id.
                'fuel_type' => 2,

                
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $dimensionsData = [
            'Length',
            'Width',
            'Height',
            'Wheel Base',
            'Ground Clearance',
            'Front Track',
            'Rear Track',
        ];

        foreach ($dimensionsData as $dimensionsName) {
            Feature::create([
                'features_name' => $dimensionsName,
                'features_image' => null,
                'fuel_type' => 2,
                'spec_id' => 7, // interior
                'fo_id' => 1, // Replace with the actual fo_id.
                
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $weightsData = [
            'Kerb Weight',
            'Gross Weight',
            'Seating Capacity',
            'Boot Space',
            'No. of Doors',
        ];

        foreach ($weightsData as $weightsName) {
            Feature::create([
                'features_name' => $weightsName,
                'features_image' => null,
                'spec_id' => 8, // interior
                'fo_id' => 1, // Replace with the actual fo_id.
                'fuel_type' => 2,

                

                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $warrantyData = [
            ' Warranty (Years)',
            ' Warranty (Kilometers)',
        ];

        foreach ($warrantyData as $warrantyName) {
            Feature::create([
                'features_name' => $warrantyName,
                'features_image' => null,
                'spec_id' => 9, // interior
                'fo_id' => 1, // Replace with the actual fo_id.
                'fuel_type' => 2,

                

                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $interiorData = [
            'Power Steering',
            'Multifunction Steering Wheel',
            'Leather Steering Wheel',
            'Adjustable Steering',
            'Gearshift Paddles',
            'Cruise Control',
            'Engine Start/Stop Button',
            'Gear Shift Indicator',
            'KeyLess Entry',
            'Key Trunk Opening',
            'Key Fuel Lid Opening',
            'Key Engine Start/Stop',
            'Active Noise Cancellation',
            'Touch Screen',
            'Touch Screen Size',
            'Instrument Cluster',
            'Navigation System',
            'Heads Up Display',
            'Android Auto',
            'Apple Car Play',
            'Mirror Link',
            'Speakers Front',
            'Speakers Rear',
            'No. of speakers',
            'USB And Auxiliary Input',
            'Bluetooth Connectivity',
            'Wifi Connectivity',
            'Ambient Lighting',
            'Air Conditioner',
            'Heater',
            'Automatic Climate Control',
            'Air Quality Control',
            'Rear AC Vents',
            'Climate Control',
            'Ventilated Seats Front',
            'Ventilated Seats Rear',
            'Heated Seats Front',
            'Heated Seats Rear',
            'Leather Seats',
            'Fabric Seats',
            'Height Adjustable Seats',
            'Electric Adjustable Seats',
            'Lumbar Support',
            'Under thigh support',
            'Massage Seats',
            'Memory Function Seats',
            'Foldable Rear Seat',
            'Adjustable Headrest',
            'Rear Seat Headrest',
            'Rear Seat Centre Armrest',
            'Power folding 3rd Row Seat',
            'Seat split ratio',
            'Power Windows',
            'One Touch Power Window',
            'Anti, Pinch Window',
            'Wireless Phone Charger',
            'Dashboard design',
            'Glove Compartment',
            'Glove Box Cooling',
            'Central Armrest',
            'Cup Holders Front',
            'Cup Holders Rear',
            'Rear Curtain',
            'Powered Boot',
            'Trunk Light',
            'Handsfree Tailgate',
            'USB Charger',
            'Accessory Power Outlet',
            'Vanity Mirror',
            'Bottle Holder',
            'Rear Reading Lamp',
            'Parking Sensors',
            'Park Assist',
            '360 Camera',
            'Tachometer',
            'Electronic Multi Tripmeter',
            'Digital Clock',
            'Outside Temperature Display',
            'Digital Odometer',
            'Voice Commands',
            'Automatic Headlamps',
            'Follow Me Home Headlamps',
            'Compass',
            'Cabin Lamps',
            'Front Armrest',
            'Cup Holders',
            'Rear Armrest with Cup Holder',
            'Rear Refrigerator',
        ];

        foreach ($interiorData as $interiorName) {
            Feature::create([
                'features_name' => $interiorName,
                'features_image' => null,
                'spec_id' => 10, // interior
                'fo_id' => 2, // Replace with the actual fo_id.
                'fuel_type' => 2,

                

                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $exteriorData = [
            'Car Type',
            'Head Lamps',
            'Fog Lamps',
            'Fog Lights Front',
            'Fog Lights Rear',
            'LED Headlights',
            'LED Tail Lights',
            'LED Fog Lamps',
            'LED DRLs',
            'Cornering Head Lamps',
            'Cornering Fog Lamps',
            'Adjustable Headlights',
            'Sunroof',
            'Moonroof',
            'Integrated Antenna',
            'Rear Spoiler',
            'Convertible Top',
            'Roof Carrier',
            'Roof Rail',
            'Powered Exterior Rear View Mirror',
            'Electric Folding Rear View Mirror',
            'Rear View Mirror Turn Indicators',
            'Chrome Grille',
            'Chrome Garnish',
            'Wheel Covers',
            'Alloy Wheels',
            'Power Antenna',
            'Tinted Glass',
            'Side Stepper',
            'Headlamp Washers',
            'Rain Sensing Wipers',
            'Rear Window Wiper',
            'Rear Window Washer',
            'Rear Window Defogger',
            'Puddle Lamps',
            'Frameless Doors',
            'Soft Close Doors',
            'Integrated Roof Rails',
            'Shark Fin Antenna',
        ];

        foreach ($exteriorData as $exteriorName) {
            Feature::create([
                'features_name' => $exteriorName,
                'features_image' => null,
                'spec_id' => 11, // Exterior
                'fo_id' => 2, // Replace with the actual fo_id.
                'fuel_type' => 2,

                

                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $safetyData = [
            'No Of Airbags',
            'Driver Airbag',
            'Knee Airbag',
            'Passenger Airbag',
            'Side Airbag Front',
            'Side Airbag Rear',
            'Anti Lock Braking System',
            'Electronic Braking Distribution',
            'Electronic Stability Control',
            'Vehicle Stability Control System',
            'Engine Check Warning light',
            'Tyre Pressure Monitor',
            'Engine Immobilizer',
            'Crash Sensor',
            'Geo Fence Alert',
            'Hill Descent Control',
            'Hill Assist',
            'Brake Assist',
            'Central Locking',
            'Power Door Locks',
            'Child Safety Locks',
            'Isofix Child Seat',
            'Anti Theft Alarm',
            'Side Impact Beams',
            'Front Impact Beams',
            'Traction Control',
            'Clutch Lock',
            'Rear Camera',
            'Anti Theft Device',
            'High-Speed Alert',
            'Speed Sensing Auto Door Lock',
            'Pretensioners And Force Limiter Seat Belts',
            'SOS Assistance',
            'Blind Spot Monitoring',
            'Lane Watch Camera',
            'Lane Change Indicator',
            'Impact Sensing Auto Door Unlock',
            'Seat Belt Warning',
            'Regenerative Braking',
            'Cornering Brake Control',
            'Speed Sensing Door Locks',
            'Limited Slip Differential',
        ];

        foreach ($safetyData as $safetyName) {
            Feature::create([
                'features_name' => $safetyName,
                'features_image' => null,
                'spec_id' => 12, // Exterior
                'fo_id' => 2, // Replace with the actual fo_id.
                'fuel_type' => 2,
                
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
