<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\FeatureValue;
use App\Models\Variant;

class FeatureValueSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */

    public function run()
    {
        $variants = Variant::all();

        $variantCount = $variants->count();

        if ($variantCount === 0) {
            $this->command->info('No variants found in the database.');
            return;
        }

        for ($i = 0; $i < $variantCount; $i++) {
            FeatureValue::factory()->create([
                'variant_id' => $variants[$i]->variant_id,
            ]);
        }
    }
}
