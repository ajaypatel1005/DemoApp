<?php

namespace Database\Seeders;

use App\Models\StandardUnit;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class StandardUnitSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $standardunitData = [
            'CC',
            'BHP',
            'WD',
            'KMPL',
            'RMP',
            'MM',
        ];

        foreach ($standardunitData as $standardunitName) {
            StandardUnit::create([
                'su_name' => $standardunitName, // Replace with the actual cartype name.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }
    }
}
