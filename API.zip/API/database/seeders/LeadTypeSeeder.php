<?php

namespace Database\Seeders;

use App\Models\CRM\LeadType;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LeadTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        $leadTypes = [
            'New',
            'Open',
            'Cold',
            'Warm',
            'Hot',
        ];

        LeadType::query()->delete();
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        LeadType::truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        foreach ($leadTypes as $leadType) {
            LeadType::create([
                'lt_name' => $leadType,
                'status' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
