<?php

namespace Database\Seeders;

use App\Models\Specification;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SpecificationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $specificationData = [
            'Engine',
            'Fuel',
            'Transmission',
            'Performance',
            'Suspension & Steering',
            'Wheels',
            'Dimensions',
            'Weights & Capacity',
            'Warranty',
        ];

        foreach ($specificationData as $specificationName) {
            Specification::create([
                'spec_name' => $specificationName, // Replace with the actual cartype name.
                'sc_id' => 1, // specification cat...
                'spec_image' => null, // Replace with the actual path to the cartype image.
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }

        $featuresData = [
            'Interior',
            'Exterior',
        ];

        foreach ($featuresData as $featuresName) {
            Specification::create([
                'spec_name' => $featuresName, // Replace with the actual cartype name.
                'sc_id' => 2, // Features cat...
                'spec_image' => null, // Replace with the actual path to the cartype image.
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }

        $safetyData = [
            'Safety',
        ];

        foreach ($safetyData as $safetyName) {
            Specification::create([
                'spec_name' => $safetyName, // Replace with the actual cartype name.
                'sc_id' => 3, // safety cat...
                'spec_image' => null, // Replace with the actual path to the cartype image.
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }
    }


}
