<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\PostCategoryType;


class PostCategoryTypesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {

        $postCategoryTypes = [
            [
                'post_cat_name' => 'News Feed',
                'post_cat_type' => 'Post',
                'slug' => 'news-feed',
                'status' => 1,
                'style' => 0
            ],
            [
                'post_cat_name' => 'Blogs',
                'post_cat_type' => 'Blog',
                'slug' => 'blogs',
                'status' => 1,
                'style' => 1

            ],
        ];

        foreach ($postCategoryTypes as $postCategoryTypeData) {
            $existingCategoryType = PostCategoryType::where('post_cat_name', $postCategoryTypeData['post_cat_name'])->first();
            if (!$existingCategoryType) {
                $postCategoryTypeData['created_at'] = now();
                $postCategoryTypeData['updated_at'] = now();

                PostCategoryType::create($postCategoryTypeData);
            }
        }
    }
}
