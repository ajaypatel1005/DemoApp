<?php

namespace Database\Seeders;

use App\Models\AllTax;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AllTaxSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $taxData = [
            'GST' => '28',
            'RTO' => '3',
            'SMC' => '6',
            'TCS' => '1',
        ];

        foreach ($taxData as $taxName => $taxValue) {
            AllTax::create([
                'tax_name' => $taxName, // Replace with the actual cartype name.
                // 'tax_value' => $taxValue, // Replace with the actual cartype name.
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }
    }
}
