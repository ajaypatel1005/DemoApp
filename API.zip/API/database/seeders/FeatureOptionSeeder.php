<?php

namespace Database\Seeders;

use App\Models\FeatureOption;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class FeatureOptionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $feature_optionData = [
            'Text Value',
            'True/False',

        ];

        foreach ($feature_optionData as $feature_optionName) {
            FeatureOption::create([
                'fo_value' => $feature_optionName, // Replace with the actual cartype name.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }
    }
}
