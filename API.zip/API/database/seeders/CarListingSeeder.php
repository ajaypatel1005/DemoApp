<?php

namespace Database\Seeders;

use App\Models\CarCategory;
use App\Models\CarListing;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CarListingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $carcategoryData = [
            'Popular Cars',
            'EV Cars',
        ];

        foreach ($carcategoryData as $carcategoryName) {
            CarListing::create([
                'cl_name' => $carcategoryName, // Replace with the actual cartype name.
//                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }
    }
}
