<?php

namespace Database\Seeders;

use App\Models\LogView;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class LogViewSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $logviewData = [
            'Banner'=>'Banners',
            'BannerCategory'=>'Banner Category',
            'CarListing'=>'Car Listing',
            'CarListingData'=>'Car Listing Data',
            'CarGraphic'=>'Graphic',
            'CarStage'=>'Car Stage',
            'CarType'=>'Car Type',
            'Brand'=>'Brand',
            'Model'=>'Model',
            'Variant'=>'Variant',
            'Color'=>'Colors',
            'Country'=>'Country',
            'City'=>'City',
            'WarningLight'=>'Car Warning Light',
            'State'=>'State',
            'EvStation'=>'Ev Stations',
            'ServiceStation'=>'Service Stations',
            'FuelStation'=>'Fuel Stations',
            'Feature'=>'Feature',
            'FeatureOption'=>'Feature Option',
            'FeatureValue'=>'Feature Value',
            'CarGraphicType'=>'Graphic Type',
            'Manager'=>'Manager',
            'ManagerLanguage'=>'Manager Language',

            'PriceEntry'=>'Price entry',
            'AllTax'=>'All Taxes',

            'SpecificationCategory'=>'Specification Category',
            'ModelSpecDisplay'=>'Specification Display',
            'Specification'=>'Specification',

            'StandardUnit'=>'Standard Unit',
            'unionTerritory'=>'Union Territory',
            

            'PageContent'=>'Page Contents',
            'Roles'=>'Roles',
            'Rating'=>'Rating',
            'RatingType'=>'Rating Type',
            'UserVisit'=>'User Visit',
            'User'=>'Users',
        ];

        LogView::truncate();

        foreach ($logviewData as $logviewModel => $data) {
            LogView::create([
                'model_name' => $logviewModel,
                'log_name' => $data,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
