<?php

namespace Database\Seeders;

use App\Models\CarStage;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CarStageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $carstageData = [
            'Upcoming',
            'Launched',
        ];

        foreach ($carstageData as $carstageName) {
            CarStage::create([
                'cs_name' => $carstageName, // Replace with the actual cartype name.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }
    }
}
