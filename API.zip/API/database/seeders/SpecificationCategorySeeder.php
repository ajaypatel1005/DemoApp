<?php

namespace Database\Seeders;

use App\Models\SpecificationCategory;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SpecificationCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $spec_catData = [
            'Specification',
            'Features',
            'Safety',
        ];

        foreach ($spec_catData as $spec_catName) {
            SpecificationCategory::create([
                'sc_name' => $spec_catName, // Replace with the actual spec_cat name.
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }
    }
}
