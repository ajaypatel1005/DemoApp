<?php

namespace Database\Seeders;
use App\Models\CRM\CallOutcome;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LeadCallOutcomeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        $leadCallOutcome = [
            'Busy',
            'Left Voice Message',
            'No Answer',
            'Unavailable',
            'Wrong Number',
        ];

        CallOutcome::query()->delete();
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        CallOutcome::truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        foreach ($leadCallOutcome as $callOutcome) {
            CallOutcome::create([
                'lco_name' => $callOutcome,
                'status' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
