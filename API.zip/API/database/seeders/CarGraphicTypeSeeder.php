<?php

namespace Database\Seeders;

use App\Models\CarGraphicType;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CarGraphicTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $graphic_typeData = [
            'Images',
            'Images 360',
            'Video',
        ];

        foreach ($graphic_typeData as $graphic_typeName) {
            CarGraphicType::create([
                'gt_name' => $graphic_typeName, // Replace with the actual cartype name.
                'status' => 1, // Replace with the appropriate value for status.
                'created_at' => now(), // Add the current timestamp for created_at.
                'updated_at' => now(), // Add the current timestamp for updated_at.
            ]);
        }
    }
}
