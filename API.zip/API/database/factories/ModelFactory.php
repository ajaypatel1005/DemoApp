<?php
namespace Database\Factories;

use App\Models\Brand;
use Illuminate\Database\Eloquent\Factories\Factory;
use Faker\Generator as Faker;
use App\Models\Model;

class ModelFactory extends Factory
{
    protected $model = Model::class;

    public function definition()
    {
        $minPrice = $this->faker->numberBetween(500000, 5000000);
        $maxPrice = $this->faker->numberBetween($minPrice, 5000000);
        return [
            'cs_id' => $this->faker->numberBetween(1, 2),
            'launch_date' => $this->faker->date,
            'ct_id' => $this->faker->numberBetween(1, 5),
            'brand_id' => Brand::inRandomOrder()->first()->brand_id,
            'model_name' => $this->faker->word,
            'model_image' => $this->faker->imageUrl(),
            'model_description' => $this->faker->paragraph,
            'min_price' => $minPrice,
            'max_price' => $maxPrice,
            'model_year' => $this->faker->year,
            'model_type' => $this->faker->randomElement([0, 1]),
//            'model_engine' => $this->faker->word,
//            'model_bhp' => $this->faker->randomNumber(2),
//            'model_transmission' => $this->faker->randomElement(['Manual', 'Automatic']),
//            'model_mileage' => $this->faker->randomFloat(2, 10, 20),
//            'model_fuel' => $this->faker->randomElement(['Petrol', 'Diesel']),
            // 'model_ncap_rating' => $this->faker->randomElement(['5', '4', '3']),
            'status' => 1,
        ];
    }
}
