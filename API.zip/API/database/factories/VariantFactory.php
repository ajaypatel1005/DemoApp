<?php

namespace Database\Factories;

// Database/Factories/VariantFactory.php

use App\Models\Brand;
use App\Models\Model;
use Illuminate\Database\Eloquent\Factories\Factory;
use Faker\Generator as Faker;
use App\Models\Variant;

class VariantFactory extends Factory
{
    protected $model = Variant::class;

    public function definition()
    {
        return [
            'brand_id' => Brand::inRandomOrder()->first()->brand_id,
            'model_id' => Model::inRandomOrder()->first()->model_id, // Assuming you have 800 models
            'variant_name' => $this->faker->word,
            'variant_image' => $this->faker->imageUrl(),
            'seating_capacity' => $this->faker->numberBetween(2, 9),
            'status' => 1,
        ];
    }
}

