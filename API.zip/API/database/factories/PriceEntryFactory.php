<?php

namespace Database\Factories;

use App\Models\Brand;
use App\Models\City;
use App\Models\Country;
use App\Models\Model;
use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\PriceEntry;
use App\Models\State;
use App\Models\Variant;

class PriceEntryFactory extends Factory
{
    protected $model = PriceEntry::class;

    public function definition()
    {
        return [
            'brand_id' => Brand::inRandomOrder()->first()->brand_id,
            'model_id' => Model::inRandomOrder()->first()->model_id,
            'variant_id' => Variant::inRandomOrder()->first()->variant_id,
            'country_id' => Country::inRandomOrder()->first()->country_id,
            'state_id' => State::inRandomOrder()->first()->state_id,
            'city_id' => City::inRandomOrder()->first()->city_id,
            'tax_id' => json_encode($this->faker->randomElements([1, 2, 3, 4], $count = 2)), // Assuming you want 2 random elements

            'ex_showroom_price' => $this->faker->numberBetween(500000, 1500000),
            'tax_cost' => json_encode([
                'GST' => $this->faker->numberBetween(50000, 200000),
                'RTO' => $this->faker->numberBetween(5000, 20000),
                'SMC' => $this->faker->numberBetween(10000, 40000),
                'TCS' => $this->faker->numberBetween(1000, 5000),
            ]),
            'total_price' => $this->faker->numberBetween(505000, 15200000),
            'status' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}

