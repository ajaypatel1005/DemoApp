<?php

namespace Database\Factories;


/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Brand>
 */

// BrandFactory.php

use App\Models\Brand;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factories\Factory;

class BrandFactory extends Factory
{
    protected $model = Brand::class;

    public function definition()
    {
        return [
            'brand_name' => $this->faker->word,
            'brand_logo' => $this->faker->imageUrl(), // You can modify this based on your actual requirements for a logo
            'brand_banner' => $this->faker->imageUrl(), // You can modify this based on your actual requirements for a banner
            'brand_description' => $this->faker->sentence,
            'status' => $this->faker->randomElement([1]),
            // Add other fields as needed
        ];
    }
}
