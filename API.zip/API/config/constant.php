<?php

return [
    'EV_banner' => 'EV Banner',
    'fronted_url' => 'ewrerere', // banner api
    'popular_cars' => 'Popular Cars', // trending api
    'API Token' => '6IlFnSlBLZy9BZlhENHNXOXVwZFBtV3c9PSIsInZhbHVlIjoidGxLYmR3YTdMSjNmR2ZiajdRWFA3Zz09IiwibWFjIjoiNDA3NTUxNGQ1YzU2ODdmNDRjZTI4ZGU4MTgwMDljZDM4MzI1OTUwMGExZTRhYWEzNzc3M2Y5MmFiZmRhYWY5NS',
    // token verify in Static
    'UPCOMING' => 'Upcoming',

    //static keywords
    'DISPLACEMENT' => 'Displacement',
    'TYPE_OF_FUEL' => 'Type of Fuel',
    'MILEAGE' => 'Mileage',
    'TYPE_OF_TRANSMISSION' => 'Type of Transmission',
    'POWER'=>'Power',
    'BATTERY_CAPACITY' => 'Battery Capacity',
    'RANGE' => 'Range',
    'POWER_EV'=>'Power (EV)',
    'CHARGING_TIME' => 'Charging Time',

    //Advance search
    'ENGINE_LIST' => ['0 to 1200', '1200 to 1500', '1500 to 2000', '2000 to 3000', '3000 to 5000', '5000 to 8000'],
    'BUDGET_LIST' => [
        '200000 to 1000000',
        '1000000 to 2500000',
        '2500000 to 5000000',
        '5000000 to 10000000',
        '10000000 to 200000000'
    ],
    'BUDGET_LIST_WORDS' => [
        '2 to 10 lakh',
        '10 to 25 lakh',
        '25 to 50 lakh',
        '50L to 1 Cr',
        '1Cr +'
    ],
    'BUDGET_LIST_WORDS_ARR' => [
        '200000 to 1000000' => '2 to 10 lakh',
        '1000000 to 2500000' => '10 to 25 lakh',
        '2500000 to 5000000' => '25 to 50 lakh',
        '5000000 to 10000000' => '50L to 1 Cr',
        '10000000 to 200000000' => '1Cr +'
    ],
    'TRANSMISSION_TYPE' => 'Type of Transmission',
    'DRIVETRAIN' => 'Drivetrain',
    'MILEAGE' => 'Mileage',
    'SAFETY' => 'Safety',
    'feature' => 'yes',
    'INTERIOR' => 'Interior',
    'EXTERIOR' => 'Exterior',
    'INTERIOR_ARR' => [
        'Multifunction Steering Wheel', 'Cruise Control', 'Engine Start/Stop Button', 'KeyLess Entry', 'Automatic Climate Control', 'Ventilated Seats Front', 'Ventilated Seats Rear', 'Electric Adjustable Seats', 'Wireless Phone Charger', '360 Camera', 'Android Auto', 'Apple Car Play', 'Bluetooth Connectivity', 'Ambient Lighting', 'Automatic Headlamps', 'Instrument Cluster', 'Heads Up Display'
    ],
    'EXTERIOR_ARR' => ['LED DRLs', 'Sunroof', 'Moonroof', 'Convertible Top', 'Chrome Grille', 'Chrome Garnish', 'Alloy Wheels', 'Rain Sensing Wipers'],
    'ENGINE_LIST' => ['0 to 1200', '1200 to 1500', '1500 to 2000', '2000 to 3000', '3000 to 5000', '5000 to 8000'],
    'NONEV_CAR_TYPE' => 0,
    'EV_CAR_TYPE' => 1,
    'MIN_PRICE' => 200000,
    'MAX_PRICE' => 200000000,
    'CAR_STAGE_LAUNCHED' => 'Launched',
    'STATUS' => 1,

    'CITY_LIST' => ['Ahmedabad', 'Surat',  'Mumbai', 'Bangalore', 'Chennai', 'Hyderabad', 'Delhi'], //'Delhi','Mumbai','Kolkata','Bangalore','Chennai','Hyderabad','Other City'
    'CITY_LIST_IMG' => [
        'Delhi' => "Delhi.png",
        'Mumbai' => "Mumbai.png",
        'Kolkata' => "Kolkata.png",
        'Bangalore' => "Bangalore.png",
        'Chennai' => "Chennai.png",
        'Hyderabad' => "Hyderabad.png",
        'Ahmedabad' => "Ahemdabad.png",
        'Bhavnagar' => "Bhavnagar.png",
        'Rajkot' => "Rajkot.png",
        'Surat' => "Surat.png",
        'Vadodara' => "Vadodara.png",
        'Other City' => "other Cities.png"
    ],

    // for book-test-drive api as per frontend
    'EXCLUDE_BRAND' => [
        'Ferrari',
        'Lamborghini',
        'Bentley',
        'Rolls Royce',
        'Aston Martin',
        'Lexus',
        'Lotus',
        'McLaren',
        'Maserati',
        'Bugatti'
    ],
    'EXCLUDE_MODEL' => [
        'Vellfire',
        'Land Cruiser 300'
    ],
    // Unveiled Models (For Book-test-drive)
    'UNVEILED_MODEL' => [
        'Syros'
    ],


    'API_URL' => [
        'send_otp' => 'https://control.msg91.com/api/v5/otp',
        'verify_otp' => 'https://control.msg91.com/api/v5/otp/verify',
        'resend_otp' => 'https://control.msg91.com/api/v5/otp/retry',
        'toll_calculate' => 'https://apis.tollguru.com/v2/origin-destination-waypoints',
        ],

    'FUEL_PRICE' => [
        'PETROL' => 'petrol',
        'DEISEL' => 'diesel',
        'CNG' => 'cng',
        'LPG' => 'lpg'
    ],

    'SERIAL_NUMBER' => [
        'BUY_NOW_TYPE' => 'buy_now',
        'BUY_NOW_PREFIX' => 'BN',
        'TEST_DRIVE_TYPE' => 'test_drive',
        'TEST_DRIVE_PREFIX' => 'BT',
    ],

    'TEST_DRIVE_STATUS' => [
        'INPROGRESS'=>1,
        'CANCELLED'=>0,
        'COMPLETED'=>2,
    ],

    'NEWS_BLOGS_DEFAULT' => [
        'CITY_ID' => 160,
        'CITY_NAME' => 'Surat'
    ],

];
