<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadType extends Model
{
    use HasFactory;

    protected $table = 'cop_lead_type_ms';
    protected $primaryKey = 'lt_id';
    protected $guarded = [];

    public function lead()
    {
        return $this->hasMany(Lead::class);
    }
}
