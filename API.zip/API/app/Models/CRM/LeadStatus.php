<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadStatus extends Model
{
    use HasFactory;
    protected $table = 'cop_lead_status_ms';
    protected $primaryKey = 'ls_status_id';
    protected $guarded = [];

    public function lead()
    {
        return $this->hasMany(Lead::class);
    }
}
