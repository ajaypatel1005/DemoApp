<?php

namespace App\Models\CRM;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadActivity extends Model
{
    use HasFactory;


    protected $table = 'cop_lead_activity';
    protected $primaryKey = 'la_id';

    public $guarded = [];

    
    public function activity_type()
    {
        return $this->belongsTo(ActivityType::class,'at_id');
    }
    public function leads_details()
    {
        return $this->belongsTo(Lead::class,'lead_id');
    }
    public function created_lead()
    {
        return $this->belongsTo(User::class,'created_by');
    }
}
