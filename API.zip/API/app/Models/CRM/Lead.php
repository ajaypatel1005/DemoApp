<?php

namespace App\Models\CRM;

use App\Models\Brand;
use App\Models\Model as ModelsModel;
use App\Models\Variant;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Lead extends Model
{
    use HasFactory;

    protected $table = 'cop_leads';
    protected $primaryKey = 'lead_id';
    protected $guarded = [];

    public function activity()
    {
        return $this->hasMany(LeadActivity::class,'lead_id');
    }
    public function lead_pipeline()
    {
        return $this->belongsTo(LeadPipeline::class,'lp_id');
    }
    public function lead_status()
    {
        return $this->belongsTo(LeadStatus::class,'ls_status_id');
    }
    public function lead_source()
    {
        return $this->belongsTo(LeadSource::class,'ls_id');
    }
    public function lead_type()
    {
        return $this->belongsTo(LeadType::class,'lt_id');
    }

    public function lead_pipeline_stage()
    {
        return $this->belongsTo(LeadPipelineStage::class,'lps_id');
    }

    public function documents()
    {
        return $this->belongsTo(LeadDocument::class,'lead_doc_id');
    }

    public function car_brand()
    {
        return $this->belongsTo(Brand::class,'brand_id');
    }
    public function car_models()
    {
        return $this->belongsTo(ModelsModel::class,'model_id');
    }
    public function car_variant()
    {
        return $this->belongsTo(Variant::class,'variant_id');
    }
}



