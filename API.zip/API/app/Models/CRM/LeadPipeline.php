<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadPipeline extends Model
{
    use HasFactory;
    protected $table = 'cop_lead_pipeline_ms';
    protected $primaryKey = 'lp_id';
    protected $guarded = [];

    public function pipeline_stage()
    {
        return $this->hasOne(LeadPipelineStage::class, 'lp_id');
    }
    
    public function lead()
    {
        return $this->hasMany(Lead::class);
    }
}
