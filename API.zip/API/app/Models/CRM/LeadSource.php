<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadSource extends Model
{
    use HasFactory;
    protected $table = 'cop_lead_source_ms';
    protected $primaryKey = 'ls_id';
    protected $guarded = [];

    public function lead()
    {
        return $this->hasMany(Lead::class);
    }
}
