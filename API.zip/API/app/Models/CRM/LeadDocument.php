<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadDocument extends Model
{
    use HasFactory;

    use HasFactory;
    protected $table = 'cop_lead_documents';
    protected $primaryKey = 'lead_doc_id';
    protected $guarded = [];
 
    public function lead()
    {
        return $this->hasMany(Lead::class);
    }
 
    public function document_type()
    {
        return $this->belongsTo(DocumentType::class, 'dt_id');
    }
}
