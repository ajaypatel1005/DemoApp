<?php

namespace App\Models\CRM;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadNotes extends Model
{
    use HasFactory;

    protected $table = 'cop_lead_notes';
    protected $primaryKey = 'ln_id';

    public $guarded = [];

    public function created_user()
    {
        return $this->belongsTo(User::class,'created_by');
    }

}
