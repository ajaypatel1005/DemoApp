<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentType extends Model
{
    use HasFactory;

    protected $table = 'cop_document_type_ms';
    protected $primaryKey = 'dt_id';

    protected $fillable = ['dt_name', 'updated_at', 'created_at'];
    protected $guarded = [];
}
