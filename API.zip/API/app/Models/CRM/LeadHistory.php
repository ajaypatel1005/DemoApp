<?php

namespace App\Models\CRM;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadHistory extends Model
{
    use HasFactory;
    protected $table = 'cop_lead_history';
    protected $primaryKey = 'lh_id';
    public function lead_pipeline()
    {
        return $this->belongsTo(LeadPipeline::class, 'lp_id');
    }
    public function lead_pipeline_stage()
    {
        return $this->belongsTo(LeadPipelineStage::class, 'lps_id');
    }
    public function lead_status()
    {
        return $this->belongsTo(LeadStatus::class, 'ls_status_id');
    }

    public function lead_notes()
    {
        return $this->belongsTo(LeadNotes::class, 'ln_id');
    }

    public function lead_activity()
    {
        return $this->belongsTo(LeadActivity::class, 'la_id');
    }

    public function lead_call_log()
    {
        return $this->belongsTo(CallLog::class, 'lcl_id');
    }


    public function created_user()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
