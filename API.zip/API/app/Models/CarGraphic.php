<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\ClientInfoTraits;


class CarGraphic extends Model
{
    use HasFactory;
    use ClientInfoTraits;

    protected $table ='cop_graphics';
    protected $primaryKey = 'graphic_id';

    protected $guarded = [];

    protected static $logAttributes = ['gt_name','status'];

    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];
        return "User {$eventNameMap[$eventName]} Car Graphic record";
    }
   
    // Log additional custom properties
    public function logActivity(string $eventName)
    {
        $oldValues=null;
        $newValues=null;
        if($eventName=="updated")
        {
            $oldValues = $this->getOriginal();
            $newValues = $this->getAttributes();
        }
        if($eventName=="deleted")
        {
            $oldValues = $this->getOriginal();
        }
        if($eventName=="created")
        {
            $newValues = $this->getAttributes();
        }

        activity('car_graphic')
            ->event($eventName)
            ->performedOn($this)
            ->withProperties([
                'old_values' => $oldValues,
                'new_values' => $newValues,
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log($this->getDescriptionForEvent($eventName));
    }

    // Log custom attributes
    protected static function boot()
    {
        parent::boot();
        static::created(function ($model) {
            $model->logActivity('created');
        });
        static::updated(function ($model) {
            $model->logActivity('updated');
        });
        static::deleted(function ($model) {
            $model->logActivity('deleted');
        });
    }
    public function scopeActive($query)
    {
        return $query->where('status', '1');
    }

    public function graphic_type()
    {
        return $this->belongsTo(CarGraphicType::class, 'gt_id');
    }

    public function brands()
    {
        return $this->belongsTo(Brand::class, 'brand_id');
    }

    public function models()
    {
        return $this->belongsTo(Model::class, 'model_id');
    }
}