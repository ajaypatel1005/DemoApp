<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FuelPrice extends Model
{
    use HasFactory;
    protected $table = 'cop_fuel_price_data';
    protected $primaryKey='id';
    protected $guarded =[];

    public function scopeActive($query)
    {
        return $query->where('status', '1');
    }

    public function fuelPriceCityData()
    {
        return $this->belongsTo(FuelPriceCity::class, 'fp_city_id');
    }
}
