<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\ClientInfoTraits;
class CarGraphicType extends Model
{
    use HasFactory;
    use ClientInfoTraits;

    protected $primaryKey = 'gt_id';
    protected $table = 'cop_gt_ms';

    protected $guarded = [];
    protected static $logAttributes = ['gt_name','status'];

    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];
        return "User {$eventNameMap[$eventName]} Car Graphic Type record";
    }

    // Log additional custom properties
    public function logActivity(string $eventName)
    {
        $oldValues=null;
        $newValues=null;
        if($eventName=="updated")
        {
            $oldValues = $this->getOriginal();
            $newValues = $this->getAttributes();
        }
        if($eventName=="deleted")
        {
            $oldValues = $this->getOriginal();
        }
        if($eventName=="created")
        {
            $newValues = $this->getAttributes();
        }

        activity('car_graphic_type')
            ->event($eventName)
            ->performedOn($this)
            ->withProperties([
                'old_values' => $oldValues,
                'new_values' => $newValues,
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log($this->getDescriptionForEvent($eventName));
    }

    // Log custom attributes
    protected static function boot()
    {
        parent::boot();
        static::created(function ($model) {
            $model->logActivity('created');
        });
        static::updated(function ($model) {
            $model->logActivity('updated');
        });
        static::deleted(function ($model) {
            $model->logActivity('deleted');
        });
    }

    public function car_graphic()
    {
        return $this->hasMany(CarGraphic::class, 'gt_id');
    }
    public function scopeActive($query)
    {
        return $query->where('status', '1');
    }
}
