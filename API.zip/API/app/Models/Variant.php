<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\ClientInfoTraits;

class Variant extends Model
{

    use HasFactory;
    use ClientInfoTraits;
    protected $table = 'cop_variants';
    // protected $primaryKey = 'variant_id';
    protected $guarded = [];
    protected static $logAttributes = ['brand_id', 'model_id', 'variant_name', 'variant_image', 'seating_capacity', 'status'];

    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];
        return "User {$eventNameMap[$eventName]} Variant record";
    }

    // Log additional custom properties
    public function logActivity(string $eventName)
    {
        $oldValues = null;
        $newValues = null;
        if ($eventName == "updated") {
            $oldValues = $this->getOriginal();
            $newValues = $this->getAttributes();
        }
        if ($eventName == "deleted") {
            $oldValues = $this->getOriginal();
        }
        if ($eventName == "created") {
            $newValues = $this->getAttributes();
        }

        activity('variant')
            ->event($eventName)
            ->performedOn($this)
            ->withProperties([
                'old_values' => $oldValues,
                'new_values' => $newValues,
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log($this->getDescriptionForEvent($eventName));
    }

    // Log custom attributes
    protected static function boot()
    {
        parent::boot();
        static::created(function ($model) {
            $model->logActivity('created');
        });
        static::updated(function ($model) {
            $model->logActivity('updated');
        });
        static::deleted(function ($model) {
            $model->logActivity('deleted');
        });
    }
    

    public function price_entry()
    {
        return $this->hasMany(PriceEntry::class, 'variant_id');
    }
    public function scopeActive($query)
    {
        return $query->where('status', '1');
    }
    public function banner()
    {
        return $this->hasMany(Banner::class, 'variant_id', 'variant_id');
    }
    public function featureValue()
    {
        return $this->hasMany(FeatureValue::class, 'variant_id','variant_id');
    }
}
