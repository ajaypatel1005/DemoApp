<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FuelPriceState extends Model
{
    use HasFactory;

    protected $table = "cop_fuel_price_state_ms";
    protected $primaryKey = "id";
    protected $guarded = [];
}
