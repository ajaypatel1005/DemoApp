<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FuelPriceCountry extends Model
{
    use HasFactory;

    protected $table = "cop_fuel_price_country_ms";
    protected $primaryKey = "id";
    protected $guarded = [];
}
