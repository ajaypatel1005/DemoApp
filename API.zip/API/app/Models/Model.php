<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model as M;
use App\Traits\ClientInfoTraits;
use Illuminate\Database\Eloquent\Model as EloquentModel;

class Model extends EloquentModel
{
    protected $table = 'cop_models';
    protected $primaryKey = 'model_id';
    use HasFactory;
    use ClientInfoTraits;

    protected static $logAttributes = ['cs_id', 'launch_date', 'ct_id', 'brand_id', 'model_name', 'model_image', 'model_description', 'min_price', 'max_price', 'model_year', 'model_type', 'status'];

    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];
        return "User {$eventNameMap[$eventName]} Model record";
    }

    // Log additional custom properties
    public function logActivity(string $eventName)
    {
        $oldValues = null;
        $newValues = null;
        if ($eventName == "updated") {
            $oldValues = $this->getOriginal();
            $newValues = $this->getAttributes();
        }
        if ($eventName == "deleted") {
            $oldValues = $this->getOriginal();
        }
        if ($eventName == "created") {
            $newValues = $this->getAttributes();
        }

        activity('model')
            ->event($eventName)
            ->performedOn($this)
            ->withProperties([
                'old_values' => $oldValues,
                'new_values' => $newValues,
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log($this->getDescriptionForEvent($eventName));
    }

    // Log custom attributes
    protected static function boot()
    {
        parent::boot();
        static::created(function ($model) {
            $model->logActivity('created');
        });
        static::updated(function ($model) {
            $model->logActivity('updated');
        });
        static::deleted(function ($model) {
            $model->logActivity('deleted');
        });
    }
    protected $guarded = [];

    // relationships
    public function variants()
    {
        return $this->hasMany(Variant::class, 'model_id', 'model_id');
    }

    public function banners()
    {
        return $this->hasMany(Banner::class, 'model_id', 'model_id');
    }

    public function car_graphics()
    {
        return $this->hasMany(CarGraphic::class, 'model_id', 'model_id');
    }

    public function car_listing_data()
    {
        return $this->hasMany(CarListingData::class, 'model_id', 'model_id');
    }


    public function price_entry()
    {
        return $this->hasMany(PriceEntry::class, 'model_id', 'model_id');
    }

    public function manager()
    {
        return $this->hasMany(Manager::class, 'model_id', 'model_id');
    }

    // public function banner()
    // {
    //     return $this->belongsTo(Banner::class,'model_id');
    // }


    public function model_info()
    {
        return $this->hasOne(ModelSpecDisplay::class,'model_id', 'model_id');
    }
    public function banner()
    {
        return $this->hasMany(Banner::class,'model_id', 'model_id');
    }
    
    public function ratings()
    {
        return $this->hasMany(Rating::class, 'model_id', 'model_id');
    }

    public function ratingType()
    {
        return $this->belongsTo(RatingType::class, 'rating_type_id', 'rating_type_id');
    }
    
    public function brand()
    {
        return $this->belongsTo(Brand::class, 'brand_id', 'brand_id');
    }
    
    public function car_stage()
    {
        return $this->belongsTo(CarStage::class, 'cs_id', 'cs_id');
    }
    
    public function car_type()
    {
        return $this->belongsTo(CarType::class, 'ct_id', 'ct_id');
    }
    
    public function wishlist()
    {
        return $this->hasMany(Wishlist::class, 'model_id', 'model_id');
    }

    public function feature_value()
    {
        return $this->hasMany(FeatureValue::class, 'model_id', 'model_id');
    }

    // status active
    public function scopeActive($query)
    {
        return $query->where('status', '1');
    }
}
