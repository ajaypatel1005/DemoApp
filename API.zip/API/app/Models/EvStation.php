<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\ClientInfoTraits;

class EvStation extends Model
{
    use HasFactory;
    use ClientInfoTraits;
    
    protected $table = 'cop_evs_ms';
    protected $primaryKey = 'evs_id';
    protected $guarded = [];

    protected static $logAttributes = ['evs_name',
    'state_id',
    'city_id',
    'evs_address',
    'evs_location' ,
    'evs_charging_slots' ,
    'evs_charging_port_type',
    'evs_charging_voltage',
    'evs_charging_rate',
    'evs_car_capacity',
    'evs_contact_number'];

    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];
        return "User {$eventNameMap[$eventName]} Ev Station record";
    }
   
    // Log additional custom properties
    public function logActivity(string $eventName)
    {
        $oldValues=null;
        $newValues=null;
        if($eventName=="updated")
        {
            $oldValues = $this->getOriginal();
            $newValues = $this->getAttributes();
        }
        if($eventName=="deleted")
        {
            $oldValues = $this->getOriginal();
        }
        if($eventName=="created")
        {
            $newValues = $this->getAttributes();
        }

        activity('ev_station')
            ->event($eventName)
            ->performedOn($this)
            ->withProperties([
                'old_values' => $oldValues,
                'new_values' => $newValues,
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log($this->getDescriptionForEvent($eventName));
    }

    // Log custom attributes
    protected static function boot()
    {
        parent::boot();
        static::created(function ($model) {
            $model->logActivity('created');
        });
        static::updated(function ($model) {
            $model->logActivity('updated');
        });
        static::deleted(function ($model) {
            $model->logActivity('deleted');
        });
    }
}
