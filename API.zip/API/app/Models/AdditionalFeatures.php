<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdditionalFeatures extends Model
{
    use HasFactory;

    protected $table = 'cop_af';
    protected $primaryKey = 'af_id';
    protected $guarded = [];
}
