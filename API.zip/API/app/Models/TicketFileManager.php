<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\ClientInfoTraits;

class TicketFileManager extends Model
{
    use HasFactory;

    use ClientInfoTraits;

    protected $table = 'ticket_file_managers';
    protected $primaryKey = 'id';
    protected $guarded = [];
}
