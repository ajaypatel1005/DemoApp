<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Ticket extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'ticket';
    protected $primaryKey = 'id';
    protected $guarded = [];
    const OPEN = 0;
    const INPROGRESS = 1;
    const CANCELED = 2;
    const ONHOLD = 3;
    const CLOSED = 4;
    const RESOLVED = 5;
    const REOPEN = 6;
    const STATUS = [
        self::OPEN => ['label' => 'Open', 'class' => 'badge-light-primary', 'radio_class' => 'form-check-primary', 'text_class' => 'text-primary'],
        self::INPROGRESS => ['label' => 'In Progress', 'class' => 'badge-secondary',  'radio_class' => 'form-check-dark', 'text_class' => 'text-dark-secondary'],
        self::CANCELED => ['label' => 'Canceled', 'class' => 'badge-light-danger', 'radio_class' => 'form-check-danger', 'text_class' => 'text-danger'],
        self::ONHOLD => ['label' => 'On Hold', 'class' => 'badge-light-info', 'radio_class' => 'form-check-info', 'text_class' => 'text-info'],
        self::CLOSED => ['label' => 'Closed', 'class' => 'badge-light-warning', 'radio_class' => 'form-check-warning', 'text_class' => 'text-warning'],
        self::RESOLVED => ['label' => 'Resolved', 'class' => 'badge-light-success', 'radio_class' => 'form-check-success', 'text_class' => 'text-success'],
        self::REOPEN => ['label' => 'Re Open', 'class' => 'badge-light-info', 'radio_class' => 'form-check-info', 'text_class' => 'text-info'],
    ];

    const LOW = 1;
    const MEDIUM = 2;
    const HIGH = 3;
    const URGENT = 4;
    const PRIORITY = [
        self::LOW => ['label' => 'Low', 'class' => 'badge-light-primary'],
        self::MEDIUM => ['label' => 'Medium', 'class' => 'badge-secondary'],
        self::HIGH => ['label' => 'High', 'class' => 'badge-light-info'],
        self::URGENT => ['label' => 'Urgent', 'class' => 'badge-light-danger'],
    ];


    /**
     * defined relationship
     */
    public function buy_now()
    {
        return $this->belongsTo(BuyNow::class, 'buynow_id', 'buynow_id');
    }

    public function test_drive()
    {
        return $this->belongsTo(BookTestDrive::class, 'test_drive_id', 'btest_id');
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'created_by_customer', 'customer_id');
    }
    public function agent_created_by()
    {
        return $this->belongsTo(User::class, 'created_by_agent', 'id');
    }

    public function agent()
    {
        return $this->belongsTo(User::class, 'assigned_to', 'id');
    }

    public function category()
    {
        return $this->belongsTo(TicketCategory::class, 'category_id', 'id');
    }
    public function conversation()
    {
        return $this->hasMany(Conversation::class, 'ticket_id', 'id');
    }
    public function notes()
    {
        return $this->hasMany(TicketNotes::class, 'ticket_id', 'id');
    }
    public function files()
    {
        return $this->hasMany(TicketFileManager::class, 'ticket_id', 'id');
    }


    public static function generateInvoiceNumber($type)
    {
        if (!empty($type) && in_array($type, ['buy_now', 'test_drive'])) {
            $ticketCount = TicketCount::first();
            if ($type == 'buy_now') {
                $prefix = 'SB';
                $count = $ticketCount->buynow_count + 1;
                $ticketCount->increment('buynow_count');
            } elseif ($type == 'test_drive') {
                $prefix = 'ST';
                $count = $ticketCount->test_drive_count + 1;
                $ticketCount->increment('test_drive_count');
            }
            return $prefix . str_pad($count, $ticketCount->total_digit, '0', STR_PAD_LEFT);
        }
        return rand(0000, 9999);
    }
}
