<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Model as ModelsModel;

class BookTestDrive extends Model
{
    use HasFactory;
    protected $table = 'cop_book_test_drives';
    protected $primaryKey = 'btest_id';
    protected $guarded = [];


    public function car_model()
    {
        return $this->belongsTo(ModelsModel::class, 'model_id', 'model_id');
    }

    public function  brand()
    {
        return $this->belongsTo(Brand::class, 'brand_id', 'brand_id');
    }
}
