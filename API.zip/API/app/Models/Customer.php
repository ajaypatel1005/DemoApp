<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
// use Laravel\Passport\HasApiTokens;
use Laravel\Sanctum\HasApiTokens;
// use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
class Customer extends Authenticatable
{
    use HasFactory, Notifiable, HasApiTokens;
    // public function getJWTIdentifier()
    // {
    //     return $this->getKey();
    // }

    // public function getJWTCustomClaims()
    // {
    //     return [];
    // }

    protected $table = 'cop_customers';
    protected $primaryKey = 'customer_id';
    protected $fillable = [
        'customer_id',
        'first_name',
        'last_name',
        'email',
        'address_1',
        'address_2',
        'contact_no',
        'profile_pic',
        'country_id',
        'state_id',
        'city_id',
        'pincode',
        'is_verified'
    ];
    // use HasFactory, HasApiTokens;
}
