<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\ClientInfoTraits;

class TicketCategory extends Model
{
    use HasFactory;

    use ClientInfoTraits;

    protected $table = 'ticket_category_ms';
    protected $primaryKey = 'id';
    protected $fillable = [
        'ticket_category_name',
        'status',
        'created_by',

    ];
}
