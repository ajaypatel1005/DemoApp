<?php

namespace App\Http\Controllers;

use App\Models\CarGraphicType;
use App\Models\Brand;
use App\Models\Model;
use Illuminate\Validation\Rule;
use Exception;
use App\Models\CarGraphic;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class CarGraphicController extends Controller
{
    //  fetch model-name from branch
    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');

        if ($selectedBrandId) {
            $models = Model::where('brand_id', $selectedBrandId)
                ->active()
                ->get(['model_name', 'model_id']);
        } else {
            $models = [];
        }

        $brands = Brand::active()->get();

        return response()->json(['models' => $models, 'brands' => $brands]);
    }

    //  Show the form for creating a new resource.
    public function create()
    {
        if (!hasAnyPermission(['create_car_graphic'])) {
            abort(403, "you don't have permission to access");
        }
        $model_name = Model::active()->get();
        $brand_name = Brand::active()->get();
        $gt_id = CarGraphicType::active()->get();

        return view('car_graphics.create', ['gt_id' => $gt_id, 'model_name' => $model_name, 'brand_name' => $brand_name]);
    }

    //  Store a newly created resource in storage.
    public function store(Request $request)
    {
        $request->validate([
            'brand_id' => 'required',
            'model_id' => 'required',
            'car_graphics_video' => 'mimes:mp4,mkv,avi,mov',
            'car_graphics_images.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_images_360.*' => 'mimes:png,jpg,jpeg,webp',
        ], [
            'brand_id.required' => 'Brand name field is required.',
            'model_id.required' => 'Model name field is required.',
            'car_graphics_video.mimes' => 'Car graphic video file must be mp4,mkv,avi,mov.',
            'car_graphics_images.*.mimes' => 'Car graphic images file must be png,jpg,jpeg,webp',
            'car_graphics_images_360.*.mimes' => 'Car graphic 360 images file must be png,jpg,jpeg,webp',
        ]);

        if ($request->gt_id) {
            $model_id = $request->model_id;
            $request->validate([
                'gt_id' => [
                    'required',
                    Rule::unique('cop_graphics')->where(function ($query) use ($model_id) {
                        return $query->where('model_id', $model_id);
                    }),
                ],
            ], [
                'gt_id.required' => 'Car graphic type name field is required.',
                'gt_id.unique' => 'Car graphic type for this model has already been taken.',
            ]);
        }
        DB::beginTransaction();
        try {
            $car_graphic_store = new CarGraphic();

            if (!empty($car_graphic_store)) {

                $car_graphic_store->brand_id = $request->brand_id;
                $car_graphic_store->model_id = $request->model_id;
                $car_graphic_store->gt_id = $request->gt_id;
                $car_graphic_store->status = $request->has('status') ? 1 : 0;
                $car_graphic_store->created_by = auth()->id();

                if ($request->hasFile('car_graphics_images')) {
                    $images = $request->file('car_graphics_images');
                    $i = 1;
                    foreach ($images as $item) {
                        $time = date('dmYHis');
                        $imageWebpImageName = $car_graphic_store->model_id . '_' . $time . '_' . $i . '.webp';
                        // $item->move(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . 'images/', $imageWebpImageName);

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());

                        // main image
                        // read image from file system
                        $image = $manager->read($item);
                        if(!is_dir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . 'images')){
                            mkdir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . 'images', 0777, true);
                        }
                        $image->toWebp()->save(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . 'images/'.$imageWebpImageName);

                        // Thumbnail image
                        if(!is_dir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . 'images/'.'/thumb')){
                            mkdir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . 'images/'.'/thumb', 0777, true);
                        }
                        $image->resize(1400,570);
                        $image->toWebp()->save(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . 'images/thumb/'.$imageWebpImageName);

                        $all_images[] = $imageWebpImageName;
                        $i++;
                    }
                    $image_name_for_db = implode(',', $all_images);
                    $car_graphic_store->graphic_file = $image_name_for_db;
                    // dd( $car_graphic_store);
                }

                if ($request->hasFile('car_graphics_images_360')) {
                    $images = $request->file('car_graphics_images_360');
                    $i = 1;
                    foreach ($images as $item) {
                        $time = date('dmYHis');
                        $image360WebpImageName = $car_graphic_store->model_id . '_' . $time . '_' . $i . '_360.webp';
                        $item->move(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images/', $image360WebpImageName);

                        /*
                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());

                        // main image
                        // read image from file system
                        $image = $manager->read($item);
                        if(!is_dir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images')){
                            mkdir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images', 0777, true);
                        }
                        $image->toWebp()->save(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images/'.$imageWebpImageName);

                        // Thumbnail image
                        if(!is_dir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images/thumb')){
                            mkdir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images/thumb', 0777, true);
                        }
                        $image->resize(1400,570);
                        $image->toWebp()->save(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images/thumb/'.$imageWebpImageName);
                        */

                        $all_images[] = $image360WebpImageName;
                        $i++;
                    }
                    $image_name_for_db = implode(',', $all_images);
                    $car_graphic_store->graphic_file = $image_name_for_db;
                }

                if ($request->hasFile('car_graphics_video')) {
                    $videoFile = $request->file('car_graphics_video');

                    $car_graphic_store->graphic_file = $request->file('car_graphics_video');
                    $time = date('dmYHis');
                    $imageVideoName = $car_graphic_store->model_id . '_' . $time . '_video.mp4';

                    $videoFile->move(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . 'videos/', $imageVideoName);

                    $car_graphic_store->graphic_file = $imageVideoName;
                }

                $car_graphic_store->save();
                DB::commit();
                session()->flash('success', 'Car Graphic Added Successfully.');
                return redirect()->route('car_graphic.view');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_graphic.view');
    }

    //  Display the specified resource.
    public function view()
    {
        if (!hasAnyPermission(['view_car_graphic'])) {
            abort(403, "you don't have permission to access");
        }
        $car_graphic_view = CarGraphic::leftJoin('cop_gt_ms', 'cop_gt_ms.gt_id', '=', 'cop_graphics.gt_id')
        ->leftJoin('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_graphics.brand_id')
        ->leftJoin('cop_models', 'cop_models.model_id', '=', 'cop_graphics.model_id')
        ->select('cop_brands_ms.brand_name', 'cop_models.model_name', 'cop_models.model_id', 'cop_gt_ms.gt_name', 'cop_graphics.graphic_file', 'cop_graphics.graphic_id', 'cop_graphics.status')
        ->where([['cop_brands_ms.status','=',1],['cop_models.status','=',1]])
        ->get();

        return view('car_graphics.view', ['car_graphic_view' => $car_graphic_view]);
    }

    //  Show the form for editing the specified resource.
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_car_graphic'])) {
            abort(403, "you don't have permission to access");
        }
        $brand_name = Brand::active()->get();
        $model_name = Model::active()->get();
        $gt_id = CarGraphicType::active()->get();
        $car_graphic_edit = CarGraphic::join('cop_gt_ms', 'cop_gt_ms.gt_id', '=', 'cop_graphics.gt_id')->where('graphic_id', decrypt($id))->first();
        $cop_graphic = CarGraphic::where('graphic_id', decrypt($id))->first();

        return view('car_graphics.edit', ['car_graphic_edit' => $car_graphic_edit, 'gt_id' => $gt_id, 'model_name' => $model_name, 'brand_name' => $brand_name, 'cop_graphic_status' => $cop_graphic]);
    }

    //  Update the specified resource in storage.
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_car_graphic'])) {
            abort(403, "you don't have permission to access");
        }

        $request->validate([
            'brand_id' => 'required',
            'model_id' => 'required',
            'car_graphics_video' => 'mimes:mp4,mkv,avi,mov',
            'car_graphics_images.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_images_360.*' => 'mimes:png,jpg,jpeg,webp',
        ], [
            'brand_id.required' => 'Brand name field is required.',
            'model_id.required' => 'Model name field is required.',
            'car_graphics_video.mimes' => 'Car graphic video file must be mp4,mkv,avi,mov.',
            'car_graphics_images.*.mimes' => 'Car graphic images file must be png,jpg,jpeg,webp',
            'car_graphics_images_360.*.mimes' => 'Car graphic 360 images file must be png,jpg,jpeg,webp',
        ]);

        if ($request->gt_id) {
            $model_id = $request->model_id;
            $request->validate([
                'gt_id' => [
                    'required',
                    Rule::unique('cop_graphics')->where(function ($query) use ($model_id) {
                        return $query->where('model_id', $model_id);
                    })->ignore(decrypt($id), 'graphic_id'),
                ],
            ], [
                'gt_id.required' => 'Car graphic type name field is required.',
                'gt_id.unique' => 'Car graphic type for this model has already been taken.',
            ]);
        }
        DB::beginTransaction();
        try {
            $car_graphic_update = CarGraphic::where('graphic_id', decrypt($id))->first();
            if (!empty($car_graphic_update)) {
                $car_graphic_update->brand_id = $request->brand_id;
                $car_graphic_update->model_id = $request->model_id;
                $car_graphic_update->gt_id = $request->gt_id;
                $car_graphic_update->status = $request->has('status') ? 1 : 0;

                if ($request->hasFile('car_graphics_images')) {
                    $images = $request->file('car_graphics_images');
                    $i = 1;
                    foreach ($images as $item) {
                        $time = date('dmYHis');
                        $imageWebpImageName = $car_graphic_update->model_id . '_' . $time . '_' . $i . '.webp';
                        // $item->move(public_path('car_graphics') . '/' . $car_graphic_update->model_id . '/' . 'images/', $imageWebpImageName);

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());

                        // main image
                        // read image from file system
                        $image = $manager->read($item);
                        if(!is_dir(public_path('car_graphics') . '/' . $car_graphic_update->model_id . '/' . 'images')){
                            mkdir(public_path('car_graphics') . '/' . $car_graphic_update->model_id . '/' . 'images', 0777, true);
                        }
                        $image->toWebp()->save(public_path('car_graphics') . '/' . $car_graphic_update->model_id . '/' . 'images/'.$imageWebpImageName);

                        // Thumbnail image
                        if(!is_dir(public_path('car_graphics') . '/' . $car_graphic_update->model_id . '/' . 'images/'.'/thumb')){
                            mkdir(public_path('car_graphics') . '/' . $car_graphic_update->model_id . '/' . 'images/'.'/thumb', 0777, true);
                        }
                        $image->resize(1400,570);
                        $image->toWebp()->save(public_path('car_graphics') . '/' . $car_graphic_update->model_id . '/' . 'images/thumb/'.$imageWebpImageName);

                        $all_images[] = $imageWebpImageName;
                        $i++;
                    }

                    if ($request->old_car_graphic_images == '') {
                        $image_name_for_db = implode(',', $all_images);
                        $car_graphic_update->graphic_file = $image_name_for_db;
                    } else {
                        $image_name_for_db = implode(',', $all_images);
                        $old_car_graphic_images = $request->old_car_graphic_images;

                        $car_graphic_update->graphic_file = $old_car_graphic_images . ',' . $image_name_for_db;
                    }
                }

                if ($request->hasFile('car_graphics_images_360')) {
                    $images = $request->file('car_graphics_images_360');
                    $i = 1;
                    foreach ($images as $item) {
                        $time = date('dmYHis');
                        $image360WebpImageName = $car_graphic_update->model_id . '_' . $time . '_' . $i . '_360.webp';
                        $item->move(public_path('car_graphics') . '/' . $car_graphic_update->model_id . '/' . '360_images/', $image360WebpImageName);

                        /*
                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());

                        // main image
                        // read image from file system
                        $image = $manager->read($item);
                        if(!is_dir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images')){
                            mkdir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images', 0777, true);
                        }
                        $image->toWebp()->save(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images/'.$imageWebpImageName);

                        // Thumbnail image
                        if(!is_dir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images/thumb')){
                            mkdir(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images/thumb', 0777, true);
                        }
                        $image->resize(1400,570);
                        $image->toWebp()->save(public_path('car_graphics') . '/' . $car_graphic_store->model_id . '/' . '360_images/thumb/'.$imageWebpImageName);
                        */
                        
                        $all_images[] = $image360WebpImageName;
                        $i++;
                    }

                    if ($request->old_car_graphic_images_360 == '') {
                        $image_name_for_db = implode(',', $all_images);
                        $car_graphic_update->graphic_file = $image_name_for_db;
                    } else {
                        $image_name_for_db = implode(',', $all_images);
                        $old_car_graphic_images_360 = $request->old_car_graphic_images_360;

                        $car_graphic_update->graphic_file = $old_car_graphic_images_360 . ',' . $image_name_for_db;
                    }
                }

                if ($request->hasFile('car_graphics_video')) {
                    $videoFile = $request->file('car_graphics_video');

                    $oldVideoName = $car_graphic_update->graphic_file;

                    if ($oldVideoName) {
                        $videoFolderPath = public_path('car_graphics') . '/' . $car_graphic_update->model_id . '/' . 'videos/';
                        $oldVideoPath = $videoFolderPath . $oldVideoName;

                        if (file_exists($oldVideoPath)) {
                            unlink($oldVideoPath);
                        }
                    }

                    $time = date('dmYHis');
                    $newVideoName = $car_graphic_update->model_id . '_' . $time . '_video.mp4';

                    $videoFile->move(public_path('car_graphics') . '/' . $car_graphic_update->model_id . '/' . 'videos/', $newVideoName);

                    $car_graphic_update->graphic_file = $newVideoName;
                }

                $car_graphic_update->save();
                DB::commit();
                session()->flash('success', 'Car Graphic Type Updated Successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_graphic.view');
    }

    //  Remove the specified resource from storage.
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_car_graphic'])) {
            abort(403, "you don't have permission to access");
        }
        DB::beginTransaction();
        try {
            $car_graphic_destroy = CarGraphic::where('graphic_id', decrypt($id))->first();
            $gt_id = $car_graphic_destroy->gt_id;
            $car_graphic_type = CarGraphicType::where('gt_id', $gt_id)->value('gt_name');

            $oldFile = $car_graphic_destroy->graphic_file;

            if ($car_graphic_type == "Video") {
                if ($oldFile) {
                    $videoFolderPath = public_path('car_graphics') . '/' . $car_graphic_destroy->model_id . '/' . 'videos/';
                    $oldVideoPath = $videoFolderPath . $oldFile;

                    if (file_exists($oldVideoPath)) {
                        unlink($oldVideoPath);
                    }
                }
            } elseif ($car_graphic_type == "Images") {
                if ($oldFile) {
                    $oldFile_explode = explode(',', $oldFile);

                    for ($i = 0; $i < count($oldFile_explode); $i++) {

                        $deleteImages = $oldFile_explode[$i];
                        $imageFolderPath = public_path('car_graphics') . '/' . $car_graphic_destroy->model_id . '/' . 'images/';
                        $oldImagePath = $imageFolderPath . $deleteImages;

                        if (file_exists($oldImagePath)) {
                            unlink($oldImagePath);
                        }
                    }
                }
            } else {
                if ($oldFile) {
                    $oldFile_explode = explode(',', $oldFile);

                    for ($i = 0; $i < count($oldFile_explode); $i++) {

                        $deleteImages360 = $oldFile_explode[$i];
                        $imageFolderPath = public_path('car_graphics') . '/' . $car_graphic_destroy->model_id . '/' . '360_images/';
                        $oldImage360Path = $imageFolderPath . $deleteImages360;

                        if (file_exists($oldImage360Path)) {
                            unlink($oldImage360Path);
                        }
                    }
                }
            }

            if (!empty($car_graphic_destroy)) {
                $car_graphic_destroy->delete();
                DB::commit();
                session()->flash('success', 'Car Graphic Deleted Successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('car_graphic.view');
    }

    //  Status change function.
    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_graphics')
            ->where('graphic_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status Updated Successfully']);
    }

    //  Delete Single-Image from Car Graphics Images using AJAX
    public function DelectSingleImage(Request $request)
    {
        $all_images = $request->all_images;
        $image_delete = $request->image_to_be_delete;
        $graphic_id = $request->graphic_id;
        $model_id = $request->model_id;

        $arr_all_images = explode(",", $all_images);

        $length = count($arr_all_images);
        $image_path = public_path('car_graphics') . '/' . $model_id . '/' . 'images/' . $image_delete;

        if ($length == 1) {
            $image_to_be_delete = $request->image_to_be_delete;
            if (file_exists($image_path)) {
                @unlink($image_path);
            }
        } else if ($image_delete == $arr_all_images[$length - 1]) {
            $image_to_be_delete = ',' . $request->image_to_be_delete;
            if (file_exists($image_path)) {
                @unlink($image_path);
            }
        } else {
            $image_to_be_delete = $request->image_to_be_delete . ',';
            if (file_exists($image_path)) {
                @unlink($image_path);
            }
        }

        $new_car_graphic_image = str_replace($image_to_be_delete, '', $all_images);

        DB::table('cop_graphics')
            ->where('graphic_id', $graphic_id)
            ->update(['graphic_file' => $new_car_graphic_image]);

        $arr = CarGraphic::where('graphic_id', $graphic_id)->get();

        echo view('car_graphics.ajax_view_images', ['new_images' => $arr]);
    }

    //  Delete Single-360-Image from Car Graphics 360_Images using AJAX
    public function DelectSingleImage360(Request $request)
    {
        $all_images_360 = $request->all_images;
        $images_360_delete = $request->image_to_be_delete;
        $graphic_id = $request->graphic_id;
        $model_id = $request->model_id;

        $arr_all_images_360 = explode(",", $all_images_360);

        $length = count($arr_all_images_360);
        $image_path = public_path('car_graphics') . '/' . $model_id . '/' . '360_images/' . $images_360_delete;

        if ($length == 1) {
            $image_to_be_delete = $request->image_to_be_delete;
            if (file_exists($image_path)) {
                @unlink($image_path);
            }
        } else if ($images_360_delete == $arr_all_images_360[$length - 1]) {
            $image_to_be_delete = ',' . $request->image_to_be_delete;
            if (file_exists($image_path)) {
                @unlink($image_path);
            }
        } else {
            $image_to_be_delete = $request->image_to_be_delete . ',';
            if (file_exists($image_path)) {
                @unlink($image_path);
            }
        }

        $new_car_graphic_images_360 = str_replace($image_to_be_delete, '', $all_images_360);

        DB::table('cop_graphics')
            ->where('graphic_id', $graphic_id)
            ->update(['graphic_file' => $new_car_graphic_images_360]);

        $arr = CarGraphic::where('graphic_id', $graphic_id)->get();

        echo view('car_graphics.ajax_view_images_360', ['new_images_360' => $arr]);
    }
}
