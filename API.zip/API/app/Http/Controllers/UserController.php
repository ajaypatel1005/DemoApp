<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Rules\PasswordStrength;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function index()
    {
        if (!hasAnyPermission(['view_users'])) {
            abort(403, "you don't have permission to access");
        }
        $users = User::with(['roles'])->get();
        return view('users.index', compact('users'));
    }

    public function create()
    {
        if (!hasAnyPermission(['create_users'])) {
            abort(403, "you don't have permission to access");
        }
        return view('users.create', [
            'roles' =>  Role::pluck('name')->all()
        ]);
    }

    /**
     * Save New User
     *
     * @param Request $request
     * @return void
     */
    public function store(Request $request)
    {

        $request->validate(
            [
                'name' => 'required',
                'email' => 'required|unique:users,email',
                'password' => ['required', 'string', 'min:16', new PasswordStrength],
                'confirmed_password' => 'required|same:password'
            ],
            [
                'name.required' => 'The Name is required.',
                'email.required' => 'The Email is required.',
                'email.unique' => 'The Email is already taken, Please choose a different email.',
                'password.required' => 'The Password is required.',
                'password.min' => 'The Password must be at least :min characters.',
                'password.custom' => 'The password must be a combination of at least 1 uppercase letter, 1 lowercase letter, 1 special character, and 1 numeric value.',
                'confirmed_password.same' => 'The confirmed password must match the password field.'
            ]
        );
        DB::beginTransaction();
        try {
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);
            $user->assignRole($request->roles);
            DB::commit();
            session()->flash('success', 'User has been created successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('users.index');
    }

    public function edit($id)
    {
        if (!hasAnyPermission(['edit_users'])) {
            abort(403, "you don't have permission to access");
        }
        $user = User::findOrFail(decrypt($id));
        $roles =  Role::pluck('name')->all();
        $userRoles = $user->roles->pluck('name')->all();
        return view('users.edit', compact('user', 'roles', 'userRoles'));
    }

    /**
     * Update user
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_users'])) {
            abort(403, "you don't have permission to access");
        }
        $request->validate(
            [
                'name' => 'required|min:1|max:30',
                'email' => 'required|unique:users,email,' . decrypt($id),
                'password' => ['nullable', 'string', 'min:16', new PasswordStrength],
                'confirmed_password' => 'required_with:password|nullable|min:16|max:50|same:password',

            ],
            [
                'name.required' => 'The Name is required.',
                'name.min' => 'The Name must be at least :min characters.',
                'name.max' => 'The Name must not exceed :max characters.',
                'email.required' => 'The Email is required.',
                'email.unique' => 'The Email is already taken, Please choose a different email.',
                'password.required' => 'The Password is required.',
                'password.min' => 'The Password must be at least :min characters.',
                'password.custom' => 'The password must be a combination of at least 1 uppercase letter, 1 lowercase letter, 1 special character, and 1 numeric value.',
                'confirmed_password.same' => 'The confirmed password must match the password field.'
            ]
        );
        DB::beginTransaction();
        try {
            $user = User::findOrFail(decrypt($id));
            $user->name = $request->name;
            $user->email = $request->email;
            if (!empty($request->password)) {
                $user->password = Hash::make($request->password);
            }
            $user->save();
            $user->syncRoles($request->roles);
            DB::commit();
            session()->flash('success', 'User has been updated successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('users.index');
    }


    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_users'])) {
            abort(403, "you don't have permission to access");
        }
        try {
            $user = User::findOrFail(decrypt($id));
            $user->delete();
            session()->flash('success', 'User has been deleted successfully.');
        } catch (Exception $e) {
            dd("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('users.index');
    }
}
