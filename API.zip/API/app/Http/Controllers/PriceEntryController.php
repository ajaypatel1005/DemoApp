<?php

namespace App\Http\Controllers;

use App\Models\AllTax;
use App\Models\Brand;
// use App\Models\unionTerritory;
use App\Models\City;
use App\Models\Country;
use App\Models\Model;
use App\Models\PriceEntry;
use App\Models\State;
use App\Models\Variant;
use App\Models\TaxValue;
use App\Models\Rto;
use App\Rules\UniquePriceEntry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Exception;
use Hamcrest\Arrays\IsArray;

class PriceEntryController extends Controller
{
    //fetch models
    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');
        //dump($selectedBrandId);
        if ($selectedBrandId) {
            $models = Model::select('model_id','model_name')->where('brand_id', $selectedBrandId)
                ->active()
                ->get();
        } else {
            $models = [];
        }

        return response()->json(['models' => $models]);
    }

    // fetch variants
    public function fetchVariants(Request $request)
    {
        $selectedModelId = $request->input('model_id');

        if ($selectedModelId) {
            $variants = Variant::select('variant_id','variant_name')->where('model_id', $selectedModelId)
                ->active()
                ->get();
        } else {
            $variants = [];
        }

        return response()->json(['variants' => $variants]);
    }

    // fetch states
    public function fetchStates(Request $request)
    {
        $selectedCountryId = $request->input('country_id');

        if ($selectedCountryId) {
            $states = State::select('state_id','state_name')->where('country_id', $selectedCountryId)
                ->active()
                ->get();

            // $ut_name = unionTerritory::where('country_id', $selectedCountryId)
            //     ->active()
            //     ->get();
        } else {
            $states = [];
            $ut_name = [];
        }

        return response()->json(['states' => $states]);
    }

    // fetch cities
    public function fetchCities(Request $request)
    {
        $selectedStateId = $request->input('state_id');

        if ($selectedStateId) {
            $cities = City::select('city_id','city_name')->where('state_id', $selectedStateId)
                ->active()
                ->get();
        } else {
            $cities = [];
        }

        return response()->json(['cities' => $cities]);
    }

    // get list of all city & list of applicable taxes of this city (city_id on change)
    public function fetchAgainstCitiesAndTaxname(Request $request)
    {
        // $selectedStateId = $request->input('state_id');
        $selectedCityId = $request->input('city_id');
        // $selectedUtId = $request->input('ut_id');


        // dd($selectedCityId);
        // if ($selectedStateId != null) {
        //     $cities = City::where('state_id', $selectedStateId)
        //         ->where('city_id', '!=', $selectedCityId)
        //         ->active()
        //         ->get();
        // } else if ($selectedUtId != null) {
        //     $cities = City::active()
        //         ->get();
        // } else {
        //     $cities = [];
        // }

        if (is_array($selectedCityId)) {
            $cities = City::select('city_id','city_name')->whereNotIn('city_id', $selectedCityId)->active()
                ->get();

            $allTaxName = AllTax::where(function($query) use ($selectedCityId) {
                    $query->whereNull('city_id')
                        ->orWhereIn('city_id', $selectedCityId);
                })
                ->where('tax_name', '!=', 'TCS')
                ->where('status','=','1')
                ->get();
        } else {
            $cities = City::select('city_id','city_name')->where('city_id', '!=', $selectedCityId)->active()
                ->get();

            $allTaxName = AllTax::where(function($query) use ($selectedCityId) {
                    $query->whereNull('city_id')
                        ->orWhere('city_id', $selectedCityId);
                })
                ->where('tax_name', '!=', 'TCS')
                ->where('status','=','1')
                ->get();
        }

        return response()->json(['cities' => $cities,'allTaxName'=>$allTaxName]);
    }

    // get data for selected agist_city_id (against_city_id on change _ first ajax)
    public function getdataagainstcities(Request $request){
        $againstCityId = $request->againstCityId;
        $variantId = $request->variantId;
        $modelId = $request->modelId;

        $data = PriceEntry::where('model_id', $modelId)
        ->where('variant_id', $variantId)
        ->where('city_id', $againstCityId)
        ->get();

        return response()->json(['price_entry_data' => $data]);
        
    }

    // get data for selected agist_city_id (against_city_id on change _ inside ajax - secound ajax)
    public function gettaxnameagainstcities(Request $request){
        $tax_id = $request->taxId;
        $tax_value = $request->taxValue;

        $data = AllTax::where('tax_id',$tax_id)->get();

        return response()->json(['tax_name' => $data,'tax_id'=>$tax_id,'tax_value'=>$tax_value]);
    }

    // Fetch taxes value (RTO, TCS, Munci Cor Taxes, etc) (ex_showroom_price on input)
    public function fatchTaxesValue(Request $request){
        $state_id = $request->state_id;
        $exShorRoomPrice = $request->exShorRoomPrice;
        $carExShorRoomPrice = $exShorRoomPrice;   // (Don't delete) This variable i have used in condition check
        $modelId = $request->model_id;
        $variantId = $request->variant_id;
        $taxId = $request->taxId ?? array();

            $checkRTOready = true;
            $rto_value_i = 0;
            $rto_value_c = 0;
            
            // For individual purchase
            $RTOrateInd = Rto::where('state_id',$state_id)->where('rto_type','=','I')->get();
            foreach($RTOrateInd as $rtocheck){

                // If rto check with the CC (No amount)
                if($rtocheck->cc == 1){
                    $checkRTOready = false;

                    $getCC = Variant::select('cop_fv.feature_value')->join('cop_fv','cop_fv.variant_id','=','cop_variants.variant_id')->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')->where('cop_features_ms.features_name','=','Displacement')->where('cop_variants.variant_id',$variantId)->first();

                    if(!empty($getCC)){
                        $checkRTOready = true;
                        $carExShorRoomPrice = $getCC->feature_value;
                    }
                }
                
                // If RTO check with Fuel-type and Amount both
                if($rtocheck->fuel_type != null){
                    $checkRTOready = false;

                    $modelIdEvCheck = Model::select('model_type')->where('model_id',$modelId)->first();

                    if($modelIdEvCheck->model_type == 1){
                        if($rtocheck->fuel_type == 'EV'){
                            $checkRTOready = true;
                        }
                    } else {
                        $getFuelType = Variant::select('cop_fv.feature_value')->join('cop_fv','cop_fv.variant_id','=','cop_variants.variant_id')->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')->where('cop_features_ms.features_name','=','Type of Fuel')->where('cop_variants.variant_id',$variantId)->first();

                        if(!empty($getFuelType) && $getFuelType->feature_value == $rtocheck->fuel_type){
                            $checkRTOready = true;
                        }
                    }
                }
                
                // If RTO check with only Amount
                if($checkRTOready == true){
                    $preCondition = $rtocheck->pre_condition;
                    $preAmount = $rtocheck->pre_amount;
                    $postCondition = $rtocheck->post_condition;
                    $postAmount = $rtocheck->post_amount;
                    $rtoPer = $rtocheck->percentage;

                    if($preCondition == null && $preAmount == null && $postCondition == null && $postAmount == null) {
                        $rto_value_i = $exShorRoomPrice * $rtoPer / 100;
                    } else if($postCondition == null && $postAmount == null){
                        if (
                            ($preCondition === '<' && $carExShorRoomPrice < $preAmount) ||
                            ($preCondition === '>' && $carExShorRoomPrice > $preAmount) ||
                            ($preCondition === '<=' && $carExShorRoomPrice <= $preAmount) ||
                            ($preCondition === '>=' && $carExShorRoomPrice >= $preAmount)
                        ) {
                            $rto_value_i = $exShorRoomPrice * $rtoPer / 100;
                        } 
                    } else {
                        if (
                            ($preCondition === '>' && $postCondition === '<=' && $carExShorRoomPrice > $preAmount && $carExShorRoomPrice <= $postAmount) ||
                            ($preCondition === '>=' && $postCondition === '<=' && $carExShorRoomPrice >= $preAmount && $carExShorRoomPrice <= $postAmount) ||
                            ($preCondition === '>=' && $postCondition === '<' && $carExShorRoomPrice >= $preAmount && $carExShorRoomPrice < $postAmount) ||
                            ($preCondition === '>' && $postCondition === '<' && $carExShorRoomPrice > $preAmount && $carExShorRoomPrice < $postAmount)
                        ) {
                            $rto_value_i = $exShorRoomPrice * $rtoPer / 100;
                        }
                    }
                }

                // rto double for cbu cars in gujarat
                $cpuType = Model::select('cbu_status')->where('model_id',$modelId)->first();
                $stateName = State::select('state_name')->where('state_id',$state_id)->first();
                if($cpuType->cbu_status == '1' && $stateName->state_name == 'Gujarat'){
                    // $RTOrate = State::where('state_id',$state_id)->select('cbu_rto')->first();
                    // $rto_per = $RTOrate->cbu_rto;
                    $rto_value_i = $rto_value_i * 2;
                    // $rto_value_c = $exShorRoomPrice * $rto_per * 2 / 100;
                }
            }
              
            // For company purchase
            $RTOrateCor = Rto::where('state_id',$state_id)->where('rto_type','=','C')->get();
            if ($RTOrateCor->count() == 0){
                $rto_value_c = $rto_value_i * 2;
            } else {
                $checkRTOready = true;
                foreach($RTOrateCor as $rtocheck){

                    // If rto check with the CC (No amount)
                    if($rtocheck->cc == 1){
                        $checkRTOready = false;

                        $getCC = Variant::select('cop_fv.feature_value')->join('cop_fv','cop_fv.variant_id','=','cop_variants.variant_id')->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')->where('cop_features_ms.features_name','=','Displacement')->where('cop_variants.variant_id',$variantId)->first();

                        if(!empty($getCC)){
                            $checkRTOready = true;
                            $carExShorRoomPrice = $getCC->feature_value;
                        }
                    }
                    
                    // If RTO check with Fuel-type and Amount both
                    if($rtocheck->fuel_type != null){
                        $checkRTOready = false;

                        $modelIdEvCheck = Model::select('model_type')->where('model_id',$modelId)->first();

                        if($modelIdEvCheck->model_type == 1){
                            if($rtocheck->fuel_type == 'EV'){
                                $checkRTOready = true;
                            }
                        } else {
                            $getFuelType = Variant::select('cop_fv.feature_value')->join('cop_fv','cop_fv.variant_id','=','cop_variants.variant_id')->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')->where('cop_features_ms.features_name','=','Type of Fuel')->where('cop_variants.variant_id',$variantId)->first();

                            if(!empty($getFuelType) && $getFuelType->feature_value == $rtocheck->fuel_type){
                                $checkRTOready = true;
                            }
                        }
                    }
                    
                    // If RTO check with only Amount
                    if($checkRTOready == true){
                        $preCondition = $rtocheck->pre_condition;
                        $preAmount = $rtocheck->pre_amount;
                        $postCondition = $rtocheck->post_condition;
                        $postAmount = $rtocheck->post_amount;
                        $rtoPer = $rtocheck->percentage;

                        if($preCondition == null && $preAmount == null && $postCondition == null && $postAmount == null) {
                            $rto_value_c = $exShorRoomPrice * $rtoPer / 100;
                        } else if($postCondition == null && $postAmount == null){
                            if (
                                ($preCondition === '<' && $carExShorRoomPrice < $preAmount) ||
                                ($preCondition === '>' && $carExShorRoomPrice > $preAmount) ||
                                ($preCondition === '<=' && $carExShorRoomPrice <= $preAmount) ||
                                ($preCondition === '>=' && $carExShorRoomPrice >= $preAmount)
                            ) {
                                $rto_value_c = $exShorRoomPrice * $rtoPer / 100;
                                // $rto_value_c = 0;
                            } 
                        } else {
                            if (
                                ($preCondition === '>' && $postCondition === '<=' && $carExShorRoomPrice > $preAmount && $carExShorRoomPrice <= $postAmount) ||
                                ($preCondition === '>=' && $postCondition === '<=' && $carExShorRoomPrice >= $preAmount && $carExShorRoomPrice <= $postAmount) ||
                                ($preCondition === '>=' && $postCondition === '<' && $carExShorRoomPrice >= $preAmount && $carExShorRoomPrice < $postAmount) ||
                                ($preCondition === '>' && $postCondition === '<' && $carExShorRoomPrice > $preAmount && $carExShorRoomPrice < $postAmount)
                            ) {
                                $rto_value_c = $exShorRoomPrice * $rtoPer / 100;
                                // $rto_value_c = 0;
                            }
                        }
                    }

                    // rto double for cbu cars in gujarat
                    $cpuType = Model::select('cbu_status')->where('model_id',$modelId)->first();
                    $stateName = State::select('state_name')->where('state_id',$state_id)->first();
                    if($cpuType->cbu_status == '1' && $stateName->state_name == 'Gujarat'){
                        // $RTOrate = State::where('state_id',$state_id)->select('cbu_rto')->first();
                        // $rto_per = $RTOrate->cbu_rto;
                        // $rto_value_c = $exShorRoomPrice * $rto_per * 2 / 100;
                        $rto_value_c = $rto_value_c * 2;
                    }
                }
            }

        // TCS calculation
        $TCS = AllTax::where('tax_name','=','TCS')->where('status','=','1')->get();
        $TCScost = null;
        foreach($TCS as $result){
            if($result->condition_status == '0'){
                $tcsPer = $result->percent;
                $tcsTaxId = $result->tax_id;
                $TCScost = $exShorRoomPrice * $tcsPer / 100;
            } else {
                $TCScondition = TaxValue::select('cop_tax_value.tax_id','cop_tax_value.condition','cop_tax_value.amount','cop_tax_value.percent')->join('cop_taxes_ms','cop_taxes_ms.tax_id','=','cop_tax_value.tax_id')->where('cop_taxes_ms.tax_name','=','TCS')->get();

                foreach($TCScondition as $results){
                    $condition = $results->condition;
                    $condition_value = $results->amount;
                    $tcsPer = $results->percent;
                    $tcsTaxId = $results->tax_id;

                    if (
                        ($condition === '<' && $exShorRoomPrice < $condition_value) ||
                        ($condition === '>' && $exShorRoomPrice > $condition_value) ||
                        ($condition === '<=' && $exShorRoomPrice <= $condition_value) ||
                        ($condition === '>=' && $exShorRoomPrice >= $condition_value)
                    ) {
                        $TCScost = $exShorRoomPrice * $tcsPer / 100;
                    } 
                }
            }
        }

        // All other taxes calculation
        $allTaxes = array();
        for($i=0; $i<count($taxId); $i++){

            $Taxes = AllTax::select('condition_status','percent')->where('tax_id',$taxId[$i])->get();
                        
            foreach($Taxes as $result){
                if($result->condition_status == '0'){
                    $taxPer = $result->percent;
                    $tax_value = $exShorRoomPrice * $taxPer / 100;
                    
                    array_push($allTaxes, array("tax_id"=>$taxId[$i],"tax_value"=>$tax_value));
                } else {
                    $TaxValue = TaxValue::select('condition','amount','percent')->where('tax_id',$result->tax_id)->get();

                    foreach($TaxValue as $result){
                        $condition = $result->condition;
                        $condition_value = $result->amount;
                        $taxPer = $result->percent;
            
                        if (
                            ($condition === '<' && $exShorRoomPrice < $condition_value) ||
                            ($condition === '>' && $exShorRoomPrice > $condition_value) ||
                            ($condition === '<=' && $exShorRoomPrice <= $condition_value) ||
                            ($condition === '>=' && $exShorRoomPrice >= $condition_value)
                        ) {
                            $tax_value = $exShorRoomPrice * $taxPer / 100;
                            array_push($allTaxes, array("tax_id"=>$taxId[$i],"tax_value"=>$tax_value));
                        }
                    }
                }
            }
        }
        
        return response()->json(['rto_value_i'=>$rto_value_i,'rto_value_c'=>$rto_value_c,'TCScost'=>$TCScost,'tcs_tax_id'=>$tcsTaxId,'all_taxes'=>$allTaxes]);
    }

    // create
    public function create()
    {
        if (!hasAnyPermission(['create_price_entry'])) {
            abort(403, "you don't have permission to access");
        }
        $brands =Brand::active()->get();
        $models = Model::active()->get();
        $variants = Variant::active()->get();
        $countries = Country::active()->get();
        $states = State::active()->get();
        $cities = City::active()->get();
        $alltaxes = AllTax::active()->get();
        $gstTaxId = AllTax::where('tax_name','=','GST')->active()->get();
        $rtoTaxId = AllTax::where('tax_name','=','RTO')->active()->get();
        $tcsTaxId = AllTax::where('tax_name','=','TCS')->active()->get();
        // $ut_city = unionTerritory::active()->get();

        return view("price_entry.create", compact("brands", "models", "variants", "countries", "states", "cities", "alltaxes", "gstTaxId","rtoTaxId","tcsTaxId"));
    }

    // Store
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_price_entry'])) {
            abort(403, "you don't have permission to access");
        }

        Validator::extend('not_zero', function ($attribute, $value, $parameters, $validator) {
            return $value != 0;
        });

        $request->validate(
            [
                'brand_id' => 'required',
                'model_id' => 'required',
                'variant_id' => 'required',
                'country_id' => 'required',
                'ex_showroom_price' => 'required|numeric|min:200000|max:500000000',
                'i_rto_price' => 'required|numeric|not_zero',
                'c_rto_price' => 'required|numeric|not_zero',
                'total_price' => 'required|numeric|not_zero',
                'total_price_c' => 'required|numeric|not_zero',
                'tax_id' => 'required',
                // 'tax_cost' => 'required',
                // 'tax_cost' => 'required|array',
                // 'tax_cost.*' => 'nullable|numeric',
            ],

            [
                'brand_id.required' => 'The Brand Name is required.',
                'model_id.required' => 'The Model Name is required.',
                'variant_id.required' => 'The Variant Name is required.',
                'country_id.required' => 'The Country Name is required.',
                'ex_showroom_price.required' => 'The Ex-Showroom is required.',
                'ex_showroom_price.min' => 'The Ex-Showroom price must be at least :min.',
                'ex_showroom_price.max' => 'The Ex-Showroom price must not exceed :max.',
                'ex_showroom_price.numeric' => 'The Ex-Showroom price field should be number only.',
                'i_rto_price.required' => 'The RTO (Individual) price is required.',
                'i_rto_price.numeric' => 'The RTO (Individual) price field should be number only.',
                'i_rto_price.not_zero' => 'The RTO (Individual) price field should not be zero.',
                'c_rto_price.required' => 'The RTO (Corporate) price is required.',
                'c_rto_price.numeric' => 'The RTO (Corporate) price field should be number only.',
                'c_rto_price.not_zero' => 'The RTO (Corporate) price field should not be zero.',
                'total_price.required' => 'Total Price is required',
                'total_price.numeric' => 'Total Price field should be number only',
                'total_price.not_zero' => 'Total Price field should not be zero',
                'total_price_c.required' => 'Total Price (Corporate) is required',
                'total_price_c.numeric' => 'Total Price (Corporate) field should be number only',
                'total_price_c.not_zero' => 'Total Price (Corporate) field should not be zero',
                'tax_id.required' => 'Please Add Tax/Insurance',
                // 'tax_cost.required' => 'The Tax Cost is required.',
                // 'tax_cost.required' => 'The Tax Cost is numeric.',
            ]
        );

        $validate = [];
        $validate_msg = [];
        $pe_id = null;

        if ($request->input('state_id')) {
            $validate['state_id'] = 'required';
            $validate['city_id'] = ['required', new UniquePriceEntry($pe_id)];

            $validate_msg['state_id.required'] = 'The State Name is required.';
            $validate_msg['city_id.required'] = 'The City Name is required.';
        }
        if ($request->input('ut_id')) {
            $validate['ut_id'] = [new UniquePriceEntry($pe_id)];
        }

        $request->validate($validate, $validate_msg);

        // Data store
        $cityId = $request->city_id ?? array();
        
        if(count($cityId) == 0){
            $cityIdCount = 1;
        } else {
            $cityIdCount = count($cityId);
        }

        for($i=0; $i<$cityIdCount; $i++){

            DB::beginTransaction();
            $price_entry_store = new PriceEntry();

            try {
                $price_entry_store->brand_id = $request->brand_id;
                $price_entry_store->model_id = $request->model_id;
                $price_entry_store->variant_id = $request->variant_id;
                $price_entry_store->country_id = $request->country_id;
                $price_entry_store->state_id = isset($request->state_id) ? $request->state_id : $request->ut_id;
                $price_entry_store->city_id = isset($request->city_id[$i]) ? $request->city_id[$i] : null;
                // $price_entry_store->ut_id = isset($request->ut_id) ? $request->ut_id : null;
                $price_entry_store->against_city_id = $request->against_city_id;
                $price_entry_store->ex_showroom_price = $request->ex_showroom_price;
                $price_entry_store->i_rto_price = $request->i_rto_price;
                $price_entry_store->c_rto_price = $request->c_rto_price;
                
                $price_entry_store->tax_id = json_encode($request->tax_id);
                if ($request->has('tax_cost') && is_array($request->tax_cost)) {
                    $price_entry_store->tax_cost = json_encode($request->tax_cost);
                } else {
                    $price_entry_store->tax_cost = null;
                }

                $price_entry_store->total_price = $request->total_price;
                $price_entry_store->total_price_c = $request->total_price_c;

                $price_entry_store->created_by = auth()->id();
                $price_entry_store->status = $request->has('status') ? 1 : 0;
                $price_entry_store->save();
                DB::commit();

                session()->flash('success', 'Price Entry Added Successfully.');
            } catch (Exception $e) {
                DB::rollBack();
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                session()->flash('error', 'Something Went Wrong.');
            }
        }
        return redirect()->route('price_entry.view');
    }

    // View
    public function view()
    {
        if (!hasAnyPermission(['view_price_entry'])) {
            abort(403, "you don't have permission to access");
        }

        $price_entry_view = PriceEntry::select(
            'cop_pe_ms.*',
            'cop_brands_ms.brand_name as brand_name',
            'cop_models.model_name as model_name',
            'cop_variants.variant_name as variant_name',
            'cop_city_ms.city_name as city_name',
            'cop_state_ms.state_name as state_name',
            'cop_country_ms.country_name as country_name',
            'cop_taxes_ms.tax_name as tax_name',
            // 'cop_ut_ms.ut_name as ut_name',
            )
            ->leftJoin('cop_brands_ms', 'cop_pe_ms.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_models', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->leftJoin('cop_variants', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')

            ->leftJoin('cop_city_ms', 'cop_pe_ms.city_id', '=', 'cop_city_ms.city_id')
            ->leftJoin('cop_state_ms', 'cop_pe_ms.state_id', '=', 'cop_state_ms.state_id')
            ->leftJoin('cop_country_ms', 'cop_pe_ms.country_id', '=', 'cop_country_ms.country_id')
            ->leftJoin('cop_taxes_ms', 'cop_pe_ms.tax_id', '=', 'cop_taxes_ms.tax_id')
            // ->leftJoin('cop_ut_ms', 'cop_pe_ms.ut_id', '=', 'cop_ut_ms.ut_id')
            ->where([['cop_brands_ms.status','=',1],['cop_models.status','=',1],['cop_variants.status','=',1]])
            ->get();

        return view('price_entry.view', ['price_entry_view' => $price_entry_view]);
    }

    // Edit
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_price_entry'])) {
            abort(403, "you don't have permission to access");
        }

        $price_entry_edit = PriceEntry::where('pe_id', decrypt($id))->first();
        $brands = Brand::active()->get();
        $models = Model::where('brand_id', $price_entry_edit->brand_id)->active()->get();
        $variants = Variant::where('model_id', $price_entry_edit->model_id)->active()->get();
        $countries = Country::active()->get();
        $states = State::where('country_id', $price_entry_edit->country_id)->active() ->get();
        $cities = City::where('state_id', $price_entry_edit->state_id)->active()->get();
        $againstCityId = City::where('city_id', '!=', $price_entry_edit->city_id)->active()->get();
        $city_id_selected = $price_entry_edit->city_id;
        // $ut_city = unionTerritory::active()->get();

        $alltaxes = AllTax::where(function($query) use ($city_id_selected) {
                        $query->whereNull('city_id')
                            ->orWhere('city_id', $city_id_selected);
                    })
                    ->where('tax_name', '!=', 'TCS')
                    ->where('status','=','1')
                    ->get();

        return view('price_entry.edit', compact('price_entry_edit', 'brands', 'models', 'variants', 'countries', 'states', 'cities', 'alltaxes','againstCityId'));
    }

    // Update
    public function update(Request $request, $id)
    {
        Validator::extend('not_zero', function ($attribute, $value, $parameters, $validator) {
            return $value != 0;
        });

        $request->validate(
            [
                'brand_id' => 'required',
                'model_id' => 'required',
                'variant_id' => 'required',
                'country_id' => 'required',
                'ex_showroom_price' => 'required|numeric|min:200000|max:500000000',
                'i_rto_price' => 'required|numeric|not_zero',
                'c_rto_price' => 'required|numeric|not_zero',
                'total_price' => 'required|numeric|not_zero',
                'total_price_c' => 'required|numeric|not_zero',
                'tax_id' => 'required',
                // 'tax_cost' => 'required',
                // 'tax_cost' => 'required|array',
                // 'tax_cost.*' => 'nullable|numeric',
            ],
            [
                'brand_id.required' => 'The Brand Name is required.',
                'model_id.required' => 'The Model Name is required.',
                'variant_id.required' => 'The Variant Name is required.',
                'country_id.required' => 'The Country Name is required.',
                'ex_showroom_price.required' => 'The Ex-Showroom Price is required.',
                'ex_showroom_price.numeric' => 'The Ex-Showroom Price field should be number only.',
                'ex_showroom_price.min' => 'The Ex-Showroom Price must be at least :min.',
                'ex_showroom_price.max' => 'The Ex-Showroom Price must not exceed :max.',
                'total_price.required' => 'Total Price is required',
                'total_price.numeric' => 'Total Price field should be number only',
                'total_price.not_zero' => 'Total Price field should not be zero',
                'total_price_c.required' => 'Total Price (Corporate) is required',
                'total_price_c.numeric' => 'Total Price (Corporate) field should be number only',
                'total_price_c.not_zero' => 'Total Price (Corporate) field should not be zero',
                'tax_id.required' => 'Please Add Tax/Insurance.',
                // 'tax_cost.required' => 'The Tax Cost is required.',
                // 'tax_cost.required' => 'The Tax Cost is numeric.',
                // 'total_price' => 'Total Price Field is Numeric',

            ]
        );

        $price_entry_update = PriceEntry::find(decrypt($id));

        $validate_edit = [];
        $validate_msg_edit = [];
        $pe_id = $price_entry_update->pe_id;

        if ($request->input('state_id')) {
            $validate_edit['state_id'] = 'required';
            $validate_edit['city_id'] = ['required', new UniquePriceEntry($pe_id)];

            $validate_msg_edit['state_id.required'] = 'The State Name is required.';
            $validate_msg_edit['city_id.required'] = 'The City Name is required.';
        }
        if ($request->input('ut_id')) {
            $validate_edit['ut_id'] = [new UniquePriceEntry($pe_id)];
        }

        $request->validate($validate_edit,$validate_msg_edit);


            // Data Update
            DB::beginTransaction();
            try{
                $price_entry_update->brand_id = $request->brand_id;
                $price_entry_update->model_id = $request->model_id;
                $price_entry_update->variant_id = $request->variant_id;
                $price_entry_update->country_id = $request->country_id;
                // $s_id = '';
                // $u_id = '';

                // if (!empty($request->state_id)) {
                //     $state_id = explode("##", $request->state_id);
                //     if (!empty($state_id)) {
                //         if (count($state_id) == 2) {
                //             $u_id = $state_id[1];
                //             $price_entry_update->ut_id = $u_id;


                //             $price_entry_update->state_id = null;
                //         } else {
                //             $s_id = $state_id[0];
                //             $price_entry_update->state_id = $s_id;
                //             $price_entry_update->ut_id = null;
                //         }
                //     }
                // }
                $price_entry_update->state_id = isset($request->state_id) ? $request->state_id : $request->ut_id;
                $price_entry_update->city_id = isset($request->city_id) ? $request->city_id : null;
                // $price_entry_update->ut_id = isset($request->ut_id) ? $request->ut_id : null;
                $price_entry_update->against_city_id = $request->against_city_id;
                $price_entry_update->ex_showroom_price = $request->ex_showroom_price;
                $price_entry_update->i_rto_price = $request->i_rto_price;
                $price_entry_update->c_rto_price = $request->c_rto_price;

                $price_entry_update->tax_id = json_encode($request->tax_id) ?? array();
                if ($request->has('tax_cost') && is_array($request->tax_cost)) {
                    $price_entry_update->tax_cost = json_encode($request->tax_cost);
                } else {
                    $price_entry_update->tax_cost = array();
                }

                $price_entry_update->total_price = $request->total_price;
                $price_entry_update->total_price_c = $request->total_price_c;

                $price_entry_update->created_by = auth()->id();
                $price_entry_update->status = $request->has('status') ? 1 : 0;

                if ($price_entry_update->save()) {
                    DB::commit();
                    session()->flash('success', 'Price Entry Updated Successfully.');
                } else {
                    session()->flash('error', 'Something Went Wrong.');
                }
            } catch (Exception $e) {
                DB::rollBack();
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                session()->flash('error', 'Something Went Wrong.');
            }

        return redirect()->route('price_entry.view');
    }


    // Delete
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_price_entry'])) {
            abort(403, "you don't have permission to access");
        }
        $price_entry_destroy = PriceEntry::where('pe_id', decrypt($id))->first();
        DB::beginTransaction();
        try {
            if (!empty($price_entry_destroy)) {
                $price_entry_destroy->delete();
                DB::commit();
                session()->flash('success', 'Price Entry Deleted Successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('price_entry.view');
    }

    // Status Change
    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_pe_ms')
            ->where('pe_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

    // public function fetchtaxprice(Request $request)
    // {
    //     $exShowroomPrice = $request->input('exShowroomPrice');
    //     $selectedTaxes = $request->input('selectedTaxes');

    //     $calculatedTaxes = [];
    //     $totalCalculatedTax = 0;
    //     $totalPrice = $exShowroomPrice;

    //     foreach ($selectedTaxes as $selectedTax) {
    //         $taxId = (int) $selectedTax['id'];
    //         $tax = AllTax::find($taxId);

    //         if ($tax) {
    //             $tax_Percentage = $tax->tax_value;
    //             $tax_name = $tax->tax_name;

    //             $calculatedTax = ($exShowroomPrice * $tax_Percentage / 100);
    //             $totalCalculatedTax += $calculatedTax;

    //             $totalPrice += $calculatedTax;

    //             $calculatedTaxes[] = [
    //                 'tax_name' => $tax_name,
    //                 'tax_percentage' => $tax_Percentage,
    //                 'calculated_tax' => $calculatedTax,
    //                 'total_price' => $totalPrice,
    //             ];
    //         }
    //     }

    //     return response()->json(['success' => true, 'calculated_taxes' => $calculatedTaxes]);
    // }
}
