<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\CarListing;
use App\Models\CarListingData;
use App\Models\Model;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CarListingDataController extends Controller
{
    public function fetchModels(Request $request)
    {
        // dd($request->__call());
        try {
            $selectedBrandId = $request->input('brand_id');
            $cl_name = $request->input('cl_id');
            $type = !empty($cl_name) && $cl_name == 'EV Cars' ? 1 : 0;
            $models = [];
            $brands = Brand::active()->get(); // Fetch all brands
            if (!empty($selectedBrandId)) {
                // Fetch models for the selected brand, filter by model_type and status
                $models = Model::where('brand_id', $selectedBrandId)
                    ->where('model_type', $type)
                    ->active()
                    ->get();
            }

            // Return the models and brands in the response
            return response()->json(['models' => $models, 'brands' => $brands]);
        } catch (\Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
            // Log the error or handle it as needed
            return response()->json(['error' => 'An error occurred while fetching models.']);
        }
    }

    public function create()
    {
        if (!hasAnyPermission(['create_car_listing_data'])) {
            abort(403, "you don't have permission to access");
        }
        $car_listing = CarListing::all();
        $brands = Brand::active()->get();

        $models = Model::active()->get();
        return view('car_listing_data.create', compact('car_listing', 'brands', 'models'));
    }

    public function store(Request $request)
    {
        $request->validate(
            [
                'cl_id' => 'required|numeric',
                'brand_id' => 'required',
                'model_id' => 'required|unique:cop_cl_data,model_id'
            ],
            [
                'cl_id.required' => 'Select Car Listing Field is required',
                'cl_id.unique' => 'Selected Car Listing already exist',
                'brand_id.required' => 'Select Brand Field is required',
                'model_id.required' => 'Select Model Field is required',
                'model_id.unique' => 'This Model already exist',
            ]
        );
        DB::beginTransaction();
        try {
            $car_listing_data_store = new CarListingData();
            if ($car_listing_data_store) {
                $car_listing_data_store->cl_id = $request->cl_id;
                $car_listing_data_store->brand_id = $request->brand_id;
                $car_listing_data_store->model_id = $request->model_id;

                $car_listing_data_store->created_by = auth()->id();
                // $car_listing_data_store->updated_by = auth()->id();
                $car_listing_data_store->status = $request->has('status') ? 1 : 0;
                $car_listing_data_store->save();
                DB::commit();
                session()->flash('success', 'Car Listing Data Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_listing_data.view');
    }

    public function view()
    {
        if (!hasAnyPermission(['view_car_listing_data'])) {
            abort(403, "you don't have permission to access");
        }
        $car_listing_data_view = CarListingData::select('cop_cl_data.*', 'cop_cl_ms.cl_name as cl_name', 'cop_brands_ms.brand_name as brand_name', 'cop_models.model_name as model_name')
            ->leftJoin('cop_cl_ms', 'cop_cl_data.cl_id', '=', 'cop_cl_ms.cl_id')
            ->leftJoin('cop_brands_ms', 'cop_cl_data.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_models', 'cop_cl_data.model_id', '=', 'cop_models.model_id')
            ->where([['cop_brands_ms.status','=',1],['cop_models.status','=',1]])
            ->get();
        return view('car_listing_data.view', ['car_listing_data_view' => $car_listing_data_view]);
    }

    public function edit(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_car_listing_data'])) {
            abort(403, "you don't have permission to access");
        }
        $car_listing_data_edit = CarListingData::where('cl_data_id', decrypt($id))->first();
        $car_listing = CarListing::all();
        $brands = Brand::all();
        $type = "0";
        foreach ($car_listing as $list) {
            if ($list->cl_name == 'EV Cars') {
                $type = "1";

            }
        }
        // $cl_name = $request->input('cl_id');
        // $type = !empty($cl_name) && $cl_name == 'EV Cars' ? 1 : 0;

        //        $type = !empty($cl_name == 'EV Cars' || $cl_name == 'Popular Cars') ? 1 : 0;

        //        $models = DB::select("select * from cop_models where model_type = $type");
        // dump($car_listing_data_edit);
        $models = Model::where('brand_id', $car_listing_data_edit->brand_id)
            ->where('model_type', $type)
            ->active()
            ->get();
        // dd($models);
        return view('car_listing_data.edit', compact('car_listing_data_edit', 'car_listing', 'brands', 'models'));
    }

    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_car_listing_data'])) {
            abort(403, "you don't have permission to access");
        }
        $request->validate(
            [
                'model_id' => 'required|unique:cop_cl_data,model_id,' . decrypt($id) . ',cl_data_id',
                'cl_id' => 'required|numeric',
                'brand_id' => 'required',
            ],
            [
                'cl_id.required' => 'Car Listing is Required',
                'brand_id.required' => 'Brand Name is Required',
                'model_id.required' => 'Model Name is Required',
                'model_id.unique' => 'This Model already exist',
            ]
        );
        DB::beginTransaction();
        try {

            $car_listing_data_updates = CarListingData::where('cl_data_id', decrypt($id))->first();
            if ($car_listing_data_updates) {
                $car_listing_data_updates->cl_id = $request->cl_id;
                $car_listing_data_updates->brand_id = $request->brand_id;
                $car_listing_data_updates->model_id = $request->model_id;

                // $car_listing_data_updates->created_by = auth()->id();
                $car_listing_data_updates->updated_by = auth()->id();
                $car_listing_data_updates->status = $request->has('status') ? 1 : 0;
                $car_listing_data_updates->update();
                DB::commit();
                session()->flash('success', 'Car Listing Data Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('car_listing_data.view');
    }

    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_car_listing_data'])) {
            abort(403, "you don't have permission to access");
        }
        DB::beginTransaction();
        try {
            $car_listing_data_destroy = CarListingData::where('cl_data_id', decrypt($id))->first();

            if ($car_listing_data_destroy) {
                $car_listing_data_destroy->delete();
                DB::commit();

                session()->flash('success', 'Car Listing Data Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong!');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_listing_data.view');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_cl_data')
            ->where('cl_data_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
}
