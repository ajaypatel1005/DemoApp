<?php

namespace App\Http\Controllers;

use App\Models\BookTestDrive;
use Illuminate\Http\Request;

class BookTestDriveController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function list()
    {
        if (!hasAnyPermission(['book_test_drive'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $bookTestDrive = BookTestDrive::select('cop_book_test_drives.*','cop_brands_ms.brand_name','cop_models.model_name','cop_customers.first_name','cop_customers.last_name')
        ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_book_test_drives.brand_id')
        ->join('cop_models','cop_models.model_id','=','cop_book_test_drives.model_id')
        ->join('cop_customers','cop_customers.customer_id','=','cop_book_test_drives.customer_id')
        ->get();
        return view('book_test_drive.view',compact('bookTestDrive'));

    }

    /**
     * Show the form for creating a new resource.
     */
    public function status(Request $request)
    {
        if (!hasAnyPermission(['book_test_drive'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $btest_id = decrypt($request->btest_id);
        $btd = BookTestDrive::where('btest_id',$btest_id)->first();
        if($btd){
            $btd ->status = $request->statusVal;
            $btd ->save();
           session()->flash('success','Status Changed Successfully');
        }
        return redirect()->route('book_test_drive.list');
    }
    // }
    /**
     * Store a newly created resource in storage.
     */
    public function getStatusModel(Request $request)
    {
        if (!hasAnyPermission(['book_test_drive'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $btd_id = decrypt($request->id);
        $btd_data = BookTestDrive::where('btest_id', $btd_id)->first();
        return view('book_test_drive.status_model',compact('btd_id','btd_data'));
    }
}
