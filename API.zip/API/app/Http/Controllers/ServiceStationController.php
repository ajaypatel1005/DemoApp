<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\City;
use App\Models\ServiceStation;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Exception;
use App\Rules\GoogleMapsURL;

class ServiceStationController extends Controller
{
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_service_station', 'view_service_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $service_station_view = ServiceStation::select('cop_s_stations_ms.*', 'cop_brands_ms.brand_name as brand_name', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_brands_ms', 'cop_s_stations_ms.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_city_ms', 'cop_s_stations_ms.city_id', '=', 'cop_city_ms.city_id')
            ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
            ->get();

        $brands = Brand::active()->get();
        $states = State::active()->get();
        $city = City::active()->get();
        return view("service_station.create", compact("states", "city", "service_station_view", "brands"));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_service_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $request->validate(
            [
                's_station_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:2|max:50',
                'state_id' => 'required',
                'brand_id' => 'required',
                'city_id' => 'required',
                's_station_address' => 'required|min:2|max:1000|unique:cop_s_stations_ms,s_station_address',
                's_station_location' => ['required', 'string', 'unique:cop_s_stations_ms,s_station_location', new GoogleMapsURL],
                'contact_no' => 'required|min:10|max:10|regex:/^[0-9]+$/|unique:cop_s_stations_ms,contact_no',
                'email' => 'nullable|email|unique:cop_s_stations_ms,email',
            ],
            [
                's_station_name.required' => 'The Service Station Name is required.',
                // 's_station_name.unique' => 'The Service Station has already been taken.',
                's_station_name.regex' => 'The Service Station Name must contain letters, numbers, and special characters.',
                's_station_name.min' => 'The Service Station Name must be at least :min characters.',
                's_station_name.max' => 'The Service Station Name must not exceed :max characters.',
                'brand_id.required' => 'The Brand field is required.',
                'state_id.required' => 'The State field is required.',
                'city_id.required' => 'The City field is required.',

                's_station_address.required' => 'The Service Station Address is required.',
                's_station_address.regex' => 'The Service Station Address must contain only letters, numbers, and spaces.',

                's_station_location.unique' => 'Service Station Location has already been taken.',
                's_station_location.required' => 'The Service Station Location is required.',

                's_station_address.min' => 'The Service Station Address must be at least :min characters.',
                's_station_address.max' => 'The Service Station Address must not exceed :max characters.',
                's_station_address.unique' => 'Service Station Address has already been taken.',

                'contact_no.unique' => 'Contact No. has already been taken.',
                'contact_no.required' => 'Contact is required',
                'contact_no.min' => 'The Contact Number must be at least :min characters.',
                'contact_no.max' => 'The Contact Number must not exceed :max characters.',

                'email' => 'Email is required ',
                'email.email' => 'Please enter a valid email address',
                'email.unique' => 'This Email has already been taken.',
            ]
        );
        DB::beginTransaction();
        $service_station_store = new ServiceStation();
        try {

            $state_id = DB::table('cop_city_ms')
            ->where('city_id', $request->city_id)
            ->value('state_id');
            $service_station_store->brand_id = $request->brand_id;
            $service_station_store->state_id = $state_id;
            $service_station_store->city_id = $request->city_id;
            $service_station_store->s_station_name = $request->s_station_name;


            $service_station_store->s_station_address = $request->s_station_address;
            $service_station_store->s_station_location = $request->s_station_location;
            $service_station_store->contact_no = $request->contact_no;
            $service_station_store->email = $request->email;
            $service_station_store->created_by  = auth()->id();
            $service_station_store->status = $request->has('status') ? 1 : 0;
            $service_station_store->save();
            DB::commit();
            session()->flash('success', 'Service Station Added Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('service_station.create');
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_service_station', 'view_service_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $service_station_edit = ServiceStation::where('s_station_id', decrypt($id))->first();

        if ($service_station_edit) {

            $city_id = $service_station_edit->city_id;

            // dump('City ID:', $city_id);

            $selected_states = DB::table('cop_city_ms')->where('city_id', $city_id)->value('state_id');

            if ($selected_states) {

                $state_name = DB::table('cop_state_ms')->where('state_id', $selected_states)->value('state_name');

            //    dump('State Name:', $state_name);
            }


        $brands = Brand::active()->get();
        $states = State::active()->get();
        $city = City::active()->get();
        $service_station_view = ServiceStation::select('cop_s_stations_ms.*', 'cop_brands_ms.brand_name as brand_name', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_brands_ms', 'cop_s_stations_ms.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_city_ms', 'cop_s_stations_ms.city_id', '=', 'cop_city_ms.city_id')
            ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
            ->get();
        return view("service_station.edit", compact("states", "city", "service_station_edit", "brands", "service_station_view",'selected_states'));
    }
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_service_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
               's_station_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:2|max:50',
                ',s_station_id',
                'state_id' => 'required',
                'brand_id' => 'required',
                'city_id' => 'required',
                's_station_address' => 'required|min:2|max:1000|unique:cop_s_stations_ms,s_station_address,' . decrypt($id) . ',s_station_id',
                's_station_location' => ['required', 'string', new GoogleMapsURL],
                'contact_no' => 'required|min:10|max:10|regex:/^[0-9]+$/|unique:cop_s_stations_ms,contact_no,' . decrypt($id) . ',s_station_id',
                'email' => 'nullable|email|unique:cop_s_stations_ms,email,' . decrypt($id) . ',s_station_id',

            ],
            [
                's_station_name.required' => 'The Service Station Name is required.',
                's_station_name.regex' => 'The Service Station Name must contain only letters, numbers, and special characters.',
                's_station_name.min' => 'The Service Station Name must be at least :min characters.',
                's_station_name.max' => 'The Service Station Name must not exceed :max characters.',
                // 's_station_name.unique' => 'This Service Station Name has already been taken.',
                'brand_id.required' => 'The Brand Name is required.',
                'state_id.required' => 'The State Name is required.',
                'city_id.required' => 'The City Name is required.',

                's_station_address.required' => 'The Service Station Address is required.',
                's_station_address.min' => 'The Service Station Address must be at least :min characters.',
                's_station_address.max' => 'The Service Station Address must not exceed :max characters.',
                's_station_address.unique' => 'This Service Station Address has already been taken.',
                's_station_location.required' => 'The Service Station Location is required.',

                'contact_no.min' => 'The Contact Number must be at least :min characters.',
                'contact_no.max' => 'The Contact Number must not exceed :max characters.',
                'email' => 'Email Must be Valid',
                'email.email' => 'Please enter a valid email address',
                'email.unique' => 'This Email has already been taken.',
            ]
        );
        DB::beginTransaction();
        $service_station_update = ServiceStation::where('s_station_id', decrypt($id))->first();

        //dd($service_station_update);
        try {
            $state_id = DB::table('cop_city_ms')
            ->where('city_id', $request->city_id)
            ->value('state_id');
            $service_station_update->brand_id = $request->brand_id;
            $service_station_update->state_id = $state_id;
            $service_station_update->city_id = $request->city_id;
            $service_station_update->s_station_name = $request->s_station_name;


            $service_station_update->s_station_address = $request->s_station_address;
            $service_station_update->s_station_location = $request->s_station_location;
            $service_station_update->contact_no = $request->contact_no;
            $service_station_update->email = $request->email;
            $service_station_update->created_by  = auth()->id();
            $service_station_update->status = $request->has('status') ? 1 : 0;
            $service_station_update->save();
            DB::commit();
            session()->flash('success', 'Service Station Updated Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('service_station.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_service_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try{
            $fuel_station_destroy = ServiceStation::where('s_station_id', decrypt($id))->first();

            if (!empty($fuel_station_destroy)) {
                $fuel_station_destroy->delete();
                DB::commit();
                session()->flash('success', 'Service Station Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('service_station.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_s_stations_ms')
            ->where('s_station_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
}
