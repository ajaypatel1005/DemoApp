<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Color;
use App\Models\Model;
use App\Models\Variant;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class VariantController extends Controller
{

    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');

        if ($selectedBrandId) {

            $models = Model::where('brand_id', $selectedBrandId)
                ->active()
                ->get();
        } else {
            $models = [];
        }

        return response()->json(['models' => $models]);
    }

    public function create()
    {
        if (!hasAnyPermission(['create_variant'])) {
            abort(403, "you don't have permission to access");
        }
        $brands = Brand::active()->get();
        $models = Model::active()->get();
        return view('variant.create', compact('models', 'brands'));
    }

    public function store(Request $request)
    {

        if (!hasAnyPermission(['create_variant'])) {
            abort(403, "you don't have permission to access");
        }
        $request->validate([
            'brand_id' => 'required',
            'model_id' => 'required',
            'variant_name' => 'required|min:2',
            'variant_image' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
            // 'variant_name' => 'required|regex:/^[()A-Za-z0-9\s]+$/|min:2|max:30',
            // 'variant_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'seating_capacity' => 'required|numeric',
            'start_variant_color_code' => 'required',
            'end_variant_color_code' => 'required',
            'variant_color_name' => 'required',
            'variant_color_image.*' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048'
        ], [
            'brand_id.required' => 'Select Brand Field is required.',
            'model_id.required' => 'Select Model Field is required.',
            'variant_name.required' => 'Variant Name is required.',
            // 'variant_name.unique' => 'This Variant Name already exists.',
            // 'variant_name.regex' => 'The Variant Name must contain only letters, numbers, and spaces.',
            'variant_name.min' => 'The Variant Name must be at least :min characters.',
            // 'variant_name.max' => 'The Variant Name must not exceed :max characters.',

            'variant_image.required' => 'Variant Image is required.',
            'variant_image.image' => 'Variant Image must be an image file.',
            'variant_image.mimes' => 'Variant Image must be a PNG, JPG, JPEG, or WebP file.',
            'variant_image.max' => 'Variant image should not be greater than 2 MB.',
            'seating_capacity.required' => 'Seating Capacity Field is required.',
            'seating_capacity.numeric' => 'Seating capacity must be numeric.',
            'start_variant_color_code.required' => 'Start color code is required.',
            'end_variant_color_code.required' => 'End color code is required.',
            'variant_color_name.required' => 'Variant color name is required.',
            'variant_color_image.*.required' => 'Variant color image is required.',
            'variant_color_image.*.image' => 'Variant color image must be an image file.',
            'variant_color_image.*.mimes' => 'Variant color image must be a PNG, JPG, JPEG, or WebP file.',
            'variant_color_image.*.max' => 'Variant color image should not be greater than 2 MB.'
        ]);

        DB::beginTransaction();
        try {
            $variant_store = new Variant;

            if ($variant_store) {
                $brand_id = DB::table('cop_models')
                ->where('model_id', $request->model_id)
                ->value('brand_id');


                // dd($brand_id);
                // code for variant data store
                $variant_store->brand_id = $brand_id;
                $variant_store->model_id = $request->model_id;
                $variant_store->variant_name = $request->variant_name;
                $variant_store->seating_capacity = $request->seating_capacity;
                $variant_store->created_by = auth()->id();
                $variant_store->updated_by = auth()->id();
                $variant_store->status = $request->has('status') ? 1 : 0;
                $variant_store->save();


                // code for variant image store
                $variant_update = Variant::find($variant_store->variant_id);
                if ($variant_update) {
                    $variant_id = $variant_update->variant_id;
                    $uploadedImage = $request->file('variant_image');
                    $webpImageName = $variant_id . '.webp';
                    // $uploadedImage->move(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id, $webpImageName);

                     // create image manager with desired driver
                    $manager = new ImageManager(new Driver());
                    // main image
                    // read image from file system
                    $image = $manager->read($uploadedImage);
                    if(!is_dir(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id)){
                        mkdir(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id, 0777, true);
                    }
                    $image->toWebp()->save(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id.'/'.$webpImageName);

                    // Thumbnail image
                    if(!is_dir(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id.'/thumb')){
                        mkdir(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id.'/thumb', 0777, true);
                    }
                    $image->resize(216,102);
                    $image->toWebp()->save(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id.'/thumb/'.$webpImageName);


                    $variant_update->variant_image = $webpImageName;
                    $variant_update->update();


                    //code for varinat color and there image store
                    $startColorCodes = $request->input('start_variant_color_code');
                    $endColorCodes = $request->input('end_variant_color_code');
                    $colorNames = $request->input('variant_color_name');
                    $uploadedImages = $request->file('variant_color_image');
                    $totalColors = count($startColorCodes);

                    for ($key = 0; $key < $totalColors; $key++) {
                        $color_store = new Color;
                        $color_store->brand_id = $request->brand_id;
                        $color_store->model_id = $request->model_id;
                        $color_store->variant_id = $variant_update->variant_id;
                        $color_store->color_code = $startColorCodes[$key];

                        // Check if end color is provided or not
                        if (isset($endColorCodes[$key])) {
                            $color_store->dual_color_code = $endColorCodes[$key];
                        } else {
                            $color_store->dual_color_code = null;
                        }

                        $color_store->color_name = $colorNames[$key];
                        $uploadedImage = $uploadedImages[$key];

                        // Move the uploaded image to the designated folder
                        $webpImageName = $color_store->variant_id . '_' . (time() + $key) . '.webp';
                        // $uploadedImage->move(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id, $webpImageName);

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());
                        // main image
                        // read image from file system
                        $image = $manager->read($uploadedImage);
                        if(!is_dir(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id)){
                            mkdir(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id, 0777, true);
                        }
                        $image->toWebp()->save(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id.'/'.$webpImageName);

                        // Thumbnail image
                        if(!is_dir(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id.'/thumb')){
                            mkdir(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id.'/thumb', 0777, true);
                        }
                        $image->resize(676,348);
                        $image->toWebp()->save(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id.'/thumb/'.$webpImageName);



                        // Store the image name
                        $color_store->variant_color_image = $webpImageName;
                        $color_store->created_by = auth()->id();
                        $color_store->updated_by = auth()->id();
                        $color_store->save();
                    }
                    DB::commit();
                    session()->flash('success', 'Variant Added Successfully.');
                } else {
                    session()->flash('error', 'Model Not Found.');
                }
            } else {
                DB::rollBack();
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            // dd($e->getMessage());
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('variant.view');
    }

    public function view()
    {
        if (!hasAnyPermission(['view_variant'])) {
            abort(403, "you don't have permission to access");
        }
        $variant_view = DB::table('cop_variants')
            ->join('cop_models', 'cop_variants.model_id', '=', 'cop_models.model_id')
            ->join('cop_brands_ms', 'cop_variants.brand_id', '=', 'cop_brands_ms.brand_id')
            ->select('cop_variants.*', 'cop_brands_ms.brand_name', 'cop_models.model_name')
            ->where([['cop_brands_ms.status','=',1],['cop_models.status','=',1]])
            ->get();

        return view('variant.view', ['variant_view' => $variant_view]);
    }

    public function edit($id)
    {
        if (!hasAnyPermission(['edit_variant'])) {
            abort(403, "you don't have permission to access");
        }
        $variant_edit = Variant::where('variant_id', decrypt($id))->first();
        $brands = Brand::active()->get();
        $models = Model::where('brand_id', $variant_edit->brand_id)
            ->active()
            ->get();
        $colors = Color::where('variant_id', $variant_edit->variant_id)->get();

        return view('variant.edit', compact('variant_edit', 'brands', 'models', 'colors'));
    }


    public function update(Request $request, $id)
    {

        if (!hasAnyPermission(['edit_variant'])) {
            abort(403, "you don't have permission to access");
        }


        $request->validate([
            'brand_id' => 'required|numeric',
            'model_id' => 'required|numeric',
            'variant_name' => 'required|min:2',
            'variant_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'seating_capacity' => 'required|numeric',
            'start_variant_color_code.required' => 'Start color code is required.',
            'end_variant_color_code.required' => 'End color code is required.',
            'variant_color_name.required' => 'Variant color name is required.',
            'variant_color_image.*.required' => 'Variant color image is required.',
            'variant_color_image.*.image' => 'Variant color image must be an image file.',
            'variant_color_image.*.mimes' => 'Variant color image must be a PNG, JPG, JPEG, or WebP file.',
            // 'variant_color_image.*.max' => 'Variant color image should not be greater than 2 MB.'
        ], [
            'brand_id.required' => 'Brand name is required.',
            'brand_id.numeric' => 'Brand ID must be numeric.',
            'model_id.required' => 'Model Model is required.',
            'model_id.numeric' => 'Model ID must be numeric.',
            'variant_name.required' => 'Variant Name is required.',
            // 'variant_name.unique' => 'This Variant Name already exists.',
            // 'variant_name.regex' => 'The Variant Name must contain only letters, numbers, and spaces.',
            'variant_name.min' => 'The Variant Name must be at least :min characters.',
            // 'variant_name.max' => 'The Variant Name must not exceed :max characters.',
            'variant_image.image' => 'Variant image must be an image file.',
            'variant_image.mimes' => 'Variant image must be a PNG, JPG, JPEG, or WebP file.',
            'variant_image.max' => 'Variant image should not be greater than 2 MB.',
            'seating_capacity.required' => 'Seating capacity is required.',
            'seating_capacity.numeric' => 'Seating capacity must be numeric.',
            'start_variant_color_code.required' => 'Start color code is required.',
            'end_variant_color_code.required' => 'End color code is required.',
            'variant_color_name.required' => 'Variant color name is required.',
            'variant_color_image.*.required' => 'Variant color image is required.',
            'variant_color_image.*.image' => 'Variant color image must be an image file.',
            'variant_color_image.*.mimes' => 'Variant color image must be a PNG, JPG, JPEG, or WebP file.',
            // 'variant_color_image.*.max' => 'Variant color image should not be greater than 2 MB.'
        ]);
        DB::beginTransaction();
        try {
            $variant_update = Variant::where('variant_id', decrypt($id))->first();

            if ($variant_update) {
                $imagePath = public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id;


                $color_name = $request->variant_color_name;

                foreach ($color_name as $key => $value) {
                    $uploadedImage = $request->file('variant_color_image')[$key] ?? null;

                    if ($uploadedImage) {
                        $webpImageName = $variant_update->variant_id . '_' . (time() + $key) . '.webp';

                        // Check if there's an existing image for this variant
                        $existingColor = Color::where([
                            'variant_id' => $variant_update->variant_id,
                            'color_name' => $request->variant_color_name[$key]
                        ])->first();

                        // If an image exists, remove the previous one
                        if ($existingColor && $existingColor->variant_color_image) {
                            $existingImagePath = $imagePath . '/' . $existingColor->variant_color_image;
                            $existingThumbImagePath = $imagePath . '/thumb/' . $existingColor->variant_color_image;
                            if (file_exists($existingImagePath)) {
                                unlink($existingImagePath);
                            }

                            if (file_exists($existingThumbImagePath)) {
                                unlink($existingThumbImagePath);
                            }
                        }

                        // Store the new image
                        // $uploadedImage->move($imagePath, $webpImageName);

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());
                        // main image
                        // read image from file system
                        $image = $manager->read($uploadedImage);
                        if(!is_dir($imagePath)){
                            mkdir($imagePath, 0777, true);
                        }
                        $image->toWebp()->save($imagePath.'/'.$webpImageName);

                        // Thumbnail image
                        if(!is_dir($imagePath.'/thumb')){
                            mkdir($imagePath.'/thumb', 0777, true);
                        }
                        $image->resize(676,348);
                        $image->toWebp()->save($imagePath.'/thumb/'.$webpImageName);


                        // Update or create the Color record
                        Color::updateOrCreate(
                            ['variant_id' => $variant_update->variant_id, 'color_name' => $request->variant_color_name[$key]],
                            [
                                'brand_id' => $request->brand_id,
                                'model_id' => $request->model_id,
                                'color_code' => $request->start_variant_color_code[$key],
                                'dual_color_code' => $request->end_variant_color_code[$key] ?? null,
                                'color_name' => $request->variant_color_name[$key],
                                'variant_color_image' => $webpImageName,
                                'created_by' => auth()->id(),
                            ]
                        );
                    } else {
                        Color::updateOrCreate(
                            ['variant_id' => $variant_update->variant_id, 'color_name' => $request->variant_color_name[$key]],
                            [
                                'brand_id' => $request->brand_id,
                                'model_id' => $request->model_id,
                                'color_code' => $request->start_variant_color_code[$key],
                                'dual_color_code' => $request->end_variant_color_code[$key] ?? null,
                                'color_name' => $request->variant_color_name[$key],
                                'created_by' => auth()->id(),
                            ]
                        );
                    }
                }

                $uploadedVariantImage = $request->file('variant_image');
                if (!empty($uploadedVariantImage)) {
                    $imagePath = public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id;

                    $webpImageName = $variant_update->variant_id . '.webp';

                    $previousImagePath = $imagePath . '/' . $variant_update->variant_image;
                    if (file_exists($previousImagePath)) {
                        unlink($previousImagePath);
                    }

                    // $uploadedVariantImage->move($imagePath, $webpImageName);
                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());
                    // main image
                    // read image from file system
                    $image = $manager->read($uploadedVariantImage);
                    if(!is_dir($imagePath)){
                        mkdir($imagePath, 0777, true);
                    }
                    $image->toWebp()->save($imagePath.'/'.$webpImageName);

                    // Thumbnail image
                    if(!is_dir($imagePath.'/thumb')){
                        mkdir($imagePath.'/thumb', 0777, true);
                    }
                    $image->resize(216,102);
                    $image->toWebp()->save($imagePath.'/thumb/'.$webpImageName);
                    $variant_update->variant_image = $webpImageName;
                }


                $brand_id = DB::table('cop_models')
                ->where('model_id', $request->model_id)
                ->value('brand_id');
                $variant_update->brand_id = $brand_id;


                $variant_update->model_id = $request->model_id;
                $variant_update->variant_name = $request->variant_name;
                $variant_update->seating_capacity = $request->seating_capacity;
                $variant_update->status = $request->has('status') ? 1 : 0;
                $variant_update->update();
                DB::commit();
                session()->flash('success', 'Variant Updated Successfully.');
            } else {
                session()->flash('error', 'Variant Not Found.');
            }
        } catch (Exception $e) {
            // dd($e->getMessage());
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wong.');
        }
        return redirect()->route('variant.view');
    }


    public function deleteColor(Request $request)
    {
        $colorId = $request->input('color_id');
        $color = Color::find($colorId);
        $variantId = $color->variant_id;
        $variant = Variant::find($variantId);
        $brandId = $variant->brand_id;
        $modelId = $variant->model_id;

        if ($color) {
            $color->delete();
            if ($color->variant_color_image) {
                $img = 'brands' . '/' . $brandId . '/' . $modelId . '/' . $variantId . '/' . $color->variant_color_image;
                if (file_exists($img)) {
                    unlink($img);
                }
            }
            return response()->json(['message' => 'Color Deleted Successfully'], 200);
        }

        return response()->json(['message' => 'Color Not Found'], 404);
    }


    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_variant'])) {
            abort(403, "you don't have permission to access");
        }
        DB::beginTransaction();
        try {
            $variant_destroy = Variant::where('variant_id', decrypt($id))->first();

            if ($variant_destroy) {

                if ($variant_destroy->price_entry->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('variant.view');
                }

                $uploadedImageDirectory = public_path('brands') . '/' . $variant_destroy->brand_id . '/' . $variant_destroy->model_id . '/' . $variant_destroy->variant_id;

                if (File::exists($uploadedImageDirectory)) {
                    File::deleteDirectory($uploadedImageDirectory);
                }

                $variant_destroy->delete();
                DB::commit();
                session()->flash('success', 'Variant Deleted Successfully.');
            } else {
                session()->flash('error', 'Variant Not Found.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }

        return redirect()->route('variant.view');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_variants')
            ->where('variant_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }



}
