<?php

namespace App\Http\Controllers;

use App\Models\BuyNow;
use Illuminate\Http\Request;

class BuyNowController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function list()
    {
        if (!hasAnyPermission(['buy_now'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $buyNow = BuyNow::select('cop_buy_now.*',
        'cop_brands_ms.brand_name',
        'cop_models.model_name',
        'cop_customers.first_name',
        'cop_customers.last_name',
        'cop_variants.variant_name',
        'cop_colors.color_name','cop_state_ms.state_name','cop_city_ms.city_name'
        )
        ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_buy_now.brand_id')
        ->join('cop_models','cop_models.model_id','=','cop_buy_now.model_id')
        ->join('cop_variants','cop_variants.variant_id','=','cop_buy_now.variant_id')
        ->join('cop_colors','cop_colors.color_id','=','cop_buy_now.color_id')
        ->join('cop_state_ms','cop_state_ms.state_id','=','cop_buy_now.state_id')
        ->join('cop_city_ms','cop_city_ms.city_id','=','cop_buy_now.city_id')
        ->join('cop_customers','cop_customers.customer_id','=','cop_buy_now.customer_id')
        ->get();
        return view("buy_now.list",compact("buyNow"));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(BuyNow $buyNow)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(BuyNow $buyNow)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, BuyNow $buyNow)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(BuyNow $buyNow)
    {
        //
    }
}
