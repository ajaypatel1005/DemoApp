<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\CarStage;
use App\Models\CarType;
use App\Models\Model;
use App\Models\ModelSpecDisplay;
use App\Models\Rating;
use App\Models\RatingType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use DateTime;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class ModelController extends Controller
{

    public function fetchupcoming(Request $request)
    {
        $selectedCarStageId = $request->input('cs_id');

        if ($selectedCarStageId) {
            $carStage = CarStage::where('cs_id', $selectedCarStageId)->first();

            if ($carStage && $carStage->cs_name === 'Upcoming') {
                $currentDate = date('d-m-Y');
                $after5Years = date('d-m-Y', strtotime('+5 years', strtotime($currentDate)));

                $oldLaunchDate = old('launch_date', $request->launch_date ?? '');
                $formattedOldLaunchDate = $oldLaunchDate ? date('d-m-Y', strtotime($oldLaunchDate)) : '';

                $isUpcoming = '
                <label for="carStageName1" class="mb-2 required">Select Launch Date:</label>
                <div class="form-group col-lg-6">
                <div class="input-group" id="kt_td_picker_localization" data-td-target-input="nearest" data-td-target-toggle="nearest">

                    <input type="text" class="form-control" data-td-target="#kt_td_picker_localization" name="launch_date" min="' . $currentDate . '" max="' . $after5Years . '"
                    value="' . $formattedOldLaunchDate . '" placeholder="DD-MM-YYYY" readonly/>
                    <span class="input-group-text" data-td-target="#kt_td_picker_localization" data-td-toggle="datetimepicker">
                        <i class="ki-duotone ki-calendar fs-2"><span class="path1"></span><span class="path2"></span></i>
                    </span>
                </div>
                </div>
                <script>
                new tempusDominus.TempusDominus(document.getElementById("kt_td_picker_localization"), {
                    localization: {
                        locale: "en",
                        startOfTheWeek: 1,
                        format: "dd-MM-yyyy",
                    },
                    restrictions: {
                        minDate: "' . $currentDate . '",
                        maxDate: "' . $after5Years . '",
                        }
                });
                </script>
                ';
                // <div class="form-group col-lg-6 mb-6">
                //                     <label for="carStageName1" class="mb-2">Select Date:</label>
                //                     <input type="date" id="carStageName1" class="form-control" name="launch_date"
                //                         min="' . $currentDate . '" max="' . $after5Years . '"
                //                         value="' . $formattedOldLaunchDate . '" />
                //                 </div>
            } else {
                $isUpcoming = null;
            }
        } else {
            $carStage = null;
            $isUpcoming = null;
        }

        return response()->json(['car_stage' => $carStage, 'is_upcoming' => $isUpcoming]);
    }




    public function create()
    {
        if (!hasAnyPermission(['create_model'])) {
            abort(403, "you don't have permission to access");
        }
        $car_stages = CarStage::all();
        $car_types = DB::select('select * from cop_ct_ms');
        $brands = Brand::active()->get();
        return view('model.create', compact('car_stages', 'car_types', 'brands'));
    }

    public function store(Request $request)
    {
        Validator::extend('gt_or_equal', function ($attribute, $value, $parameters, $validator) {
            $minValue = $validator->getData()[$parameters[0]];
            return $value >= $minValue;
        });
        // dd($request->all());
        if (!hasAnyPermission(['edit_model'])) {
            abort(403, "you don't have permission to access");
        }
        // dd($request->all());
        $csId = $request->input('cs_id');
        $cs = CarStage::find($csId);
        $csName = $cs ? $cs->cs_name : null;
        $ratingValueRule = ($csName !== 'Upcoming') ? 'required' : 'nullable';
        $modelYear = ($csName !== 'Upcoming') ? 'required' : 'nullable';
        $lauchDate = ($csName == 'Upcoming') ? 'required' : 'nullable';
        $modelDescription = ($csName == 'Upcoming') ? 'nullable' : 'required|min:2|max:1000';
        $minPrice = ($csName == 'Upcoming') ? 'nullable' : 'required|numeric|min:200000|max:500000000';
        $maxPrice = ($csName == 'Upcoming') ? 'nullable' : 'required|numeric|min:200000|max:500000000|gt_or_equal:min_price';
        $modelType = ($csName == 'Upcoming') ? 'nullable' : 'required';
        $modelEngine = ($csName == 'Upcoming') ? 'nullable' : 'required|min:1|max:20';
        $modelBhp = ($csName == 'Upcoming') ? 'nullable' : 'required|min:1|max:20';
        $modelTransmission = ($csName == 'Upcoming') ? 'nullable' : 'required|min:1|max:20';
        $modelMileage = ($csName == 'Upcoming') ? 'nullable' : 'required|min:1|max:20';
        $modelFuel = ($csName == 'Upcoming') ? 'nullable' : 'required|min:1|max:30';
        // $modelName = $request->model_type == 0 ? 'None Ev' : 'Ev';
        $modelRatingTypeRule = ($csName !== 'Upcoming')
            ? [
                'required',
                Rule::in(['NCAP', 'BCAP']), // Assuming you want to validate against specific values
            ]
            : 'nullable';

        $request->validate(
            [
                'cs_id' => 'required',
                'ct_id' => 'required',
                'brand_id' => 'required',

                'model_name' => [
                    'required',
                    'min:2',
                    'max:30',
                    Rule::unique('cop_models')->where(function ($q) use ($request) {
                        return $q->where('model_type', $request->model_type)
                            ->where('model_name', $request->model_name);
                    }),
                ],
                'model_image' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
                'model_description' => $modelDescription,
                'launch_date' => $lauchDate,
                'model_year' => $modelYear,
                'min_price' => $minPrice,
                'max_price' => $maxPrice,
                'model_type' => $modelType,
                'model_engine' => $modelEngine,
                'model_bhp' => $modelBhp,
                'model_transmission' => $modelTransmission,
                'model_mileage' => $modelMileage,
                'model_fuel' => $modelFuel,
                'rating_value' => $ratingValueRule,
                'model_rating_type' => $modelRatingTypeRule,
            ],

            [
                'cs_id.required' => 'Select Car Stage Field is required.',
                'ct_id.required' => 'Select Car Type Field is required.',
                'brand_id.required' => 'Select Brand Field is required.',
                'model_name.required' => 'Model Name is required.',
                'model_name.min' => 'The Model Name must be at least :min characters.',
                'model_name.max' => 'The Model Name must not exceed :max characters.',
                'model_name.regex' => 'The Model Name must contain only letters, numbers, and spaces.',
                // 'model_name.unique' => 'This Model Name already exists.',
                'model_image.required' => 'Model image is required.',
                'model_image.image' => 'Model image must be an image file.',
                'model_image.mimes' => 'Model image must be a PNG, JPG, JPEG, or WebP file.',
                'model_image.max' => 'The maximum size of the image should not exceed 2MB.',
                'model_description.required' => 'The Model Description is required.',
                'model_description.regex' => 'The Model Description must contain only letters, alphanumeric, and spaces.',
                'model_description.min' => 'The Model Description must be at least :min characters.',
                'model_description.max' => 'The Model Description must not exceed :max characters.',
                // 'model_description.unique' => 'Model Description has already been taken.',
                'launch_date.required' => 'Model Date is required',
                'model_year.required' => 'Model Year is required',
                'min_price.required' => 'Minimum price is required.',
                'min_price.numeric' => 'Minimum price should be numeric.',
                'min_price.min' => 'The Minimum Price must be at least :min.',
                'min_price.max' => 'The Minimum Price must not exceed :max.',
                'max_price.required' => 'Maximum Price is required.',
                'max_price.numeric' => 'Maximum Price should be numeric.',
                'max_price.min' => 'The Maximum Price must be at least :min.',
                'max_price.max' => 'The Maximum Price must not exceed :max.',
                'max_price.gt_or_equal' => 'The Maximum Price must be greater than the Minimum Price.',
                'model_type.required' => 'Model type is required.',
                'model_engine.required' => 'This Field is required.',
                'model_engine.min' => 'This Field must be at least :min characters.',
                'model_engine.max' => 'This Field must not exceed :max characters.',
                'model_bhp.required' => 'This Field is required.',
                'model_bhp.min' => 'This Field must be at least :min characters.',
                'model_bhp.max' => 'This Field must not exceed :max characters.',
                'model_transmission.required' => 'This Field is required.',
                'model_transmission.min' => 'The Transmission must be at least :min characters.',
                'model_transmission.max' => 'The Transmission must not exceed :max characters.',
                'model_mileage.required' => 'This Field is required.',
                'model_mileage.min' => 'This Field must be at least :min characters.',
                'model_mileage.max' => 'The Field must not exceed :max characters.',
                'model_fuel.required' => 'This Field is required.',
                'model_fuel.min' => 'The Field must be at least :min characters.',
                'model_fuel.max' => 'The Field must not exceed :max characters.',
                'rating_value.required' => 'Model Rating Value field is required.',
                'model_rating_type.required' => 'Model Rating Type is required.',
                'model_ncap_rating.required_if' => 'Model NCAP rating is required when rating type is NCAP and Car stage is not Upcoming.',
                'model_bcap_rating.required_if' => 'Model BCAP rating is required when rating type is BCAP and Car stage is not Upcoming.',
                'max_price.gt' => 'The maximum price must be greater than the minimum price.',
            ]
        );

        DB::beginTransaction();
        try {
            $model_store = new Model;
            if ($model_store) {

                //code for model data store
                $model_store->cs_id = $request->cs_id;
                $model_store->launch_date = $request->launch_date;

                $launchDate = DateTime::createFromFormat('d-m-Y', $request->launch_date);
                if ($launchDate !== false) {
                    $model_store->launch_date = $launchDate->format('Y-m-d');
                }
                $model_store->ct_id = $request->ct_id;
                $model_store->brand_id = $request->brand_id;
                $model_store->model_name = $request->model_name;
                $model_store->model_description = $request->model_description;
                $model_store->min_price = $request->min_price;
                $model_store->max_price = $request->max_price;
                $carStage = CarStage::find($request->cs_id);
                if ($carStage->cs_name === 'Upcoming') {
                    $model_store->model_year = date('Y', strtotime($request->launch_date));
                } else {
                    $model_store->model_year = $request->model_year;
                }
                $model_store->model_type = $request->model_type;
                $model_store->cbu_status = $request->has('cbu_status') || isset($request->cbu_status) ? 1 : 0;
                $model_store->created_by = auth()->id();
                $model_store->updated_by = auth()->id();
                $model_store->status = $request->has('status') || !isset($request->status) ? 1 : 0;
                $model_store->save();

                //code for find model id
                $model_update = Model::find($model_store->model_id);
                $ncap = $request->input('model_rating_type');
                $rating = $request->input('rating_value');

                if ($csName === 'Launched') {
                    $rating_store = new Rating;

                    if ($rating_store) {
                        $rating_type_name = ($ncap == 'NCAP') ? 'NCAP' : 'BCAP';
                        $rating_type = RatingType::where('rating_type_name', $rating_type_name)->first();

                        if (!$rating_type) {
                            $rating_type = new RatingType(['rating_type_name' => $rating_type_name]);
                            $rating_type->status = $request->has('status') ? 1 : 0;
                            $rating_type->save();
                        }

                        $rating_store->brand_id = $model_update->brand_id;
                        $rating_store->model_id = $model_update->model_id;
                        $rating_store->rating_type_id = $rating_type->rating_type_id;
                        $rating_store->rating_value = $rating;
                        $rating_store->save();
                    }
                }


                // code for store model image using model id
                if ($model_update) {
                    $model_id = $model_update->model_id;
                    $uploadedImage = $request->file('model_image');
                    $webpImageName = $model_id . '.webp';
                    // $uploadedImage->move(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id, $webpImageName);

                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());

                    // read image from file system
                    // main image

                    $image = $manager->read($uploadedImage);
                    if(!is_dir(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id)){
                        mkdir(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id, 0777, true);
                    }
                    $image->toWebp()->save(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id.'/'.$webpImageName);

                    // Thumbnail image
                    if(!is_dir(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id.'/thumb')){
                        mkdir(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id.'/thumb', 0777, true);
                    }
                    $image->resize(333,206);
                    $image->toWebp()->save(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id.'/thumb/'.$webpImageName);

                    $model_update->model_image = $webpImageName;
                    $model_update->update();


                    // code for store model spec values in cop_msd table
                    $modelspec_store = new ModelSpecDisplay;

                    if ($modelspec_store) {
                        $modelspec_store->model_id = $model_update->model_id;
                        $modelspec_store->model_engine = $request->model_engine;
                        $modelspec_store->model_bhp = $request->model_bhp;
                        $modelspec_store->model_transmission = $request->model_transmission;
                        $modelspec_store->model_mileage = $request->model_mileage;
                        $modelspec_store->model_fuel = $request->model_fuel;
                        $modelspec_store->save();
                    }
                    DB::commit();
                    session()->flash('success', 'Model Added Successfully.');
                    return redirect()->route('model.view');
                } else {
                    session()->flash('error', 'Model Not Found.');
                }
            } else {
                DB::rollBack();
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('model.view');
    }

    public function view()
    {
        if (!hasAnyPermission(['view_model'])) {
            abort(403, "you don't have permission to access");
        }

        $model_view = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
            ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
            ->leftJoin('cop_ratings', function ($join) {
                $join->on('cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->where('cop_cs_ms.cs_name', '!=', 'Upcoming');
            })
            ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
            ->select(
                'cop_models.*',
                'cop_cs_ms.cs_name',
                'cop_brands_ms.brand_name',
                'cop_ct_ms.ct_name',
                DB::raw('COALESCE(cop_ratings.rating_value, "N/A") as rating_value'),
                'cop_rating_types.rating_type_name'
            )->where('cop_brands_ms.status','=',1) // check brand is active
            ->distinct()
            ->get();

        return view('model.view', ['model_view' => $model_view]);
    }


    public function edit($id)
    {
        if (!hasAnyPermission(['edit_model'])) {
            abort(403, "you don't have permission to access");
        }
        $model_edit = Model::where('model_id', decrypt($id))->first();
        $car_stages = CarStage::all();
        $car_types = CarType::all();
        $brands = Brand::active()->get();
        $msd = ModelSpecDisplay::where('model_id', decrypt($id))->first();

        $rating_edit = Rating::where('model_id', decrypt($id))->first();
        $rating_type_edit = null;

        if ($rating_edit) {
            $rating_type_edit = RatingType::where('rating_type_id', $rating_edit->rating_type_id)->first();
        } else {
            $rating_edit = [];
        }

        // dd($model_edit);
        return view('model.edit', compact('model_edit', 'car_stages', 'car_types', 'brands', 'rating_edit', 'msd', 'rating_type_edit'));
    }


    public function update(Request $request, $id)
    {
        Validator::extend('gt_or_equal', function ($attribute, $value, $parameters, $validator) {
            $minValue = $validator->getData()[$parameters[0]];
            return $value >= $minValue;
        });
        if (!hasAnyPermission(['edit_model'])) {
            abort(403, "you don't have permission to access");
        }

        // dd($request->all());
        $csId = $request->input('cs_id');
        $cs = CarStage::find($csId);
        $csName = $cs ? $cs->cs_name : null;

        $ratingValueRule = ($csName !== 'Upcoming') ? 'required' : 'nullable';
        $modelYear = ($csName !== 'Upcoming') ? 'required' : 'nullable';
        $lauchDate = ($csName == 'Upcoming') ? 'required' : 'nullable';
        $modelDescription = ($csName == 'Upcoming') ? 'nullable' : 'required|min:2|max:1000';
        $minPrice = ($csName == 'Upcoming') ? 'nullable' : 'required|numeric|min:200000|max:500000000';
        $maxPrice = ($csName == 'Upcoming') ? 'nullable' : 'required|numeric|min:200000|max:500000000|gt_or_equal:min_price';
        $modelType = ($csName == 'Upcoming') ? 'nullable' : 'required';
        $modelEngine = ($csName == 'Upcoming') ? 'nullable' : 'required|min:1|max:20';
        $modelBhp = ($csName == 'Upcoming') ? 'nullable' : 'required|min:1|max:20';
        $modelTransmission = ($csName == 'Upcoming') ? 'nullable' : 'required|min:1|max:20';
        $modelMileage = ($csName == 'Upcoming') ? 'nullable' : 'required|min:1|max:20';
        $modelFuel = ($csName == 'Upcoming') ? 'nullable' : 'required|min:1|max:30';

        $modelRatingTypeRule = ($csName !== 'Upcoming')
            ? [
                'required',
                Rule::in(['NCAP', 'BCAP']), // Assuming you want to validate against specific values
            ]
            : 'nullable';
        $model_id = decrypt($id);

        $request->validate([
            'cs_id' => 'required',
            'ct_id' => 'required',
            'brand_id' => 'required',
            'model_name' => [
                'required',
                'min:2',
                'max:30',
                Rule::unique('cop_models')->ignore(decrypt($id), 'model_id')->where(function ($q) use ($request) {
                    return $q->where('model_type', $request->model_type)->where('model_name', $request->model_name);
                })
            ],

            'launch_date' => $lauchDate,
            'model_year' => $modelYear,
            'model_image' => 'image|mimes:png,jpg,jpeg,webp|max:2048',
            'model_description' => $modelDescription,
            'min_price' => $minPrice,
            'max_price' => $maxPrice,
            'model_type' => $modelType,
            'model_engine' => $modelEngine,
            'model_bhp' => $modelBhp,
            'model_transmission' => $modelTransmission,
            'model_mileage' => $modelMileage,
            'model_fuel' => $modelFuel,
            'rating_value' => $ratingValueRule,
            'model_rating_type' => $modelRatingTypeRule,
        ], [
            'cs_id.required' => 'Select Car Stage Field is required.',
            'ct_id.required' => 'Select Car Type Field is required.',
            'brand_id.required' => 'Select Brand Field is required.',
            'model_name.required' => 'Model Name is required.',
            'model_name.min' => 'The Model Name must be at least :min characters.',
            'model_name.max' => 'The Model Name must not exceed :max characters.',
            'model_name.regex' => 'The Model Name must contain only letters, numbers, and spaces.',
            // 'model_name.unique' => 'This Model Name already exists.',
            'model_description.required' => 'The Model Description is required.',
            'model_description.regex' => 'The Model Description must contain only letters, alphanumeric, and spaces.',
            'model_description.min' => 'The Model Description must be at least :min characters.',
            'model_description.max' => 'The Model Description must not exceed :max characters.',
            // 'model_description.unique' => 'Model Description has already been taken.',
            'launch_date.required' => 'Model Date is required',
            'model_year.required' => 'Model Year is required',
            'model_image.image' => 'Model image must be an image file.',
            'model_image.mimes' => 'Model image must be a PNG, JPG, JPEG, or WebP file.',
            'model_image.max' => 'The maximum size of the image should not exceed 2MB.',
            'min_price.required' => 'Minimum price is required.',
            'min_price.numeric' => 'Minimum price should be numeric.',
            'min_price.min' => 'The Minimum Price must be at least :min.',
            'min_price.max' => 'The Minimum Price must not exceed :max.',
            'max_price.required' => 'Maximum Price is required.',
            'max_price.numeric' => 'Maximum Price should be numeric.',
            'max_price.min' => 'The Maximum Price must be at least :min.',
            'max_price.max' => 'The Maximum Price must not exceed :max.',
            'max_price.gt_or_equal' => 'The Maximum Price must be greater than the Minimum Price.',
            'model_type.required' => 'Model type is required.',
            'model_engine.required' => 'This Field is required.',
            'model_engine.min' => 'This Field must be at least :min characters.',
            'model_engine.max' => 'This Field must not exceed :max characters.',
            'model_bhp.required' => 'This Field is required.',
            'model_bhp.min' => 'This Field must be at least :min characters.',
            'model_bhp.max' => 'This Field must not exceed :max characters.',
            'model_transmission.required' => 'This Field is required.',
            'model_transmission.min' => 'The Transmission must be at least :min characters.',
            'model_transmission.max' => 'The Transmission must not exceed :max characters.',
            'model_mileage.required' => 'This Field is required.',
            'model_mileage.min' => 'This Field must be at least :min characters.',
            'model_mileage.max' => 'The Field must not exceed :max characters.',
            'model_fuel.required' => 'This Field is required.',
            'model_fuel.min' => 'The Field must be at least :min characters.',
            'model_fuel.max' => 'The Field must not exceed :max characters.',
            'model_rating_type.required' => 'Model Rating Type is required.',
            'rating_value.required' => 'Model Rating Value field is required.',
            'model_ncap_rating.required_if' => 'Model NCAP rating is required when rating type is NCAP and Car stage is not Upcoming.',
            'model_bcap_rating.required_if' => 'Model BCAP rating is required when rating type is BCAP and Car stage is not Upcoming.',
            'max_price.gt' => 'The maximum price must be greater than the minimum price.',
        ]);
        DB::beginTransaction();
        try {

            $model_update = Model::where('model_id', decrypt($id))->first();
            $ncap = $request->input('model_rating_type');
            $rating = $request->rating_value;

            if (!empty($model_update)) {

                $csId = $request->input('cs_id');
                $cs = CarStage::find($csId);
                $csName = $cs ? $cs->cs_name : null;

                if ($csName === 'Upcoming') {
                    $rating_store = Rating::where('brand_id', $model_update->brand_id)
                        ->where('model_id', $model_update->model_id)
                        ->first();

                    if ($rating_store) {
                        $rating_store->delete();
                    }
                } else {

                    $rating_type_name = ($ncap == 'NCAP') ? 'NCAP' : 'BCAP';
                    $rating_type = RatingType::where('rating_type_name', $rating_type_name)->first();
                    if (!$rating_type) {
                        $rating_type = new RatingType(['rating_type_name' => $rating_type_name]);
                        $rating_type->update();
                    }

                    Rating::updateOrcreate([
                        'brand_id' => $model_update->brand_id,
                        'model_id' => $model_update->model_id
                    ], [
                        'rating_type_id' => $rating_type->rating_type_id,
                        'rating_value' => $rating,
                    ]);
                }
            }

            if ($model_update) {
                if ($request->model_image) {
                    $previousImagePath = public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id . '/' . $model_update->model_image;
                    $previousThumbImagePath = public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id . '/thumb/' . $model_update->model_image;
                    if (file_exists($previousImagePath)) {
                        unlink($previousImagePath);
                    }
                    if (file_exists($previousThumbImagePath)) {
                        unlink($previousThumbImagePath);
                    }

                    $model_id = $model_update->model_id;
                    $uploadedImage = $request->file('model_image');
                    $webpImageName = $model_id . '.webp';
                    // $uploadedImage->move(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id, $webpImageName);
                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());

                    // main image
                    // read image from file system
                    $image = $manager->read($uploadedImage);
                    if(!is_dir(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id)){
                        mkdir(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id, 0777, true);
                    }
                    $image->toWebp()->save(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id.'/'.$webpImageName);

                    // Thumbnail image
                    if(!is_dir(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id.'/thumb')){
                        mkdir(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id.'/thumb', 0777, true);
                    }
                    $image->resize(333,206);
                    $image->toWebp()->save(public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id.'/thumb/'.$webpImageName);

                    $model_update->model_image = $webpImageName;
                }

                $model_update->cs_id = $request->cs_id;
                // $model_update->launch_date = date('Y-m-d', strtotime($request->launch_date));
                $model_update->launch_date = $request->launch_date;
                $launchDate = DateTime::createFromFormat('d-m-Y', $request->launch_date);
                if ($launchDate !== false) {
                    $model_update->launch_date = $launchDate->format('Y-m-d');
                }
                $model_update->ct_id = $request->ct_id;
                $model_update->brand_id = $request->brand_id;
                $model_update->model_name = $request->model_name;
                $model_update->model_description = $request->model_description;
                $model_update->min_price = $request->min_price;
                $model_update->max_price = $request->max_price;
                $carStage = CarStage::find($request->cs_id);
                if ($carStage->cs_name === 'Upcoming') {
                    $model_update->model_year = date('Y', strtotime($request->launch_date));
                } else {
                    $model_update->model_year = $request->model_year;
                }
                $model_update->model_type = $request->model_type;
                $model_update->cbu_status = $request->has('cbu_status') || isset($request->cbu_status) ? 1 : 0;
                $model_update->status = $request->has('status') ? 1 : 0;
                $model_update->update();

                $modelspec_store = ModelSpecDisplay::where('model_id', $model_update->model_id)->first();

                if ($modelspec_store) {
                    $modelspec_store->model_engine = $request->model_engine;
                    $modelspec_store->model_bhp = $request->model_bhp;
                    $modelspec_store->model_transmission = $request->model_transmission;
                    $modelspec_store->model_mileage = $request->model_mileage;
                    $modelspec_store->model_fuel = $request->model_fuel;

                    $modelspec_store->save();
                }

                DB::commit();
                session()->flash('success', 'Model Updated Successfully.');
            } else {
                session()->flash('error', 'Model Not Found.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('model.view');
    }

    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_model'])) {
            abort(403, "you don't have permission to access");
        }
        DB::beginTransaction();
        try {


            $model_destroy = Model::where('model_id', decrypt($id))->first();

            if ($model_destroy) {

                if ($model_destroy->variants->isNotEmpty() || $model_destroy->banners->isNotEmpty() || $model_destroy->car_graphics->isNotEmpty() || $model_destroy->car_listing_data->isNotEmpty() || $model_destroy->price_entry->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('model.view');
                }
                $uploadedImageDirectory = public_path('brands') . '/' . $model_destroy->brand_id . '/' . $model_destroy->model_id;
                if (File::exists($uploadedImageDirectory)) {
                    File::deleteDirectory($uploadedImageDirectory);
                }
                $model_destroy->delete();
                DB::commit();
                session()->flash('success', 'Model Deleted Successfully.');
            } else {
                session()->flash('error', 'Model Not Found Or Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('model.view');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_models')
            ->where('model_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
    public function toggleCbu(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_models')
            ->where('model_id', $id)
            ->update(['cbu_status' => DB::raw('IF(cbu_status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

}
