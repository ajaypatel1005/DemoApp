<?php

namespace App\Http\Controllers;

use App\Models\PageContent;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class PageContentController extends Controller
{
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_page_content'])) {
            abort(403, "you don't have permission to access");
        }
        return view('page_content.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'pc_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:2|max:50|unique:cop_pc,pc_name',

            'pc_title' => 'nullable|min:2|max:50',
            'pc_sub_title' => 'nullable|min:2|max:100',
            'pc_m_title' => 'nullable|min:2|max:50',
            'pc_m_sub_title' => 'nullable|min:2|max:100',
            'pc_b_text' => 'nullable|min:2|max:50',
            'pc_b_link' => 'nullable|min:2|max:500',

        ], [
            'pc_name.required' => 'The Page Content Name is required.',
            'pc_name.regex' => 'The Page Content Name must contain only letters, numbers, and spaces.',
            'pc_name.min' => 'The Page Content Name must be at least :min characters.',
            'pc_name.max' => 'The Page Content Name must not exceed :max characters.',
            'pc_name.unique' => 'The Page Content name is already taken, Please choose a different name.',

            'pc_title.min' => 'The Page Content Title must be at least :min characters.',
            'pc_title.max' => 'The Page Content Title must not exceed :max characters.',

            'pc_sub_title.min' => 'The Page Content Sub Title must be at least :min characters.',
            'pc_sub_title.max' => 'The Page Content Sub Title must not exceed :max characters.',

            'pc_b_text.min' => 'The Page Content Button Type must be at least :min characters.',
            'pc_b_text.max' => 'The Page Content Button Type must not exceed :max characters.',

            'pc_b_link.min' => 'The Page Content Button Link must be at least :min characters.',
            'pc_b_link.max' => 'The Page Content Button Link must not exceed :max characters.',
        ]);

        $action = $request->input('action');
        DB::beginTransaction();
        try {

            PageContent::create([
                'pc_name' => $request->pc_name,
                'pc_title' => $request->pc_title,
                'pc_sub_title' => $request->pc_sub_title,
                'pc_description' => $request->pc_description_hidden,
                'pc_m_title' => $request->pc_m_title,
                'pc_m_sub_title' => $request->pc_m_sub_title,
                'pc_m_description' => $request->pc_m_description_hidden,
                'pc_b_text' => $request->pc_b_text,
                'pc_b_link' => $request->pc_b_link,
                'pc_b_type' => $request->pc_b_type,
                'status' => $request->has('status') ? 1 : 0,
                'created_by' => auth()->id(),
            ]);
            DB::commit();
            session()->flash('success', 'Page Content Added Successfully.');
            if ($action === 'saveAndView') {
                return redirect()->route('page_content.view');
            } else {
                return redirect()->route('page_content.create');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            dd("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
            if ($action === 'saveAndView') {
                return redirect()->route('page_content.view');
            } else {
                return redirect()->route('page_content.create');
            }
        }

        //return redirect()->route('page_content.view');
    }

    /**
     * Display the specified resource.
     */
    public function view()
    {
        if (!hasAnyPermission(['view_page_content'])) {
            abort(403, "you don't have permission to access");
        }
        $page_content_view = PageContent::get();
        return view('page_content.view', ['page_content_view' => $page_content_view]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_page_content'])) {
            abort(403, "you don't have permission to access");
        }
        $page_content_edit = PageContent::where('pc_id', decrypt($id))->first();
        return view('page_content.edit', ['page_content_edit' => $page_content_edit]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_page_content'])) {
            abort(403, "you don't have permission to access");
        }
        $request->validate([
            'pc_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:2|max:50|unique:cop_pc,pc_name,' . decrypt($id) . ',pc_id',
            'pc_title' => 'nullable|min:2|max:50',
            'pc_sub_title' => 'nullable|min:2|max:50',

            'pc_m_title' => 'nullable|min:2|max:50',
            'pc_m_sub_title' => 'nullable|min:2|max:50',

            'pc_b_text' => 'nullable|min:2|max:50',
            'pc_b_link' => 'nullable|min:2|max:500',
        ], [
            'pc_name.required' => 'The Page Content Name is required.',
            'pc_name.regex' => 'The Page Content Name must contain only letters, numbers, and spaces.',
            'pc_name.min' => 'The Page Content Name must be at least :min characters.',
            'pc_name.max' => 'The Page Content Name must not exceed :max characters.',
            'pc_name.unique' => 'The Page Content name is already taken, Please choose a different name.',

            'pc_title.min' => 'The Page Content Title must be at least :min characters.',
            'pc_title.max' => 'The Page Content Title must not exceed :max characters.',

            'pc_sub_title.min' => 'The Page Content Sub Title must be at least :min characters.',
            'pc_sub_title.max' => 'The Page Content Sub Title must not exceed :max characters.',

            'pc_b_text.min' => 'The Page Content Button Type must be at least :min characters.',
            'pc_b_text.max' => 'The Page Content Button Type must not exceed :max characters.',

            'pc_b_link.min' => 'The Page Content Button Link must be at least :min characters.',
            'pc_b_link.max' => 'The Page Content Button Link must not exceed :max characters.',
        ]);
        DB::beginTransaction();
        try {
            $page_content_update = PageContent::where('pc_id', decrypt($id))->first();
            if (!empty($page_content_update)) {
                $page_content_update->pc_name = $request->pc_name;
                $page_content_update->pc_title = $request->pc_title;
                $page_content_update->pc_sub_title = $request->pc_sub_title;
                $page_content_update->pc_description = $request->pc_description_hidden;
                $page_content_update->pc_m_title = $request->pc_m_title;
                $page_content_update->pc_m_sub_title = $request->pc_m_sub_title;
                $page_content_update->pc_m_description = $request->pc_m_description_hidden;
                $page_content_update->pc_b_text = $request->pc_b_text;
                $page_content_update->pc_b_link = $request->pc_b_link;
                $page_content_update->pc_b_type = $request->pc_b_type;
                $page_content_update->status = $request->has('status') ? 1 : 0;
                $page_content_update->pc_b_type = $request->pc_b_type;
                $page_content_update->updated_by = auth()->id();
                $page_content_update->save();
                DB::commit();
                session()->flash('success', 'Page Content Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('page_content.view');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_page_content'])) {
            abort(403, "you don't have permission to access");
        }
        DB::beginTransaction();
        try {
            $page_content_destroy = PageContent::where('pc_id', decrypt($id))->first();

            if (!empty($page_content_destroy)) {
                DB::commit();
                $page_content_destroy->delete();
                session()->flash('success', 'Page Content Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('page_content.view');
    }


    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_pc')
            ->where('pc_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
}
