<?php

namespace App\Http\Controllers\Helpers;

use App\Models\Model;
use Illuminate\Support\Facades\DB;
use Response;

class CommanFunctionApi
{
    public function convertToLakhCrore($price)
    {
        if ($price >= 10000000) {
            return number_format($price / 10000000, 2) . ' Cr';
        } elseif ($price >= 100000) {
            return number_format($price / 100000, 2) . ' Lakh';
        } else {
            return $price;
        }
    }
    
    public function pricefilter($model_id)
    {
        $commanFunctionApi = new CommanFunctionApi();

        $priceMinMax = Model::select(
            DB::raw('MIN(cop_pe_ms.ex_showroom_price) as min_ex_showroom_price'),
            DB::raw('MAX(cop_pe_ms.ex_showroom_price) as max_ex_showroom_price')
        )
            ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->where('cop_models.model_id', $model_id)
            ->where('cop_models.model_type', '0')
            ->first();

        return [
            'price_filter' => $priceMinMax['min_ex_showroom_price'],
            'min_ex_showroom_price' => $commanFunctionApi->convertToLakhCrore($priceMinMax['min_ex_showroom_price']),
            'max_ex_showroom_price' => $commanFunctionApi->convertToLakhCrore($priceMinMax['max_ex_showroom_price']),
        ];
    }
}
