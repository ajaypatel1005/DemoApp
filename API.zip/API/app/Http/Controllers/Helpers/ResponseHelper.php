<?php

namespace App\Http\Controllers\Helpers;

use Response;

class ResponseHelper
{
    public static $responseCodes = [

        // SUCCESS
        'success' => 200,
        'created' => 201,
        'accepted' => 202,
        'no_content' => 204,

        // ERROR
        'error' => 400,
        'unauthorized' => 401,
        'disallowed' => 403,
        'data_not_found' => 404,
        'method_not_allowed' => 405,
        'request_timeout' => 408,
        'missing_required_field' => 428,
    ];

    public static $responseMessage = [
        // SUCCESS
        200 => 'Success',
        201 => 'Created',
        202 => 'Accepted',
        204 => 'No Content',

        // ERROR
        400 => 'Something Went Wrong',
        401 => 'Unauthorized',
        403 => 'Disallowed',
        404 => 'Data Not Found',
        405 => 'Method Not Allowed',
        408 => 'Request Timeout',
        428 => 'Missing required Field',
    ];

    /**
     * @param $code
     * @param array $data
     * @param string $message
     * @param string $version
     *
     * @return \Illuminate\Http\JsonResponse|string
     */
    public static function responseMessage($code, $data = array(), $message = '')
    {

        if (!is_numeric($code)) {
            $code = self::$responseCodes[$code];
            if ($message === '') {
                $message = self::$responseMessage[$code];
            }
        } else if ($message === '') {
            if (array_key_exists($code, self::$responseMessage)) {
                $message = self::$responseMessage[$code];
            } else {
                $message = 'Unknown Status';
            }
        }

        $request = request();

        $response = response()->json([
            'status' => true,
            'code' => $code,
            'msg' => $message,
            'msg_detail' => 'Success',
            'data' => $data
        ], $code);
        $response->header('Content-Type', 'application/json');

        return $response;
    }

    /**
     * @param array $errors
     * @param int $code
     *
     * @return \Illuminate\Http\JsonResponse|string
     */
    public static function errorResponse($code, $data = array(), $message = '')
    {
        if (!is_numeric($code)) {
            $code = self::$responseCodes[$code];
            if ($message === '') {
                $message = self::$responseMessage[$code];
            }
        } else if ($message === '') {
            // dd($message);
            if (array_key_exists($code, self::$responseMessage)) {
                $message = self::$responseMessage[$code];
            } else {
                $message = 'Unknown Status';
            }
        }

        $request = request();

        $array = [
            'status' => false,
            'code' => $code,
            'msg' => $message,
            'msg_detail' => $data ? $data : $message,
            'data' => [],
        ];

        $response = response()->json($array, $code);

        $response->header('Content-Type', 'application/json');

        return $response;
    }

    public static function errorResponseSMS($code, $data = array(), $message = '')
    {
        if (!is_numeric($code)) {
            $code = self::$responseCodes[$code];
            if ($message === '') {
                $message = self::$responseMessage[$code];
            }
        } else if ($message === '') {
            // dd($message);
            if (array_key_exists($code, self::$responseMessage)) {
                $message = self::$responseMessage[$code];
            } else {
                $message = 'Unknown Status';
            }
        }

        $request = request();

        $array = [
            'status' => false,
            'code' => $code,
            'msg' => 'Error',
            'msg_detail' => $data ? $data : $message,
            // 'data'=> []
        ];

        $response = response()->json($array, $code);

        $response->header('Content-Type', 'application/json');

        return $response;
    }
}
