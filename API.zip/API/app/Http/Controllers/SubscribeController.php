<?php

namespace App\Http\Controllers;

use App\Models\Subscribe;
use Exception;
use Illuminate\Support\Facades\Log;

class SubscribeController extends Controller
{
    public function index()
    {
        if (!hasAnyPermission(['view_subscribe'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $subscribeList = Subscribe::all();
        return view('subscribe.list', compact('subscribeList'));
    }

    public function delete($id)
    {
        if (!hasAnyPermission(['delete_subscribe'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        try {
            $deleteSub = Subscribe::where('id', decrypt($id))->first();
            if (!empty($deleteSub)) {
                $deleteSub->delete();
                session()->flash('success', 'Subscription has been delete successfully.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('subscribe');
    }
}
