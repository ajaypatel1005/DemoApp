<?php

namespace App\Http\Controllers;

use App\Models\City;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;

class CityController extends Controller
{

    public function create()
    {
        if (!hasAnyPermission(['create_city', 'view_city'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $state = State::active()->get();
        $city_view = City::select('cop_city_ms.*', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
            ->leftJoin('cop_country_ms', 'cop_country_ms.country_id', '=', 'cop_state_ms.country_id')
            ->where([['cop_state_ms.status', '=', 1], ['cop_country_ms.status', '=', 1]])
            ->get();
        return view('city.create', compact('city_view', 'state'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_city'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'state_id' => 'required',
                // 'city_name' => 'required|regex:/^[()A-Za-z\s]+$/|unique:cop_city_ms,city_name|min:2|max:35'
                'city_name' => [
                    'required',
                    'regex:/^[()A-Za-z\s]+$/',
                    'min:2',
                    'max:35',
                    Rule::unique('cop_city_ms')->where(function ($q) use ($request) {
                        return $q->where('city_name', $request->city_name)->where('state_id', $request->state_id);
                    })
                ],
                'city_image' => 'nullable|image|mimes:png,svg|max:2048',
                'tier' => 'required',
            ],
            [
                'state_id.required' => 'Select State is required',
                'city_name.regex' => 'City Name contain only letters and spaces.',
                'city_name.required' => 'City Name is required',
                'city_name.unique' => 'City Name has already been taken.',
                'city_name.min' => 'The City Name must be at least :min characters.',
                'city_name.max' => 'The City Name must not exceed :max characters.',
                // 'city_image.required' => 'Car Type Image required',
                'city_image.image' => 'This must be an Image',
                'city_image.mimes' => 'City Image must be png, svg',
                'city_image.max' => 'Image should not be greater than 2 MB',
                'tier.required' => 'Tier is required.'
            ]
        );

        DB::beginTransaction();
        try {
            $city_store = new City();
            if ($city_store) {
                $city_store->state_id = $request->state_id;
                $city_store->city_name = $request->city_name;
                $city_store->tier = $request->tier;
                $city_store->status = $request->has('status') ? 1 : 0;
                $city_store->save();

               // Handle the uploaded image
        if ($request->hasFile('city_image')) {
            $city_image_Uploaded_File = $request->file('city_image');
            $imageImageName = $city_store->city_id . '.' . $city_image_Uploaded_File->getClientOriginalExtension();
            $city_image_Uploaded_File->move(public_path('city_image') . '/' . $city_store->city_id, $imageImageName);
            $city_store->city_image = $imageImageName;
            $city_store->save(); // Update the city record with the image name
        }

                DB::commit();
                session()->flash('success', 'City Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong!');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('city.create');
    }



    public function edit($id)
    {
        if (!hasAnyPermission(['edit_city'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $state = State::active()->get();
        $city_view = City::select('cop_city_ms.*', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
            ->leftJoin('cop_country_ms', 'cop_country_ms.country_id', '=', 'cop_state_ms.country_id')
            ->where([['cop_state_ms.status', '=', 1], ['cop_country_ms.status', '=', 1]])
            ->get();
        $city_edit = City::where('city_id', decrypt($id))->first();
        return view('city.edit', compact('city_view', 'state', 'city_edit'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_city'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'state_id' => 'required',
                'city_name' => [
                    'required',
                    'regex:/^[()A-Za-z\s]+$/',
                    'min:2',
                    'max:35',
                    Rule::unique('cop_city_ms')->ignore(decrypt($id), 'city_id')->where(function ($q) use ($request) {
                        return $q->where('city_name', $request->city_name)->where('state_id', $request->state_id);
                    })
                ],
                'city_image' => 'nullable|image|mimes:png,svg|max:2048',
                'tier' => 'required',
            ],
            [
                'state_id.required' => 'State Must be Selected',
                'city_name.required' => 'City Name is required',
                'city_name.regex' => 'City Name contain only letters and spaces.',
                'city_name.unique' => 'City Name has already been taken.',
                'city_name.min' => 'The City Name must be at least :min characters.',
                'city_name.max' => 'The City Name must not exceed :max characters.',
                'tier.required' => 'Tier is required.',
                'city_image.image' => 'This must be an Image',
                'city_image.mimes' => 'Car Type Image must be png, svg',
                'city_image.max' => 'Image should not be greater than 2 MB'
            ]
        );
        DB::beginTransaction();
        try {
            $city_update = City::where('city_id', decrypt($id))->first();
            if ($city_update) {
                $city_update->state_id = $request->state_id;
                $city_update->city_name = $request->city_name;
                $city_update->tier = $request->tier;
                $city_update->status = $request->has('status') ? 1 : 0;
                $city_update->update();

               // Handle the uploaded image
            if ($request->hasFile('city_image')) {
                $city_image_Uploaded_File = $request->file('city_image');
                $imageImageName = $city_update->city_id . '.' . $city_image_Uploaded_File->getClientOriginalExtension();
                $city_image_Uploaded_File->move(public_path('city_image') . '/' . $city_update->city_id, $imageImageName);
                $city_update->city_image = $imageImageName;
                $city_update->save(); // Update the city record with the image name
            }

                DB::commit();
                session()->flash('success', 'City Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong!');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('city.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_city'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $city_destroy = City::where('city_id', decrypt($id))->first();

            if ($city_destroy) {

                if ($city_destroy->s_station->isNotEmpty() || $city_destroy->f_station->isNotEmpty() || $city_destroy->ev_station->isNotEmpty() || $city_destroy->price_entry->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('city.create');
                }

                $filePath = public_path('city_image') . '/' . $city_destroy->city_id . '/' . $city_destroy->city_image;
                $folderPath = public_path('city_image') . '/' . $city_destroy->city_id;
                if (File::exists($filePath)) {
                    File::delete($filePath);
                }
                // Check if the folder exists and delete it
                if (File::isDirectory($folderPath)) {
                    File::deleteDirectory($folderPath);
                }

                $city_destroy->delete();
                DB::commit();
                session()->flash('success', 'City Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wx`rong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('city.create');
    }


    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        // Perform the database update logic
        DB::table('cop_city_ms')
            ->where('city_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);

        return response()->json(['message', 'Status Updated Successfully']);
    }
}
