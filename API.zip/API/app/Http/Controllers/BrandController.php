<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Intervention\Image\ImageManager;
use Illuminate\Support\Str;

use Intervention\Image\Drivers\Gd\Driver;

class BrandController extends Controller
{
    public function create()
    {
        if (!hasAnyPermission(['create_brand', 'view_brand'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $brands_view = Brand::all();
        return view('brands.create', compact('brands_view'));
    }

    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_brand'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'brand_name' => 'required|min:2|max:30|unique:cop_brands_ms,brand_name',
                'brand_logo' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
                'brand_banner' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
                'brand_description' => 'required|min:2|max:1000|unique:cop_brands_ms,brand_description',

            ],
            [
                'brand_name.required' => 'Brand Name Required',
                'brand_logo.required' => 'Brand Logo Required',
                // 'brand_name.regex' => 'Brand Name is Invalid',
                'brand_logo.image' => 'This must be an Image',
                'brand_logo.mimes' => 'Brand Logo must be png,jpg,jpeg,webp',
                'brand_logo.max' => 'Brand Logo should not be greater than 2 MB',
                'brand_banner.required' => 'Brand Banner Required',
                'brand_banner.image' => 'This must be an Image',
                'brand_banner.mimes' => 'Brand Banner must be png,jpg,jpeg,webp',
                'brand_banner.max' => 'Brand Banner should not be greater than 2 MB',
                'brand_description.required' => 'The Brand Description is required.',
                'brand_description.min' => 'The Brand Description must be at least :min characters.',
                'brand_description.max' => 'The Brand Description must not exceed :max characters.',
                'brand_description.unique' => 'Brand Description has already been taken.',
                'brand_name.max' => 'Brand name field must not be greater than 25 characters',
                'brand_name.min' => 'Brand name field must be at least 2 characters',
            ]
        );
        DB::beginTransaction();
        try {
            $brands_store = new Brand();
            if ($brands_store) {
                $brands_store->brand_name = $request->brand_name;        //name

                $brands_store->slug = \Illuminate\Support\Str::slug($request->brand_name, '-');


                $brands_store->brand_description = $request->brand_description;
                $brands_store->created_by = auth()->id();     //description
                $brands_store->status = $request->has('status') ? 1 : 0;
                $brands_store->save();
                //Brand Logo
                $brand_id = $brands_store->brand_id;
                $brand_logo_Uploaded_File = $request->file('brand_logo');
                if (!empty($brand_logo_Uploaded_File)) {
                    $logoImageName = $brand_id . '.' . $brand_logo_Uploaded_File->getClientOriginalExtension();
                    $logoWebpImageName = $brand_id . '.webp';
                    // $brand_logo_Uploaded_File->move(public_path('brands') . '/' . $brand_id, $logoWebpImageName);
                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());

                    // main image
                    // read image from file system
                    $image = $manager->read($brand_logo_Uploaded_File);
                    if (!is_dir(public_path('brands') . '/' . $brand_id)) {
                        mkdir(public_path('brands') . '/' . $brand_id, 0777, true);
                    }
                    $image->toWebp()->save(public_path('brands') . '/' . $brand_id . '/' . $logoWebpImageName);

                    // Thumbnail image
                    if (!is_dir(public_path('brands') . '/' . $brand_id . '/thumb')) {
                        mkdir(public_path('brands') . '/' . $brand_id . '/thumb', 0777, true);
                    }
                    $image->resize(300, 200);
                    $image->toWebp()->save(public_path('brands') . '/' . $brand_id . '/thumb/' . $logoWebpImageName);
                    $brands_store->brand_logo = $logoWebpImageName;
                    $brands_store->update();
                }

                //Brand Banner
                $bannerUploadedFile = $request->file('brand_banner');
                if (!empty($bannerUploadedFile)) {
                    $bannerImageName = $brand_id . '.' . $bannerUploadedFile->getClientOriginalExtension();
                    $bannerWebpImageName = $brand_id . '_banner.webp';
                    $bannerUploadedFile->move(public_path('brands') . '/' . $brand_id, $bannerWebpImageName);
                    $brands_store->brand_banner = $bannerWebpImageName;
                    $brands_store->update();
                }
                DB::commit();
                session()->flash('success', 'Brand Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('brands.create');
    }




    public function edit($id)
    {
        if (!hasAnyPermission(['edit_brand', 'view_brand'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $brands_edit = Brand::where('brand_id', decrypt($id))->first();
        $brands_view = Brand::all();
        return view('brands.edit', compact('brands_edit', 'brands_view'));
    }

    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_brand'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'brand_name' => 'required|min:2|max:30|unique:cop_brands_ms,brand_name,' . decrypt($id) . ',brand_id',
                'brand_description' => 'required|min:2|max:1000|unique:cop_brands_ms,brand_description,' . decrypt($id) . ',brand_id',
                'brand_logo' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
                'brand_banner' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            ],
            [
                'brand_name.required' => 'Brand Name Required',
                // 'brand_name.regex'=>'Brand Name is Invalid',
                'brand_description.required' => 'The Brand Description is required.',
                'brand_description.min' => 'The Brand Description must be at least :min characters.',
                'brand_description.max' => 'The Brand Description must not exceed :max characters.',
                'brand_description.unique' => 'Brand Description has already been taken.',
                'brand_logo.required' => 'Brand Logo Required',
                'brand_logo.image' => 'This must be an Image',
                'brand_logo.mimes' => 'Brand Logo must be png,jpg,jpeg,webp',
                'brand_logo.max' => 'Brand Logo should not be greater than 2 MB',
                'brand_banner.required' => 'Brand Banner Required',
                'brand_banner.image' => 'This must be an Image',
                'brand_banner.mimes' => 'Brand Banner must be png,jpg,jpeg,webp',
                'brand_banner.max' => 'Brand Banner should not be greater than 2 MB',
                'brand_name.max' => 'Brand name field must not be greater than 25 characters',
                'brand_name.min' => 'Brand name field must be at least 2 characters',
            ]
        );
        DB::beginTransaction();
        try {
            $brands_update = Brand::WHERE('brand_id', decrypt($id))->first();
            $brand_id = $brands_update->brand_id;
            if (!empty($brands_update)) {
                $imagePath = 'brands/' . $brands_update->brand_id . '/' . $brands_update->brand_logo;
                $imageThumbPath = 'brands/' . $brands_update->brand_id . '/thumb/' . $brands_update->brand_logo;
                $imageBannerPath = 'brands/' . $brands_update->brand_id . '/' . $brands_update->brand_banner;

                //Brand Logo
                if (isset($request->brand_logo)) {
                    // Update brand_logo

                    // File::deleteDirectory($imagePath);

                    if (File::exists($imagePath)) {
                        File::delete($imagePath);
                    }
                    if (File::exists($imageThumbPath)) {
                        File::delete($imageThumbPath);
                    }
                    $brand_logo_Uploaded_File = $request->file('brand_logo');
                    $logoWebpImageName = $brand_id . '.webp';
                    // $brand_logo_Uploaded_File->move(public_path('brands') . '/' . $brand_id, $logoWebpImageName);
                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());

                    // main image
                    // read image from file system
                    $image = $manager->read($brand_logo_Uploaded_File);
                    if (!is_dir(public_path('brands') . '/' . $brand_id)) {
                        mkdir(public_path('brands') . '/' . $brand_id, 0777, true);
                    }
                    $image->toWebp()->save(public_path('brands') . '/' . $brand_id . '/' . $logoWebpImageName);

                    // Thumbnail image
                    if (!is_dir(public_path('brands') . '/' . $brand_id . '/thumb')) {
                        mkdir(public_path('brands') . '/' . $brand_id . '/thumb', 0777, true);
                    }
                    $image->resize(300, 200);
                    $image->toWebp()->save(public_path('brands') . '/' . $brand_id . '/thumb/' . $logoWebpImageName);
                    $brands_update->brand_logo = $logoWebpImageName;
                }
                //Brand Banner
                if (isset($request->brand_banner)) {
                    // Update brand_logo
                    // File::deleteDirectory($imagePath);
                    if (File::exists($imageBannerPath)) {
                        File::delete($imageBannerPath);
                    }

                    $bannerUploadedFile = $request->file('brand_banner');
                    $bannerImageName = $brand_id . '.' . $bannerUploadedFile->getClientOriginalExtension();
                    $bannerWebpImageName = $brand_id . '_banner.webp';
                    $bannerImagePath = public_path('brands') . '/' . $brand_id . '/' . $bannerImageName;
                    $bannerWebpImagePath = public_path('brands') . '/' . $brand_id . '/' . $bannerWebpImageName;
                    $bannerWebpThumbImagePath = public_path('brands') . '/' . $brand_id . '/thumb/' . $bannerWebpImageName;
                    // $bannerUploadedFile->move(public_path('brands') . '/' . $brand_id, $bannerWebpImageName);

                    if (File::exists($bannerWebpImagePath)) {
                        File::delete($imagePath);
                    }
                    if (File::exists($bannerWebpThumbImagePath)) {
                        File::delete($bannerWebpThumbImagePath);
                    }
                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());

                    // main image
                    // read image from file system
                    $image = $manager->read($bannerUploadedFile);
                    if (!is_dir(public_path('brands') . '/' . $brand_id)) {
                        mkdir(public_path('brands') . '/' . $brand_id, 0777, true);
                    }
                    $image->toWebp()->save(public_path('brands') . '/' . $brand_id . '/' . $bannerWebpImageName);

                    // Thumbnail image
                    if (!is_dir(public_path('brands') . '/' . $brand_id . '/thumb')) {
                        mkdir(public_path('brands') . '/' . $brand_id . '/thumb', 0777, true);
                    }
                    $image->resize(1920, 580);
                    $image->toWebp()->save(public_path('brands') . '/' . $brand_id . '/thumb/' . $bannerWebpImageName);

                    $brands_update->brand_banner = $bannerWebpImageName;
                }

                $brands_update->brand_name = $request->brand_name;        //name
                $brands_update->slug = \Illuminate\Support\Str::slug(strtolower($request->brand_name), '-');

                $brands_update->brand_description = $request->brand_description;     //description
                $brands_update->status = $request->has('status') ? 1 : 0;
                $brands_update->updated_by = auth()->id();
                $brands_update->update();
                DB::commit();
                session()->flash('success', 'Brand Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('brands.create');
    }

    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_brand'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $brands_delete = Brand::WHERE('brand_id', decrypt($id))->first();
        DB::beginTransaction();
        try {
            if ($brands_delete) {

                if ($brands_delete->models->isNotEmpty() || $brands_delete->variants->isNotEmpty() || $brands_delete->banners->isNotEmpty() || $brands_delete->car_graphics->isNotEmpty() || $brands_delete->car_listing_data->isNotEmpty() ||  $brands_delete->price_entry->isNotEmpty() || $brands_delete->manager->isNotEmpty()) {

                    session()->flash('error', 'This field value cannot be deleted because other records are using it.');
                    return redirect()->route('brands.create');
                }

                $filePath = public_path('brands') . '/' . $brands_delete->brand_id . '/' . $brands_delete->brand_logo;
                $folderPath = public_path('brands') . '/' . $brands_delete->brand_id;

                if (File::exists($filePath)) {
                    File::delete($filePath);
                }


                if (File::isDirectory($folderPath)) {
                    File::deleteDirectory($folderPath);
                }

                $brands_delete->delete();
                DB::commit();
                session()->flash('success', 'Brand Deleted successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('brands.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');

        DB::table('cop_brands_ms')
            ->where('brand_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);

        return response()->json(['message', 'Status Updated Successfully']);
    }
}
