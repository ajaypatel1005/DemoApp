<?php

namespace App\Http\Controllers\CRM;
use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Support\Facades\Log;
use App\Models\CRM\CallOutcome;
use Illuminate\Http\Request;

class CallOutcomeController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $CalloutcomeList = CallOutcome::get();
        return view('crm.calloutcome.create', compact('CalloutcomeList'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $request->validate(
            [
                'lco_name' => 'required|min:2|max:50|unique:cop_lead_call_outcome_ms,lco_name',
            ],
            [
                'lco_name.required' => 'Call Outcome Name Required',
                'lco_name.min' => 'The Call Outcome Name must be at least :min characters.',
                'lco_name.max' => 'The Call Outcome Name must not exceed :max characters.',
                'lco_name.unique' => 'Call Outcome Name has already been taken.',

            ]
        );
        try
        {
            $Calloutcome = new CallOutcome;
            $Calloutcome->lco_name=$request->lco_name;
            $Calloutcome->status = $request->has('status') ? 1 : 0;
            $Calloutcome->save();

            session()->flash('success', 'Call Outcome    Added Successfully.');

            return redirect()->route('call_outcome.create');
        }
        catch(Exception $e)
        {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(CallOutcome $leadSource)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {

        $CalloutcomeList=CallOutcome::get();
        $Calloutcome = CallOutcome::where('lco_id', decrypt($id))->first();
        return view('crm.calloutcome.edit',compact('CalloutcomeList','Calloutcome'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {

        $request->validate(
            [
                'lco_name' => 'required|min:2|max:50|unique:cop_lead_call_outcome_ms,lco_name,'.decrypt($id).',lco_id',
            ],
            [
                'lco_name.required' => 'Call Outcome Name Required',
                'lco_name.min' => 'The Call Outcome Name must be at least :min characters.',
                'lco_name.max' => 'The Call Outcome Name must not exceed :max characters.',
                'lco_name.unique' => 'Call Outcome Name has already been taken.',
            ]
        );
        try {
            $Calloutcome = CallOutcome::where('lco_id', decrypt($id))->first();
            if ($Calloutcome) {
                $Calloutcome->lco_name = $request->lco_name;
                $Calloutcome->status = $request->has('status') ? 1 : 0;
                $Calloutcome->update();

                session()->flash('success', 'Call Outcome Update Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('call_outcome.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        try {
            $Calloutcome = CallOutcome::where('lco_id', decrypt($id))->first();

            if ($Calloutcome) {
                $Calloutcome->delete();

                session()->flash('success', 'Call Outcome Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            return redirect()->route('call_outcome.create');

        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    /**
     * Toggle status feild active/Inactive.
     */
    public function toggleStatus(Request $request)
    {
        //Begin::toggle lead source status
        // dd($request->all());
        $id = $request->input('id');
        $Calloutcome = CallOutcome::find($id);
        $Calloutcome->status = $Calloutcome->status == 1 ? 0 : 1;
        $Calloutcome->save();
        //End::toggle lead source status

        return response()->json(['message' => 'Status updated successfully']);
    }
}
