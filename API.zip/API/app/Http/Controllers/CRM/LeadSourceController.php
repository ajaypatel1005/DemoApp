<?php

namespace App\Http\Controllers\CRM;
use App\Http\Controllers\Controller;

use App\Models\CRM\LeadSource;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LeadSourceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $leadSources = LeadSource::get();
        return view('crm.lead_source.create', compact('leadSources'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $request->validate(
            [
                'ls_name' => 'required|min:2|max:50|unique:cop_lead_source_ms,ls_name',
            ],
            [
                'ls_name.required' => 'Source Name Required',
                'ls_name.min' => 'The Source Name must be at least :min characters.',
                'ls_name.max' => 'The Source Name must not exceed :max characters.',
                'ls_name.unique' => 'Source Name has already been taken.',

            ]
        );
        try
        {
            $leadSource = new LeadSource;
            $leadSource->ls_name=$request->ls_name;
            $leadSource->status = $request->has('status') ? 1 : 0;
            $leadSource->save();

            session()->flash('success', 'Lead Source Added Successfully.');

            return redirect()->route('lead_source.create');
        }
        catch(Exception $e)
        {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(LeadSource $leadSource)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $leadSources=LeadSource::get();
        $leadSource = LeadSource::where('ls_id', decrypt($id))->first();
        return view('crm.lead_source.edit',compact('leadSources','leadSource'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        $request->validate(
            [
                'ls_name' => 'required|min:2|max:50|unique:cop_lead_source_ms,ls_name,'.decrypt($id).',ls_id',
            ],
            [
                'ls_name.required' => 'Source Name Required',
                'ls_name.min' => 'The Source Name must be at least :min characters.',
                'ls_name.max' => 'The Source Name must not exceed :max characters.',
                'ls_name.unique' => 'Source Name has already been taken.',
            ]
        );
        try {
            $leadSource = LeadSource::where('ls_id', decrypt($id))->first();
            if ($leadSource) {
                $leadSource->ls_name = $request->ls_name;
                $leadSource->status = $request->has('status') ? 1 : 0;
                $leadSource->update();

                session()->flash('success', 'Lead Source Update Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('lead_source.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        try {
            $leadSource = LeadSource::where('ls_id', decrypt($id))->first();

            if ($leadSource) {
                $leadSource->delete();

                session()->flash('success', 'Lead Source Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            return redirect()->route('lead_source.create');

        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    /**
     * Toggle status feild active/Inactive.
     */
    public function toggleStatus(Request $request)
    {
        //Begin::toggle lead source status
        $id = $request->input('id');
        $leadSource = LeadSource::find($id);
        $leadSource->status = $leadSource->status == 1 ? 0 : 1;
        $leadSource->save();
        //End::toggle lead source status

        return response()->json(['message' => 'Status updated successfully']);
    }
}
