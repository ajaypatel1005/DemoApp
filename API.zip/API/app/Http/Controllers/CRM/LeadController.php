<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\City;
use App\Models\Country;
use App\Models\CRM\Lead;
use App\Models\CRM\LeadHistory;
use App\Models\unionTerritory;
use App\Models\CRM\LeadPipeline;
use App\Models\CRM\LeadSource;
use App\Models\CRM\LeadStatus;
use App\Models\CRM\LeadType;
use App\Models\Manager;
use App\Models\Model;
use App\Models\State;
use App\Models\User;
use App\Models\Variant;
use App\Models\CRM\CallOutcome;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CRM\ActivityType;
use App\Models\CRM\DocumentType;
use App\Models\CRM\LeadActivity;
use App\Models\CRM\LeadNotes;
use Illuminate\Support\Facades\Validator;
use App\Models\CRM\LeadPipelineStage;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;

class LeadController extends Controller
{
    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');
        //dump($selectedBrandId);
        if ($selectedBrandId) {
            $models = Model::where('brand_id', $selectedBrandId)
                ->where('status', 1)
                ->get();
        } else {
            $models = [];
        }

        return response()->json(['models' => $models]);
    }

    public function fetchVariants(Request $request)
    {
        $selectedModelId = $request->input('model_id');

        if ($selectedModelId) {
            $variants = Variant::where('model_id', $selectedModelId)
                ->where('status', 1)
                ->get();
        } else {
            $variants = [];
        }

        return response()->json(['variants' => $variants]);
    }
    public function fetchStates(Request $request)
    {
        $selectedCountryId = $request->input('country_id');

        if ($selectedCountryId) {
            $states = State::where('country_id', $selectedCountryId)
                ->where('status', 1)
                ->get();

            $ut_name = unionTerritory::where('country_id', $selectedCountryId)
                ->where('status', 1)
                ->get();
        } else {
            $states = [];
            $ut_name = [];
        }

        return response()->json(['states' => $states, 'ut_name' => $ut_name]);
    }

    public function fetchCities(Request $request)
    {
        $selectedStateId = $request->input('state_id');

        if ($selectedStateId) {
            $cities = City::where('state_id', $selectedStateId)
                ->where('status', 1)
                ->get();
        } else {
            $cities = [];
        }

        return response()->json(['cities' => $cities]);
    }
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        

        $pipelines = LeadPipeline::all();
        $lead_source = LeadSource::all();
        $lead_status = LeadStatus::all();
        $lead_type = LeadType::all();
        $brand = Brand::all();
       
        $country = Country::all();
      
        $data = compact('pipelines', 'lead_source', 'lead_status', 'lead_type', 'brand', 'country');
        return view('crm.lead.create', $data);
    }

    public function list()
    {
        $Leads = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_pipeline_stage'])->get()->map(function ($lead) {
            $lead['id'] = encrypt($lead['lead_id']); // Encrypt lead_id and assign it to id
            // unset($lead['lead_id']); // Remove lead_id
            return $lead;
        });
        return response()->json(['Leads' => $Leads]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $validator = Validator::make(
            $request->all(),
            [
                'lead_name' => 'nullable|min:2|max:200',
                'lead_contact' => 'required|min:10|max:10|regex:/^[0-9]+$/',
                'lead_email' => 'nullable|email',
                'lead_address' => 'nullable|min:2|max:200',
                'brand_id' => 'nullable',
                'model_id' => 'nullable',
                'variant_id' => 'nullable',
                'manager_user_id' => 'nullable',
                'assign_id' => 'nullable',
                'lead_budget' => 'nullable|numeric',
                'country_id' => 'nullable',
                'state_id' => 'nullable',
                'city_id' => 'nullable',
                'lp_id' => 'nullable',
                'lps_id' => 'nullable',
                'ls_id' => 'nullable',
                'ls_status_id' => 'nullable',
                'lt_id' => 'nullable',
                'customer_id' => 'nullable',
                'exp_end_date' => 'nullable|date',
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
                'remark' => 'nullable|min:2|max:200',
            ],
            [
                'lead_name.min' => 'The lead name must be at least 2 characters.',
                'lead_name.max' => 'The lead name may not be greater than 200 characters.',
                'lead_contact.required' => 'Contact is required',
                'lead_contact.min' => 'The Contact Number must be at least :min characters.',
                'lead_contact.max' => 'The Contact Number must not exceed :max characters.',
                'lead_email.email' => 'Enter valid email address',
                'lead_address.min' => 'The lead address must be at least :min characters.',
                'lead_address.max' => 'The lead address may not be greater than :max characters.',
                'lead_budget.numeric' => 'The budget must be Number.',
                'exp_end_date.date' => 'The expected close date must be a valid date.',
                'start_date.date' => 'The start date must be a valid date.',
                'end_date.date' => 'The end date must be a valid date.',
                'end_date.after_or_equal' => 'The end date must be after or equal to the start date.',
                'remark.min' => 'The remark must be at least :min characters.',
                'remark.max' => 'The remark may not be greater than :max characters.',
            ]
        );

        if ($validator->fails()) {
            return ResponseHelper::errorResponse($validator->errors());
        }

        try {
            $lead = new Lead;
            $lead->lead_name = $request->lead_name;
            $lead->lead_contact = $request->lead_contact;
            $lead->lead_email = $request->lead_email;
            $lead->lead_address = $request->lead_address;
            $lead->brand_id = $request->brand_id;
            $lead->model_id = $request->model_id;
            $lead->variant_id = $request->variant_id;
            $lead->manager_user_id = $request->manager_user_id;
            $lead->assign_id = $request->assign_id;
            $lead->lead_budget = $request->lead_budget;
            $lead->country_id = $request->country_id;
            $lead->state_id = $request->state_id;
            $lead->city_id = $request->city_id;
            $lead->lp_id = $request->lp_id;
            $lead->ls_id = $request->ls_id;
            $lead->ls_status_id = $request->ls_status_id;
            $lead->lt_id = $request->lt_id;
            $lead->exp_end_date = $request->exp_end_date;
            $lead->start_date = $request->start_date;
            $lead->end_date = $request->end_date;
            $lead->remark = $request->remark;
            $lead->created_by = Auth::user()->id;
            $lead->save();

            // session()->flash('success', 'Lead Pipeline Added Successfully.');

            // return redirect()->route('lead.create');
            if ($lead) {
                return ResponseHelper::responseMessage('success', $lead, 'Lead Added Successfully.');
            } else {
                return ResponseHelper::errorResponse(['Error...While add Lead.!!']);
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            // session()->flash('error', 'Something Went Wrong.');
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request, $id)
    {

        $callOutcomeList = CallOutcome::where('status', 1)->get();
        $leadactivityType = ActivityType::where('status', 1)->get();
        $leadsname = Lead::get();
        $leadTypeList= LeadType::where('status', 1)->get();
        $leadSourceList= LeadSource::where('status', 1)->get();
        $documentType = DocumentType::where('status', 1)->get();
        return view('crm.lead.edit', compact('callOutcomeList', 'id', 'leadactivityType', 'leadsname','leadTypeList', 'leadSourceList','documentType'));
    }

    public function fetchmanager(Request $request)
    {
        try {
        $selectedBrandId = $request->input('brand_id');
        if ($selectedBrandId) {
                $roleNames = ['Relationship Manager','Telecaller'];

                // Begin::For Relationship Manager
                $rmUserIds = User::role($roleNames[0])->pluck('id');
                $managers = Manager::where('brand_id', $selectedBrandId)
                            ->whereIn('user_id',$rmUserIds)
                            ->where('status', 1)
                            ->get();
                // End::For Relationship Manager

                // Begin::For Telecaller
                $telecallerUserIds = User::role($roleNames[1])->pluck('id');
                $telecallers = Manager::where('brand_id', $selectedBrandId)
                            ->whereIn('user_id',$telecallerUserIds)
                            ->where('status', 1)
                            ->get();
                // End::For Telecaller

            } else {
                $managers = [];
                $telecallers = [];
            }

        return response()->json(['managers' => $managers,'telecallers'=>$telecallers]);

        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }

    }

    public function fetchDetail(Request $request)
    {
        $Lead = Lead::where('lead_id', decrypt($request->lead_id))->get();
        $Lead[0]['id'] = encrypt($Lead[0]->lead_id);
        unset($Lead[0]['lead_id']);
        return response()->json(['Lead' => $Lead]);
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        // echo "hello";exit;
        try {
            // Check if an ID is provided. If yes, it means we are updating an existing record.

            $lead_update = Lead::findOrFail(decrypt($request->lead_id));

            // Update or set the attributes

            $lead_update->lead_name = $request->lead_name;
            $lead_update->lead_contact = $request->lead_contact;
            $lead_update->lead_email = $request->lead_email;
            $lead_update->lead_address = $request->lead_address;
            $lead_update->brand_id = $request->brand_id;
            $lead_update->model_id = $request->model_id;
            $lead_update->variant_id = $request->variant_id;
            $lead_update->manager_user_id = $request->manager_user_id;
            $lead_update->assign_id = $request->assign_id;
            $lead_update->lead_budget = $request->lead_budget;
            $lead_update->country_id = $request->country_id;
            $lead_update->state_id = $request->state_id;
            $lead_update->city_id = $request->city_id;
            $lead_update->lp_id = $request->lp_id;
            $lead_update->ls_id = $request->ls_id;
            $lead_update->ls_status_id = $request->ls_status_id;
            $lead_update->lt_id = $request->lt_id;
            $lead_update->exp_end_date = $request->exp_end_date;
            $lead_update->start_date = $request->start_date;
            $lead_update->end_date = $request->end_date;
            $lead_update->remark = $request->remark;
            $lead_update->updated_by = Auth::user()->id;
            $lead_update->update();

            // Check if the activity was saved successfully

            return ResponseHelper::responseMessage('success', 'Lead Updated Successfully.');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function delete(Request $request)
    {
        try {
            // Find the activity by its ID
            $lead_delete = Lead::findOrFail(decrypt($request->lead_id));

            // Delete the activity
            $lead_delete->delete();

            // Check if the activity was deleted successfully
            return ResponseHelper::responseMessage('success', 'Lead Deleted Successfully.');
        } catch (Exception $e) {
            // Log any errors that occur during the deletion process
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());

            // Return an error response
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    public function leadDetail(Request $request)
    {
        try {
            $leadDetail = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_source', 'lead_pipeline_stage','car_brand','car_models','car_variant'])->where('lead_id', '=', decrypt($request->id))->first();
            $leadDetail['id'] = encrypt($leadDetail->lead_id);
            unset($leadDetail['lead_id']);
            $leadDetail->created_at_formatted = $leadDetail->created_at->format('Y-m-d H:i:s A');
            $leadPipelineStage = LeadPipelineStage::where('lp_id', $leadDetail->lp_id)->get();
            $leadActivity = LeadActivity::with('activity_type')
            ->where('lead_id', decrypt($request->id))
            ->orderBy('la_id', 'desc')
            ->get();
            return response()->json(['leadDetail' => $leadDetail, 'leadPipelineStage' => $leadPipelineStage, 'leadActivity' => $leadActivity]);
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            // session()->flash('error', 'Something Went Wrong.');
            return ResponseHelper::errorResponse(['Something Went Wrong.']);
        }
    }

    // Begin::change status win/lost/on hold or re-open for lead
    // if re-open then only insert into lead history table
    public function leadChangeStatus(Request $request)
    {
        try {
            $ls_status_id = null;
            $successMsg = null;
            if ($request->lead_status == "Win") {
                $ls_status_id = 1;
                $successMsg = "Lead move to Win";
            } elseif ($request->lead_status == "Lost") {
                $ls_status_id = 2;
                $successMsg = "Lead move to Lost";
            } elseif ($request->lead_status == "On Hold") {
                $ls_status_id = 3;
                $successMsg = "Lead is On Hold";
            } elseif ($request->lead_status == "Re Open") {
                $ls_status_id = null;
                $successMsg = "Lead is Re Open";
            }
            $leadStatusUpdate = Lead::findOrFail(decrypt($request->lead_id));
            $leadStatusUpdate->ls_status_id = $ls_status_id;

            if ($request->lead_status == "On Hold") {
            $leadStatusUpdate->hold_reminder_date =date('Y-m-d H:i:s', strtotime($request->hold_reminder_date));
            }
            if ($request->lead_status == "Re Open") {
                $leadStatusUpdate->hold_reminder_date =null;
            }

            $leadStatusUpdate->update();

            if ($leadStatusUpdate) {
                $leadHistory = new LeadHistory();
                $leadHistory->lead_id = $leadStatusUpdate['lead_id'];
                $leadHistory->lp_id = $leadStatusUpdate['lp_id'];
                $leadHistory->lps_id = $leadStatusUpdate['lps_id'];
                if ($request->lead_status == "Lost") {
                    $leadHistory->remarks = $request->lost_reason;
                }
                
                if ($request->lead_status == "Re Open") {
                    $leadHistory->ls_status_id = 4;
                } else {
                    $leadHistory->ls_status_id = $leadStatusUpdate['ls_status_id'];
                }

                if ($request->lead_status == "On Hold") {
                    $leadHistory->reminder_date =date('Y-m-d H:i:s', strtotime($request->hold_reminder_date));
                    $leadHistory->remarks = $request->hold_reason;
                }

                $leadHistory->lt_id = $leadStatusUpdate['lt_id'];
                $leadHistory->created_by = Auth::user()->id;
                $leadHistory->lh_type = "status";

                $leadHistory->save();
            }

            return ResponseHelper::responseMessage('success', $successMsg);
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse(['Something Went Wrong.']);
        }
    }
    // End::change status win/lost/on hold for lead

    public function stageChange(Request $request)
    {
        try {
            $leadStageUpdate = Lead::findOrFail(decrypt($request->lead_id));
            $leadStageUpdate->lps_id = $request->stage_id;
            $leadStageUpdate->update();

            if ($leadStageUpdate) {
                $leadHistory = new LeadHistory();
                $leadHistory->lead_id = $leadStageUpdate['lead_id'];
                $leadHistory->lp_id = $leadStageUpdate['lp_id'];
                $leadHistory->lps_id = $request->stage_id;
                $leadHistory->ls_status_id = $leadStageUpdate['ls_status_id'];
                $leadHistory->lt_id = $leadStageUpdate['lt_id'];
                $leadHistory->lh_type = "stage";
                $leadHistory->created_by = Auth::user()->id;
                $leadHistory->save();
            }
            return ResponseHelper::responseMessage('success', 'Stage Change Success..!!');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse(['Something Went Wrong.']);
        }
    }

    public function fetchAllActivityHistory(Request $request)
    {
        try {
            $leadHistory = LeadHistory::
            with(['lead_pipeline', 'lead_pipeline_stage',
            'lead_status','lead_notes','lead_activity', 'created_user','lead_call_log','lead_call_log.call_outcome'])
                ->where('lead_id', '=', decrypt($request->id))
                ->orderBy('lh_id', 'desc')
                ->get();

            $leadHistory->map(function ($history) {
                $history->created_at_formatted = $history->created_at->format('Y-m-d H:i:s A');
                return $history;
            });
            return response()->json(['leadHistory' => $leadHistory]);
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            // session()->flash('error', 'Something Went Wrong.');
            return ResponseHelper::errorResponse(['Something Went Wrong.']);
        }
    }



    /**
     * Update the specified resource in storage.
     */
    public function updateDetails(Request $request)
    {
        try {
            // Check if an ID is provided. If yes, it means we are updating an existing record.
            $lead_update = Lead::findOrFail(decrypt($request->lead_id));
            // Update or set the attributes
            $lead_update->lead_budget = $request->lead_budget;
            $lead_update->ls_id = $request->ls_id;
            $lead_update->lt_id = $request->lt_id;
            $lead_update->exp_end_date = $request->exp_end_date;
            $lead_update->update();
            // Check if the activity was saved successfully

            return ResponseHelper::responseMessage('success', 'Lead Updated Successfully.');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    // Begin::get telecaller list for current relationship manager login
    public function fetchTelecaller()
    {
        try {
                $roleNames = ['Relationship Manager','Telecaller'];

                $roles = auth()->user()->roles;
                if ($roles->first()->name==$roleNames[0]) {
                // Begin::For Relationship Manager
                $manager = Manager::where('user_id',Auth::user()->id)
                            ->where('status', 1)
                            ->get();
                
                // End::For Relationship Manager
                if($manager)
                {
                // Begin::For Telecaller
                $tcRoleUserIds = User::role($roleNames[1])->pluck('id');//role wise user ids get for telecaller list
                $telecallerList = Manager::where('brand_id', $manager[0]->brand_id)
                            ->whereIn('user_id',$tcRoleUserIds)
                            ->where('status', 1)
                            ->get();  
                // End::For Telecaller

                }
                else
                {
                    $telecallerList = [];
                }
            }
            else
            {
                $telecallerList = [];
            } 
           
        return response()->json(['telecallerList'=>$telecallerList]);

        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }

    }
    // End::get telecaller list for current relationship manager login

    // Begin::Assign lead to telecaller
    public function assignTelecaller(Request $request)
    {

        $validator = Validator::make(
            $request->all(),
            [
                'lead_ids' => 'required',
                'filter_assign_id' => 'required',
                
            ],
            [
                'lead_ids.required' => 'Please Select Leads',
                'filter_assign_id.required' => 'Please select Telecaller',
              
            ]
        );

        if ($validator->fails()) {
            return ResponseHelper::errorResponse($validator->errors());
        }
       
        try
        {
        $leadIds = $request->input('lead_ids');
         
        if(count($leadIds)<=0)
        {

        }
        else
        {
            $assignLead=Lead::whereIn('lead_id', $leadIds)
            ->update(['assign_id' => $request->filter_assign_id,'lt_id'=>2]);
    
            if($assignLead)
            {
                return ResponseHelper::responseMessage('success', 'Lead Assigned Successfully.');
            }
            else
            {
                return ResponseHelper::errorResponse(['Something Went Wrong.']);
            }
        }
        
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }
    }
    // End::Assign lead to telecaller

}
