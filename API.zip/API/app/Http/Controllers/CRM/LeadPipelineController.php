<?php

namespace App\Http\Controllers\CRM;
use App\Http\Controllers\Controller;

use App\Models\CRM\LeadPipeline;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LeadPipelineController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $leadPipelineList = LeadPipeline::get();
        return view('crm.lead_pipeline.create', compact('leadPipelineList'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate(
            [
                'lp_name' => 'required|min:2|max:50|unique:cop_lead_pipeline_ms,lp_name',
            ],
            [
                'lp_name.required' => 'Pipeline Name Required',
                'lp_name.min' => 'The Pipeline Name must be at least :min characters.',
                'lp_name.max' => 'The Pipeline Name must not exceed :max characters.',
                'lp_name.unique' => 'Pipeline Name has already been taken.',
               
            ]
        );
        try
        {
            $leadPipeline = new LeadPipeline;
            $leadPipeline->lp_name=$request->lp_name;
            $leadPipeline->status = $request->has('status') ? 1 : 0;
            $leadPipeline->save();

            session()->flash('success', 'Lead Pipeline Added Successfully.');
          
            return redirect()->route('lead_pipeline.create');
        }
        catch(Exception $e)
        {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $leadPipelineList=LeadPipeline::get();
        $leadPipeline = LeadPipeline::where('lp_id', decrypt($id))->first();
        return view('crm.lead_pipeline.edit',compact('leadPipelineList','leadPipeline'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        $request->validate(
            [
                'lp_name' => 'required|min:2|max:50|unique:cop_lead_pipeline_ms,lp_name,'.decrypt($id).',lp_id',
            ],
            [
                'lp_name.required' => 'Pipeline Name Required',
                'lp_name.min' => 'The Pipeline Name must be at least :min characters.',
                'lp_name.max' => 'The Pipeline Name must not exceed :max characters.',
                'lp_name.unique' => 'Pipeline Name has already been taken.',
            ]
        );
        try {
            $leadPipeline = LeadPipeline::where('lp_id', decrypt($id))->first();
            if ($leadPipeline) {
                $leadPipeline->lp_name = $request->lp_name;
                $leadPipeline->status = $request->has('status') ? 1 : 0;
                $leadPipeline->update();

                session()->flash('success', 'Lead Pipeline Update Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('lead_pipeline.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        try {
            $leadPipeline = LeadPipeline::where('lp_id', decrypt($id))->first();
           
            if ($leadPipeline) {
                $leadPipeline->delete();

                session()->flash('success', 'Lead Pipeline Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            return redirect()->route('lead_pipeline.create');

        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

     /**
     * Toggle status feild active/Inactive.
     */
    public function toggleStatus(Request $request)
    {
        //Begin::toggle status
        $id = $request->input('id');
        $leadPipeline = LeadPipeline::find($id);
        $leadPipeline->status = $leadPipeline->status == 1 ? 0 : 1;
        $leadPipeline->save();
        //End::toggle status

        return response()->json(['message' => 'Status updated successfully']);
    }
}
