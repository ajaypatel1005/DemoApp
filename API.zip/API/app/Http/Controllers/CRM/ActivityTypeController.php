<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CRM\ActivityType;
use Exception;
use Illuminate\Support\Facades\Log;

class ActivityTypeController extends Controller
{
    public function index()
    {
        //

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $activity_types = ActivityType::get();
        return view('crm.activity_type.create', compact('activity_types'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate(
            [
                'at_name' => 'required|min:2|max:50|unique:cop_activity_type,at_name',
            ],
            [
                'at_name.required' => 'Activity Name Required',
                'at_name.min' => 'The Activity Name must be at least :min characters.',
                'at_name.max' => 'The Activity Name must not exceed :max characters.',
                'at_name.unique' => 'Activity Name has already been taken.',

            ]
        );
        try
        {
            $activity_type = new ActivityType;
            $activity_type->at_name=$request->at_name;
            $activity_type->status = $request->has('status') ? 1 : 0;
            $activity_type->save();

            session()->flash('success', 'Activity Type Added Successfully.');

            return redirect()->route('activity_type.create');
        }
        catch(Exception $e)
        {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    // /**
    //  * Display the specified resource.
    //  */
    public function show(ActivityType $activity_type)
    {
        //
    }

    // /**
    //  * Show the form for editing the specified resource.
    //  */
    public function edit(string $id)
    {
        //
        $activity_types=ActivityType::get();
        $activity_type = ActivityType::where('at_id', decrypt($id))->first();
        return view('crm.activity_type.edit',compact('activity_types','activity_type'));
    }

    // /**
    //  * Update the specified resource in storage.
    //  */
    public function update(Request $request, string $id)
    {
        //
        $request->validate(
            [
                'at_name' => 'required|min:2|max:50|unique:cop_activity_type,at_name,'.decrypt($id).',at_id',
            ],
            [
                'at_name.required' => 'Activity Name Required',
                'at_name.min' => 'The Activity Name must be at least :min characters.',
                'at_name.max' => 'The Activity Name must not exceed :max characters.',
                'at_name.unique' => 'Activity Name has already been taken.',

            ]
        );
        try {
            $activity_type = ActivityType::where('at_id', decrypt($id))->first();
            if ($activity_type) {
                $activity_type->at_name = $request->at_name;
                $activity_type->status = $request->has('status') ? 1 : 0;
                $activity_type->update();

                session()->flash('success', 'Activity Type Update Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('activity_type.create');
    }

    // /**
    //  * Remove the specified resource from storage.
    //  */
    public function destroy(string $id)
    {
        //
        try {
            $activity_type = ActivityType::where('at_id', decrypt($id))->first();

            if ($activity_type) {
                $activity_type->delete();

                session()->flash('success', 'Activity Type Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            return redirect()->route('activity_type.create');

        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    // /**
    //  * Toggle status feild active/Inactive.
    //  */
    public function toggleStatus(Request $request)
    {
        //Begin::toggle lead source status
        $id = $request->input('id');
        $activity_type = ActivityType::find($id);
        $activity_type->status = $activity_type->status == 1 ? 0 : 1;
        $activity_type->save();
        //End::toggle lead source status

        return response()->json(['message' => 'Status updated successfully']);
    }
}