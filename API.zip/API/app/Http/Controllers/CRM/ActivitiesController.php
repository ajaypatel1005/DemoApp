<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CRM\ActivityType;
use App\Models\CRM\Lead;
use App\Models\CRM\LeadActivity;
use App\Models\CRM\LeadHistory;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ActivitiesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //

        $leadactivityType = ActivityType::where('status', 1)->get();
        $leadsname = Lead::get();
        $activities = LeadActivity::with(['activity_type', 'leads_details', 'created_lead'])->get();
        // dd($activities);
        return view('crm.activities.create', compact('leadactivityType', 'leadsname', 'activities'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validation rules with custom messages
        $validator = Validator::make(
            $request->all(),
            [
                'la_title' => 'required|min:2|max:200',
                'at_id' => 'required',
                'lead_id' => $request->has('edit_activty_lead_id') ? '' : 'required',
                'edit_activty_lead_id' => $request->has('edit_activty_lead_id') ? 'required' : '',
                'form_date' => 'nullable|date',
                'to_date' => 'nullable|date|after_or_equal:form_date',
            ],
            [
                'la_title.required' => 'The title is required.',
                'la_title.min' => 'The title must be at least :min characters.',
                'la_title.max' => 'The title must not exceed :max characters.',
                'at_id.required' => 'Select the Activity Type.',
                'lead_id.required' => 'Select the Lead.',
                'edit_activty_lead_id.required' => 'Select the Lead.',
                'form_date.date' => 'The from date must be a valid date.',
                'to_date.date' => 'The to date must be a valid date.',
                'to_date.after_or_equal' => 'The to date must be after or equal to the from date.',
            ]
        );

        // Check validation
        if ($validator->fails()) {
            return ResponseHelper::errorResponse($validator->errors());
        }

        try {

            $activity = new LeadActivity;
            $activity->la_title = $request->la_title;
            $activity->at_id = $request->at_id;
            if ($request->has('edit_activty_lead_id')) {
                $activity->lead_id = $request->edit_activty_lead_id;
            } else {
                $activity->lead_id = $request->lead_id;
            }
            $activity->form_date = date('Y-m-d H:i:s', strtotime($request->form_date));
            $activity->to_date = date('Y-m-d H:i:s', strtotime($request->to_date));
            $activity->reminder_datetime = date('Y-m-d H:i:s', strtotime($request->reminder));
            $activity->remarks = $request->remarks;
            $activity->created_by = Auth::user()->id;
            $activity->save();

            if ($activity) {

                $leadDetail = Lead::where('lead_id', $activity->lead_id)->first();
                    $leadHistory = new LeadHistory();
                    $leadHistory->lead_id = $leadDetail->lead_id;
                    $leadHistory->lp_id =$leadDetail->lp_id;
                    $leadHistory->lps_id =$leadDetail->lps_id;
                    $leadHistory->ls_status_id = $leadDetail->ls_status_id;
                    $leadHistory->lt_id = $leadDetail->lt_id;
                    $leadHistory->la_id = $activity->la_id;
                    $leadHistory->created_by = Auth::user()->id;
                    $leadHistory->lh_type = "activity";
                    $leadHistory->save();

                return ResponseHelper::responseMessage('success', 'Activity Added Successfully.');
            } else {
                return ResponseHelper::errorResponse(['Error...While add Activity.!!']);
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            // session()->flash('error', 'Something Went Wrong.');
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request)
    {
        $Activity = null;
        if ($request->has('activity_id')) {
            $Activity = LeadActivity::where('la_id', $request->activity_id)->get();
        } else {
            $Activity = LeadActivity::where('la_id', decrypt($request->la_id))->get();
        }
        $Activity[0]['id'] = encryptor('e',$Activity[0]->la_id);
        unset($Activity[0]['la_id']);
        return response()->json(['Activity' => $Activity]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {

        $validator = Validator::make(
            $request->all(),
            [
                'la_title' => 'required|min:2|max:200',
                'at_id' => 'required',
                'lead_id' => $request->has('edit_activty_lead_id') ? '' : 'required',
                'edit_activty_lead_id' => $request->has('edit_activty_lead_id') ? 'required' : '',
                'form_date' => 'nullable|date',
                'to_date' => 'nullable|date|after_or_equal:form_date',
            ],
            [
                'la_title.required' => 'The title is required.',
                'la_title.min' => 'The title must be at least :min characters.',
                'la_title.max' => 'The title must not exceed :max characters.',
                'at_id.required' => 'Select the Activity Type.',
                'lead_id.required' => 'Select the Lead.',
                'edit_activty_lead_id.required' => 'Select the Lead.',
                'form_date.date' => 'The from date must be a valid date.',
                'to_date.date' => 'The to date must be a valid date.',
                'to_date.after_or_equal' => 'The to date must be after or equal to the from date.',
            ]
        );

        // Check validation
        if ($validator->fails()) {
            return ResponseHelper::errorResponse($validator->errors());
        }

        try {
            // Check if an ID is provided. If yes, it means we are updating an existing record.

            $activity = LeadActivity::findOrFail(decrypt($request->la_id));


            // Update or set the attributes
            $activity->la_title = $request->la_title;
            $activity->at_id = $request->at_id;

            if ($request->has('edit_activty_lead_id')) {
                $activity->lead_id = $request->edit_activty_lead_id;
            } else {
                $activity->lead_id = $request->lead_id;
            }
            $activity->form_date = date('Y-m-d H:i:s', strtotime($request->form_date));
            $activity->to_date = date('Y-m-d H:i:s', strtotime($request->to_date));
            $activity->reminder_datetime = date('Y-m-d H:i:s', strtotime($request->reminder));
            $activity->remarks = $request->remarks;
            $activity->updated_by = Auth::user()->id;

            $activity->update();

            // Check if the activity was saved successfully


            return ResponseHelper::responseMessage('success', 'Activity Updated Successfully.');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function delete(Request $request)
    {
        try {
            // Find the activity by its ID
            if ($request->has('la_delete_id')) {
                $activity = LeadActivity::findOrFail($request->la_delete_id);
            } else {
                $activity = LeadActivity::findOrFail(decrypt($request->la_id));
            }
            // Delete the activity
            $activity->delete();

            // Check if the activity was deleted successfully
            return ResponseHelper::responseMessage('success', 'Activity Deleted Successfully.');
        } catch (Exception $e) { // Specify the exception type as \Exception
            // Log any errors that occur during the deletion process
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());

            // Return an error response
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    public function list()
    {
        $Activity = LeadActivity::with(['activity_type', 'leads_details', 'created_lead'])->get()->map(function ($activity) {
            $activity['id'] = encryptor('e',$activity['la_id']); // Encrypt la_id and assign it to id
            unset($activity['la_id']); // Remove la_id
            // $activity['la_id']=$activity['id'];
            return $activity;
        });

        // foreach ($Activity as $activity) {
        //     $activity['la_id'] = encrypt($activity->la_id);
        // }
        return response()->json(['Activity' => $Activity]);
    }

    public function toggleStatus(Request $request)
    {
        $la_id = $request->input('la_id');

        DB::table('cop_lead_activity')
            ->where('la_id', $la_id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);

        return response()->json(['message' => 'Status Updated Successfully']);
    }
}
