<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\CRM\LeadType;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LeadTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $all_leadtype = LeadType::get();
        return view('crm.lead_type.create', compact('all_leadtype'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate(
            [
                'lt_name' => 'required|min:2|max:50|unique:cop_lead_type_ms,lt_name',
            ],
            [
                'lt_name.required' => 'Lead Type Name Required',
                'lt_name.min' => 'The Lead Type Name must be at least :min characters.',
                'lt_name.max' => 'The Lead Type Name must not exceed :max characters.',
                'lt_name.unique' => 'Lead Type Name has already been taken.',

            ]
        );
        try
        {
            $leadtype = new LeadType;
            $leadtype->lt_name=$request->lt_name;
            $leadtype->status = $request->has('status') ? 1 : 0;
            $leadtype->save();

            session()->flash('success', 'Lead Type Added Successfully.');

            return redirect()->route('lead_type.create');
        }
        catch(Exception $e)
        {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    // /**
    //  * Display the specified resource.
    //  */
    public function show(LeadType $leadtype)
    {
        //
    }

    // /**
    //  * Show the form for editing the specified resource.
    //  */
    public function edit(string $id)
    {
        //
        $all_leadtype=LeadType::get();
        $leadtype = LeadType::where('lt_id', decrypt($id))->first();
        return view('crm.lead_type.edit',compact('all_leadtype','leadtype'));
    }

    // /**
    //  * Update the specified resource in storage.
    //  */
    public function update(Request $request, string $id)
    {
        //
        $request->validate(
            [
                'lt_name' => 'required|min:2|max:50|unique:cop_lead_type_ms,lt_name,'.decrypt($id).',lt_id',
            ],
            [
                'lt_name.required' => 'Lead Type Name Required',
                'lt_name.min' => 'The Lead Type Name must be at least :min characters.',
                'lt_name.max' => 'The Lead Type Name must not exceed :max characters.',
                'lt_name.unique' => 'Lead Type Name has already been taken.',

            ]
        );
        try {
            $leadtype = LeadType::where('lt_id', decrypt($id))->first();
            if ($leadtype) {
                $leadtype->lt_name = $request->lt_name;
                $leadtype->status = $request->has('status') ? 1 : 0;
                $leadtype->update();

                session()->flash('success', 'Lead Type Update Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('lead_type.create');
    }

    // /**
    //  * Remove the specified resource from storage.
    //  */
    public function destroy(string $id)
    {
        //
        try {
            $leadtype = LeadType::where('lt_id', decrypt($id))->first();

            if ($leadtype) {
                $leadtype->delete();

                session()->flash('success', 'Lead Type Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            return redirect()->route('lead_type.create');

        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    // /**
    //  * Toggle status feild active/Inactive.
    //  */
    public function toggleStatus(Request $request)
    {
        //Begin::toggle lead source status
        $id = $request->input('id');
        $leadtype = LeadType::find($id);
        $leadtype->status = $leadtype->status == 1 ? 0 : 1;
        $leadtype->save();
        //End::toggle lead source status

        return response()->json(['message' => 'Status updated successfully']);
    }
}
