<?php

namespace App\Http\Controllers\CRM;
use App\Http\Controllers\Controller;

use App\Models\CRM\DocumentType;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class DocumentTypeController extends Controller
{
    public function index()
    {
        //

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $all_document_type = DocumentType::get();
        return view('crm.document_type.create', compact('all_document_type'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate(
            [
                'dt_name' => 'required|min:2|max:50|unique:cop_document_type_ms,dt_name',
            ],
            [
                'dt_name.required' => 'Document Name Required',
                'dt_name.min' => 'The Document Name must be at least :min characters.',
                'dt_name.max' => 'The Document Name must not exceed :max characters.',
                'dt_name.unique' => 'Document Name has already been taken.',

            ]
        );
        try
        {
            $document_type = new DocumentType;
            $document_type->dt_name=$request->dt_name;
            $document_type->status = $request->has('status') ? 1 : 0;
            $document_type->save();

            session()->flash('success', 'Document Type Added Successfully.');

            return redirect()->route('document_type.create');
        }
        catch(Exception $e)
        {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    // /**
    //  * Display the specified resource.
    //  */
    public function show(DocumentType $document_type)
    {
        //
    }

    // /**
    //  * Show the form for editing the specified resource.
    //  */
    public function edit(string $id)
    {
       
        $all_document_type=DocumentType::get();
        $DocumentType = DocumentType::where('dt_id', decrypt($id))->first();
        return view('crm.document_type.edit',compact('all_document_type','DocumentType'));
    }

    // /**
    //  * Update the specified resource in storage.
    //  */
    public function update(Request $request, string $id)
    {
        //
        $request->validate(
            [
                'dt_name' => 'required|min:2|max:50|unique:cop_document_type_ms,dt_name,'.decrypt($id).',dt_id',
            ],
            [
                'dt_name.required' => 'Document Name Required',
                'dt_name.min' => 'The Document Name must be at least :min characters.',
                'dt_name.max' => 'The Document Name must not exceed :max characters.',
                'dt_name.unique' => 'Document Name has already been taken.',

            ]
        );
        try {
            $document_type = DocumentType::where('dt_id', decrypt($id))->first();
            if ($document_type) {
                $document_type->dt_name = $request->dt_name;
                $document_type->status = $request->has('status') ? 1 : 0;
                $document_type->update();

                session()->flash('success', 'Document Type Update Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('document_type.create');
    }

    // /**
    //  * Remove the specified resource from storage.
    //  */
    public function destroy(string $id)
    {
        //
        try {
            $document_type = DocumentType::where('dt_id', decrypt($id))->first();

            if ($document_type) {
                $document_type->delete();

                session()->flash('success', 'Document Type Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            return redirect()->route('document_type.create');

        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    // /**
    //  * Toggle status feild active/Inactive.
    //  */
    public function toggleStatus(Request $request)
    {
        //Begin::toggle lead source status
        $id = $request->input('id');
        $document_type = DocumentType::find($id);
        $document_type->status = $document_type->status == 1 ? 0 : 1;
        $document_type->save();
        //End::toggle lead source status

        return response()->json(['message' => 'Status updated successfully']);
    }
}
