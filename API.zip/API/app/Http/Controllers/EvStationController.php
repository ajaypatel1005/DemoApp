<?php

namespace App\Http\Controllers;

use App\Models\City;
use App\Models\EvStation;
use App\Models\State;
use App\Rules\GoogleMapsURL;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class EvStationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (!hasAnyPermission(['create_ev_station', 'view_ev_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $states = State::active()->get();
        $city = City::active()->get();
        $evStations = EvStation::select('cop_evs_ms.*', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_city_ms', 'cop_evs_ms.city_id', '=', 'cop_city_ms.city_id')
            ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
            ->get();
        return view('ev_station.view', compact('evStations', 'states', 'city'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function fetchCities(Request $request)
    {
        $selectedStateId = $request->input('state_id');
        if ($selectedStateId) {
            $cities = City::where('state_id', $selectedStateId)
                ->where('status', 1)
                ->get();
        } else {
            $cities = [];
        }
        return response()->json(['cities' => $cities]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_ev_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $request->validate([
            'evs_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:2|max:30',
            'state_id' => 'required',
            'city_id' => 'required',
            'evs_address' => 'required|min:15|max:700|unique:cop_evs_ms,evs_address',
            'evs_location' => ['required', 'string','unique:cop_evs_ms,evs_location', new GoogleMapsURL],
            // 'evs_charging_slots' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:1|max:30',
            // 'evs_charging_port_type' => 'required|min:1|max:30',
            // 'evs_charging_voltage' => 'required|min:1|max:30',
            // 'evs_charging_rate' => 'required|min:1|max:30',
            // 'evs_car_capacity' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:1|max:30',
            // 'evs_contact_number' => 'required|digits:10|numeric|unique:cop_evs_ms,evs_contact_number',
            'evs_charging_slots' => 'min:0|max:30',
            'evs_charging_port_type' => 'min:0|max:30',
            'evs_charging_voltage' => 'min:0|max:30',
            'evs_charging_rate' => 'min:0|max:30',
            'evs_car_capacity' => 'min:0|max:30',
            'evs_contact_number' => '',
        ],
        [
            'state_id.required'=> 'State is Required',
            'city_id.required'=>'City is Required',

            'evs_name.required' => 'The EVS name is required.',
            'evs_name.regex' => 'The EVS name must contain only letters, numbers, and spaces.',
            'evs_name.min' => 'The EVS name must be at least :min characters.',
            'evs_name.max' => 'The EVS name must not exceed :max characters.',

            'evs_address.required' => 'The EVS address is required.',
            'evs_address.min' => 'The EVS address  must be at least :min characters.',
            'evs_address.max' => 'The EVS address  must not exceed :max characters.',
            'evs_address.unique' => 'The EVS address has been already exist in another EVS station',

            'evs_location.required' => 'The EVS location address is required.',
            'evs_location.string' => 'The EVS location must be a string.',
            'evs_location.custom' => 'The EVS location is not a valid Google Maps URL.',
            'evs_location.unique' => 'The EVS location has been already exist in another EVS station',

            'evs_charging_slots.required' => 'The EVS charging slots is required.',
            // 'evs_charging_slots.regex' => 'The EVS charging slots must contain only letters, numbers, and spaces.',
            'evs_charging_slots.min' => 'The EVS charging slots must be at least :min characters.',
            'evs_charging_slots.max' => 'The EVS charging slots must not exceed :max characters.',

            'evs_charging_port_type.required' => 'The EVS port type is required.',
            // 'evs_charging_port_type.regex' => 'The EVS port type must contain only letters, numbers, and spaces.',
            'evs_charging_port_type.min' => 'The EVS port type must be at least :min characters.',
            'evs_charging_port_type.max' => 'The EVS port type must not exceed :max characters.',

            'evs_charging_voltage.required' => 'The EVS charging voltage is required.',
            'evs_charging_voltage.min' => 'The EVS charging voltage must be at least :min characters.',
            'evs_charging_voltage.max' => 'The EVS charging voltage must not exceed :max characters.',

            'evs_charging_rate.required' => 'The EVS charging rate is required.',
            // 'evs_charging_rate.regex' => 'The EVS charging rate must contain only letters, numbers, and spaces.',
            'evs_charging_rate.min' => 'The EVS charging rate must be at least :min characters.',
            'evs_charging_rate.max' => 'The EVS charging rate must not exceed :max characters.',

            'evs_car_capacity.required' => 'The EVS capacity is required.',
            'evs_car_capacity.regex' => 'The EVS capacity must contain only letters, numbers, and spaces.',
            'evs_car_capacity.min' => 'The EVS capacity must be at least :min characters.',
            'evs_car_capacity.max' => 'The EVS capacity must not exceed :max characters.',
            'evs_contact_number.required' => 'The contact number is required.',
            'evs_contact_number.numeric' => 'The EVS contact number must be an number.',
            'evs_contact_number.digits' => 'The EVS contact number must be 10 digits.',
            'evs_contact_number.unique' => 'The EVS contact number has been already exist in another EVS station'
        ]
        );
        DB::beginTransaction();
        try {
            $state_id = DB::table('cop_city_ms')
            ->where('city_id', $request->city_id)
            ->value('state_id');

        // dd($state_name);

            EvStation::create([


                'evs_name' => $request->evs_name,
                'state_id' => $state_id,
                'city_id' => $request->city_id,
                'evs_address' => $request->evs_address,
                'evs_location' => $request->evs_location,
                'evs_charging_slots' => $request->evs_charging_slots,
                'evs_charging_port_type' => $request->evs_charging_port_type,
                'evs_charging_voltage' => $request->evs_charging_voltage,
                'evs_charging_rate' => $request->evs_charging_rate,
                'evs_car_capacity' => $request->evs_car_capacity,
                'evs_contact_number' => $request->evs_contact_number,
                'status' => $request->has('status') ? 1 : 0,
                'created_by' => Auth::user()->id,
                'updated_by' => Auth::user()->id
            ]);
            DB::commit();
            session()->flash('success', 'Ev Station Added Sccessfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('ev_station.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_ev_station', 'view_ev_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $states = DB::select('select * from cop_state_ms where status = 1');
        $city = DB::select('select * from cop_city_ms where status = 1');
        return view("ev_station.create", compact("states", "city"));
    }

    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_ev_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $ev_station_edit = EvStation::where('evs_id', decrypt($id))->first();
        if ($ev_station_edit) {

            $city_id = $ev_station_edit->city_id;

            // dump('City ID:', $city_id);

            $selected_states = DB::table('cop_city_ms')->where('city_id', $city_id)->value('state_id');

            if ($selected_states) {

                $state_name = DB::table('cop_state_ms')->where('state_id', $selected_states)->value('state_name');

            //    dump('State Name:', $state_name);
            }

        $states = DB::select('select * from cop_state_ms where status = 1');

        $evStations = EvStation::select('cop_evs_ms.*', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_city_ms', 'cop_evs_ms.city_id', '=', 'cop_city_ms.city_id')
            ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
            ->get();

        // $city = DB::select('select * from cities where status = 1');
        $city = City::where('state_id', $ev_station_edit->state_id)
            ->where('status', 1)
            ->get();
        return view('ev_station.edit', compact('ev_station_edit', 'states', 'city','selected_states','evStations'));
    }
}
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_ev_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $ev_station_destroy = EvStation::where('evs_id', decrypt($id))->first();



            if ($ev_station_destroy) {
                $ev_station_destroy->delete();
                DB::commit();
                session()->flash('success', 'Ev Station Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('ev_station.index');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_evs_ms')
            ->where('evs_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_ev_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $request->validate([
            'evs_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:2|max:30',
            'state_id' => 'required',
            'city_id' => 'required',
            'evs_address' => 'required|min:15|max:700|unique:cop_evs_ms,evs_address,' . decrypt($id) . ',evs_id',
            'evs_location' => ['required', 'string','unique:cop_evs_ms,evs_location,' . decrypt($id) . ',evs_id', new GoogleMapsURL],
            // 'evs_charging_slots' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:1|max:30',
            // 'evs_charging_port_type' => 'required|min:1|max:30',
            // 'evs_charging_voltage' => 'required|min:1|max:30',
            // 'evs_charging_rate' => 'required|min:1|max:30',
            // 'evs_car_capacity' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:1|max:30',
            // 'evs_contact_number' => 'required|digits:10|numeric|unique:cop_evs_ms,evs_contact_number,'. decrypt($id) . ',evs_id',
            'evs_charging_slots' => 'min:0|max:30',
            'evs_charging_port_type' => 'min:0|max:30',
            'evs_charging_voltage' => 'min:0|max:30',
            'evs_charging_rate' => 'min:0|max:30',
            'evs_car_capacity' => 'min:0|max:30',
            'evs_contact_number' => '',
        ],
        [
            'state_id.required'=> 'State is Required',
            'city_id.required'=>'City is Required',

            'evs_name.required' => 'The EVS name is required.',
            'evs_name.regex' => 'The EVS name must contain only letters, numbers, and spaces.',
            'evs_name.min' => 'The EVS name must be at least :min characters.',
            'evs_name.max' => 'The EVS name must not exceed :max characters.',

            'evs_address.required' => 'The EVS address is required.',
            'evs_address.min' => 'The EVS address  must be at least :min characters.',
            'evs_address.max' => 'The EVS address  must not exceed :max characters.',
            'evs_address.unique' => 'The EVS address has been already exist in another EVS station',

            'evs_location.required' => 'The EVS location address is required.',
            'evs_location.string' => 'The EVS location must be a string.',
            'evs_location.custom' => 'The EVS location is not a valid Google Maps URL.',
            'evs_location.unique' => 'The EVS location has been already exist in another EVS station',

            'evs_charging_slots.required' => 'The EVS charging slots is required.',
            'evs_charging_slots.regex' => 'The EVS charging slots must contain only letters, numbers, and spaces.',
            'evs_charging_slots.min' => 'The EVS charging slots must be at least :min characters.',
            'evs_charging_slots.max' => 'The EVS charging slots must not exceed :max characters.',

            'evs_charging_port_type.required' => 'The EVS port type is required.',
            'evs_charging_port_type.min' => 'The EVS port type must be at least :min characters.',
            'evs_charging_port_type.max' => 'The EVS port type must not exceed :max characters.',

            'evs_charging_voltage.required' => 'The EVS charging voltage is required.',
            'evs_charging_voltage.min' => 'The EVS charging voltage must be at least :min characters.',
            'evs_charging_voltage.max' => 'The EVS charging voltage must not exceed :max characters.',

            'evs_charging_rate.required' => 'The EVS charging rate is required.',
            'evs_charging_rate.min' => 'The EVS charging rate must be at least :min characters.',
            'evs_charging_rate.max' => 'The EVS charging rate must not exceed :max characters.',

            'evs_car_capacity.required' => 'The EVS capacity is required.',
            'evs_car_capacity.regex' => 'The EVS capacity must contain only letters, numbers, and spaces.',
            'evs_car_capacity.min' => 'The EVS capacity must be at least :min characters.',
            'evs_car_capacity.max' => 'The EVS capacity must not exceed :max characters.',
            'evs_contact_number.required' => 'The contact number is required.',
            'evs_contact_number.numeric' => 'The EVS contact number must be an number.',
            'evs_contact_number.digits' => 'The EVS contact number must be 10 digits.',
            'evs_contact_number.unique' => 'The EVS contact number has been already exist in another EVS station'
        ]
        );
        DB::beginTransaction();
        try {
            $ev_station_update = EvStation::where('evs_id', decrypt($id))->first();
            $state_id = DB::table('cop_city_ms')
            ->where('city_id', $request->city_id)
            ->value('state_id');

            if (!empty($ev_station_update)) {
                $ev_station_update->evs_name = $request->evs_name;
                $ev_station_update->state_id = $state_id;
                $ev_station_update->city_id = $request->city_id;
                $ev_station_update->evs_address = $request->evs_address;
                $ev_station_update->evs_location = $request->evs_location;
                $ev_station_update->evs_charging_slots = $request->evs_charging_slots;
                $ev_station_update->evs_charging_port_type = $request->evs_charging_port_type;
                $ev_station_update->evs_charging_voltage = $request->evs_charging_voltage;
                $ev_station_update->evs_charging_rate = $request->evs_charging_rate;
                $ev_station_update->evs_car_capacity = $request->evs_car_capacity;
                $ev_station_update->evs_contact_number = $request->evs_contact_number;
                $ev_station_update->status = $request->has('status') ? 1 : 0;
                $ev_station_update->update();
                DB::commit();
                session()->flash('success', 'Ev Station Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('ev_station.index');
    }
}
