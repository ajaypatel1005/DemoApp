<?php

namespace App\Http\Controllers\exports;

use App\Exports\FeatureValueExport;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;

class FeatureValueExportController extends Controller
{
    public function downloadInvoices()
    {
        return Excel::download(new FeatureValueExport, 'feature_value.xlsx');
    }
}
