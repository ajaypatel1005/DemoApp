<?php

namespace App\Http\Controllers\exports;

use App\Exports\VariantsExport;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;

class VariantExportController extends Controller
{
    public function downloadInvoices()
    {
        return Excel::download(new VariantsExport, 'variants.xlsx');
    }
    public function create()  {
        return view('exports.variants');
    }
}
