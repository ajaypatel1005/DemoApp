<?php

namespace App\Http\Controllers;

use App\Models\Rto;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Exception;
use Illuminate\Validation\Rule;

class RtoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        $states = State::all();
        return view('rto.create', compact('states'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $request->validate([
            'state_id' => 'required',
            'rto_type' => 'required',
            'pre_condition' => 'nullable',
            'pre_amount' => 'nullable|numeric',
            'percentage' => 'required|numeric|between:0,100',
            'post_condition' => 'nullable|different:pre_condition',
            'post_amount' => [
                'nullable',
                'numeric',
                function ($attribute, $value, $fail) use ($request) {
                    if ($value !== null && $value <= $request->pre_amount) {
                        $fail('Post Amount must be greater than Pre Amount');
                    }
                },
            ],
        ], [
            'state_id.required' => 'State is required',
            'rto_type.required' => 'RTO Type is required',
            // 'pre_condition.required' => 'Pre Condition is required',
            // 'pre_amount.required' => 'Pre Amount is required',
            'pre_amount.numeric' => 'Pre Amount must be a number',
            'post_amount.numeric' => 'Post Amount must be a number',
            'percentage.required' => 'Percentage is required',
            'percentage.numeric' => 'Percentage must be a number',
            'percentage.between' => 'The percentage must be between :min and :max.',
            'post_condition.different' => 'Post Condition must be different from Pre Condition',
        ]);

        $rto_store = new Rto;
        try {
            $rto_store->state_id = $request->state_id;
            $rto_store->rto_type = $request->rto_type;
            $rto_store->pre_condition = $request->pre_condition;
            $rto_store->pre_amount = $request->pre_amount;
            $rto_store->post_condition = $request->post_condition;
            $rto_store->post_amount = $request->post_amount;
            $rto_store->percentage = $request->percentage;
            $rto_store->fuel_type = $request->fuel_type;
            $rto_store->cc = $request->has('cc') ? "1" : "0";
            $rto_store->save();
            DB::commit();
            session()->flash('success', 'Tax Added Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('rto.view');
    }

    /**
     * Display the specified resource.
     */
    public function view()
    {

        $rto_data_view = DB::table('cop_rto_ms')
            ->join('cop_state_ms', 'cop_rto_ms.state_id', '=', 'cop_state_ms.state_id')
            ->select('cop_rto_ms.*', 'cop_state_ms.state_name as state_name')
            ->get();
        return view('rto.view', ['rto_data_view' => $rto_data_view]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $rto_data_edit = Rto::where('rto_id', decrypt($id))->first();
        $states = State::all();

        return view('rto.edit', compact('rto_data_edit', 'states'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {

        $request->validate([
            'state_id' => 'required',
            'rto_type' => 'required',
            'pre_condition' => 'nullable',
            'pre_amount' => 'nullable|numeric',
            'percentage' => 'required|numeric|between:0,100',
            'post_condition' => 'nullable|different:pre_condition',
            'post_amount' => [
                'nullable',
                'numeric',
                function ($attribute, $value, $fail) use ($request) {
                    if ($value !== null && $value <= $request->pre_amount) {
                        $fail('Post Amount must be greater than Pre Amount');
                    }
                },
            ],
        ], [
            'state_id.required' => 'State is required',
            'rto_type.required' => 'RTO Type is required',
            // 'pre_condition.required' => 'Pre Condition is required',
            // 'pre_amount.required' => 'Pre Amount is required',
            'pre_amount.numeric' => 'Pre Amount must be a number',
            'post_amount.numeric' => 'Post Amount must be a number',
            'percentage.required' => 'Percentage is required',
            'percentage.numeric' => 'Percentage must be a number',
            'percentage.between' => 'The percentage must be between :min and :max.',
            'post_condition.different' => 'Post Condition must be different from Pre Condition',
        ]);
        try {

            $rto_data_updates = Rto::where('rto_id', decrypt($id))->first();
            if ($rto_data_updates) {
                $rto_data_updates->state_id = $request->state_id;
                $rto_data_updates->rto_type = $request->rto_type;
                $rto_data_updates->pre_condition = $request->pre_condition;
                $rto_data_updates->pre_amount = $request->pre_amount;
                $rto_data_updates->post_condition = $request->post_condition;
                $rto_data_updates->post_amount = $request->post_amount;
                $rto_data_updates->percentage = $request->percentage;
                $rto_data_updates->fuel_type = $request->fuel_type;
                $rto_data_updates->cc = $request->has('cc') ? "1" : "0";
                $rto_data_updates->update();
                DB::commit();
                session()->flash('success', 'RTO Data Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('rto.view');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $rto_data_destroy = Rto::where('rto_id', decrypt($id))->first();

            if ($rto_data_destroy) {
                $rto_data_destroy->delete();
                DB::commit();

                session()->flash('success', 'RTO Data Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong!');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('rto.view');
    }
}
