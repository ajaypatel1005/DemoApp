<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Log;
use App\Models\ManagerLanguage;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ManagerLanguageController extends Controller
{

    public function create()
    {
        if (!hasAnyPermission(['create_manager_language', 'view_manager_language'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $manager_lang_view = ManagerLanguage::all();
        return view('manager_lang.create', compact('manager_lang_view'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_manager_language'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'lang_name' => 'required|regex:/^[A-Za-z\s]+$/|min:5|max:30|unique:cop_ml_ms,lang_name',
        ], [
            'lang_name.required' => 'Manager Language name is required',
            'lang_name.regex' => 'Manager Language name allow only alphabets',
            'lang_name.min' => 'The Manager Language must be at least :min characters.',
            'lang_name.max' => 'The Manager Language must not exceed :max characters.',
            'lang_name.unique' => 'Manager Language name already exist',
        ]);
        DB::beginTransaction();
        try {
            ManagerLanguage::create([
                'lang_name' => $request->lang_name,
                'status' => $request->has('status') ? 1 : 0,
            ]);
            DB::commit();
            session()->flash('success', 'Manager Language Added Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('manager_lang.create');
    }

    /**
     * Display the specified resource.
     */
    // public function view()
    // {
    //     $manager_lang_view = ManagerLanguage::get();
    //     return view('manager_lang.create', ['manager_lang_view' => $manager_lang_view]);
    // }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_manager_language', 'view_manager_language'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $manager_lang_edit = ManagerLanguage::where('lang_id', decrypt($id))->first();
        $manager_lang_view = ManagerLanguage::all();
        return view('manager_lang.edit', ['manager_lang_edit' => $manager_lang_edit], ['manager_lang_view' => $manager_lang_view]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_manager_language'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'lang_name' => 'required|regex:/^[A-Za-z\s]+$/|min:5|max:30|unique:cop_ml_ms,lang_name,' . decrypt($id) . ',lang_id'
            ],
            [
                'lang_name.required' => 'Manager Language name is required',
                'lang_name.regex' => 'Manager Language name allow only alphabets',
                'lang_name.min' => 'The Manager Language must be at least :min characters.',
                'lang_name.max' => 'The Manager Language must not exceed :max characters.',
                'lang_name.unique' => 'Manager Language name already exist',
            ]
        );
        DB::beginTransaction();
        try {
            $manager_lang_update = ManagerLanguage::where('lang_id', decrypt($id))->first();
            // dd($manager_lang_update);
            if ($manager_lang_update) {
                $manager_lang_update->lang_name = $request->lang_name;
                $manager_lang_update->status = $request->has('status') ? 1 : 0;
                $manager_lang_update->save();
                DB::commit();
                session()->flash('success', 'Manager Language Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('manager_lang.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_manager_language'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $manager_lang_destroy = ManagerLanguage::where('lang_id', decrypt($id))->first();
            if (!empty($manager_lang_destroy)) {

                if ($manager_lang_destroy->manager->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('manager_lang.create');
                }
                $manager_lang_destroy->delete();
                DB::commit();
                session()->flash('success', 'Manager Language Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('manager_lang.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_ml_ms')
            ->where('lang_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
}
