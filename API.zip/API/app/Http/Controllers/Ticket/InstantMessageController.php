<?php

namespace App\Http\Controllers\Ticket;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Models\TicketInstantMessage;

class InstantMessageController extends Controller
{
    /**
     * Show the form for creating a new resource.
     */
    public function index(Request $request)
    {
        if (!hasAnyPermission(['create_instant_message'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $messages = TicketInstantMessage::get();
        return view("tickets.instant_message.index", compact('messages'));
    }

    /**
     * Display the specified resource.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_instant_message'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $request->validate(
            [
                'instant_message_title' => 'required',
                'instant_message_msg' => 'required'
            ],
            [
                'instant_message_title.required' => 'Title is Required',
                'instant_message_msg' => 'Message is Required'
            ]
        );

        try {

            TicketInstantMessage::create([
                'title' => $request->instant_message_title,
                'messages' => $request->instant_message_msg,
                'status' => $request->has('status') ? 1 : 0,
                'created_by' => auth()->id()
            ]);
            session()->flash('success', 'Instant Message Added Successfully.');
            return redirect()->route('instant_message.index');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_instant_message'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $instant_message_edit = TicketInstantMessage::where('id', decrypt($id))->first();
        $messages = TicketInstantMessage::get();
        return view('tickets.instant_message.edit', compact('instant_message_edit', 'messages'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate(
            [
                'instant_message_title' => 'required',
                'instant_message_msg' => 'required'
            ],
            [
                'instant_message_title.required' => 'Title is Required',
                'instant_message_msg' => 'Message is Required'
            ]
        );

        try {
            $instant_message_update = TicketInstantMessage::where('id', decrypt($id))->first();
            if (!empty($instant_message_update)) {
                $instant_message_update->title = $request->instant_message_title;
                $instant_message_update->messages = $request->instant_message_msg;
                $instant_message_update->update();
                session()->flash('success', 'Instant Message Updated Successfully.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('instant_message.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function delete($id)
    {
        if (!hasAnyPermission(['delete_instant_message'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        try {
            $instant_message_delete = TicketInstantMessage::where('id', decrypt($id))->first();
            if (!empty($instant_message_delete)) {
                $instant_message_delete->delete();
                session()->flash('success', 'Instant Message has been deleted successfully.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('instant_message.index');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');

        TicketInstantMessage::where('id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);

        return response()->json(['message', 'Status Updated Successfully']);
    }
}
