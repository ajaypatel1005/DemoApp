<?php

namespace App\Http\Controllers\imports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Imports\FeaturesImport;
use Illuminate\Support\Facades\Redirect;
use Maatwebsite\Excel\Facades\Excel;

class FeaturesImportController extends Controller
{
    // Car Feature
    public function create()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "you don't have permission to access");
        }
        return view('import.features');
    }
    public function store(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,csv',
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new FeaturesImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.features', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }
}
