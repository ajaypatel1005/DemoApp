<?php

namespace App\Http\Controllers\imports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Imports\EvModelImportLaunchedImport;
use App\Imports\EvModelImportUpcomingImport;
use App\Imports\NonEvModelImportLaunchedImport;
use App\Imports\NonEvModelImportUpcomingImport;
use App\Models\Model;
use Illuminate\Support\Facades\Redirect;
use Maatwebsite\Excel\Facades\Excel;

class ModelImportController extends Controller
{
    // Non Ev Upcoming
    public function non_ev_upcoming_create()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "you don't have permission to access");
        }
        return view('import.non_ev_models_upcoming');
    }
    public function non_ev_upcoming_store(Request $request)
    {
         // Validate the request
         $request->validate([
            'file' => 'required|mimes:xlsx,csv', // Adjust the allowed file types if needed
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new NonEvModelImportUpcomingImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.non_ev_models_upcoming', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }

    // Non EV Launched
    public function non_ev_launched_create()
    {
        return view('import.non_ev_models_launched');
    }
    public function non_ev_launched_store(Request $request)
    {
         // Validate the request
         $request->validate([
            'file' => 'required|mimes:xlsx,csv', // Adjust the allowed file types if needed
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new NonEvModelImportLaunchedImport();

            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.non_ev_models_launched', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }


    // Ev Upcoming
    public function ev_upcoming_create()
    {
        return view('import.ev_models_upcoming');
    }
    public function ev_upcoming_store(Request $request)
    {
         // Validate the request
         $request->validate([
            'file' => 'required|mimes:xlsx,csv', // Adjust the allowed file types if needed
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new EvModelImportUpcomingImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.ev_models_upcoming', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }

    // EV Launched
    public function ev_launched_create()
    {
        return view('import.ev_models_launched');
    }
    public function ev_launched_store(Request $request)
    {
         // Validate the request
         $request->validate([
            'file' => 'required|mimes:xlsx,csv', // Adjust the allowed file types if needed
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new EvModelImportLaunchedImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.ev_models_launched', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }
}
