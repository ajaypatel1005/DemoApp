<?php

namespace App\Http\Controllers;

use App\Models\StandardUnit;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class StandardUnitController extends Controller
{

    public function create()
    {
        if (!hasAnyPermission(['create_standard_unit', 'view_standard_unit'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $standard_unit_view = StandardUnit::all();
        return view('standard_unit.create', compact('standard_unit_view'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_standard_unit'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'su_name' => 'required|regex:/^[A-Za-z\/\s]+$/|min:2|max:20|unique:cop_su_ms,su_name',
            ],
            [
                'su_name.required' => 'Standard Unit Name is required',
                'su_name.regex' => 'Standard Unit Name is invalid',
                'su_name.unique' => 'Standard Unit Already Exists',
                'su_name.min' => 'Minimum 2 Characters are required',
                'su_name.max' => 'Maximum 20 Characters are allowed'
            ]
        );
        DB::beginTransaction();
        try {
            $standard_unit_store = new StandardUnit();
            if ($standard_unit_store) {
                $standard_unit_store->su_name = $request->su_name;
                $standard_unit_store->save();
                DB::commit();
                session()->flash('success', 'Standard Unit Added Successfully');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('standard_unit.create');
    }

    public function edit($id)
    {
        if (!hasAnyPermission(['edit_standard_unit', 'view_standard_unit'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        try {
            $standard_unit_edit = StandardUnit::where('su_id', decrypt($id))->first();
            $standard_unit_view = StandardUnit::all();
            return view('standard_unit.edit', compact('standard_unit_edit', 'standard_unit_view'));
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_standard_unit'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'su_name' => 'required|regex:/^[A-Za-z\/\s]+$/|min:2|max:20|unique:cop_su_ms,su_name,' . decrypt($id) . ',su_id'
            ],
            [
                'su_name.required' => 'Standard Unit Name is required',
                'su_name.regex' => 'Standard Unit Name is invalid',
                'su_name.unique' => 'Standard Unit Already Exists',
                'su_name.min' => 'Minimum 2 Characters are required',
                'su_name.max' => 'Maximum 20 Characters are allowed'
            ]
        );
        DB::beginTransaction();
        try {
            $standard_unit_update = StandardUnit::where('su_id', decrypt($id))->first();
            if ($standard_unit_update) {
                $standard_unit_update->su_name = $request->su_name;
                $standard_unit_update->update();
                DB::commit();
                session()->flash('success', 'Standard Unit Updated Successfully');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('standard_unit.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_standard_unit'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        try {
            $standard_unit_destroy = StandardUnit::where('su_id', decrypt($id))->first();
            if ($standard_unit_destroy) {
                if ($standard_unit_destroy->feature->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('standard_unit.create');
                }
                $standard_unit_destroy->delete();
                session()->flash('success', 'Standard Unit Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('standard_unit.create');
    }
}
