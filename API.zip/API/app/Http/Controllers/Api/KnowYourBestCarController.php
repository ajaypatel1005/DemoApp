<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\FeatureValue;
use App\Models\Model;
use Illuminate\Support\Facades\DB;
use Mockery\Undefined;

class KnowYourBestCarController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    // (NOT IN USE CURRETNLY -> budget)
    public function budget(Request $request)
    {
        $cityName = $request->input('cityname');
        // $upcoming = 'Upcoming';

        $budget_1 = Model::join('cop_pe_ms', 'cop_models.model_id', '=', 'cop_pe_ms.model_id')
            ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
            ->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
            ->where('cop_cs_ms.cs_name', '!=', 'Upcoming')
            ->where('cop_city_ms.city_name', $cityName)
            ->where('cop_models.status', 1)
            ->where('cop_pe_ms.status', 1)
            ->whereBetween('cop_pe_ms.ex_showroom_price', [200000, 1000000])
            ->distinct('cop_models.model_id')
            ->count();
        // $budget_1 = Model::whereHas('car_stage', function ($query) {
        //     $query->where('cs_name', '!=', 'Upcoming');
        // })
        //     ->whereHas('price_entry.city', function ($query) use ($cityName) {
        //         $query->where('city_name', $cityName)
        //             ->whereBetween('ex_showroom_price', [200000, 1000000])
        //             ->where('status', 1);
        //     })
        //     ->where('status', 1)
        //     ->distinct('model_id')
        //     ->count();

        $budget_2 = Model::join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
            ->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
            ->where('cop_cs_ms.cs_name', '!=', 'Upcoming')
            ->where('cop_city_ms.city_name', $cityName)
            ->where('cop_models.status', '=', 1)
            ->where('cop_pe_ms.status', '=', 1)
            ->whereBetween('cop_pe_ms.ex_showroom_price', [1000000, 2500000])
            ->distinct('cop_models.model_id')
            ->count();
        // $budget_2 = Model::whereHas('car_stage', function ($query) {
        //     $query->where('cs_name', '!=', 'Upcoming');
        // })
        //     ->whereHas('price_entry.city', function ($query) use ($cityName) {
        //         $query->where('city_name', $cityName)
        //             ->whereBetween('ex_showroom_price', [1000000, 2500000])
        //             ->where('status', 1);
        //     })
        //     ->where('status', 1)
        //     ->distinct('model_id')
        //     ->count();

        $budget_3 = Model::join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
            ->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
            ->where('cop_cs_ms.cs_name', '!=', 'Upcoming')
            ->where('cop_city_ms.city_name', $cityName)
            ->where('cop_models.status', '=', 1)
            ->where('cop_pe_ms.status', '=', 1)
            ->whereBetween('cop_pe_ms.ex_showroom_price', [2500000, 5000000])
            ->distinct('cop_models.model_id')
            ->count();
        // $budget_3 = Model::whereHas('car_stage', function ($query) {
        //     $query->where('cs_name', '!=', 'Upcoming');
        // })
        //     ->whereHas('price_entry.city', function ($query) use ($cityName) {
        //         $query->where('city_name', $cityName)
        //             ->whereBetween('ex_showroom_price', [2500000, 5000000])
        //             ->where('status', 1);
        //     })
        //     ->where('status', 1)
        //     ->distinct('model_id')
        //     ->count();

        $budget_4 = Model::join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
            ->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
            ->where('cop_cs_ms.cs_name', '!=', 'Upcoming')
            ->where('cop_city_ms.city_name', $cityName)
            ->where('cop_models.status', '=', 1)
            ->where('cop_pe_ms.status', '=', 1)
            ->whereBetween('cop_pe_ms.ex_showroom_price', [5000000, 10000000])
            ->distinct('cop_models.model_id')
            ->count();
        // $budget_4 = Model::whereHas('car_stage', function ($query) {
        //     $query->where('cs_name', '!=', 'Upcoming');
        // })
        //     ->whereHas('price_entry.city', function ($query) use ($cityName) {
        //         $query->where('city_name', $cityName)
        //             ->whereBetween('ex_showroom_price', [5000000, 10000000])
        //             ->where('status', 1);
        //     })
        //     ->where('status', 1)
        //     ->distinct('model_id')
        //     ->count();

        $budget_5 = Model::join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
            ->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
            ->where('cop_cs_ms.cs_name', '!=', 'Upcoming')
            ->where('cop_city_ms.city_name', $cityName)
            ->where('cop_models.status', '=', 1)
            ->where('cop_pe_ms.status', '=', 1)
            ->where('cop_pe_ms.ex_showroom_price', '>', 10000000)
            ->distinct('cop_models.model_id')
            ->count();

        // $budget_5 = Model::whereHas('car_stage', function ($query) {
        //     $query->where('cs_name', '!=', 'Upcoming');
        // })
        //     ->whereHas('price_entry.city', function ($query) use ($cityName) {
        //         $query->where('city_name', $cityName)
        //             ->where('ex_showroom_price', '>', 10000000)
        //             ->where('status', 1);
        //     })
        //     ->where('status', 1)
        //     ->distinct('model_id')
        //     ->count();

        $formattedData = [
            'budget_1' => '2 lakh - 10 lakh',
            'model_count_budget_1' => $budget_1,
            'budget_2' => '10 lakh - 25 lakh',
            'model_count_budget_2' => $budget_2,
            'budget_3' => '25 lakh - 50 lakh',
            'model_count_budget_3' => $budget_3,
            'budget_4' => '50 lakh - 1 cr',
            'model_count_budget_4' => $budget_4,
            'budget_5' => 'above 1 cr',
            'model_count_budget_5' => $budget_5,

        ];

        return ResponseHelper::responseMessage('success', $formattedData);
    }

    // (NOT IN USE CURRETNLY -> drive)
    public function drive(Request $request)
    {
        $minPrice = $request->input('minprice');
        $maxPrice = $request->input('maxprice');
        $cityName = $request->input('cityname');
        // $upcoming = 'Upcoming';
        // $displacement = 'Displacement';
        // $hatchback = 'Hatchback';
        // $drivetrain = 'Drivetrain';
        $request->validate([
            'cityname' => 'required|string',
        ]);

        $formattedData = [];

        $drive_1 = Model::join('cop_fv','cop_fv.model_id','=','cop_models.model_id')
        ->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')
        ->join('cop_ct_ms','cop_ct_ms.ct_id','=','cop_models.ct_id')
        ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
        ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
        ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
        ->where(function ($query) {
            $query->where([
                ['cop_features_ms.features_name', 'Displacement'],
                ['cop_fv.feature_value', '>=', 0],
                ['cop_fv.feature_value', '<=', 1200]
            ])->orWhere([
                ['cop_features_ms.features_name', 'Displacement'],
                ['cop_fv.feature_value', '>', 3000]
            ]);
        })
        ->where('cop_ct_ms.ct_name','=','Hatchback')
        ->where('cop_cs_ms.cs_name','!=','Upcoming')
        ->where('cop_city_ms.city_name',$cityName)
        ->where('cop_models.status','=',1)
        ->where('cop_pe_ms.status','=',1)
        ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
        ->distinct('cop_models.model_id')
        ->count();

        $drive_2 = Model::join('cop_fv','cop_fv.model_id','=','cop_models.model_id')
        ->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')
        ->join('cop_ct_ms','cop_ct_ms.ct_id','=','cop_models.ct_id')
        ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
        ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
        ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
        ->where(function ($query) {
            $query->where([
                ['cop_features_ms.features_name','=','Displacement'],
                ['cop_fv.feature_value', '>=', 1200],
                ['cop_fv.feature_value', '<=', 3000]
            ]);
        })
        // ->where('cop_features_ms.features_name','=','Displacement')
        // ->whereBetween('cop_fv.feature_value',[1200, 3000])
        // ->whereIn('cop_ct_ms.ct_name', ['MPV','SUV','Sedan','Hatchback'])
        ->where('cop_cs_ms.cs_name','!=','Upcoming')
        ->where('cop_city_ms.city_name',$cityName)
        ->where('cop_models.status','=',1)
        ->where('cop_pe_ms.status','=',1)
        ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
        ->distinct('cop_models.model_id')
        ->count();

        $drive_3 = Model::join('cop_fv','cop_fv.model_id','=','cop_models.model_id')
        ->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')
        ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
        ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
        ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
        ->where(function ($query){
            $query->where('cop_features_ms.features_name', '=', 'Drivetrain')
                ->whereIn('cop_fv.feature_value', ['4WD', 'AWD']);
        })
        ->where('cop_cs_ms.cs_name','!=','Upcoming')
        ->where('cop_city_ms.city_name',$cityName)
        ->where('cop_models.status','=',1)
        ->where('cop_pe_ms.status','=',1)
        ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
        ->distinct('cop_models.model_id')
        ->count();

        $drive_4 = Model::join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
        ->join('cop_fv','cop_fv.model_id','=','cop_models.model_id')
        ->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')
        ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
        ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
        ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
        ->where(function ($query) {
            $query->where([
                ['cop_features_ms.features_name','=','Mileage'],
                ['cop_fv.feature_value', '>', 15]
            ]);
        })
        ->whereIn('cop_brands_ms.brand_name', ['Maruti', 'Hyundai'])
        ->where('cop_cs_ms.cs_name','!=','Upcoming')
        ->where('cop_city_ms.city_name',$cityName)
        ->where('cop_models.status','=',1)
        ->where('cop_pe_ms.status','=',1)
        ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
        ->distinct('cop_models.model_id')
        ->count();

        $drive_5 = Model::join('cop_variants','cop_variants.model_id','=','cop_models.model_id')
        ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
        ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
        ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
        ->where('cop_variants.seating_capacity','>',6)
        ->where('cop_cs_ms.cs_name','!=','Upcoming')
        ->where('cop_city_ms.city_name',$cityName)
        ->where('cop_models.status','=',1)
        ->where('cop_pe_ms.status','=',1)
        ->where('cop_variants.status','=',1)
        ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
        ->distinct('cop_models.model_id')
        ->count();

        $drive_6 = Model::join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
        ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
        ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
        ->where('cop_cs_ms.cs_name','!=','Upcoming')
        ->where('cop_city_ms.city_name',$cityName)
        ->where('cop_models.status','=',1)
        ->where('cop_pe_ms.status','=',1)
        ->where('cop_pe_ms.ex_showroom_price','>=',4000000)
        ->where('cop_pe_ms.ex_showroom_price','<=',$maxPrice)
        ->distinct('cop_models.model_id')
        ->count();

        if($minPrice >= 200000 && $maxPrice <= 2500000) {
            $formattedData = [
                'drive_1' => 'Short Distance',
                'model_count_drive_1' => $drive_1,
                'drive_2' => 'Long Distance',
                'model_count_drive_2' => $drive_2,
                'drive_3' => 'Off-Roading Adventures',
                'model_count_drive_3' => $drive_3,
                'drive_4' => 'Fuel Efficiency',
                'model_count_drive_4' => $drive_4,
                'drive_5' => 'Family Travel',
                'model_count_drive_5' => $drive_5,
            ];
        }
        else if($minPrice >= 2500000 && $maxPrice <= 10000000) {
            $formattedData = [
                'drive_1' => 'Long Distance',
                'model_count_drive_1' => $drive_2,
                'drive_2' => 'Off-Roading Adventures',
                'model_count_drive_2' => $drive_3,
                'drive_3' => 'Fuel Efficiency',
                'model_count_drive_3' => $drive_4,
                'drive_4' => 'Family Travel',
                'model_count_drive_4' => $drive_5,
                'drive_5' => 'Luxury and Comfort',
                'model_count_drive_5' => $drive_6,
            ];
        }
        else {
            $formattedData = ['Enter minprice and minprice properly'];
        }

        return ResponseHelper::responseMessage('success', $formattedData);
    }

    // (NOT IN USE CURRETNLY -> answer)
    public function answer(Request $request)
    {
        $minPrice = $request->input('minprice');
        $maxPrice = $request->input('maxprice');
        $cityName = $request->input('cityname');

        if($minPrice == "" || $minPrice == null){
            $formattedData = ['minPrice required'];
            return ResponseHelper::responseMessage('success', $formattedData);
        }

        if($minPrice >= $maxPrice){
            $formattedData = ['maxPrice should be greater than minPrice'];
            return ResponseHelper::responseMessage('success', $formattedData);
        }

        if($minPrice >= 200000 && $maxPrice <= 10000000){
            $drive_type = $request->input('drivetype');
        }

        if($cityName == "" || $cityName == null){
            $formattedData = ['cityName required'];
            return ResponseHelper::responseMessage('success', $formattedData);
        }



        $formattedData = [];

        if($minPrice < 200000) {
            $formattedData = ['Enter minPrice greater than or equal to 200000'];
            return ResponseHelper::responseMessage('success', $formattedData);
        }
        else if($minPrice >= 200000 && $maxPrice <= 10000000) {
            if($drive_type == 'short_distance') {
                $answer = Model::select(
                    'cop_models.*',
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_rating_types.rating_type_name',
                    'cop_ratings.rating_value'
                )
                ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
                ->join('cop_fv','cop_fv.model_id','=','cop_models.model_id')
                ->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')
                ->join('cop_ct_ms','cop_ct_ms.ct_id','=','cop_models.ct_id')
                ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
                ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
                ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
                ->join('cop_ratings','cop_ratings.model_id','=','cop_models.model_id')
                ->join('cop_rating_types','cop_rating_types.rating_type_id','=','cop_ratings.rating_type_id')
                ->where(function ($query) {
                    $query->where([
                        ['cop_features_ms.features_name', 'Displacement'],
                        ['cop_fv.feature_value', '>=', 0],
                        ['cop_fv.feature_value', '<=', 1200]
                    ])->orWhere([
                        ['cop_features_ms.features_name', 'Displacement'],
                        ['cop_fv.feature_value', '>', 3000]
                    ]);
                })
                ->where('cop_ct_ms.ct_name','=','Hatchback')
                ->where('cop_cs_ms.cs_name','!=','Upcoming')
                ->where('cop_city_ms.city_name',$cityName)
                ->where('cop_models.status','=',1)
                ->where('cop_pe_ms.status','=',1)
                ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
                ->distinct()
                ->get();
            }
            else if($drive_type == 'long_distance') {
                $answer = Model::select(
                    'cop_models.*',
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_rating_types.rating_type_name',
                    'cop_ratings.rating_value',
                    'cop_ct_ms.ct_name'
                )
                ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
                ->join('cop_fv','cop_fv.model_id','=','cop_models.model_id')
                ->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')
                ->join('cop_ct_ms','cop_ct_ms.ct_id','=','cop_models.ct_id')
                ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
                ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
                ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
                ->join('cop_ratings','cop_ratings.model_id','=','cop_models.model_id')
                ->join('cop_rating_types','cop_rating_types.rating_type_id','=','cop_ratings.rating_type_id')
                ->where(function ($query) {
                    $query->where([
                        ['cop_features_ms.features_name','=','Displacement'],
                        ['cop_fv.feature_value', '>=', 1200],
                        ['cop_fv.feature_value', '<=', 3000]
                    ]);
                })
                ->where('cop_cs_ms.cs_name','!=','Upcoming')
                ->where('cop_city_ms.city_name',$cityName)
                ->where('cop_models.status','=',1)
                ->where('cop_pe_ms.status','=',1)
                ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
                ->orderByRaw("CASE cop_ct_ms.ct_name
                        WHEN 'MPV' THEN 1
                        WHEN 'SUV' THEN 2
                        WHEN 'Sedan' THEN 3
                        WHEN 'Hatchback' THEN 4
                        ELSE 5
                    END")
                ->distinct()
                ->get();
            }
            else if($drive_type == 'off_roading_adventures') {
                $answer = Model::select(
                    'cop_models.*',
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_rating_types.rating_type_name',
                    'cop_ratings.rating_value'
                )
                ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
                ->join('cop_fv','cop_fv.model_id','=','cop_models.model_id')
                ->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')
                ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
                ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
                ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
                ->join('cop_ratings','cop_ratings.model_id','=','cop_models.model_id')
                ->join('cop_rating_types','cop_rating_types.rating_type_id','=','cop_ratings.rating_type_id')
                ->where(function ($query){
                    $query->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', ['4WD', 'AWD']);
                })
                ->where('cop_cs_ms.cs_name','!=','Upcoming')
                ->where('cop_city_ms.city_name',$cityName)
                ->where('cop_models.status','=',1)
                ->where('cop_pe_ms.status','=',1)
                ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
                ->distinct()
                ->get();
            }
            else if($drive_type == 'fuel_efficiency') {
                $answer = Model::select(
                    'cop_models.*',
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_rating_types.rating_type_name',
                    'cop_ratings.rating_value'
                )
                ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
                ->join('cop_fv','cop_fv.model_id','=','cop_models.model_id')
                ->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')
                ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
                ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
                ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
                ->join('cop_ratings','cop_ratings.model_id','=','cop_models.model_id')
                ->join('cop_rating_types','cop_rating_types.rating_type_id','=','cop_ratings.rating_type_id')
                ->where(function ($query) {
                    $query->where([
                        ['cop_features_ms.features_name','=','Mileage'],
                        ['cop_fv.feature_value', '>', 15]
                    ]);
                })
                ->whereIn('cop_brands_ms.brand_name', ['Maruti', 'Hyundai'])
                ->where('cop_cs_ms.cs_name','!=','Upcoming')
                ->where('cop_city_ms.city_name',$cityName)
                ->where('cop_models.status','=',1)
                ->where('cop_pe_ms.status','=',1)
                ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
                ->orderByRaw("CASE cop_brands_ms.brand_name
                        WHEN 'Maruti' THEN 1
                        WHEN 'Hyundai' THEN 2
                    END")
                ->distinct()
                ->get();
            }
            else if($drive_type == 'family_travel') {
                $answer = Model::select(
                    'cop_models.*',
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_rating_types.rating_type_name',
                    'cop_ratings.rating_value'
                )
                ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
                ->join('cop_variants','cop_variants.model_id','=','cop_models.model_id')
                ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
                ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
                ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
                ->join('cop_ratings','cop_ratings.model_id','=','cop_models.model_id')
                ->join('cop_rating_types','cop_rating_types.rating_type_id','=','cop_ratings.rating_type_id')
                ->where('cop_variants.seating_capacity','>',6)
                ->where('cop_cs_ms.cs_name','!=','Upcoming')
                ->where('cop_city_ms.city_name',$cityName)
                ->where('cop_models.status','=',1)
                ->where('cop_pe_ms.status','=',1)
                ->where('cop_variants.status','=',1)
                ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
                ->distinct()
                ->get();
            }
            else if ($drive_type == 'luxury_and_comfort') {
                $answer = Model::select(
                    'cop_models.*',
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_rating_types.rating_type_name',
                    'cop_ratings.rating_value'
                )
                ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
                ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
                ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
                ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
                ->join('cop_ratings','cop_ratings.model_id','=','cop_models.model_id')
                ->join('cop_rating_types','cop_rating_types.rating_type_id','=','cop_ratings.rating_type_id')
                ->where('cop_cs_ms.cs_name','!=','Upcoming')
                ->where('cop_city_ms.city_name',$cityName)
                ->where('cop_models.status','=',1)
                ->where('cop_pe_ms.status','=',1)
                ->where('cop_pe_ms.ex_showroom_price','>=',4000000)
                ->where('cop_pe_ms.ex_showroom_price','<=',$maxPrice)
                ->distinct()
                ->get();
            }
            else {
                $formattedData = ['drivetype is required / Enter drivetype properly'];
                return ResponseHelper::responseMessage('success', $formattedData);
            }
        }
        else if ($minPrice > 10000000) {
            $answer = Model::select(
                'cop_models.*',
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_rating_types.rating_type_name',
                'cop_ratings.rating_value'
            )
            ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
            ->join('cop_pe_ms','cop_pe_ms.model_id','=','cop_models.model_id')
            ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
            ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
            ->join('cop_ratings','cop_ratings.model_id','=','cop_models.model_id')
            ->join('cop_rating_types','cop_rating_types.rating_type_id','=','cop_ratings.rating_type_id')
            ->where('cop_cs_ms.cs_name','!=','Upcoming')
            ->where('cop_city_ms.city_name',$cityName)
            ->where('cop_models.status','=',1)
            ->where('cop_pe_ms.status','=',1)
            ->where('cop_pe_ms.ex_showroom_price','>',$minPrice)
            ->distinct()
            ->get();
        }
        else {
            $formattedData = ['Enter minPrice and maxPrice properly'];
            return ResponseHelper::responseMessage('success', $formattedData);
        }

        foreach($answer as $item) {
            $engine = Model::select(
                'cop_features_ms.features_name',
                'cop_fv.feature_value',
                'cop_su_ms.su_name'
            )
            ->join('cop_fv','cop_fv.model_id','=','cop_models.model_id')
            ->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')
            ->leftJoin('cop_su_ms','cop_su_ms.su_id','=','cop_features_ms.su_id')
            ->where('cop_models.model_id',$item->model_id)
            ->where(function ($query) {
                $query->where('cop_features_ms.features_name','=','Displacement')
                      ->orWhere('cop_features_ms.features_name','=','Battery Capacity');
            })
            ->first();

            $seating = Model::select(
                'cop_variants.seating_capacity'
            )
            ->join('cop_variants','cop_variants.model_id','=','cop_models.model_id')
            ->where('cop_models.model_id',$item->model_id)
            ->orderByDesc('cop_variants.seating_capacity')
            ->first();

                $formattedData[] = [
                    'brand_id' => encryptor('e',$item->brand_id),
                    'brand_name' => $item->brand_name,

                    'model_id' => encryptor('e',$item->model_id),
                    'model_name' => $item->model_name,
                    'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_image}" ?? null,

                    'rating_type_name' => $item->rating_type_name ?? null,
                    'rating_value' => $item->rating_value ?? null,
                    'price' => $this->pricefilter($item->model_id),
                    // 'min_price' =>  convertToLakhCrore($item->min_price),
                    // 'max_price' =>  convertToLakhCrore($item->max_price),

                    'features_name' => $engine->features_name ?? null,
                    'feature_value' => $engine->feature_value ?? null,
                    'su_name' => $engine->su_name ?? null,

                    'seating_capacity' => $seating->seating_capacity
                ];
        }

        if ($answer->isEmpty()) {
            // return ResponseHelper::errorResponse('data_not_found');
            return ResponseHelper::errorResponse('data_not_found');
        }


        return ResponseHelper::responseMessage('success', $formattedData);
    }

    private function pricefilter($model_id)
    {
        $priceMinMax = Model::select(
            DB::raw('MIN(cop_pe_ms.ex_showroom_price) as min_ex_showroom_price'),
            DB::raw('MAX(cop_pe_ms.ex_showroom_price) as max_ex_showroom_price')
        )
            ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->where('cop_models.model_id', $model_id)
            ->where('cop_models.model_type', '0')
            ->first();

        return [
            'price_filter' => $priceMinMax['min_ex_showroom_price'],
            'min_ex_showroom_price' =>  convertToLakhCrore($priceMinMax['min_ex_showroom_price']),
            'max_ex_showroom_price' =>  convertToLakhCrore($priceMinMax['max_ex_showroom_price']),
        ];
    }
}