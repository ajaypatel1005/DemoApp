<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BuyNow;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Helpers\ResponseHelper;

class BuyNowApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    public function generateBookingId()
    {
        return strval( mt_rand(0000001,9999999));
    }

    public function index(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required',
            'model_id' => 'required',
            'variant_id' => 'required',
            'price_id' => 'required',
            'manager_id' => 'required',
            'city_id' => 'required',
        ]);

        if ($validator->fails()) {
            return ResponseHelper::errorResponse('missing_required_field');
        }

        $booking_id = 'BN'.$this->generateBookingId();
        $exists = BuyNow::where('booking_id', $booking_id)->exists();

        if ($exists) {
            do {
                $booking_id = 'BN'.$this->generateBookingId();
                $exists = BuyNow::where('booking_id', $booking_id)->exists();
            } while ($exists);
        }
        // dd($request->all());
        $addbuyNow = new BuyNow();
        $addbuyNow->customer_id = $request->customer_id;
        $addbuyNow->booking_id = $booking_id;
        $addbuyNow->model_id = $request->model_id;
        $addbuyNow->variant_id = $request->variant_id;
        $addbuyNow->price_id = $request->price_id;
        $addbuyNow->manager_user_id = $request->manager_id;
        $addbuyNow->city_id = $request->city_id;
        $addbuyNow->color_id = $request->color_id;

        $addbuyNow->save();
        return ResponseHelper::responseMessage('success', $addbuyNow);
    }
}
