<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use Illuminate\Http\Request;

class VersionControlApiController extends Controller
{
    public function Version(Request $request)
    {
        if (!$request->source && trim($request->source)==''){
            return ResponseHelper::errorResponse('missing_required_field');
        }

        if ($request->source == 'android') {
            $data['version']    = '1.1.0';
        } elseif ($request->source == 'ios') {
            $data['version']    = '1.15';
        } else {
            return ResponseHelper::errorResponse('error','Please enter correct source');
        }

        return ResponseHelper::responseMessage('success', $data);
    }
}