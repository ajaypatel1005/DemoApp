<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Mail\BookTestDriveOtpMail;
use App\Models\BookTestDrive;
use App\Models\Brand;
use App\Models\City;
use App\Models\CRM\Lead;
use App\Models\Customer;
use App\Models\FeatureValue;
use App\Models\Manager;
use App\Models\Model;
use App\Models\SerialNumber;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

use function Laravel\Prompts\select;

class BookTestDriveApiController extends Controller
{
    protected $imagePath;

    public function __construct()
    {
        $this->imagePath = env('IMAGE_PATH');
    }

    // to get all brand, its model, its fuel_type
    public function testDriveBrandModel()
    {
        $dataGet = Brand::with(['models' => function ($modelQuery) {
            $modelQuery->with(['feature_value' => function ($fvQuery) {
                $fvQuery->select('cop_fv.feature_value', 'cop_features_ms.features_name', 'model_id', 'brand_id')
                    ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                    ->whereIn('cop_features_ms.features_name', [
                        config('constant.TYPE_OF_FUEL')
                    ])
                    ->distinct();
            }, 'variants' => function ($vQuery) {
                $vQuery->select('cop_variants.variant_image', 'cop_variants.variant_id', 'model_id', 'brand_id')
                    ->orderBy('cop_variants.variant_id');
            }])
                ->select('cop_models.model_id', 'cop_models.model_name', 'cop_models.model_image', 'cop_models.model_id', 'cop_models.brand_id', 'cop_models.model_type')
                ->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
                ->where('cop_cs_ms.cs_name', config('constant.CAR_STAGE_LAUNCHED'))
                ->whereNotIn('cop_models.model_name', array_merge(
                    config('constant.EXCLUDE_MODEL'),
                    config('constant.UNVEILED_MODEL')
                ))
                ->where('cop_models.status', 1);
        }])
            ->whereHas('models', function ($query) {
                $query->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
                    ->where('cop_cs_ms.cs_name', config('constant.CAR_STAGE_LAUNCHED'))
                    ->whereNotIn('cop_models.model_name', array_merge(
                        config('constant.EXCLUDE_MODEL'),
                        config('constant.UNVEILED_MODEL')
                    ))
                    ->where('cop_models.status', 1);
            })
            ->select('cop_brands_ms.brand_id', 'cop_brands_ms.brand_name', 'cop_brands_ms.brand_id')
            ->whereNotIn('cop_brands_ms.brand_name', config('constant.EXCLUDE_BRAND'))
            ->where('cop_brands_ms.status', 1)
            ->orderBy('cop_brands_ms.priority','asc')
            ->get();

        $formattedData = $dataGet->map(function ($item) {
            $models = $item->models->map(function ($m_item) {
                $feature_value_data = [
                    'fuel_type' => []
                ];
                $m_item->feature_value->map(function ($fv_item) use (&$feature_value_data) {
                    if ($fv_item->features_name == config('constant.TYPE_OF_FUEL')) {
                        $feature_value_data['fuel_type'][] = $fv_item->feature_value;
                    }
                    return $feature_value_data;
                });

                $variant_image = '';
                if ($m_item->variants->isNotEmpty()) {
                    $variant_image = $this->imagePath . "brands/{$m_item->brand_id}/{$m_item->model_id}/{$m_item->variants[0]->variant_id}/{$m_item->variants[0]->variant_image}";
                }

                return [
                    'model_id' => encryptor('e', $m_item->model_id),
                    'model_name' => $m_item->model_name,
                    'model_image' => $variant_image,
                    'model_type' => ($m_item->model_type == 0) ? 'Non-EV' : 'EV',
                    'feature_values' => $feature_value_data
                ];
            });

            return [
                'brand_id' => encryptor('e', $item->brand_id),
                'brand_name' => $item->brand_name,
                'models' => $models
            ];
        });

        return ResponseHelper::responseMessage('success', $formattedData);
    }

    // to get transmission from model_id & fuel_type
    public function testDriveTransmission(Request $request)
    {
        // model_id input filed
        if (!$request->has('model_id') && trim($request->input('model_id')) == '') {
            return ResponseHelper::errorResponse('missing_required_field');
        } else {
            $model_id_dec = encryptor('d', $request->input('model_id'));
            if (!$model_id_dec) {
                return ResponseHelper::errorResponse('error', $request->input('model_id') . ' model_id is not found');
            } else {
                $model = Model::find($model_id_dec);

                if (!$model) {
                    return ResponseHelper::errorResponse('error', $request->input('model_id') . ' model_id is not found');
                } else {
                    $model_id = $model_id_dec;
                }
            }
        }

        // fuel_type input filed
        if (!$request->has('fuel_type') && trim($request->input('fuel_type')) == '') {
            return ResponseHelper::errorResponse('missing_required_field');
        } else {
            $fuel_type = $request->input('fuel_type');
        }

        $getTransmissionType = FeatureValue::select('cop_fv.feature_value')
            ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            ->whereIn('cop_fv.variant_id', function ($query) use (&$fuel_type, &$model_id) {
                $query->select(DB::raw('DISTINCT variant_id'))
                    ->from('cop_fv')
                    ->where('feature_value', $fuel_type)
                    ->where('model_id', $model_id);
            })
            ->where('cop_features_ms.features_name', config('constant.TYPE_OF_TRANSMISSION'))
            ->distinct()
            ->get();

        $data = [];
        $getTransmissionType->map(function ($item) use (&$data) {
            if ($item->feature_value == 'Manual') {
                $data[] = $item->feature_value;  // if transmission type is 'manual'
            } else {
                if (!in_array("Automatic", $data)) {
                    $data[] = "Automatic";  // if transmission type is other then 'manual' then will show it as 'automatic'
                }
            }
        });
        return ResponseHelper::responseMessage('success', $data);
    }

    // send mail OTP
    public function testDriveSendMailOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
        ], [
            'email,required' => 'Email field is required',
            'email.email' => 'It must be an valid email'
        ]);

        if ($validator->fails()) {
            $message = implode(',', $validator->errors()->all());
            return ResponseHelper::errorResponse('error', $message);
        }

        try {
            $otp = rand(100000, 999999); // generate 6 digit otp using random function

            // Store OTP in cache with a 10-minute expiry
            Cache::put("otp_{$request->email}", $otp, now()->addMinutes(2));

            // Send the OTP email
            Mail::to($request->email)->send(new BookTestDriveOtpMail($otp));

            return ResponseHelper::responseMessage('success', ['OTP sent successfully!']);
        } catch (\Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // verify mail OTP
    public function testDriveVerifyMailOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'otp' => 'required|digits:6',
        ], [
            'email,required' => 'Email field is required',
            'email.email' => 'It must be an valid email',
            'otp.required' => 'Please enter 6 digits OTP',
            'otp.digits' => 'OTP must be an 6 digits only'
        ]);

        if ($validator->fails()) {
            $message = implode(',', $validator->errors()->all());
            return ResponseHelper::errorResponse('error', $message);
        }

        try {
            $email = $request->email;
            $getOtp = $request->otp;

            $sentOtp = Cache::get("otp_{$email}");
            if ($sentOtp == $getOtp) {
                return ResponseHelper::responseMessage('success', ['OTP verified successfully!']);
                Cache::forget("otp_{$email}");
            } else {
                return ResponseHelper::errorResponse('error', 'Entered OTP not matched!');
            }
        } catch (\Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // submit book-test-drive data (with authToken)
    public function testDriveSubmit(Request $request)
    {
        $customerId = Auth::guard('api')->id();
        $validator = Validator::make($request->all(), [
            'lat_long' => 'required', // lat long
            'full_address' => 'required', // text full address
            'email' => 'required',
            'name' => 'required',
            'brand_id' => 'required',
            'model_id' => 'required',
            'fuel_types' => 'required',
            'transmission' => 'required',
            'estimated_purchase_date' => 'required',
        ]);

        if ($validator->fails()) {
            $validtion_error = implode(',', $validator->errors()->all());
            return ResponseHelper::errorResponse('missing_required_field', $validtion_error);
        }

        try {
            DB::beginTransaction();

            // generate booking_id
            $serialNo = SerialNumber::select('count')->where('type', config('constant.SERIAL_NUMBER.TEST_DRIVE_TYPE'))->first();
            $testDriveCount = $serialNo->count + 1;
            $bookingId = config('constant.SERIAL_NUMBER.TEST_DRIVE_PREFIX') . padWithZeros($testDriveCount);

            // insert data of book test drive
            BookTestDrive::create([
                'customer_id' => $customerId,
                'location' => $request->lat_long,
                'address' => $request->full_address,
                'email' => $request->email,
                'name' => $request->name,
                'brand_id' => encryptor('d', $request->brand_id),
                'model_id' => encryptor('d', $request->model_id),
                'fuel_types' => $request->fuel_types,
                'transmission' => $request->transmission,
                'estimated_purchase_date' => $request->estimated_purchase_date,
                'booking_id' => $bookingId
            ]);

            // update new count of book-test-drive in serial_number table
            $newSerianNoUpdate = SerialNumber::where('type', config('constant.SERIAL_NUMBER.TEST_DRIVE_TYPE'))->first();
            $newSerianNoUpdate->update([
                'count' => $testDriveCount,
            ]);
            DB::commit();

            // show the message of booked test drive sucessfully...
            $model = Model::with('brand')->where('model_id', encryptor('d', $request->model_id))->first();
            return ResponseHelper::responseMessage('success', ['Your test drive for ' . $model->brand->brand_name . ' ' . $model->model_name . ' is confirmed.']);
        } catch (\Exception $e) {
            DB::rollBack();
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRETNLY -> generateBookingId)
    public function generateBookingId()
    {
        return strval(mt_rand(0000001, 9999999));
    }

    // (NOT IN USE CURRETNLY -> addTestDrive)
    public function addTestDrive(Request $request)
    {
        try {
            // Create lead record
            $customer_data = Customer::where('customer_id', auth()->id())->first();
            $customer_id = $customer_data->customer_id;
            $customer_name = encryptor('d', $customer_data->first_name) . ' ' . encryptor('d', $customer_data->last_name);
            $ls_id = 2;
            $lp_id = 1;
            $ls_status_id = 1;

            $validator = Validator::make($request->all(), [
                'customer_id' => 'required',
                'model_id' => 'required',
                'brand_id' => 'required',
                'fuel_types' => 'required',
                'additional_notes' => 'nullable',
                'btest_date' => 'required',
                'btest_time' => 'required',
                'city_id' => 'required',
            ]);

            if ($validator->fails()) {
                return ResponseHelper::errorResponse('missing_required_field');
            }

            // $manager_ID = '';
            $brand_id = $request->brand_id;
            $manager_id = Manager::select('user_id')->where('brand_id', $brand_id)->get()->first();
            $state_id = $request->state_id;
            $city_id = $request->city_id;
            $state_id = City::where('city_id', $city_id)
                ->join('cop_state_ms', 'cop_state_ms.state_id', '=', 'cop_city_ms.state_id')
                ->select('cop_state_ms.state_id')
                ->get();

            $get_manager = Manager::where('brand_id', $brand_id)
                ->whereNotIn('user_id', function ($query) use ($brand_id) {
                    $query->select('manager_user_id')
                        ->from('cop_leads')
                        ->where('brand_id', $brand_id);
                })
                ->pluck('user_id')
                ->toArray();

            if ($get_manager) {
                $manager_ID = $get_manager[0];
            } else {
                $count_results = Lead::selectRaw('manager_user_id, COUNT(manager_user_id) as count')
                    ->where('brand_id', $brand_id)
                    ->groupBy('manager_user_id')
                    ->get();

                $min_count = PHP_INT_MAX;
                $min_count_manager_id = null;

                foreach ($count_results as $count_result) {
                    $manager_id = $count_result['manager_user_id'];
                    $count = $count_result['count_id'];
                    if ($count < $min_count) {
                        $min_count = $count;
                        $min_count_manager_id = $manager_id;
                    }
                }
                if ($min_count_manager_id !== null) {
                    $manager_ID = $min_count_manager_id;
                }
            }

            $booking_id = 'BT' . $this->generateBookingId();
            $exists = BookTestDrive::where('booking_id', $booking_id)->exists();

            if ($exists) {
                do {
                    $booking_id = 'BT' . $this->generateBookingId();
                    $exists = BookTestDrive::where('booking_id', $booking_id)->exists();
                } while ($exists);
            }
            // dd($get_manager);
            $test_drive = new BookTestDrive();
            $test_drive->customer_id = $request->customer_id;
            $test_drive->booking_id = $booking_id;
            $test_drive->manager_user_id = $manager_ID;
            $test_drive->model_id = $request->model_id;
            $test_drive->brand_id = $request->brand_id;
            $test_drive->fuel_types = $request->fuel_types;
            $test_drive->additional_notes = $request->additional_notes;
            $test_drive->btest_date = $request->btest_date;
            $test_drive->btest_time = $request->btest_time;
            $test_drive->state_id = $state_id;
            $test_drive->city_id = $city_id;
            $test_drive->save();

            Lead::create([
                'lead_name' => $customer_name,
                'lead_contact' => encryptor('d', $customer_data->contact_no),
                'lead_email' => $customer_data->email,
                'brand_id' => $brand_id,
                'model_id' => $request->model_id,
                'manager_user_id' => $manager_ID,
                'state_id' => $state_id,
                'city_id' => $city_id,
                'lp_id' => $lp_id,
                'ls_id' => $ls_id,
                'ls_status_id' => $ls_status_id,
                'customer_id' => $customer_id
            ]);

            return ResponseHelper::responseMessage('success', $test_drive);
        } catch (\Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
