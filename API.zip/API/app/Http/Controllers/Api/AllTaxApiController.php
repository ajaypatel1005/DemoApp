<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AllTax;
use Exception;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\Helpers\ResponseHelper;

class AllTaxApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {
            $all_tax_view = AllTax::select('tax_name','display_name','status')
            ->where('status',1)->get();

            if ($all_tax_view->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }


            $formattedData = $all_tax_view->map(function ($item) {

                $data = [
                    'tax_id' => encryptor('e',$item->tax_id),
                    'tax_name' => $item->tax_name,
                    'display_name' => $item->display_name,
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('error');
        }
    }
    
}
