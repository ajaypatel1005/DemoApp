<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AllTax;
use App\Models\City;
use Exception;
use App\Traits\LocationTrait;
use App\Http\Controllers\Helpers\ResponseHelper;
// use App\Http\Controllers\App\Providers;

class LocationApiController extends Controller
{
    use LocationTrait;
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    // (NOT IN USE CURRETNLY -> index)
    public function index(Request $request)
    {
        $location = $this->getCurrentLocation($request);
        return response()->json(['location' => $location]);
    }

    public function popular_city(Request $request)
    {
        try {
            $defaultCities = config('constant.CITY_LIST');
            $popularCity = $otherCity = [];
            $allCity =  City::RightJoin('cop_pe_ms','cop_pe_ms.city_id','cop_city_ms.city_id')
            ->whereNotNull('cop_pe_ms.city_id')
            ->select('cop_pe_ms.city_id', 'cop_city_ms.city_name', 'city_image')
            ->groupBy('cop_pe_ms.city_id','cop_city_ms.city_name','cop_city_ms.city_image')
            ->get()->map(function ($data) use (&$popularCity, &$otherCity,$defaultCities) {
            
                if (in_array(strtolower($data->city_name), array_map('strtolower', $defaultCities))) {
                    $popularCity[] = ['city_id' => encryptor('e',$data->city_id),
                    'city_name' => $data->city_name,
                    'city_image' => $this->imagePath. 'city_image/' . $data->city_id . '/' . $data->city_image
                    ];
                } else {
                    $otherCity[] = ['city_id' => encryptor('e',$data->city_id),
                    'city_name' => $data->city_name,
                    ];
                }
                
            });
            $formatData =['popular_city' => $popularCity,'other_city' => $otherCity]; 
            return ResponseHelper::responseMessage('success', $formatData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
