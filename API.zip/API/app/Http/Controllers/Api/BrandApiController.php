<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\City;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Model;
use App\Models\PriceEntry;
use App\Models\Variant;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\Helpers\CommanFunctionApi;
use App\Models\Wishlist;

use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\DB;

// use GuzzleHttp\Psr7\Request;

class BrandApiController extends Controller
{

    protected $commanFunctionApi;
    protected $imagePath;

    public function __construct(CommanFunctionApi $commanFunctionApi)
    {
        $this->commanFunctionApi = $commanFunctionApi;
        $this->imagePath = env('IMAGE_PATH');
    }

    // to get all brands (app & website both) (3-4-2024)
    public function brand()
    {
        try {

            $brands = Brand::select(
                'cop_brands_ms.brand_name',
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_description',
                'cop_brands_ms.brand_logo',
                'cop_brands_ms.brand_banner',
                'cop_brands_ms.slug AS brand_slug',
            )
            ->join('cop_models', 'cop_models.brand_id','=','cop_brands_ms.brand_id')
            ->join('cop_cs_ms', 'cop_models.cs_id','=','cop_cs_ms.cs_id')
            ->where('cop_cs_ms.cs_name',config('constant.CAR_STAGE_LAUNCHED'))
            ->orderBy('priority', 'asc')
            ->where('cop_brands_ms.status', 1)
            ->where('cop_models.status', 1)
            ->distinct('cop_brands_ms.brand_id')
            ->get();

            // $brands = Brand::select(
            //         'cop_brands_ms.brand_name',
            //         'cop_brands_ms.brand_id',
            //         'cop_brands_ms.brand_description',
            //         'cop_brands_ms.brand_logo',
            //         'cop_brands_ms.brand_banner',
            //         'cop_brands_ms.slug AS brand_slug',
            //     )
            //     ->with('models')
            //     ->whereHas('models', function($query){
            //         $query->with('car_stage')
            //         ->whereHas('car_stage', function($query){
            //             $query->where('cs_name',config('constant.CAR_STAGE_LAUNCHED'));
            //         })
            //     ->where('status',1);
            //     })
            //     ->where('status',1)
            //     ->orderBy('priority', 'asc')
            //     ->distinct('cop_brands_ms.brand_id')
            //     ->get();

            if ($brands->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $allBrandsData = $brands->map(function ($item) {
                $data = [
                    'brand_id' => encryptor('e', $item->brand_id),
                    'brand_name' => $item->brand_name,
                    'brand_description' => $item->brand_description,
                    'brand_logo' => $this->imagePath . "brands/{$item->brand_id}/{$item->brand_logo}",
                    'brand_banner' => $this->imagePath . "brands/{$item->brand_id}/{$item->brand_banner}",
                    'brand_slug' => $item->brand_slug,
                ];
                return  $data;
            });

            return ResponseHelper::responseMessage('success', $allBrandsData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRETNLY -> brandDetail) explore brand/brand details page (for website)
    public function brandDetail($id)
    {
        try {
            $brand_name = $id;
            $brandDetails = Brand::join('cop_models', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                ->select(
                    'cop_cs_ms.cs_name',
                    'cop_ct_ms.ct_name',
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_brands_ms.brand_description',
                    'cop_brands_ms.brand_banner',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_type',
                    'cop_models.model_image',
                    'cop_variants.variant_id',
                    'cop_variants.variant_name',
                    'cop_variants.seating_capacity',
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                )
                ->where('cop_brands_ms.brand_name', '=', $brand_name)
                ->where('cop_cs_ms.cs_name', '=', 'Launched')
                ->where('cop_variants.variant_id', '=', function ($query) {
                    $query->select('variant_id')
                        ->from('cop_variants')
                        ->whereColumn('cop_variants.model_id', '=', 'cop_models.model_id')
                        ->where('cop_variants.status', '=', 1)
                        ->orderBy('variant_id')
                        ->limit(1);
                })
                ->where('cop_models.status', '=', 1)
                ->where('cop_brands_ms.status', '=', 1)
                ->where('cop_variants.status', '=', 1)
                ->distinct()
                ->get();

            if ($brandDetails->isEmpty()) {

                $brandDetail = Brand::select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_brands_ms.brand_description',
                    'cop_brands_ms.brand_banner',
                )
                    ->where('cop_brands_ms.brand_name', '=', $brand_name)

                    ->where('cop_brands_ms.status', '=', 1)

                    ->distinct()
                    ->get();
                $brandsDatas = $brandDetail->map(function ($item) {
                    $data = [
                        'brand_id' => encryptor('e', $item->brand_id),
                        'brand_name' => $item->brand_name,
                        'brand_description' => $item->brand_description,
                        'brand_logo' => $this->imagePath . "brands/{$item->brand_id}/{$item->brand_id}.webp" ?? null,
                        'brand_banner' => $this->imagePath . "brands/{$item->brand_id}/{$item->brand_id}_banner.webp" ?? null,
                        'models' => [],
                    ];
                    return  $data;
                });

                return ResponseHelper::responseMessage('success', $brandsDatas);
            }

            $grouped_models = $brandDetails->groupBy('brand_id');

            $result = [];

            foreach ($grouped_models as $brand_id => $models) {
                $brand_name = Brand::where('brand_id', $brand_id)->value('brand_name');
                $brand_description = Brand::where('brand_id', $brand_id)->value('brand_description');
                $brand_banner = Brand::where('brand_id', $brand_id)->value('brand_banner');

                $brand_data = [
                    'brand_id' => encryptor('e', $brand_id),
                    'brand_name' => $brand_name,
                    'brand_description' => $brand_description,
                    'brand_banner' => asset("brands/{$brand_id}/{$brand_id}_banner.webp") ?? null,

                    'models' => [],
                ];
                foreach ($models as $model) {
                    $model_data = [
                        'ct_name' => $model->ct_name,
                        'model_id' => encryptor('e', $model->model_id),
                        'brand_name' => $brand_name,
                        'model_name' => $model->model_name,

                        'price' => $this->commanFunctionApi->pricefilter($model->model_id),

                        'model_type' => $model->model_type == 0 ? 'Non EV' : 'EV',
                        'model_image' => $this->imagePath . "brands/{$model->brand_id}/{$model->model_id}/{$model->model_id}.webp" ?? null,
                        'rating_type_name' => $model->rating_type_name,
                        'rating_value' => isset($model->rating_value) ? number_format((float)$model->rating_value, 1, '.', '') : NULL,
                        'variants' => [],
                    ];

                    $variants =  $models->where('variant_id', $model->variant_id)->map(function ($variant) {
                        return [
                            'variant_id' => encryptor('e', $variant->variant_id),
                            'variant_name' => $variant->variant_name,
                            'seating_capacity' => $variant->seating_capacity,
                            'features' => [],
                        ];
                    })->values()->toArray();
                    foreach ($variants as &$variant) {
                        $variantDetails = Variant::join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                            ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                            ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                            ->select(
                                'cop_fv.feature_value',
                                'cop_features_ms.features_name',
                                'cop_su_ms.su_name'
                            )
                            ->where('cop_variants.variant_id', encryptor('e', $variant['variant_id']))
                            ->where(function ($query) {
                                $query->whereIn('cop_features_ms.features_name', ['Displacement', 'Battery Capacity']);
                            })
                            ->distinct()
                            ->where('cop_variants.status', '=', 1)
                            ->where('cop_features_ms.status', '=', 1)
                            ->where('cop_fv.status', '=', 1)
                            ->get();
                        $variant['features'] = $variantDetails->toArray();
                    }
                    $variants = is_array($variants) ? $variants : [$variants];
                    $model_data['variants'] = $variants;
                    $brand_data['models'][] = $model_data;
                }

                $result[] = $brand_data;
            }

            return ResponseHelper::responseMessage('success', $result);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // explore brand/brand details page (for app) (3-4-2024)
    public function explore_brand(Request $request)
    {
        try {
            // city_id input field
            if (!$request->has('city_id') && trim($request->input('city_id')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $city_id_dec = encryptor('d', $request->input('city_id'));
                if (!$city_id_dec) {
                    return ResponseHelper::errorResponse('error', $request->input('city_id') . ' city_id is not found');
                } else {
                    $city = City::find($city_id_dec);

                    if (!$city) {
                        return ResponseHelper::errorResponse('error', $request->input('city_id') . ' city_id is not found');
                    } else {
                        $city_id = $city_id_dec;
                    }
                }
            }

            // brand_id input filed
            if (!$request->has('brand_id') && trim($request->input('brand_id')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                // dd(encryptor('e', $request->input('brand_id')));
                $brand_id_dec = encryptor('d', $request->input('brand_id'));
                if (!$brand_id_dec) {
                    return ResponseHelper::errorResponse('error', $request->input('brand_id') . ' brand_id is not found');
                } else {
                    $brand = Brand::find($brand_id_dec);

                    if (!$brand) {
                        return ResponseHelper::errorResponse('error', $request->input('brand_id') . ' brand_id is not found');
                    } else {
                        $brand_id = $brand_id_dec;
                    }
                }
            }

            // car stage as launched
            $carStageLaunched = config('constant.CAR_STAGE_LAUNCHED');
            $auth_id = Auth::guard('api')->id();

            $brandDetails = Brand::with(['models' => function ($querys) use ($city_id, $carStageLaunched, $auth_id) {
                $querys->select(
                    'cop_ct_ms.ct_name',
                    'cop_models.brand_id',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_type',
                    'cop_models.model_image',
                    'cop_rating_types.rating_type_name',
                    'cop_ratings.rating_value',
                    DB::raw('(SELECT MIN(ex_showroom_price) FROM cop_pe_ms WHERE city_id = "' . $city_id . '" AND model_id = cop_models.model_id AND cop_pe_ms.status = 1) as min_ex_showroom_price'),
                    DB::raw('(SELECT MAX(ex_showroom_price) FROM cop_pe_ms WHERE city_id = "' . $city_id . '" AND model_id = cop_models.model_id AND cop_pe_ms.status = 1) as max_ex_showroom_price'),
                    DB::raw("(select wl_id from cop_wl where cop_wl.model_id = cop_models.model_id and customer_id = '$auth_id') as wl_id")
                )
                    ->with(['variants' => function ($queryss) {
                        $queryss->select('variant_image', 'variant_id', 'model_id');
                    }])
                    ->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
                    ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                    ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_rating_types', 'cop_rating_types.rating_type_id', '=', 'cop_ratings.rating_type_id')
                    ->where('cop_cs_ms.cs_name', $carStageLaunched)
                    ->where('cop_models.status', 1)
                    ->orderBy('cop_models.model_id', 'asc');
            }])
                ->select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_brands_ms.brand_description',
                    'cop_brands_ms.brand_logo',
                    'cop_brands_ms.brand_banner',
                )
                ->join('cop_models', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->where('cop_brands_ms.brand_id', $brand_id)
                ->where('cop_brands_ms.status', 1)
                ->where('cop_models.status', 1)
                ->distinct()
                ->get();

            if (!$brandDetails) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $exploreBrandApp = null;
            $brandDetails->map(function ($itemBrand) use (&$exploreBrandApp) {

                $modelData = [];
                $itemBrand->models->map(function ($itemModel) use (&$modelData) {

                    $variant = $itemModel->variants->first();
                    if (!empty($variant)) {
                        $modelData[] = [
                            'ct_name' => $itemModel->ct_name,
                            'model_id' => encryptor('e', $itemModel->model_id),
                            'model_name' => $itemModel->model_name,
                            'price' => [
                                'min_ex_showroom_price' => $itemModel->min_ex_showroom_price ?  convertToLakhCrore($itemModel->min_ex_showroom_price) : null,
                                'max_ex_showroom_price' => $itemModel->max_ex_showroom_price ?  convertToLakhCrore($itemModel->max_ex_showroom_price) : null,
                            ],
                            'model_type' => $itemModel->model_type == 0 ? 'Non EV' : 'EV',
                            'model_image' => $this->imagePath . "brands/{$itemModel->brand_id}/{$itemModel->model_id}/{$itemModel->model_image}",
                            'wishlist' => (!empty($itemModel->wl_id) ? true : false),
                            'rating_type_name' => $itemModel->rating_type_name,
                            'rating_value' => isset($itemModel->rating_value) ? number_format((float)$itemModel->rating_value, 1, '.', '') : null,

                            'variant_image' => $this->imagePath . "brands/{$itemModel->brand_id}/{$variant->model_id}/{$variant->variant_id}/{$variant->variant_image}",
                        ];
                    }
                });

                $exploreBrandApp = [
                    'brand_id' => encryptor('e', $itemBrand->brand_id),
                    'brand_name' => $itemBrand->brand_name,
                    'brand_description' => $itemBrand->brand_description,
                    'brand_logo' => $this->imagePath . "brands/{$itemBrand->brand_id}/{$itemBrand->brand_logo}",
                    'brand_banner' => $this->imagePath . "brands/{$itemBrand->brand_id}/{$itemBrand->brand_banner}",
                    'models' => $modelData,
                ];
            });

            return ResponseHelper::responseMessage('success', $exploreBrandApp);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // explore brand/brand details page (for react)
    public function explore_brand_data(Request $request,$brand_slug)
    {
        try {
            // city_id input field
            if (!$request->has('city_id') && trim($request->input('city_id')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $city_id_dec = encryptor('d', $request->input('city_id'));
                if (!$city_id_dec) {
                    return ResponseHelper::errorResponse('error', $request->input('city_id') . ' city_id is not found');
                } else {
                    $city = City::find($city_id_dec);

                    if (!$city) {
                        return ResponseHelper::errorResponse('error', $request->input('city_id') . ' city_id is not found');
                    } else {
                        $city_id = $city_id_dec;
                    }
                }
            }


            // car stage as launched
            $carStageLaunched = config('constant.CAR_STAGE_LAUNCHED');
            $auth_id = Auth::guard('api')->id();
           
            $brandDetails = Brand::with(['models' => function ($querys) use ($city_id, $carStageLaunched, $auth_id) {
                $querys->select(
                    'cop_ct_ms.ct_name',
                    'cop_models.brand_id',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_type',
                    'cop_models.model_image',
                    'cop_rating_types.rating_type_name',
                    'cop_ratings.rating_value',
                    DB::raw('(SELECT MIN(ex_showroom_price) FROM cop_pe_ms WHERE city_id = "' . $city_id . '" AND model_id = cop_models.model_id AND cop_pe_ms.status = 1) as min_ex_showroom_price'),
                    DB::raw('(SELECT MAX(ex_showroom_price) FROM cop_pe_ms WHERE city_id = "' . $city_id . '" AND model_id = cop_models.model_id AND cop_pe_ms.status = 1) as max_ex_showroom_price'),
                    DB::raw("(select wl_id from cop_wl where cop_wl.model_id = cop_models.model_id and customer_id = '$auth_id') as wl_id")
                )
                    ->with(['variants' => function ($queryss) {
                        $queryss->select('variant_image', 'variant_id', 'model_id');
                    }])
                    ->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
                    ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                    ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_rating_types', 'cop_rating_types.rating_type_id', '=', 'cop_ratings.rating_type_id')
                    ->where('cop_cs_ms.cs_name', $carStageLaunched)
                    ->orderBy('cop_models.model_id', 'asc');
            }])
                ->select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_brands_ms.brand_description',
                    'cop_brands_ms.brand_logo',
                    'cop_brands_ms.brand_banner',
                )
                ->join('cop_models', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->where('cop_brands_ms.slug', $brand_slug)
                ->where('cop_brands_ms.status', 1)
                ->where('cop_models.status', 1)
                ->distinct()
                ->get();

            if (!$brandDetails) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $exploreBrandApp = null;
            $brandDetails->map(function ($itemBrand) use (&$exploreBrandApp) {

                $modelData = [];
                $itemBrand->models->map(function ($itemModel) use (&$modelData) {

                    $variant = $itemModel->variants->first();
                    if (!empty($variant)) {
                        $modelData[] = [
                            'ct_name' => $itemModel->ct_name,
                            'model_id' => encryptor('e', $itemModel->model_id),
                            'model_name' => $itemModel->model_name,
                            'price' => [
                                'min_ex_showroom_price' => $itemModel->min_ex_showroom_price ?  convertToLakhCrore($itemModel->min_ex_showroom_price) : null,
                                'max_ex_showroom_price' => $itemModel->max_ex_showroom_price ?  convertToLakhCrore($itemModel->max_ex_showroom_price) : null,
                            ],
                            'model_type' => $itemModel->model_type == 0 ? 'Non EV' : 'EV',
                            'model_image' => $this->imagePath . "brands/{$itemModel->brand_id}/{$itemModel->model_id}/{$itemModel->model_image}",
                            'wishlist' => (!empty($itemModel->wl_id) ? true : false),
                            'rating_type_name' => $itemModel->rating_type_name,
                            'rating_value' => isset($itemModel->rating_value) ? number_format((float)$itemModel->rating_value, 1, '.', '') : null,

                            'variant_image' => $this->imagePath . "brands/{$itemModel->brand_id}/{$variant->model_id}/{$variant->variant_id}/{$variant->variant_image}",
                        ];
                    }
                });

                $exploreBrandApp = [
                    'brand_id' => encryptor('e', $itemBrand->brand_id),
                    'brand_name' => $itemBrand->brand_name,
                    'brand_description' => $itemBrand->brand_description,
                    'brand_logo' => $this->imagePath . "brands/{$itemBrand->brand_id}/{$itemBrand->brand_logo}",
                    'brand_banner' => $this->imagePath . "brands/{$itemBrand->brand_id}/{$itemBrand->brand_banner}",
                    'models' => $modelData,
                ];
            });

            return ResponseHelper::responseMessage('success', $exploreBrandApp);
        } catch (Exception $e) {
            \Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRENTLY -> globalSearch) global serach
    public function globalSearch(Request $request)
    {
        try {
            $search_keyword = $request->input('search_keyword');


            if (empty($search_keyword)) {

                return ResponseHelper::errorResponse('data_not_found');
            }

            $all_models = Model::select('cop_brands_ms.brand_id', 'cop_brands_ms.brand_name', 'cop_models.model_name', 'cop_models.model_id')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->where(function ($query) use ($search_keyword) {
                    $query->where('cop_brands_ms.brand_name', 'like', '%' . $search_keyword . '%')
                        ->orWhere('cop_models.model_name', 'like', '%' . $search_keyword . '%');
                })
                ->where('cop_cs_ms.cs_name', '!=', 'Upcoming')
                ->where('cop_models.status', '=', 1)
                ->where('cop_brands_ms.status', '=', 1)
                ->get();

            if ($all_models->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }

            $result = [];

            foreach ($all_models as $model) {
                $brand_name = Brand::where('brand_id', $model->brand_id)->value('brand_name');

                $variants = Variant::where('model_id', $model->model_id)
                    ->where('cop_variants.status', '=', 1)
                    ->get();

                $variant_data = [];

                foreach ($variants as $variant) {
                    $priceEntry = PriceEntry::where('variant_id', $variant->variant_id)
                        ->where('cop_pe_ms.status', '=', 1)
                        ->first();
                    if ($priceEntry) {
                        $variant_data[] = [
                            'variant_id' => encryptor('e', $variant->variant_id),
                            'variant_name' => $variant->variant_name,
                        ];
                    }
                }

                $model_data = [
                    'model_id' => encryptor('e', $model->model_id),
                    'model_name' => $model->model_name,
                    'variants' => $variant_data,
                ];

                if (!isset($result[$brand_name])) {
                    $result[$brand_name] = [
                        'brand_id' => encryptor('e', $model->brand_id),
                        'brand_name' => $brand_name,
                        'models' => [],
                    ];
                }

                $result[$brand_name]['models'][] = $model_data;
            }


            $result = array_values($result);

            return ResponseHelper::responseMessage('success', $result);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
