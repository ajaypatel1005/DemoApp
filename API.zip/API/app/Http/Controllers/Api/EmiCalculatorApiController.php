<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Brand;
use App\Models\Model;
use App\Models\PriceEntry;
use App\Models\Variant;

class EmiCalculatorApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> getprice)
    public function getprice(Request $request)
    {
        $expectedOrder = ['model_id', 'variant_id', 'city_id'];
        $selectedParameters = [];
        try {
            $emi = PriceEntry::select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_city_ms.city_id',
                'cop_city_ms.city_name',
                'cop_pe_ms.*',
                'cop_variants.variant_id',
                'cop_variants.variant_name',
                'cop_variants.variant_image',
                'cop_variants.seating_capacity',
                'cop_msd.model_engine',
                'cop_rating_types.rating_type_name',
                'cop_ratings.rating_value',
                'cop_features_ms.features_name',
                'cop_features_ms.feature_id',
                'cop_fv.feature_value',
                'cop_su_ms.su_name'
            )
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_pe_ms.brand_id')

                ->join('cop_models', 'cop_models.model_id', '=', 'cop_pe_ms.model_id')
                ->join('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                ->join('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->join('cop_rating_types', 'cop_rating_types.rating_type_id', '=', 'cop_ratings.rating_type_id')

                ->join('cop_variants', 'cop_variants.variant_id', '=', 'cop_pe_ms.variant_id')

                ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')

                ->whereRaw("(CASE WHEN cop_models.model_type = 0 THEN cop_features_ms.features_name='Displacement' ELSE cop_features_ms.features_name='Battery Capacity' END)", [])
                ->where('cop_brands_ms.status', '!=', 0)
                ->where('cop_models.status', '!=', 0)
                ->where('cop_city_ms.status', '!=', 0)
                ->where('cop_variants.status', '!=', 0)
                ->where('cop_fv.status', '!=', 0)
                ->where('cop_features_ms.status', '!=', 0)
                ->where('cop_pe_ms.status', '!=', 0);

            foreach ($expectedOrder as $parameter) {
                if ($request->has($parameter)) {
                    $emi->where('cop_pe_ms.' . $parameter, encryptor('e',$request->$parameter));

                    // dd($parameter);
                    $selectedParameters[] = $parameter;
                } else {
                    break;
                }
            }

            if (in_array('variant_id', $selectedParameters) && in_array('model_id', $selectedParameters) && in_array('city_id', $selectedParameters)) {
                $emi = $emi->get();

                if ($emi->isEmpty()) {

                    return ResponseHelper::errorResponse('data_not_found');
                }
                // dd($emi->toSql());
                $formattedData = $emi->map(function ($item) {

                    $data = [
                        'pe_id' => encryptor('e',$item->pe_id),

                        'brand_id' => encryptor('e',$item->brand_id),
                        'brand_name' => $item->brand_name,

                        'model_id' => encryptor('e',$item->model_id),
                        'model_name' => $item->model_name,

                        'variant_id' => encryptor('e',$item->variant_id),
                        'variant_name' => $item->variant_name,
                        // 'variant_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_image}") ?? NULL,
                        'variant_image' => $this->imagePath ."brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_image}" ?? null,

                        'city_id' => encryptor('e',$item->city_id),
                        'city_name' => $item->city_name,

                        'rating_value' => $item->rating_value,
                        'rating_type_name' => $item->rating_type_name,

                        'ex_showroom_price' =>  convertToLakhCrore($item->ex_showroom_price),
                        'actual_price' => $item->ex_showroom_price,
                        'feature_id' => encryptor('e',$item->feature_id),
                        'feature_value' => $item->feature_value,
                        'su_name' => $item->su_name,

                        'seating_capacity' => $item->seating_capacity,

                    ];
                    return $data;
                });

                return ResponseHelper::responseMessage('success', $formattedData);
            }

            if (in_array('variant_id', $selectedParameters)) {

                $selectedVariantId = encryptor('e',$request->input('variant_id'));

                $cities = PriceEntry::join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
                    ->where('cop_pe_ms.variant_id', $selectedVariantId)
                    ->where('cop_city_ms.status', '!=', 0)
                    ->get();
                // dd($cities->toSql());
                $cityData = [];
                foreach ($cities as $item) {
                    $cityData[] = [
                        'pe_id' => encryptor('e',$item->pe_id),
                        'city_id' => encryptor('e',$item->city_id),
                        'city_name' => $item->city_name,
                    ];
                }
                return response()->json(['cities' => $cityData]);
            }

            // Check if 'model_id' is selected
            elseif (in_array('model_id', $selectedParameters)) {
                $selectedModelId = encryptor('e',$request->input('model_id'));

                // Fetch variants matching with the selected model
                $variants = Variant::where('model_id', $selectedModelId)->get();

                $variantData = [];
                foreach ($variants as $variant) {
                    $variantData[] = [
                        'variant_id' => encryptor('e',$variant->variant_id),
                        'variant_name' => $variant->variant_name,
                    ];
                }

                return response()->json(['variants' => $variantData]);
            } else {

                $data = [];
                $brands = Brand::where('status', '=', 1)->get();

                if (!empty($brands)) {
                    foreach ($brands as $brand) {
                        $brandData = [
                            'brand_id' => encryptor('e',$brand->brand_id),
                            'brand_name' => $brand->brand_name,
                            'models' => [],
                        ];

                        $models = Model::where('brand_id', $brand->brand_id)
                            ->where('status', '=', 1)
                            ->get();

                        foreach ($models as $model) {
                            $modelData = [
                                'model_id' => encryptor('e',$model->model_id),
                                'model_name' => $model->model_name,
                                'variants' => [],
                            ];

                            $variants = Variant::where('model_id', $model->model_id)
                                ->where('status', '=', 1)
                                ->get();

                            foreach ($variants as $variant) {
                                $variantData = [
                                    'variant_id' => encryptor('e',$variant->variant_id),
                                    'variant_name' => $variant->variant_name,
                                ];

                                $modelData['variants'][] = $variantData;
                            }

                            $brandData['models'][] = $modelData;
                        }

                        $data['brands'][] = $brandData;
                    }
                }

                return response()->json($data);
            }
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse('error');
            return ResponseHelper::errorResponse('error');
        }
    }
}