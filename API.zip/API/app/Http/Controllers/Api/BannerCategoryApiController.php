<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Models\BannerCategory;
use App\Http\Controllers\Helpers\ResponseHelper;

class BannerCategoryApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    // (NOT IN USE CURRENTLY -> index)
    public function index()
    {
        try {
            $banner_cat = BannerCategory::all();
            // dd($models);

            if ($banner_cat->isEmpty()) {


                return ResponseHelper::errorResponse('data_not_found');
            }
            $formattedData = $banner_cat->map(function ($item) {


                $data = [
                    'banner_cat_id' => encryptor('e',$item->bc_id),
                    'banner_cat' => $item->bc_name,
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('error');
        }
    }
}
