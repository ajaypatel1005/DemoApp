<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\Variant;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CarType;
use App\Models\FeatureValue;
use App\Models\Feature;
use App\Models\Model;
use Illuminate\Support\Facades\DB;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;

class AdvancedSearchApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    public function advance_search_model(Request $request)
    {
        try{
            if(!$request->has('city_id') && trim($request->input('city_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $city_id=encryptor('d',$request->input('city_id'));

            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]); //$brandArr[$i];
            }

            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    foreach ($budgetData as $budgetRange) {
                        if(!empty($budgetWordArr[$budgetRange[0].' to '.$budgetRange[1]])){
                            $search_filter[]=$budgetWordArr[$budgetRange[0].' to '.$budgetRange[1]];
                        }else{
                            $search_filter[]=convertRangeToWords($budgetRange[0].' to '.$budgetRange[1]);
                            
                        }
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                    if(!empty($minBudget) && !empty($maxBudget)){
                        $search_filter[]=convertRangeToWords($min_price.' to '.$max_price);
                    }
                }

            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter
            
            /*** Advance Search model card start ***/
                // $city_id = 160;
                $status = config('constant.STATUS');
                $launched = config('constant.CAR_STAGE_LAUNCHED');
                $nonEv=config('constant.NONEV_CAR_TYPE');
                // DB::raw('DISTINCT cop_models.model_id')
                $auth_id=Auth::guard('api')->id();
                $model_Card = Model::distinct('cop_models.model_id')->select('cop_models.model_id','cop_brands_ms.slug as brand_slug','cop_models.slug as model_slug','cop_models.model_name', 'cop_models.model_image', DB::raw('( SELECT MIN(ex_showroom_price) FROM cop_pe_ms WHERE cop_pe_ms.model_id = cop_models.model_id AND cop_pe_ms.status = ' . $status . ' AND cop_pe_ms.city_id = ' . $city_id . ' ) AS min_price'), DB::raw('( SELECT MAX(ex_showroom_price) FROM cop_pe_ms WHERE cop_pe_ms.model_id = cop_models.model_id AND cop_pe_ms.status = ' . $status . ' AND cop_pe_ms.city_id = ' . $city_id . '
                    ) AS max_price'), 'cop_rating_types.rating_type_name', 'cop_rating_types.rating_type_id', 'cop_ratings.rating_value', 'cop_ratings.rating_value', 'cop_brands_ms.brand_id', 'cop_brands_ms.brand_name',
                    DB::raw("(select wl_id from cop_wl where cop_wl.model_id=cop_models.model_id and customer_id = '".$auth_id."') as wl_id")
                    )
                    ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                    ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                    ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_rating_types', 'cop_rating_types.rating_type_id', '=', 'cop_ratings.rating_type_id')
                    ->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
                    ->where('model_type', $nonEv)
                    ->where('cop_brands_ms.status', $status)
                    ->where('cop_models.status', $status)
                    ->where('cop_cs_ms.cs_name', $launched);
                    // Create a new query builder instance for the variant count subquery
                    $variantCountQuery = Variant::selectRaw('count(*)')
                    ->whereColumn('cop_variants.model_id', '=', 'cop_models.model_id')
                    ->where('cop_variants.status', 1);

                    /** Filter start from here **/
                        if(!empty($engine)){
                            $engineData = array_map(function ($item) {
                                return explode(' to', $item);
                            }, $engine);

                            $getDisplacement = config('constant.DISPLACEMENT');

                            $model_Card->whereIn('cop_variants.variant_id', function ($query) use ($engineData, $getDisplacement) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                                    ->where('cop_features_ms.features_name', $getDisplacement)
                                    ->where(function ($query) use ($engineData) {
                                        foreach ($engineData as $engineRange) {
                                            $query->orWhereBetween('cop_fv.feature_value', [(int)$engineRange[0], (int)$engineRange[1]]);
                                        }
                                    });
                            });

                            $variantCountQuery->whereIn('cop_variants.variant_id', function ($query) use ($engineData, $getDisplacement) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                                    ->where('cop_features_ms.features_name', $getDisplacement)
                                    ->where(function ($query) use ($engineData) {
                                        foreach ($engineData as $engineRange) {
                                            $query->orWhereBetween('cop_fv.feature_value', [(int)$engineRange[0], (int)$engineRange[1]]);
                                        }
                                    });
                            });

                        }
                        if(!empty($min_price) && !empty($max_price)){
                            $model_Card->whereIn('cop_variants.variant_id', (function ($query) use ($min_price,$max_price,$city_id) {
                                    $query->from('cop_pe_ms')
                                        ->select('cop_pe_ms.variant_id')
                                        ->where('cop_pe_ms.city_id',$city_id)
                                        ->whereBetween('cop_pe_ms.ex_showroom_price', [$min_price, $max_price]);
                                }));

                                $variantCountQuery->whereIn('cop_variants.variant_id', (function ($query) use ($min_price,$max_price,$city_id) {
                                    $query->from('cop_pe_ms')
                                        ->select('cop_pe_ms.variant_id')
                                        ->where('cop_pe_ms.city_id',$city_id)
                                        ->whereBetween('cop_pe_ms.ex_showroom_price', [$min_price, $max_price]);
                                }));
                        }
                        if(!empty($budget)){
                            $budgetData = array_map(function ($item) {
                                return explode(' to ', $item);
                            }, $budget);
                            $model_Card->whereIn('cop_variants.variant_id', function ($query) use ($budgetData,$city_id) {
                                $query->select('cop_pe_ms.variant_id')
                                    ->from('cop_pe_ms')
                                    ->where('cop_pe_ms.city_id',$city_id)
                                    ->where(function ($query) use ($budgetData) {
                                        foreach ($budgetData as $budgetRange) {
                                            $query->orWhereBetween('cop_pe_ms.ex_showroom_price', [(int)$budgetRange[0], (int)$budgetRange[1]]);
                                        }
                                    });
                            });

                            $variantCountQuery->whereIn('cop_variants.variant_id', function ($query) use ($budgetData,$city_id) {
                                $query->select('cop_pe_ms.variant_id')
                                    ->from('cop_pe_ms')
                                    ->where('cop_pe_ms.city_id',$city_id)
                                    ->where(function ($query) use ($budgetData) {
                                        foreach ($budgetData as $budgetRange) {
                                            $query->orWhereBetween('cop_pe_ms.ex_showroom_price', [(int)$budgetRange[0], (int)$budgetRange[1]]);
                                        }
                                    });
                            });
                        }

                        if(!empty($brand)){
                            $getQuery=Brand::whereIn('brand_id',$brand)->get();
                            foreach($getQuery as $resultData){
                                $search_filter[]=$resultData->brand_name;
                            }
                            $model_Card->whereIn('cop_models.brand_id', $brand);
                        }

                        if(!empty($cartype)){
                            $getQuery=CarType::whereIn('ct_id',$cartype)->get();
                            foreach($getQuery as $resultData){
                                $search_filter[]=$resultData->ct_name;
                            }
                            $model_Card->whereIn('cop_models.ct_id', $cartype);
                        }
                        if(!empty($fuelType)){
                            // $getQuery=FeatureValue::whereIn('feature_value',$fuelType)->get();
                            // foreach($getQuery as $resultData){
                            for($i=0;$i<count($fuelType);$i++){
                                 $search_filter[]=$fuelType[$i];
                            }

                            $getFuelType=config('constant.TYPE_OF_FUEL');
                            $model_Card->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                                $query->from('cop_fv')
                                    ->select('cop_fv.variant_id')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->whereIn('cop_fv.feature_value', $fuelType)
                                    ->where('cop_features_ms.features_name',$getFuelType);
                            }));

                            $variantCountQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                                $query->from('cop_fv')
                                    ->select('cop_fv.variant_id')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->whereIn('cop_fv.feature_value', $fuelType)
                                    ->where('cop_features_ms.features_name',$getFuelType);
                            }));
                        }

                        if(!empty($driveTrain)){
                            // $getQuery=FeatureValue::whereIn('feature_value',$driveTrain)->get();
                            // foreach($getQuery as $resultData){
                            for($i=0;$i<count($driveTrain);$i++){
                                $search_filter[]=$driveTrain[$i];
                            }

                            $getDriveTrain = config('constant.DRIVETRAIN');
                            $model_Card->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->whereIn('cop_fv.feature_value',$driveTrain)
                                    ->where('cop_features_ms.features_name',$getDriveTrain);
                            });

                            $variantCountQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->whereIn('cop_fv.feature_value',$driveTrain)
                                    ->where('cop_features_ms.features_name',$getDriveTrain);
                            });

                        }
                        if(!empty($transType)){
                            // $getQuery=FeatureValue::whereIn('feature_value',$transType)->get();
                            // foreach($getQuery as $resultData){
                            for($i=0;$i<count($transType);$i++){
                                $search_filter[]=$transType[$i];
                            }

                            $getTransType = config('constant.TRANSMISSION_TYPE');
                            $model_Card->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->whereIn('cop_fv.feature_value', $transType)
                                    ->where('cop_features_ms.features_name',$getTransType);
                            });

                            $variantCountQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->whereIn('cop_fv.feature_value', $transType)
                                    ->where('cop_features_ms.features_name',$getTransType);
                            });
                        }
                        if(!empty($safety)){
                            // $getQuery=Feature::whereIn('features_name',$safety)->get();
                            // foreach($getQuery as $resultData){
                            for($i=0;$i<count($safety);$i++){
                                $search_filter[]=$safety[$i];
                            }

                            $getSafety = config('constant.SAFETY');
                            $model_Card->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                    ->where('cop_fv.feature_value', 'yes')
                                    ->whereIn('cop_features_ms.features_name',$safety)
                                    ->where('cop_spec_ms.spec_name',$getSafety)
                                    ->groupBy('cop_fv.variant_id')
                                    ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                            });

                            $variantCountQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                    ->where('cop_fv.feature_value', 'yes')
                                    ->whereIn('cop_features_ms.features_name',$safety)
                                    ->where('cop_spec_ms.spec_name',$getSafety)
                                    ->groupBy('cop_fv.variant_id')
                                    ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                            });
                        }
                        if(!empty($interior)){
                            // $getQuery=Feature::whereIn('features_name',$interior)->get();
                            // foreach($getQuery as $resultData){
                            for($i=0;$i<count($interior);$i++){
                                $search_filter[]=$interior[$i];
                            }

                            $getInterior = config('constant.INTERIOR');
                            $model_Card->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                    ->where('cop_fv.feature_value', 'yes')
                                    ->whereIn('cop_features_ms.features_name',$interior)
                                    ->where('cop_spec_ms.spec_name',$getInterior)
                                    ->groupBy('cop_fv.variant_id')
                                    ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                            });

                            $variantCountQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                    ->where('cop_fv.feature_value', 'yes')
                                    ->whereIn('cop_features_ms.features_name',$interior)
                                    ->where('cop_spec_ms.spec_name',$getInterior)
                                    ->groupBy('cop_fv.variant_id')
                                    ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                            });
                        }
                        if(!empty($exterior)){
                            // $getQuery=Feature::whereIn('features_name',$exterior)->get();
                            // foreach($getQuery as $resultData){
                            for($i=0;$i<count($exterior);$i++){
                                $search_filter[]=$exterior[$i];
                            }

                            $getExterior = config('constant.EXTERIOR');
                            $model_Card->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                            });

                            $variantCountQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                                $query->select('cop_fv.variant_id')
                                    ->from('cop_fv')
                                    ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                    ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                    ->where('cop_fv.feature_value', 'yes')
                                    ->whereIn('cop_features_ms.features_name',$exterior)
                                    ->where('cop_spec_ms.spec_name',$getExterior)
                                    ->groupBy('cop_fv.variant_id')
                                    ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                                });
                        }
                    /** Filter end **/
                    /** sorting start**/
                        if($sort =="ASC"){
                            $model_Card->orderBy('min_price','ASC');
                        }else if($sort == "DESC"){
                            $model_Card->orderBy('max_price','DESC');
                        }else{
                            $model_Card->orderBy('min_price','ASC');
                        }
                    /** sorting end **/

                    // Merge the subquery into the main query
                    $model_Card->addSelect(DB::raw("({$variantCountQuery->toSql()}) as variant_count"));
                    // Bind the subquery's parameters to the main query
                    // $model_Card->mergeBindings($variantCountQuery->getQuery());
                    // Bind the subquery's bindings to the main query
                    foreach ($variantCountQuery->getBindings() as $binding) {
                        $model_Card->addBinding($binding, 'select');
                    }
                   
                    $model_Card=$model_Card->paginate(12);
                    // dd($model_Card);
                    $imagePath=$this->imagePath;
                    $model_card_output=[];
                    // dd($model_Card);
                    
                    foreach ($model_Card as $modelData){
                        $rating = $modelData->rating_value ?? '';
                        $ratingTypeName = $modelDatarating_type_name ?? '';
                        // $ratingStar = generateStarRating($rating, $ratingTypeName);
                        $min_price = $modelData->min_price ?? 0;
                        $max_price = $modelData->max_price ?? 0;
                        $model_card_output[]=array(
                            'brand_id' => encryptor('e',$modelData->brand_id),
                            'brand_name' => $modelData->brand_name,
                            'model_id' => encryptor('e',$modelData->model_id),
                            'model_name' => $modelData->model_name,
                            'min_ex_showroom_price' => convertToLakhCrore($min_price),
                            'max_ex_showroom_price' => convertToLakhCrore($max_price),
                            'model_image' => $imagePath.'/brands/'. $modelData->brand_id.'/'.$modelData->model_id.'/'. $modelData->model_image,
                            "rating_type_name" => $ratingTypeName,
                            "rating_value" => $rating,
                            'wishlist' => (!empty($modelData->wl_id)?true:false),
                            "variant_count" => $modelData->variant_count
                        );
                    }
            $formatData=['model_card'=>$model_card_output,
                         'search_filter'=>$search_filter,
                         'total_record'=>$model_Card->total(),
                         'current_page'=>$model_Card->currentPage(),
                         'last_page'=>$model_Card->lastPage(),
                        //  'model'=>$model_Card
                        ];
            return ResponseHelper::responseMessage('success', $formatData);
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    public function advance_search_filter(Request $request)
    {
        try{
            ini_set('max_execution_time', '300');
            
            // if(!$request->has('city_id') && trim($request->input('city_id'))==''){
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }
            // $city_id=encryptor('d',$request->input('city_id'));
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }

            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/
            
             /*** budget query start ***/
                // Get Budget Range List
                $budgetRange = config('constant.BUDGET_LIST');
                $budgetRangeWords = config('constant.BUDGET_LIST_WORDS');
                // Initialize the CASE statement string
                $caseStatement = '';

                // Iterate through the price ranges to construct the CASE statement
                $i = 0;
                foreach ($budgetRange as $range) {
                    list($min, $max) = explode(' to ', $range);
                    $condition = "WHEN cop_pe_ms.ex_showroom_price >= $min AND cop_pe_ms.ex_showroom_price < $max THEN '$range' ";
                    $caseStatement .= $condition;
                    $i++;
                }

                // Add the ELSE condition for prices beyond the specified ranges
                $caseStatement .= "END AS price_range";

                $budgetQuery = Model::selectRaw('
                CASE
                ' . $caseStatement . ',
                COUNT(DISTINCT cop_models.model_id) as model_count
                ')
                    ->join('cop_variants', 'cop_models.model_id', '=', 'cop_variants.model_id')
                    ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                    ->where('cop_models.model_type', '=', '0')
                    ->whereBetween('cop_pe_ms.ex_showroom_price', [config('constant.MIN_PRICE'), config('constant.MAX_PRICE')])
                    ->groupBy('price_range')
                    ->orderByRaw("FIELD(price_range, '" . implode("', '", $budgetRange) . "')")
                    ->havingRaw('model_count > 0');

            /*** budget query End ***/

            /*** brand count query ****/
                $brandQuery = Model::selectRaw('cop_brands_ms.brand_id,cop_brands_ms.brand_name,COUNT(DISTINCT cop_models.model_id) as model_count
                ')
                    ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                    ->where('cop_models.model_type', '=', '0')
                    ->whereIn('cop_variants.variant_id', $allVariants)
                    ->groupBy('cop_brands_ms.brand_id', 'cop_brands_ms.brand_name')
                    ->havingRaw('model_count > 0');
            /*** brand count query ****/

            /*** car type count query ***/
                $carBodyTypeQuery = Model::select('cop_ct_ms.ct_id', 'cop_ct_ms.ct_image', 'cop_ct_ms.ct_name', DB::raw("count(DISTINCT cop_models.model_id) as model_count"))
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->where('cop_models.model_type', '=', 0)
                ->where('cop_models.status', '=', 1)
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->groupBy('cop_ct_ms.ct_id', 'cop_ct_ms.ct_image', 'cop_ct_ms.ct_name')
                ->havingRaw('model_count > 0');
            /*** car type count query ***/

            /*** fuel type count query ***/
                $getFuelType = config('constant.TYPE_OF_FUEL');
                $fuelTypeQuery = Model::select('cop_fv.feature_id', 'cop_fv.feature_value', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->whereIn('cop_fv.feature_id', (function ($query) use ($getFuelType) {
                    $query->from('cop_features_ms')
                        ->select('feature_id')
                        ->where('features_name', '=', $getFuelType);
                }))
                ->where('model_type', '=', 0)
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->groupBy('cop_fv.feature_value', 'cop_fv.feature_id')
                ->havingRaw('model_count > 0');
                // dd($fuelTypeQuery->toSql());
            /*** fuel type count query end ***/

            /*** Engine Range query start ***/
                // Get fuel capacity Range List
                $fuelRange = config('constant.ENGINE_LIST');
                // Initialize the CASE statement string
                $caseStatement = '';

                // Iterate through the price ranges to construct the CASE statement
                $i = 0;
                foreach ($fuelRange as $range) {
                    list($min, $max) = explode(' to ', $range);
                    $condition = "WHEN cop_fv.feature_value >= $min AND cop_fv.feature_value < $max THEN '$range' ";
                    $caseStatement .= $condition;
                    $i++;
                }

                // Add the ELSE condition for prices beyond the specified ranges
                $caseStatement .= "END AS engine_range";

                $engineQuery = Model::selectRaw('
                CASE
                ' . $caseStatement . ',
                COUNT(DISTINCT cop_models.model_id) as model_count
                ')
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_variants.variant_id', '=', 'cop_fv.variant_id')
                ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                ->where('cop_models.model_type', '=', '0')
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_features_ms.features_name', '=', config('constant.DISPLACEMENT'))
                ->groupBy('engine_range')
                ->orderByRaw("FIELD(engine_range, '" . implode("', '", $fuelRange) . "')")
                ->havingRaw('model_count > 0');
            /*** Engine Range query End ***/


            /*** Transmission Type count query ***/
                $getTransType = config('constant.TRANSMISSION_TYPE');
                $transTypeQuery = Model::select('cop_fv.feature_id', 'cop_fv.feature_value', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->whereIn('cop_fv.feature_id', (function ($query) use ($getTransType) {
                    $query->from('cop_features_ms')
                        ->select('feature_id')
                        ->where('features_name', '=', $getTransType);
                }))
                ->where('model_type', '=', 0)
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->groupBy('cop_fv.feature_value', 'cop_fv.feature_id')
                ->havingRaw('model_count > 0');
            /*** Transmission Type count query end ***/

            /*** DRIVETRAIN Type count query ***/
                $getDriveTrainType = config('constant.DRIVETRAIN');
                $driveTrainQuery = Model::select('cop_fv.feature_id', 'cop_fv.feature_value', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->whereIn('cop_fv.feature_id', (function ($query) use ($getDriveTrainType) {
                    $query->from('cop_features_ms')
                        ->select('feature_id')
                        ->where('features_name', '=', $getDriveTrainType);
                }))
                ->where('model_type', '=', 0)
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->groupBy('cop_fv.feature_value', 'cop_fv.feature_id')
                ->havingRaw('model_count > 0');
            /*** DRIVETRAIN Type count query end ***/


            /*** Safety count query ***/
                // $safetyData="";
                $getSafety = config('constant.SAFETY');
                $get_feature_value = config('constant.feature');
                $safetyQuery = Model::select('cop_features_ms.features_name', 'cop_features_ms.feature_id', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->whereIn('cop_features_ms.spec_id', (function ($query) use ($getSafety) {
                    $query->from('cop_spec_ms')
                        ->select('spec_id')
                        ->where('spec_name', '=', $getSafety);
                }))
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_fv.feature_value', '=', $get_feature_value)
                ->where('model_type', '=', 0)
                ->groupBy('cop_features_ms.features_name', 'cop_features_ms.feature_id')
                ->havingRaw('model_count > 0');
                // dd($safetyQuery->toSql());
            /*** Safety count query end ***/

            /*** Interior count query ***/
                $getInterior = config('constant.INTERIOR');
                $getInterior_arr = config('constant.INTERIOR_ARR');
                
                $interiorQuery = Model::select('cop_features_ms.features_name', 'cop_fv.feature_id', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_models.model_id', '=', 'cop_variants.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                // ->join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                ->where('cop_fv.feature_value', '=', $get_feature_value)
                ->where('model_type', '=', 0)
                ->whereIn('cop_features_ms.features_name', $getInterior_arr)
                // ->where('cop_spec_ms.spec_name',$getInterior)
                ->whereIn('cop_features_ms.spec_id', (function ($query) use ($getInterior) {
                    $query->from('cop_spec_ms')
                        ->select('spec_id')
                        ->where('spec_name', '=', $getInterior);
                }))
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->groupBy('cop_features_ms.features_name', 'cop_fv.feature_id')
                ->havingRaw('model_count > 0');


            /*** interior count query end ***/

            /*** exterior count query ***/
                $exteriorData = [];
                $getExterior = config('constant.EXTERIOR');
                $getExterior_arr = config('constant.EXTERIOR_ARR');
                $exteriorQuery = Model::select('cop_features_ms.features_name', 'cop_features_ms.feature_id', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->where('cop_fv.feature_value', '=', $get_feature_value)
                ->where('model_type', '=', 0)
                ->whereIn('cop_features_ms.features_name', $getExterior_arr)
                ->whereIn('cop_features_ms.spec_id', (function ($query) use ($getExterior) {
                    $query->from('cop_spec_ms')
                        ->select('spec_id')
                        ->where('spec_name', '=', $getExterior);
                }))
                // ->whereIn('cop_models.model_id',explode(",", $result))
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->groupBy('cop_features_ms.features_name', 'cop_features_ms.feature_id')
                ->havingRaw('model_count > 0');
            // dd($exterior_cnt);
            /*** exterior count query end ***/

            /**** filter start from here ****/
                /** brand filter start **/
                    if(!empty($brand)){
                        $budgetQuery->whereIn('cop_models.brand_id', $brand);
                        $carBodyTypeQuery->whereIn('cop_models.brand_id', $brand);
                        $fuelTypeQuery->whereIn('cop_models.brand_id', $brand);
                        $engineQuery->whereIn('cop_models.brand_id', $brand);
                        $transTypeQuery->whereIn('cop_models.brand_id', $brand);
                        $driveTrainQuery->whereIn('cop_models.brand_id', $brand);
                        $safetyQuery->whereIn('cop_models.brand_id', $brand);
                        $interiorQuery->whereIn('cop_models.brand_id', $brand);
                        $exteriorQuery->whereIn('cop_models.brand_id', $brand);
                    }
                /** brand filter end **/

                /** car type filter start **/
                    if(!empty($cartype)){
                        $brandQuery->whereIn('cop_models.ct_id', $cartype);
                        $budgetQuery->whereIn('cop_models.ct_id', $cartype);
                        $fuelTypeQuery->whereIn('cop_models.ct_id', $cartype);
                        $engineQuery->whereIn('cop_models.ct_id', $cartype);
                        $transTypeQuery->whereIn('cop_models.ct_id', $cartype);
                        $driveTrainQuery->whereIn('cop_models.ct_id', $cartype);
                        $safetyQuery->whereIn('cop_models.ct_id', $cartype);
                        $interiorQuery->whereIn('cop_models.ct_id', $cartype);
                        $exteriorQuery->whereIn('cop_models.ct_id', $cartype);
                    }
                /** car type filter end **/

                /** Fuel Type filter start **/
                    if(!empty($fuelType)){
                        $getFuelType=config('constant.TYPE_OF_FUEL');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $fuelType));
                        $brandQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                        $budgetQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                        $engineQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                        $transTypeQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                        $driveTrainQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                        $safetyQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                        $interiorQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                        $exteriorQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                    }
                /** Fuel Type filter end **/

                /** Engine Capacity filter start **/
                    if(!empty($engine)){
                        $getDisplacement = config('constant.DISPLACEMENT');
                        $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });

                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });

                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });

                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });

                        $transTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });

                        $driveTrainQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });

                        $safetyQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });

                        $interiorQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });

                        $exteriorQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });
                    }
                /** Engine Capacity filter end **/


                /** Drive Train filter start **/
                    if(!empty($driveTrain)){
                        $getDriveTrain = config('constant.DRIVETRAIN');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $driveTrain));
                        $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });

                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });

                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });

                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });

                        $transTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });

                        $engineQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });

                        $safetyQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });

                        $interiorQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });

                        $exteriorQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });
                    }
                /** Drive Train filter end **/

                /** Transmission type filter start **/
                    if(!empty($transType)){
                        $getTransType = config('constant.TRANSMISSION_TYPE');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $transType));
                        $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });

                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });

                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });

                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });

                        $driveTrainQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });

                        $engineQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });

                        $safetyQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });

                        $interiorQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });

                        $exteriorQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });
                    }
                /** Transmission type filter end **/

                /** safety filter start **/
                    if(!empty($safety)){
                        $getSafety = config('constant.SAFETY');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $safety));
                        $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });

                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });

                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });

                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });

                        $driveTrainQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });

                        $engineQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });

                        $transTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });

                        $interiorQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });

                        $exteriorQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });
                    }
                /** safety filter end **/

                /** Interior filter start **/
                    if(!empty($interior)){
                        $getInterior = config('constant.INTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $interior));
                        $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });

                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });

                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });

                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });

                        $driveTrainQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });

                        $engineQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });

                        $transTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });

                        $safetyQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });

                        $exteriorQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });
                    }
                /** Interior filter end **/
                /** exterior filter **/
                    if(!empty($exterior)){
                        $getExterior = config('constant.EXTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $exterior));
                        $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });

                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });

                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });

                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });

                        $driveTrainQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });

                        $engineQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });

                        $transTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });

                        $safetyQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });

                        $interiorQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });
                    }
                /** exterior filter end **/
            /**** filter end here ****/

            /** Initialize array **/
            $budgetArrData = $brandArrData = $cartypeArrData = $fuelArrData = $engineArrData = $transArrData = $driveArrData = $safetyArrData = $interiorArrData = $exteriorArrData = [];
            /** get image path**/
            $image_path=$this->imagePath;
            $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');
            
            /** budget data mapping **/
            $budgetQuery->get()->map(function($query) use ($budgetWordArr,&$budgetArrData){
                $budgetArrData[]=['price_range'=>$query->price_range,
                'price_in_words'=>  $budgetWordArr[$query->price_range],
                'model_count'=>$query->model_count
                ];
            });
            
            /** brand data mapping **/
            $brandQuery->orderBy('cop_brands_ms.priority')->get()->map(function($query) use (&$brandArrData){
                $brandArrData[]=['brand_id'=>encryptor('e',$query->brand_id),
                                    'brand_name'=>$query->brand_name,
                                    'model_count'=>$query->model_count
                                    ];
            });
            
            /** car body type data mapping **/
            $carBodyTypeQuery->orderBy('priority')->get()->map(function($query) use(&$cartypeArrData,$image_path){
                    $cartypeArrData[]=['car_type_id'=>encryptor('e',$query->ct_id),
                                    'car_type_name'=>$query->ct_name,
                                    'car_type_image'=>$image_path . '/car_types/' . $query->ct_id . '/' . $query->ct_image,
                                    'mode_count'=>$query->model_count
                                    ];
            });
            /** fuel type data mapping **/
            $fuelTypeQuery->get()->map(function($query) use (&$fuelArrData){
                $fuelArrData[]=['fuel_type'=>$query->feature_value,
                                'model_count'=>$query->model_count
                                ];
            });
            /** engine capacity data mapping **/
            $engineQuery->get()->map(function($query) use (&$engineArrData){
                $engineArrData[]=['engine_range'=>$query->engine_range,
                                  'model_count'=>$query->model_count
                                 ];
            });
            /** transition type data mapping **/
            $transTypeQuery->get()->map(function($query) use (&$transArrData){
                $transArrData[]=['transition_type'=>$query->feature_value,
                                    'model_count'=>$query->model_count
                                    ];
            });
            /** drive train data query **/
            $driveTrainQuery->get()->map(function($query) use (&$driveArrData){
                $driveArrData[]=['drive_train'=>$query->feature_value,
                                    'model_count'=>$query->model_count
                                    ];
            });

            /** safety data mapping **/
            $safetyQuery->get()->map(function($query) use(&$safetyArrData){
                $safetyArrData[]=['safety'=>$query->features_name,
                                    'model_count'=>$query->model_count
                                    ];
            });
            /** interior data mapping **/
            $interiorQuery->get()->map(function($query) use (&$interiorArrData){
                $interiorArrData[]=['interior'=>$query->features_name,
                                    'model_count'=>$query->model_count
                                    ];
            });
            /** exterior data mapping **/
            $exteriorQuery->get()->map(function($query) use (&$exteriorArrData){
                $exteriorArrData[]=['exterior'=>$query->features_name,
                'model_count'=>$query->model_count
                ];
            });
            
           
            /** Bind all data in an array **/
            $response = [
                'by_budget' => $budgetArrData,
                'by_brand' => $brandArrData,
                'bt_carType' => $cartypeArrData,
                'by_fuelType' => $fuelArrData,
                'by_engine' => $engineArrData,
                'by_transType' => $transArrData,
                'by_driveTrain' => $driveArrData,
                'by_safety' => $safetyArrData,
                'by_interior' => $interiorArrData,
                'by_exterior' => $exteriorArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // by budget //
    public function budget_advanced_filter(Request $request)
    {
        try{
            ini_set('max_execution_time', '300');
            
            // if(!$request->has('city_id') && trim($request->input('city_id'))==''){
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }
            // $city_id=encryptor('d',$request->input('city_id'));
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }
            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/
            
            /*** budget query start ***/
                // Get Budget Range List
                $budgetRange = config('constant.BUDGET_LIST');
                $budgetRangeWords = config('constant.BUDGET_LIST_WORDS');
                // Initialize the CASE statement string
                $caseStatement = '';

                // Iterate through the price ranges to construct the CASE statement
                $i = 0;
                foreach ($budgetRange as $range) {
                    list($min, $max) = explode(' to ', $range);
                    $condition = "WHEN cop_pe_ms.ex_showroom_price >= $min AND cop_pe_ms.ex_showroom_price < $max THEN '$range' ";
                    $caseStatement .= $condition;
                    $i++;
                }

                // Add the ELSE condition for prices beyond the specified ranges
                $caseStatement .= "END AS price_range";

                $budgetQuery = Model::selectRaw('
                CASE
                ' . $caseStatement . ',
                COUNT(DISTINCT cop_models.model_id) as model_count
                ')
                    ->join('cop_variants', 'cop_models.model_id', '=', 'cop_variants.model_id')
                    ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                    ->where('cop_models.model_type', '=', '0')
                    ->where('cop_pe_ms.ex_showroom_price', '>=', config('constant.MIN_PRICE'))
                    ->where('cop_pe_ms.ex_showroom_price', '<=', config('constant.MAX_PRICE'))
                    ->groupBy('price_range')
                    ->where('cop_models.status', 1)
                    ->where('cop_variants.status', 1)
                    ->orderByRaw("FIELD(price_range, '" . implode("', '", $budgetRange) . "')")
                    ->havingRaw('model_count > 0');

            /*** budget query End ***/

            /**** filter start from here ****/
                /** brand filter start **/
                    if(!empty($brand)){
                        $budgetQuery->whereIn('cop_models.brand_id', $brand);
                    }
                /** brand filter end **/

                /** car type filter start **/
                    if(!empty($cartype)){
                        $budgetQuery->whereIn('cop_models.ct_id', $cartype);
                    }
                /** car type filter end **/

                /** Fuel Type filter start **/
                    if(!empty($fuelType)){
                        $getFuelType=config('constant.TYPE_OF_FUEL');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $fuelType));
                        $budgetQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                    }
                /** Fuel Type filter end **/

                /** Engine Capacity filter start **/
                    if(!empty($engine)){
                        $getDisplacement = config('constant.DISPLACEMENT');
                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });
                    }
                /** Engine Capacity filter end **/


                /** Drive Train filter start **/
                    if(!empty($driveTrain)){
                        $getDriveTrain = config('constant.DRIVETRAIN');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $driveTrain));
                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });
                    }
                /** Drive Train filter end **/

                /** Transmission type filter start **/
                    if(!empty($transType)){
                        $getTransType = config('constant.TRANSMISSION_TYPE');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $transType));
                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });
                    }
                /** Transmission type filter end **/

                /** safety filter start **/
                    if(!empty($safety)){
                        $getSafety = config('constant.SAFETY');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $safety));
                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });
                    }
                /** safety filter end **/

                /** Interior filter start **/
                    if(!empty($interior)){
                        $getInterior = config('constant.INTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $interior));
                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });
                    }
                /** Interior filter end **/
                /** exterior filter **/
                    if(!empty($exterior)){
                        $getExterior = config('constant.EXTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $exterior));
                        $budgetQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });
                    }
                /** exterior filter end **/
            /**** filter end here ****/

            /** Initialize array **/
            $budgetArrData = $brandArrData = $cartypeArrData = $fuelArrData = $engineArrData = $transArrData = $driveArrData = $safetyArrData = $interiorArrData = $exteriorArrData = [];
            /** get image path**/
            $image_path=$this->imagePath;
            $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');
            
            /** budget data mapping **/
            $budgetQuery->get()->map(function($query) use ($budgetWordArr,&$budgetArrData){
                $budgetArrData[]=['price_range'=>$query->price_range,
                'price_in_words'=>  $budgetWordArr[$query->price_range],
                'model_count'=>$query->model_count
                ];
            });
           
            /** Bind all data in an array **/
            $response = [
                'by_budget' => $budgetArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // by brand
    public function brand_advanced_filter(Request $request)
    {
        try {
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }

            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/

            /*** brand count query ****/
            $brandQuery = Model::selectRaw('cop_brands_ms.brand_id,cop_brands_ms.brand_name,COUNT(DISTINCT cop_models.model_id) as model_count
            ')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->where('cop_models.model_type', '=', '0')
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_brands_ms.status', 1)
                ->where('cop_models.status', 1)
                ->where('cop_variants.status', 1)
                ->groupBy('cop_brands_ms.brand_id', 'cop_brands_ms.brand_name')
                ->havingRaw('model_count > 0');
            /*** brand count query ****/

            /** car type filter start **/
            if(!empty($cartype)){
                $brandQuery->whereIn('cop_models.ct_id', $cartype);
            }
            /** car type filter end **/

            /** Fuel Type filter start **/
            if(!empty($fuelType)){
                $getFuelType=config('constant.TYPE_OF_FUEL');
                $featureData = implode(',', array_map(function ($item) {
                    return "'" . $item . "'";
                }, $fuelType));
                $brandQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                    $query->from('cop_fv')
                        ->select('cop_fv.variant_id')
                        ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                        ->whereIn('cop_fv.feature_value', $fuelType)
                        ->where('cop_features_ms.features_name',$getFuelType);
                }));
            }
            /** Fuel Type filter end **/

            /** Engine Capacity filter start **/
            if(!empty($engine)){
                $getDisplacement = config('constant.DISPLACEMENT');
                $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                    $query->select('cop_fv.variant_id')
                        ->from('cop_fv')
                        ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                        ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                        ->where('cop_features_ms.features_name',$getDisplacement);
                });
            }
            /** Engine Capacity filter end **/


            /** Drive Train filter start **/
            if(!empty($driveTrain)){
                $getDriveTrain = config('constant.DRIVETRAIN');
                $featureData = implode(',', array_map(function ($item) {
                    return "'" . $item . "'";
                }, $driveTrain));
                $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                    $query->select('cop_fv.variant_id')
                        ->from('cop_fv')
                        ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                        ->whereIn('cop_fv.feature_value',$driveTrain)
                        ->where('cop_features_ms.features_name',$getDriveTrain);
                });
            }
            /** Drive Train filter end **/

            /** Transmission type filter start **/
            if(!empty($transType)){
                $getTransType = config('constant.TRANSMISSION_TYPE');
                $featureData = implode(',', array_map(function ($item) {
                    return "'" . $item . "'";
                }, $transType));
                $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                    $query->select('cop_fv.variant_id')
                        ->from('cop_fv')
                        ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                        ->whereIn('cop_fv.feature_value', $transType)
                        ->where('cop_features_ms.features_name',$getTransType);
                });
            }
            /** Transmission type filter end **/

            /** safety filter start **/
            if(!empty($safety)){
                $getSafety = config('constant.SAFETY');
                $featureData = implode(',', array_map(function ($item) {
                    return "'" . $item . "'";
                }, $safety));
                $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                    $query->select('cop_fv.variant_id')
                        ->from('cop_fv')
                        ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                        ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                        ->where('cop_fv.feature_value', 'yes')
                        ->whereIn('cop_features_ms.features_name',$safety)
                        ->where('cop_spec_ms.spec_name',$getSafety)
                        ->groupBy('cop_fv.variant_id')
                        ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                });
            }
            /** safety filter end **/

            /** Interior filter start **/
            if(!empty($interior)){
                $getInterior = config('constant.INTERIOR');
                $featureData = implode(',', array_map(function ($item) {
                    return "'" . $item . "'";
                }, $interior));
                $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                    $query->select('cop_fv.variant_id')
                        ->from('cop_fv')
                        ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                        ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                        ->where('cop_fv.feature_value', 'yes')
                        ->whereIn('cop_features_ms.features_name',$interior)
                        ->where('cop_spec_ms.spec_name',$getInterior)
                        ->groupBy('cop_fv.variant_id')
                        ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                });
            }
            /** Interior filter end **/

            /** exterior filter **/
            if(!empty($exterior)){
                $getExterior = config('constant.EXTERIOR');
                $featureData = implode(',', array_map(function ($item) {
                    return "'" . $item . "'";
                }, $exterior));
                $brandQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                    $query->select('cop_fv.variant_id')
                        ->from('cop_fv')
                        ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                        ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                        ->where('cop_fv.feature_value', 'yes')
                        ->whereIn('cop_features_ms.features_name',$exterior)
                        ->where('cop_spec_ms.spec_name',$getExterior)
                        ->groupBy('cop_fv.variant_id')
                        ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                });
            }

            $brandArrData=[];
            /** brand data mapping **/
            $brandQuery->orderBy('cop_brands_ms.priority')->get()->map(function($query) use (&$brandArrData){
                $brandArrData[]=['brand_id'=>encryptor('e',$query->brand_id),
                                    'brand_name'=>$query->brand_name,
                                    'model_count'=>$query->model_count
                                    ];
            });
        
            /** Bind all data in an array **/
            $response = [
                'by_brand' => $brandArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // by car type
    public function car_type_advanced_filter(Request $request)
    {
        try{
            ini_set('max_execution_time', '300');
            
            // if(!$request->has('city_id') && trim($request->input('city_id'))==''){
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }
            // $city_id=encryptor('d',$request->input('city_id'));
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }
            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/

            /*** car type count query ***/
                $carBodyTypeQuery = Model::select('cop_ct_ms.ct_id', 'cop_ct_ms.ct_image', 'cop_ct_ms.ct_name', DB::raw("count(DISTINCT cop_models.model_id) as model_count"))
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->where('cop_models.model_type', '=', 0)
                ->where('cop_models.status', '=', 1)
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_models.status', 1)
                ->where('cop_variants.status', 1)
                ->groupBy('cop_ct_ms.ct_id', 'cop_ct_ms.ct_image', 'cop_ct_ms.ct_name')
                ->havingRaw('model_count > 0');
            /*** car type count query ***/

            /**** filter start from here ****/
                /** brand filter start **/
                    if(!empty($brand)){
                        $carBodyTypeQuery->whereIn('cop_models.brand_id', $brand);
                    }
                /** brand filter end **/

                /** Fuel Type filter start **/
                    if(!empty($fuelType)){
                        $getFuelType=config('constant.TYPE_OF_FUEL');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $fuelType));
                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                    }
                /** Fuel Type filter end **/

                /** Engine Capacity filter start **/
                    if(!empty($engine)){
                        $getDisplacement = config('constant.DISPLACEMENT');

                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });
                    }
                /** Engine Capacity filter end **/


                /** Drive Train filter start **/
                    if(!empty($driveTrain)){
                        $getDriveTrain = config('constant.DRIVETRAIN');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $driveTrain));

                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });
                    }
                /** Drive Train filter end **/

                /** Transmission type filter start **/
                    if(!empty($transType)){
                        $getTransType = config('constant.TRANSMISSION_TYPE');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $transType));

                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });
                    }
                /** Transmission type filter end **/

                /** safety filter start **/
                    if(!empty($safety)){
                        $getSafety = config('constant.SAFETY');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $safety));
                        
                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });
                    }
                /** safety filter end **/

                /** Interior filter start **/
                    if(!empty($interior)){
                        $getInterior = config('constant.INTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $interior));
                        
                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });
                    }
                /** Interior filter end **/
                /** exterior filter **/
                    if(!empty($exterior)){
                        $getExterior = config('constant.EXTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $exterior));
                        
                        $carBodyTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });
                    }
                /** exterior filter end **/
            /**** filter end here ****/

            /** Initialize array **/
            $budgetArrData = $brandArrData = $cartypeArrData = $fuelArrData = $engineArrData = $transArrData = $driveArrData = $safetyArrData = $interiorArrData = $exteriorArrData = [];
            /** get image path**/
            $image_path=$this->imagePath;
            $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');
            
            /** car body type data mapping **/
            $carBodyTypeQuery->orderBy('priority')->get()->map(function($query) use(&$cartypeArrData,$image_path){
                    $cartypeArrData[]=['car_type_id'=>encryptor('e',$query->ct_id),
                                    'car_type_name'=>$query->ct_name,
                                    'car_type_image'=>$image_path . '/car_types/' . $query->ct_id . '/' . $query->ct_image,
                                    'mode_count'=>$query->model_count
                                    ];
            });
           
            /** Bind all data in an array **/
            $response = [
                'bt_carType' => $cartypeArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    //by fuel type
    public function fuel_type_advanced_filter(Request $request)
    {
        try{
            ini_set('max_execution_time', '300');
            
            // if(!$request->has('city_id') && trim($request->input('city_id'))==''){
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }
            // $city_id=encryptor('d',$request->input('city_id'));
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }
            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/

            /*** fuel type count query ***/
                $getFuelType = config('constant.TYPE_OF_FUEL');
                $fuelTypeQuery = Model::select('cop_fv.feature_id', 'cop_fv.feature_value', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->whereIn('cop_fv.feature_id', (function ($query) use ($getFuelType) {
                    $query->from('cop_features_ms')
                        ->select('feature_id')
                        ->where('features_name', '=', $getFuelType);
                }))
                ->where('model_type', '=', 0)
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_models.status', 1)
                ->where('cop_variants.status', 1)
                ->groupBy('cop_fv.feature_value', 'cop_fv.feature_id')
                ->havingRaw('model_count > 0');
                // dd($fuelTypeQuery->toSql());
            /*** fuel type count query end ***/

            /**** filter start from here ****/
                /** brand filter start **/
                    if(!empty($brand)){
                        $fuelTypeQuery->whereIn('cop_models.brand_id', $brand);
                    }
                /** brand filter end **/

                /** car type filter start **/
                    if(!empty($cartype)){
                        $fuelTypeQuery->whereIn('cop_models.ct_id', $cartype);
                    }
                /** car type filter end **/

                /** Engine Capacity filter start **/
                    if(!empty($engine)){
                        $getDisplacement = config('constant.DISPLACEMENT');
                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });
                    }
                /** Engine Capacity filter end **/


                /** Drive Train filter start **/
                    if(!empty($driveTrain)){
                        $getDriveTrain = config('constant.DRIVETRAIN');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $driveTrain));
                        
                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });
                    }
                /** Drive Train filter end **/

                /** Transmission type filter start **/
                    if(!empty($transType)){
                        $getTransType = config('constant.TRANSMISSION_TYPE');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $transType));
                       
                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });
                    }
                /** Transmission type filter end **/

                /** safety filter start **/
                    if(!empty($safety)){
                        $getSafety = config('constant.SAFETY');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $safety));

                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });
                    }
                /** safety filter end **/

                /** Interior filter start **/
                    if(!empty($interior)){
                        $getInterior = config('constant.INTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $interior));
                        
                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });
                    }
                /** Interior filter end **/
                /** exterior filter **/
                    if(!empty($exterior)){
                        $getExterior = config('constant.EXTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $exterior));
                        
                        $fuelTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });
                    }
                /** exterior filter end **/
            /**** filter end here ****/

            /** Initialize array **/
            $budgetArrData = $brandArrData = $cartypeArrData = $fuelArrData = $engineArrData = $transArrData = $driveArrData = $safetyArrData = $interiorArrData = $exteriorArrData = [];
            /** get image path**/
            $image_path=$this->imagePath;
            $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');
            
            /** fuel type data mapping **/
            $fuelTypeQuery->get()->map(function($query) use (&$fuelArrData){
                $fuelArrData[]=['fuel_type'=>$query->feature_value,
                                'model_count'=>$query->model_count
                                ];
            });
           
            /** Bind all data in an array **/
            $response = [
                'by_fuelType' => $fuelArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // by engine
    public function engine_advanced_filter(Request $request)
    {
        try{
            ini_set('max_execution_time', '300');
            
            // if(!$request->has('city_id') && trim($request->input('city_id'))==''){
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }
            // $city_id=encryptor('d',$request->input('city_id'));
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }
            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/

            /*** Engine Range query start ***/
                // Get fuel capacity Range List
                $fuelRange = config('constant.ENGINE_LIST');
                // Initialize the CASE statement string
                $caseStatement = '';

                // Iterate through the price ranges to construct the CASE statement
                $i = 0;
                foreach ($fuelRange as $range) {
                    list($min, $max) = explode(' to ', $range);
                    $condition = "WHEN cop_fv.feature_value >= $min AND cop_fv.feature_value < $max THEN '$range' ";
                    $caseStatement .= $condition;
                    $i++;
                }

                // Add the ELSE condition for prices beyond the specified ranges
                $caseStatement .= "END AS engine_range";

                $engineQuery = Model::selectRaw('
                CASE
                ' . $caseStatement . ',
                COUNT(DISTINCT cop_models.model_id) as model_count
                ')
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_variants.variant_id', '=', 'cop_fv.variant_id')
                ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                ->where('cop_models.model_type', '=', '0')
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_models.status', 1)
                ->where('cop_variants.status', 1)
                ->where('cop_features_ms.features_name', '=', config('constant.DISPLACEMENT'))
                ->groupBy('engine_range')
                ->orderByRaw("FIELD(engine_range, '" . implode("', '", $fuelRange) . "')")
                ->havingRaw('model_count > 0');
            /*** Engine Range query End ***/

            /**** filter start from here ****/
                /** brand filter start **/
                    if(!empty($brand)){
                        $engineQuery->whereIn('cop_models.brand_id', $brand);
                    }
                /** brand filter end **/

                /** car type filter start **/
                    if(!empty($cartype)){
                        $engineQuery->whereIn('cop_models.ct_id', $cartype);
                    }
                /** car type filter end **/

                /** Fuel Type filter start **/
                    if(!empty($fuelType)){
                        $getFuelType=config('constant.TYPE_OF_FUEL');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $fuelType));
                        $engineQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                    }
                /** Fuel Type filter end **/

                /** Drive Train filter start **/
                    if(!empty($driveTrain)){
                        $getDriveTrain = config('constant.DRIVETRAIN');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $driveTrain));

                        $engineQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });
                    }
                /** Drive Train filter end **/

                /** Transmission type filter start **/
                    if(!empty($transType)){
                        $getTransType = config('constant.TRANSMISSION_TYPE');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $transType));

                        $engineQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });
                    }
                /** Transmission type filter end **/

                /** safety filter start **/
                    if(!empty($safety)){
                        $getSafety = config('constant.SAFETY');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $safety));

                        $engineQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });
                    }
                /** safety filter end **/

                /** Interior filter start **/
                    if(!empty($interior)){
                        $getInterior = config('constant.INTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $interior));

                        $engineQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });
                    }
                /** Interior filter end **/
                /** exterior filter **/
                    if(!empty($exterior)){
                        $getExterior = config('constant.EXTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $exterior));
                       
                        $engineQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });
                    }
                /** exterior filter end **/
            /**** filter end here ****/

            /** Initialize array **/
            $budgetArrData = $brandArrData = $cartypeArrData = $fuelArrData = $engineArrData = $transArrData = $driveArrData = $safetyArrData = $interiorArrData = $exteriorArrData = [];
            /** get image path**/
            $image_path=$this->imagePath;
            $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');
            
            /** engine capacity data mapping **/
            $engineQuery->get()->map(function($query) use (&$engineArrData){
                $engineArrData[]=['engine_range'=>$query->engine_range,
                                  'model_count'=>$query->model_count
                                 ];
            });
    
            /** Bind all data in an array **/
            $response = [
                'by_engine' => $engineArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // by trans type
    public function trans_type_advanced_filter(Request $request)
    {
        try{
            ini_set('max_execution_time', '300');
            
            // if(!$request->has('city_id') && trim($request->input('city_id'))==''){
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }
            // $city_id=encryptor('d',$request->input('city_id'));
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }
            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/
            
            /*** Transmission Type count query ***/
                $getTransType = config('constant.TRANSMISSION_TYPE');
                $transTypeQuery = Model::select('cop_fv.feature_id', 'cop_fv.feature_value', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->whereIn('cop_fv.feature_id', (function ($query) use ($getTransType) {
                    $query->from('cop_features_ms')
                        ->select('feature_id')
                        ->where('features_name', '=', $getTransType);
                }))
                ->where('model_type', '=', 0)
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_models.status', 1)
                ->where('cop_variants.status', 1)
                ->groupBy('cop_fv.feature_value', 'cop_fv.feature_id')
                ->havingRaw('model_count > 0');
            /*** Transmission Type count query end ***/

            /**** filter start from here ****/
                /** brand filter start **/
                    if(!empty($brand)){
                        $transTypeQuery->whereIn('cop_models.brand_id', $brand);
                    }
                /** brand filter end **/

                /** car type filter start **/
                    if(!empty($cartype)){
                        $transTypeQuery->whereIn('cop_models.ct_id', $cartype);
                    }
                /** car type filter end **/

                /** Fuel Type filter start **/
                    if(!empty($fuelType)){
                        $getFuelType=config('constant.TYPE_OF_FUEL');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $fuelType));
                        
                        $transTypeQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                    }
                /** Fuel Type filter end **/

                /** Engine Capacity filter start **/
                    if(!empty($engine)){
                        $getDisplacement = config('constant.DISPLACEMENT');

                        $transTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });
                    }
                /** Engine Capacity filter end **/


                /** Drive Train filter start **/
                    if(!empty($driveTrain)){
                        $getDriveTrain = config('constant.DRIVETRAIN');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $driveTrain));
                        
                        $transTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });
                    }
                /** Drive Train filter end **/

                /** safety filter start **/
                    if(!empty($safety)){
                        $getSafety = config('constant.SAFETY');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $safety));
                        
                        $transTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });
                    }
                /** safety filter end **/

                /** Interior filter start **/
                    if(!empty($interior)){
                        $getInterior = config('constant.INTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $interior));

                        $transTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });
                    }
                /** Interior filter end **/
                /** exterior filter **/
                    if(!empty($exterior)){
                        $getExterior = config('constant.EXTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $exterior));

                        $transTypeQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });
                    }
                /** exterior filter end **/
            /**** filter end here ****/

            /** Initialize array **/
            $budgetArrData = $brandArrData = $cartypeArrData = $fuelArrData = $engineArrData = $transArrData = $driveArrData = $safetyArrData = $interiorArrData = $exteriorArrData = [];
            /** get image path**/
            $image_path=$this->imagePath;
            $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');
            
            /** transition type data mapping **/
            $transTypeQuery->get()->map(function($query) use (&$transArrData){
                $transArrData[]=['transition_type'=>$query->feature_value,
                                    'model_count'=>$query->model_count
                                    ];
            });            
           
            /** Bind all data in an array **/
            $response = [
                'by_transType' => $transArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // by drivetrain
    public function drivetrain_advanced_filter(Request $request)
    {
        try{
            ini_set('max_execution_time', '300');
            
            // if(!$request->has('city_id') && trim($request->input('city_id'))==''){
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }
            // $city_id=encryptor('d',$request->input('city_id'));
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }
            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/

            /*** Drivetrain Type count query ***/
                $getDriveTrainType = config('constant.DRIVETRAIN');
                $driveTrainQuery = Model::select('cop_fv.feature_id', 'cop_fv.feature_value', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->whereIn('cop_fv.feature_id', (function ($query) use ($getDriveTrainType) {
                    $query->from('cop_features_ms')
                        ->select('feature_id')
                        ->where('features_name', '=', $getDriveTrainType);
                }))
                ->where('model_type', '=', 0)
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_models.status', 1)
                ->where('cop_variants.status', 1)
                ->groupBy('cop_fv.feature_value', 'cop_fv.feature_id')
                ->havingRaw('model_count > 0');
            /*** Drivetrain Type count query end ***/

            /**** filter start from here ****/
                /** brand filter start **/
                    if(!empty($brand)){
                        $driveTrainQuery->whereIn('cop_models.brand_id', $brand);
                    }
                /** brand filter end **/

                /** car type filter start **/
                    if(!empty($cartype)){
                        $driveTrainQuery->whereIn('cop_models.ct_id', $cartype);
                    }
                /** car type filter end **/

                /** Fuel Type filter start **/
                    if(!empty($fuelType)){
                        $getFuelType=config('constant.TYPE_OF_FUEL');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $fuelType));
                        $driveTrainQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                    }
                /** Fuel Type filter end **/

                /** Engine Capacity filter start **/
                    if(!empty($engine)){
                        $getDisplacement = config('constant.DISPLACEMENT');
                        $driveTrainQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });
                    }
                /** Engine Capacity filter end **/

                /** Transmission type filter start **/
                    if(!empty($transType)){
                        $getTransType = config('constant.TRANSMISSION_TYPE');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $transType));

                        $driveTrainQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });
                    }
                /** Transmission type filter end **/

                /** safety filter start **/
                    if(!empty($safety)){
                        $getSafety = config('constant.SAFETY');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $safety));

                        $driveTrainQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });
                    }
                /** safety filter end **/

                /** Interior filter start **/
                    if(!empty($interior)){
                        $getInterior = config('constant.INTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $interior));

                        $driveTrainQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });
                    }
                /** Interior filter end **/
                /** exterior filter **/
                    if(!empty($exterior)){
                        $getExterior = config('constant.EXTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $exterior));

                        $driveTrainQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });
                    }
                /** exterior filter end **/
            /**** filter end here ****/

            /** Initialize array **/
            $budgetArrData = $brandArrData = $cartypeArrData = $fuelArrData = $engineArrData = $transArrData = $driveArrData = $safetyArrData = $interiorArrData = $exteriorArrData = [];
            /** get image path**/
            $image_path=$this->imagePath;
            $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');
            
            /** drive train data query **/
            $driveTrainQuery->get()->map(function($query) use (&$driveArrData){
                $driveArrData[]=['drive_train'=>$query->feature_value,
                                    'model_count'=>$query->model_count
                                    ];
            });            
           
            /** Bind all data in an array **/
            $response = [
                'by_driveTrain' => $driveArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // by safety
    public function safety_advanced_filter(Request $request)
    {
        try{
            ini_set('max_execution_time', '300');
            
            // if(!$request->has('city_id') && trim($request->input('city_id'))==''){
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }
            // $city_id=encryptor('d',$request->input('city_id'));
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }
            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/

            /*** Safety count query ***/
                // $safetyData="";
                $getSafety = config('constant.SAFETY');
                $get_feature_value = config('constant.feature');
                $safetyQuery = Model::select('cop_features_ms.features_name', 'cop_features_ms.feature_id', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->whereIn('cop_features_ms.spec_id', (function ($query) use ($getSafety) {
                    $query->from('cop_spec_ms')
                        ->select('spec_id')
                        ->where('spec_name', '=', $getSafety);
                }))
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_fv.feature_value', '=', $get_feature_value)
                ->where('model_type', '=', 0)
                ->where('cop_models.status', 1)
                ->where('cop_variants.status', 1)
                ->groupBy('cop_features_ms.features_name', 'cop_features_ms.feature_id')
                ->havingRaw('model_count > 0');
                // dd($safetyQuery->toSql());
            /*** Safety count query end ***/

            /**** filter start from here ****/
                /** brand filter start **/
                    if(!empty($brand)){
                        $safetyQuery->whereIn('cop_models.brand_id', $brand);
                    }
                /** brand filter end **/

                /** car type filter start **/
                    if(!empty($cartype)){
                        $safetyQuery->whereIn('cop_models.ct_id', $cartype);
                    }
                /** car type filter end **/

                /** Fuel Type filter start **/
                    if(!empty($fuelType)){
                        $getFuelType=config('constant.TYPE_OF_FUEL');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $fuelType));
                        $safetyQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                    }
                /** Fuel Type filter end **/

                /** Engine Capacity filter start **/
                    if(!empty($engine)){
                        $getDisplacement = config('constant.DISPLACEMENT');
                        $safetyQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });
                    }
                /** Engine Capacity filter end **/


                /** Drive Train filter start **/
                    if(!empty($driveTrain)){
                        $getDriveTrain = config('constant.DRIVETRAIN');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $driveTrain));
                        $safetyQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });
                    }
                /** Drive Train filter end **/

                /** Transmission type filter start **/
                    if(!empty($transType)){
                        $getTransType = config('constant.TRANSMISSION_TYPE');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $transType));
                        $safetyQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });
                    }
                /** Transmission type filter end **/

                /** Interior filter start **/
                    if(!empty($interior)){
                        $getInterior = config('constant.INTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $interior));
                        $safetyQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });
                    }
                /** Interior filter end **/
                /** exterior filter **/
                    if(!empty($exterior)){
                        $getExterior = config('constant.EXTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $exterior));
                        $safetyQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });
                    }
                /** exterior filter end **/
            /**** filter end here ****/

            /** Initialize array **/
            $budgetArrData = $brandArrData = $cartypeArrData = $fuelArrData = $engineArrData = $transArrData = $driveArrData = $safetyArrData = $interiorArrData = $exteriorArrData = [];
            /** get image path**/
            $image_path=$this->imagePath;
            $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');

            /** safety data mapping **/
            $safetyQuery->get()->map(function($query) use(&$safetyArrData){
                $safetyArrData[]=['safety'=>$query->features_name,
                                    'model_count'=>$query->model_count
                                    ];
            });
            
           
            /** Bind all data in an array **/
            $response = [
                'by_safety' => $safetyArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // by interior
    public function interior_advanced_filter(Request $request)
    {
        try{
            ini_set('max_execution_time', '300');
            
            // if(!$request->has('city_id') && trim($request->input('city_id'))==''){
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }
            // $city_id=encryptor('d',$request->input('city_id'));
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }
            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/

            /*** Interior count query ***/
                $getInterior = config('constant.INTERIOR');
                $getInterior_arr = config('constant.INTERIOR_ARR');
                $get_feature_value = config('constant.feature');
                
                $interiorQuery = Model::select('cop_features_ms.features_name', 'cop_fv.feature_id', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_models.model_id', '=', 'cop_variants.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                // ->join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                ->where('cop_fv.feature_value', '=', $get_feature_value)
                ->where('model_type', '=', 0)
                ->whereIn('cop_features_ms.features_name', $getInterior_arr)
                // ->where('cop_spec_ms.spec_name',$getInterior)
                ->whereIn('cop_features_ms.spec_id', (function ($query) use ($getInterior) {
                    $query->from('cop_spec_ms')
                        ->select('spec_id')
                        ->where('spec_name', '=', $getInterior);
                }))
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_models.status', 1)
                ->where('cop_variants.status', 1)
                ->groupBy('cop_features_ms.features_name', 'cop_fv.feature_id')
                ->havingRaw('model_count > 0');


            /*** interior count query end ***/

            /**** filter start from here ****/
                /** brand filter start **/
                    if(!empty($brand)){
                        $interiorQuery->whereIn('cop_models.brand_id', $brand);
                    }
                /** brand filter end **/

                /** car type filter start **/
                    if(!empty($cartype)){
                        $interiorQuery->whereIn('cop_models.ct_id', $cartype);
                    }
                /** car type filter end **/

                /** Fuel Type filter start **/
                    if(!empty($fuelType)){
                        $getFuelType=config('constant.TYPE_OF_FUEL');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $fuelType));
                        $interiorQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                    }
                /** Fuel Type filter end **/

                /** Engine Capacity filter start **/
                    if(!empty($engine)){
                        $getDisplacement = config('constant.DISPLACEMENT');
                        $interiorQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });
                    }
                /** Engine Capacity filter end **/


                /** Drive Train filter start **/
                    if(!empty($driveTrain)){
                        $getDriveTrain = config('constant.DRIVETRAIN');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $driveTrain));
                        $interiorQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });
                    }
                /** Drive Train filter end **/

                /** Transmission type filter start **/
                    if(!empty($transType)){
                        $getTransType = config('constant.TRANSMISSION_TYPE');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $transType));
                        $interiorQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });
                    }
                /** Transmission type filter end **/

                /** safety filter start **/
                    if(!empty($safety)){
                        $getSafety = config('constant.SAFETY');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $safety));
                        $interiorQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });
                    }
                /** safety filter end **/

                /** exterior filter **/
                    if(!empty($exterior)){
                        $getExterior = config('constant.EXTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $exterior));
                        $interiorQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$exterior)
                                ->where('cop_spec_ms.spec_name',$getExterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                        });
                    }
                /** exterior filter end **/
            /**** filter end here ****/

            /** Initialize array **/
            $budgetArrData = $brandArrData = $cartypeArrData = $fuelArrData = $engineArrData = $transArrData = $driveArrData = $safetyArrData = $interiorArrData = $exteriorArrData = [];
            /** get image path**/
            $image_path=$this->imagePath;
            $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');
            
            /** interior data mapping **/
            $interiorQuery->get()->map(function($query) use (&$interiorArrData){
                $interiorArrData[]=['interior'=>$query->features_name,
                                    'model_count'=>$query->model_count
                                    ];
            });
           
            /** Bind all data in an array **/
            $response = [
                'by_interior' => $interiorArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // by exterior
    public function exterior_advanced_filter(Request $request)
    {
        try{
            ini_set('max_execution_time', '300');
            
            // if(!$request->has('city_id') && trim($request->input('city_id'))==''){
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }
            // $city_id=encryptor('d',$request->input('city_id'));
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }
            // $cartype = $request->input('cartype', []);

            // $fuelType = $request->input('fuelType', []);
            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            $sort = $request->input('sort');
            $search_filter=[];

            // Begin:: for min and max price filter
                if(!empty($budget)){
                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);
                    $min_price=config('constant.MIN_PRICE');
                    $max_price=config('constant.MAX_PRICE');
                    foreach ($budgetData as $budgetRange) {
                        $min_price=$budgetRange[0];
                        $max_price=$budgetRange[1];
                    }
                }else{
                    $min_price = (!empty($minBudget)?$minBudget:config('constant.MIN_PRICE'));
                    $max_price = (!empty($maxBudget)?$maxBudget:config('constant.MAX_PRICE'));
                }
            // End:: for min and max price filter

            // Begin:: for engine capacity filter
                if(!empty($engine)){
                    $result = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);
                    for ($i = 0; $i <= count($engine) - 1; $i++) {
                        $engine_min = $result[$i][0];
                        $engine_max = $result[$i][1];
                        $search_filter[]=$engine_min.' to '.$engine_max;
                    }
                }
            // End:: for engine capacity filter

            /*** Get all variant id between price range using store procedure ***/
                DB::select('CALL getVariantIds(?, ?, @varIds)', [$min_price, $max_price]);
                $outputVariable = DB::select('SELECT @varIds as variant_ids');
                $allVariants = explode(",",$outputVariable[0]->variant_ids);
            /*** Get all variant id between price range using store procedure end ***/
            
            /*** exterior count query ***/
                $exteriorData = [];
                $getExterior = config('constant.EXTERIOR');
                $getExterior_arr = config('constant.EXTERIOR_ARR');
                $get_feature_value = config('constant.feature');

                $exteriorQuery = Model::select('cop_features_ms.features_name', 'cop_features_ms.feature_id', DB::raw("count(DISTINCT cop_fv.model_id) as model_count"))
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->where('cop_fv.feature_value', '=', $get_feature_value)
                ->where('model_type', '=', 0)
                ->whereIn('cop_features_ms.features_name', $getExterior_arr)
                ->whereIn('cop_features_ms.spec_id', (function ($query) use ($getExterior) {
                    $query->from('cop_spec_ms')
                        ->select('spec_id')
                        ->where('spec_name', '=', $getExterior);
                }))
                // ->whereIn('cop_models.model_id',explode(",", $result))
                ->whereIn('cop_variants.variant_id', $allVariants)
                ->where('cop_models.status', 1)
                ->where('cop_variants.status', 1)
                ->groupBy('cop_features_ms.features_name', 'cop_features_ms.feature_id')
                ->havingRaw('model_count > 0');
            /*** exterior count query end ***/

            /**** filter start from here ****/
                /** brand filter start **/
                    if(!empty($brand)){
                        $exteriorQuery->whereIn('cop_models.brand_id', $brand);
                    }
                /** brand filter end **/

                /** car type filter start **/
                    if(!empty($cartype)){
                        $exteriorQuery->whereIn('cop_models.ct_id', $cartype);
                    }
                /** car type filter end **/

                /** Fuel Type filter start **/
                    if(!empty($fuelType)){
                        $getFuelType=config('constant.TYPE_OF_FUEL');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $fuelType));
                        $exteriorQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                            $query->from('cop_fv')
                                ->select('cop_fv.variant_id')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $fuelType)
                                ->where('cop_features_ms.features_name',$getFuelType);
                        }));
                    }
                /** Fuel Type filter end **/

                /** Engine Capacity filter start **/
                    if(!empty($engine)){
                        $getDisplacement = config('constant.DISPLACEMENT');
                        $exteriorQuery->whereIn('cop_variants.variant_id', function ($query) use ($engine_min, $engine_max, $getDisplacement) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereBetween('cop_fv.feature_value', [$engine_min, $engine_max])
                                ->where('cop_features_ms.features_name',$getDisplacement);
                        });
                    }
                /** Engine Capacity filter end **/


                /** Drive Train filter start **/
                    if(!empty($driveTrain)){
                        $getDriveTrain = config('constant.DRIVETRAIN');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $driveTrain));
                        $exteriorQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value',$driveTrain)
                                ->where('cop_features_ms.features_name',$getDriveTrain);
                        });
                    }
                /** Drive Train filter end **/

                /** Transmission type filter start **/
                    if(!empty($transType)){
                        $getTransType = config('constant.TRANSMISSION_TYPE');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $transType));
                        $exteriorQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->whereIn('cop_fv.feature_value', $transType)
                                ->where('cop_features_ms.features_name',$getTransType);
                        });
                    }
                /** Transmission type filter end **/

                /** safety filter start **/
                    if(!empty($safety)){
                        $getSafety = config('constant.SAFETY');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $safety));
                        $exteriorQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$safety)
                                ->where('cop_spec_ms.spec_name',$getSafety)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                        });
                    }
                /** safety filter end **/

                /** Interior filter start **/
                    if(!empty($interior)){
                        $getInterior = config('constant.INTERIOR');
                        $featureData = implode(',', array_map(function ($item) {
                            return "'" . $item . "'";
                        }, $interior));
                        $exteriorQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                            $query->select('cop_fv.variant_id')
                                ->from('cop_fv')
                                ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                                ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                                ->where('cop_fv.feature_value', 'yes')
                                ->whereIn('cop_features_ms.features_name',$interior)
                                ->where('cop_spec_ms.spec_name',$getInterior)
                                ->groupBy('cop_fv.variant_id')
                                ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                        });
                    }
                /** Interior filter end **/
            /**** filter end here ****/

            /** Initialize array **/
            $budgetArrData = $brandArrData = $cartypeArrData = $fuelArrData = $engineArrData = $transArrData = $driveArrData = $safetyArrData = $interiorArrData = $exteriorArrData = [];
            /** get image path**/
            $image_path=$this->imagePath;
            $budgetWordArr = config('constant.BUDGET_LIST_WORDS_ARR');
            
            /** exterior data mapping **/
            $exteriorQuery->get()->map(function($query) use (&$exteriorArrData){
                $exteriorArrData[]=['exterior'=>$query->features_name,
                'model_count'=>$query->model_count
                ];
            });
            
           
            /** Bind all data in an array **/
            $response = [
                'by_exterior' => $exteriorArrData,
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRETNLY -> advance_search_matching_variant)
    public function advance_search_matching_variant(Request $request)
    {
        try{
            if(!$request->has('model_id') && trim($request->input('model_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            }
            if(!$request->has('city_id') && trim($request->input('city_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $city_id = encryptor('d',$request->input('city_id'));
            $model_id = encryptor('d',$request->input('model_id'));
           
            $budget = $request->filled('budget') ? explode(',', trim($request->input('budget'))) : [];
            $brandArr = $request->filled('brand_id') ? explode(',', trim($request->input('brand_id'))) : [];
            $brand=[];
            for($i=0;$i<count($brandArr);$i++){
                $brand[]=encryptor('d',$brandArr[$i]);
            }
            $cartypeArr = $request->filled('cartype') ? explode(',', trim($request->input('cartype'))) : [];//$request->input('brand', []);
            $cartype=[];
            for($i=0;$i<count($cartypeArr);$i++){
                $cartype[]=encryptor('d',$cartypeArr[$i]);
            }

            $fuelType = $request->filled('fuelType') ? explode(',', trim($request->input('fuelType'))) : [];
            $engine = $request->filled('engine') ? explode(',', trim($request->input('engine'))) : [];

            $driveTrain = $request->filled('driveTrain') ? explode(',', trim($request->input('driveTrain'))) : [];
            $transType = $request->filled('transType') ? explode(',', trim($request->input('transType'))) : [];
            $safety = $request->filled('safety') ? explode(',', trim($request->input('safety'))) : [];
            $interior = $request->filled('interior') ? explode(',', trim($request->input('interior'))) : [];
            $exterior = $request->filled('exterior') ? explode(',', trim($request->input('exterior'))) : [];
            $minBudget = $request->filled('minBudget') ? explode(',', trim($request->input('minBudget'))) : [];
            $maxBudget = $request->filled('maxBudget') ? explode(',', trim($request->input('maxBudget'))) : [];
            
            $status = config('constant.STATUS');
            
            $getFuelType = config('constant.TYPE_OF_FUEL');
            $variantQuery = Variant::select( 'model_name',DB::raw("(select feature_value from cop_fv inner join cop_features_ms on cop_features_ms.feature_id=cop_fv.feature_id where features_name='$getFuelType' and cop_fv.variant_id=cop_variants.variant_id) as feature_value"),'cop_variants.model_id','cop_variants.variant_id','cop_variants.variant_name',DB::raw('( SELECT ex_showroom_price FROM cop_pe_ms WHERE cop_pe_ms.variant_id=cop_variants.variant_id AND cop_pe_ms.status = ' . $status . ' AND cop_pe_ms.city_id = ' . $city_id . ' ) AS ex_showroom_price'))
            ->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
            ->where('cop_variants.status',$status)
            ->where('cop_models.model_id',$model_id);

            /** Filter start from here **/
                if(!empty($engine)){
                    $engineData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $engine);

                    $getDisplacement = config('constant.DISPLACEMENT');

                    $variantQuery->whereIn('cop_variants.variant_id', function ($query) use ($engineData, $getDisplacement) {
                        $query->select('cop_fv.variant_id')
                            ->from('cop_fv')
                            ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                            ->where('cop_features_ms.features_name', $getDisplacement)
                            ->where(function ($query) use ($engineData) {
                                foreach ($engineData as $engineRange) {
                                    $query->orWhereBetween('cop_fv.feature_value', [(int)$engineRange[0], (int)$engineRange[1]]);
                                }
                            });
                    });

                }

                if(!empty($budget)){
                    // $model_Card->whereIn('cop_models.model_id', (function ($query) use ($min_price,$max_price) {
                    //     $query->from('cop_pe_ms')
                    //         ->select('cop_pe_ms.model_id')
                    //         ->whereBetween('cop_pe_ms.ex_showroom_price', [$min_price, $max_price]);
                    //         // ->where('cop_pe_ms.ex_showroom_price','>=', $min_price)
                    //         // ->where('cop_pe_ms.ex_showroom_price','<=', $max_price);
                    // }));

                    $budgetData = array_map(function ($item) {
                        return explode(' to ', $item);
                    }, $budget);


                    $variantQuery->whereIn('cop_variants.variant_id', function ($query) use ($budgetData) {
                        $query->select('cop_pe_ms.variant_id')
                            ->from('cop_pe_ms')
                            ->where(function ($query) use ($budgetData) {
                                foreach ($budgetData as $budgetRange) {
                                    $query->orWhereBetween('cop_pe_ms.ex_showroom_price', [(int)$budgetRange[0], (int)$budgetRange[1]]);
                                }
                            });
                    });

                } elseif(!empty($minBudget) && !empty($maxBudget)){
                    $variantQuery->whereIn('cop_variants.variant_id', (function ($query) use ($minBudget,$maxBudget) {
                            $query->from('cop_pe_ms')
                                ->select('cop_pe_ms.variant_id')
                                ->whereBetween('cop_pe_ms.ex_showroom_price', [$minBudget, $maxBudget]);
                        }));
                }

                if(!empty($brand)){
                    $variantQuery->whereIn('cop_models.brand_id', $brand);
                }


                if(!empty($cartype)){
                    $variantQuery->whereIn('cop_models.ct_id', $cartype);
                }
                if(!empty($fuelType)){
                    $getFuelType=config('constant.TYPE_OF_FUEL');
                    $variantQuery->whereIn('cop_variants.variant_id', (function ($query) use ($getFuelType,$fuelType) {
                        $query->from('cop_fv')
                            ->select('cop_fv.variant_id')
                            ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                            ->whereIn('cop_fv.feature_value', $fuelType)
                            ->where('cop_features_ms.features_name',$getFuelType);
                    }));
                }

                if(!empty($driveTrain)){
                    $getDriveTrain = config('constant.DRIVETRAIN');
                    $variantQuery->whereIn('cop_variants.variant_id', function ($query) use ($driveTrain, $getDriveTrain) {
                        $query->select('cop_fv.variant_id')
                            ->from('cop_fv')
                            ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                            ->whereIn('cop_fv.feature_value',$driveTrain)
                            ->where('cop_features_ms.features_name',$getDriveTrain);
                    });
                }
                if(!empty($transType)){
                    $getTransType = config('constant.TRANSMISSION_TYPE');
                    $variantQuery->whereIn('cop_variants.variant_id', function ($query) use ($transType, $getTransType) {
                        $query->select('cop_fv.variant_id')
                            ->from('cop_fv')
                            ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                            ->whereIn('cop_fv.feature_value', $transType)
                            ->where('cop_features_ms.features_name',$getTransType);
                    });
                }
                if(!empty($safety)){
                    $getSafety = config('constant.SAFETY');
                    $variantQuery->whereIn('cop_variants.variant_id', function ($query) use ($safety, $getSafety) {
                        $query->select('cop_fv.variant_id')
                            ->from('cop_fv')
                            ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                            ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                            ->where('cop_fv.feature_value', 'yes')
                            ->whereIn('cop_features_ms.features_name',$safety)
                            ->where('cop_spec_ms.spec_name',$getSafety)
                            ->groupBy('cop_fv.variant_id')
                            ->havingRaw('count(cop_fv.feature_id)='.count($safety));
                    });
                }
                if(!empty($interior)){
                    $getInterior = config('constant.INTERIOR');
                    $variantQuery->whereIn('cop_variants.variant_id', function ($query) use ($interior, $getInterior) {
                        $query->select('cop_fv.variant_id')
                            ->from('cop_fv')
                            ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                            ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                            ->where('cop_fv.feature_value', 'yes')
                            ->whereIn('cop_features_ms.features_name',$interior)
                            ->where('cop_spec_ms.spec_name',$getInterior)
                            ->groupBy('cop_fv.variant_id')
                            ->havingRaw('count(cop_fv.feature_id)='.count($interior));
                    });
                }
                if(!empty($exterior)){
                    $getExterior = config('constant.EXTERIOR');
                    $variantQuery->whereIn('cop_variants.variant_id', function ($query) use ($exterior, $getExterior) {
                    $query->select('cop_fv.variant_id')
                        ->from('cop_fv')
                        ->join("cop_features_ms","cop_features_ms.feature_id","=","cop_fv.feature_id")
                        ->join("cop_spec_ms","cop_features_ms.spec_id","=","cop_spec_ms.spec_id")
                        ->where('cop_fv.feature_value', 'yes')
                        ->whereIn('cop_features_ms.features_name',$exterior)
                        ->where('cop_spec_ms.spec_name',$getExterior)
                        ->groupBy('cop_fv.variant_id')
                        ->havingRaw('count(cop_fv.feature_id)='.count($exterior));
                    });
                }
            /** Filter end **/

            $variantQuery = $variantQuery->get();
            $cnt = $variantQuery->count();
            $outputData = [];
            if($cnt>0){
                foreach($variantQuery as $variantData){
                    $outputData[]=['variant_name' => $variantData->variant_name,
                                    'ex_showroom_price' => formatAmount($variantData->ex_showroom_price,$variantData->ex_showroom_price),
                                    'feature_value' => $variantData->feature_value
                                  ];
                }
            }
            $response = [
                'variant_data' => $outputData
            ];
            return ResponseHelper::responseMessage('success', $response);
        }catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    private function pricefilter($model_id)
    {
        try {
            $priceMinMax = Model::select(
                DB::raw('MIN(cop_pe_ms.ex_showroom_price) as min_ex_showroom_price'),
                DB::raw('MAX(cop_pe_ms.ex_showroom_price) as max_ex_showroom_price')
            )
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->where('cop_models.model_id', $model_id)
                ->where('cop_models.model_type', '0')
                ->first();

            return [
                'price_filter' => $priceMinMax['min_ex_showroom_price'],
                'min_ex_showroom_price' =>  convertToLakhCrore($priceMinMax['min_ex_showroom_price']),
                'max_ex_showroom_price' =>  convertToLakhCrore($priceMinMax['max_ex_showroom_price']),
            ];
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index(Request $request)
    {
        $minPrice = $request->input('minprice');
        $maxPrice = $request->input('maxprice');
        $brandName = $request->filled('brand_name') ? explode(',', trim($request->input('brand_name'))) : [];
        $ct_name = $request->filled('ct_name') ? explode(',', trim($request->input('ct_name'))) : [];
        $fuelType = $request->filled('fuel_type') ? explode(',', trim($request->input('fuel_type'))) : ['Petrol', 'Diesel', 'Petrol-CNG', 'Hybrid'];
        $engineCapacity = $request->input('engine_type');
        $transmissionType = $request->filled('transmission_type') ? [$request->input('transmission_type')] : ['Automatic', 'Manual'];
        $driveTrain = $request->filled('drivetrain') ? explode(',', trim($request->input('drivetrain'))) : [];
        $safetyFeatures = $request->filled('safetyfeature') ? explode(',', trim($request->input('safetyfeature'))) : [];
        $interiorFeatures = $request->filled('interiorfeature') ? explode(',', trim($request->input('interiorfeature'))) : [];
        $exteriorFeatures = $request->filled('exteriorfeature') ? explode(',', trim($request->input('exteriorfeature'))) : [];

        try {
            //car model card data
            $fvModel = FeatureValue::join('cop_models', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_fv.brand_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')

                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                ->select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_image',
                    'cop_models.min_price',
                    'cop_models.max_price',

                    DB::raw('MIN(cop_pe_ms.ex_showroom_price) AS min_ex_showroom_price'),
                    DB::raw('MAX(cop_pe_ms.ex_showroom_price) AS max_ex_showroom_price'),
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                );

            if (!empty($minPrice) && !empty($maxPrice)) {

                $fvModel->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $fvModel->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $fvModel->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $fvModel->whereIn('cop_fv.model_id', function ($fvModel) use ($fuelType) {
                    $fvModel->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $fvModel->whereIn('cop_fv.model_id', function ($fvModel) use ($transmissionType) {
                    $fvModel->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $fvModel->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->leftJoin('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            // dd($explodeEngineCapacity);
                            foreach ($explodeEngineCapacity as $range) {

                                $result = explode('-', $range);

                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                // dd(  $toEngine );
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [(int)$fromEngine, (int)$toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [(int)$fromEngine, (int)$toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }
            if (!empty($driveTrain)) {
                $fvModel->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }
            if (!empty($safetyFeatures)) {
                $fvModel->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }
            if (!empty($interiorFeatures)) {
                $fvModel->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }
            if (!empty($exteriorFeatures)) {
                $fvModel->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }
            $models = $fvModel->groupBy(
                'cop_fv.model_id',
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_models.model_image',
                'cop_models.min_price',
                'cop_models.max_price',
                'cop_ratings.rating_value',
                'cop_rating_types.rating_type_name',

            )->distinct()
                ->get();
            // dd($models->get()->count());
            $responseCardData = $models->map(function ($item) {
                return
                    $data['modelcard'] = [
                        'brand_id' => encryptor('e',$item->brand_id),
                        'brand_name' => $item->brand_name,
                        'model_id' => encryptor('e',$item->model_id),
                        'model_name' => $item->model_name,
                        'model_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->model_image}") ?? "",
                        // 'min_price' =>  convertToLakhCrore($item->min_price),
                        // 'max_price' =>  convertToLakhCrore($item->max_price),
                        'price' => $this->pricefilter($item->model_id),
                        'rating_type_name' => $item->rating_type_name ?? NULL,
                        'rating_value' => isset($item->rating_value) ? $item->rating_value : NULL,

                    ];
            });

            //by budget

            $price_count = Model::selectRaw('
            CASE
                WHEN (cop_pe_ms.ex_showroom_price >= 200000 AND cop_pe_ms.ex_showroom_price < 1000000) THEN "200000 - 1000000"
                WHEN (cop_pe_ms.ex_showroom_price >= 1000000 AND cop_pe_ms.ex_showroom_price < 2500000) THEN "1000000 - 2500000"
                WHEN (cop_pe_ms.ex_showroom_price >= 2500000 AND cop_pe_ms.ex_showroom_price < 5000000) THEN "2500000 - 5000000"
                WHEN (cop_pe_ms.ex_showroom_price >= 5000000 AND cop_pe_ms.ex_showroom_price < 10000000) THEN "5000000 - 10000000"
                ELSE "10000000 - 990000000"
            END AS price_range,
            COUNT(DISTINCT cop_fv.model_id) as model_count
            ')
                ->join('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->where('cop_models.model_type', '=', '0')
                ->groupBy('price_range')
                ->orderByRaw("FIELD(price_range, '200000 - 1000000', '1000000 - 2500000', '2500000 - 5000000', '5000000 - 10000000', '10000000 - 990000000')");


            if (!empty($brandName)) {
                $price_count->whereIn('cop_brands_ms.brand_name', $brandName);
            }

            // if (!empty($minPrice) && !empty($maxPrice)) {
            //     $price_count->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            // }


            if (!empty($ct_name)) {
                $price_count->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $price_count->whereIn('cop_fv.model_id', function ($by_brand) use ($fuelType) {
                    $by_brand->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $price_count->whereIn('cop_fv.model_id', function ($by_brand) use ($transmissionType) {
                    $by_brand->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $price_count->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }
            if (!empty($driveTrain)) {
                $price_count->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $price_count->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $price_count->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $price_count->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $count_price = $price_count->get();
            $show_prices = []; // Initialize an array to store all price range data

            foreach ($count_price as $price) {
                switch ($price->price_range) {
                    case "200000 - 1000000":
                        $show_keyword = "2 - 10 lakh";
                        break;
                    case "1000000 - 2500000":
                        $show_keyword = "10 - 25 lakh";
                        break;
                    case "2500000 - 5000000":
                        $show_keyword = "25 - 50 lakh";
                        break;
                    case "5000000 - 10000000":
                        $show_keyword = "50 lakh  - 1 crore";
                        break;
                    case "10000000 - 990000000":
                        $show_keyword = "1 Cr+";
                        break;
                    default:
                        $show_keyword = "Unknown";
                }

                $show_prices[] = [
                    "price_range" => $price->price_range,
                    "model_count" => $price->model_count,
                    "show_keyword" => $show_keyword
                ];
            }
            //end by budget

            //By Brand
            $brands = Brand::select('brand_id', 'brand_name')->get();

            $by_brand = Model::select('cop_models.brand_id', 'cop_brands_ms.brand_name', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->Join('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')

                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->where('cop_models.model_type', '=', '0');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $by_brand->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                // $by_brand->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $by_brand->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $by_brand->whereIn('cop_fv.model_id', function ($by_brand) use ($fuelType) {
                    $by_brand->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $by_brand->whereIn('cop_fv.model_id', function ($by_brand) use ($transmissionType) {
                    $by_brand->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $by_brand->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }
            if (!empty($driveTrain)) {
                $by_brand->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $by_brand->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $by_brand->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $by_brand->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }


            $by_brand = $by_brand->groupBy('cop_models.brand_id', 'cop_brands_ms.brand_name')
                ->havingRaw('model_count > 0')
                ->get();
            // dd($by_brand->toSql());
            if ($by_brand->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }

            $byBrand = $brands->map(function ($brand) use ($by_brand) {
                $brand_id = $brand->brand_id;
                $brand_name = $brand->brand_name;
                $count = 0;

                $modelCount = $by_brand->firstWhere('brand_id', $brand_id);
                if ($modelCount) {
                    $count = $modelCount->model_count;
                }

                return [
                    'brand_id' => $brand_id,
                    'brand_name' => $brand_name,
                    'model_count' => $count,
                ];
            })->filter(function ($brand_count) {
                return $brand_count['model_count'] > 0;
            })->values();


            //By Body Type
            $carType = CarType::select('ct_id', 'ct_name', 'ct_image')->get();

            $by_body_type = Model::select('cop_models.ct_id', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->where('cop_models.model_type', 0);

            if (!empty($minPrice) && !empty($maxPrice)) {
                $by_body_type->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $by_body_type->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                // $by_body_type->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($by_body_type) use ($fuelType) {
                    $by_body_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($by_body_type) use ($transmissionType) {
                    $by_body_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }
            if (!empty($driveTrain)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $by_body_type = $by_body_type->groupBy('cop_models.ct_id')
                ->havingRaw('model_count > 0')
                ->get();

            $byBodyType = $carType->map(function ($cartype) use ($by_body_type) {
                $ct_id = $cartype->ct_id;
                $ct_name = $cartype->ct_name;
                $ct_image = asset("car_types/{$cartype->ct_id}/{$cartype->ct_image}");

                $count = 0;

                $modelCount = $by_body_type->firstWhere('ct_id', $ct_id);
                if ($modelCount) {
                    $count = $modelCount->model_count;
                }
                // if($count>0){
                return [
                    'ct_id' => $ct_id,
                    'ct_name' => $ct_name,
                    'ct_image' => $ct_image,
                    'model_count' => $count,
                ];
            })->filter(function ($body_type_count) {
                return $body_type_count['model_count'] > 0;
            })->values();


            //Fuel Type

            $fuel = FeatureValue::select('feature_value')->whereIn('feature_value', ['Petrol', 'Diesel', 'Petrol-CNG', 'Hybrid'])->distinct()->get();

            $fuel_type = Model::select('cop_fv.feature_value', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_features_ms.features_name', '=', 'Type of Fuel');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $fuel_type->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $fuel_type->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $fuel_type->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            // if (!empty($fuelType)) {
            //     $fuel_type->whereIn('cop_fv.model_id', function ($fuel_type) use ($fuelType) {
            //         $fuel_type->select('model_id')
            //             ->from('cop_fv')
            //             ->whereIn('feature_value', $fuelType);
            //     });
            // }
            if (!empty($transmissionType)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($fuel_type) use ($transmissionType) {
                    $fuel_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }

            if (!empty($engineCapacity)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }

            if (!empty($driveTrain)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $fuel_type = $fuel_type->groupBy('cop_fv.feature_value')
                ->havingRaw('model_count > 0')
                ->get();
            // dd($fuel_type->toSql());

            $byfuelType = $fuel->map(function ($fuel) use ($fuel_type) {

                $feature_value = $fuel->feature_value;
                $count = 0;

                $modelCount = $fuel_type->firstWhere('feature_value', $feature_value);
                if ($modelCount) {
                    $count = $modelCount->model_count;
                }

                return [
                    'feature_value' => $feature_value,
                    'model_count' => $count,
                ];
            })->filter(function ($item) {
                return $item['model_count'] > 0;
            })->values();


            //Engine capacity(cc)
            $engineCc = Model::selectRaw("
                CASE
                    WHEN feature_value >= 0 AND feature_value < 1200 THEN '0 - 1200'
                    WHEN feature_value >= 1200 AND feature_value < 1500 THEN '1200 - 1500'
                    WHEN feature_value >= 1500 AND feature_value < 2000 THEN '1500 - 2000'
                    WHEN feature_value >= 2000 AND feature_value < 3000 THEN '2000 - 3000'
                    WHEN feature_value >= 3000 AND feature_value < 5000 THEN '3000 - 5000'
                    WHEN feature_value >= 5000 AND feature_value < 8000 THEN '5000 - 8000'
                END AS feature_value_range,
                COUNT(DISTINCT cop_fv.model_id) AS model_count
            ")
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_features_ms.features_name', '=', 'Displacement');


            if (!empty($minPrice) && !empty($maxPrice)) {
                $engineCc->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $engineCc->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $engineCc->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $engineCc->whereIn('cop_fv.model_id', function ($engineCc) use ($fuelType) {
                    $engineCc->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $engineCc->whereIn('cop_fv.model_id', function ($engineCc) use ($transmissionType) {
                    $engineCc->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            // if (!empty($engineCapacity)) {
            //     $engineCc->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
            //         $query->select('cop_fv.model_id')
            //             ->from('cop_features_ms')
            //             ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
            //             ->where('features_name', '=', 'Displacement')
            //             ->where(function ($query) use ($engineCapacity) {
            //                 $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
            //                 $cnt = 0;
            //                 foreach ($explodeEngineCapacity as $range) {
            //                     $result = explode('-', $range);
            //                     $fromEngine = $result[0];
            //                     $toEngine = $result[1];
            //                     if ($cnt == 0) {
            //                         $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
            //                     } else {
            //                         $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
            //                     }
            //                     $cnt++;
            //                 }
            //             });
            //     });
            // }

            if (!empty($driveTrain)) {
                $engineCc->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $engineCc->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $engineCc->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $engineCc->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $engine_capacity = $engineCc->groupBy('feature_value_range')
                ->having('model_count', '>', 0)
                ->get();


            //Transmission Type
            $transmission_type = Model::select('cop_fv.feature_value', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_features_ms.features_name', '=', 'Type of Transmission');


            if (!empty($minPrice) && !empty($maxPrice)) {
                $transmission_type->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $transmission_type->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $transmission_type->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($transmission_type) use ($fuelType) {
                    $transmission_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            // if (!empty($transmissionType)) {
            //     $transmission_type->whereIn('cop_fv.model_id', function ($transmission_type) use ($transmissionType) {
            //         $transmission_type->select('model_id')
            //             ->from('cop_fv')
            //             ->whereIn('feature_value', $transmissionType);
            //     });
            // }
            if (!empty($engineCapacity)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [(int)$fromEngine, (int)$toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [(int)$fromEngine, (int)$toEngine]);
                                }
                            }
                        });
                });
            }
            if (!empty($driveTrain)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }
            if (!empty($safetyFeatures)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $bytransmissionType = $transmission_type->groupBy('cop_fv.feature_value')
                ->havingRaw('model_count > 0')->get()->map(function ($data) {
                    $feature_value = $data->feature_value;
                    return [
                        'feature_value' => $feature_value,
                        'model_count' => $data->model_count,
                    ];
                });

            //Drivetrain Type
            // $feature_id = 26;
            $drivetrain_type = DB::table('cop_models')
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->select(
                    'cop_fv.feature_value',
                    DB::raw('COUNT(DISTINCT cop_fv.model_id) AS model_count')
                )
                ->where('cop_models.model_type', 0)
                ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                ->where('cop_fv.feature_value', '!=', '-');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $drivetrain_type->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $drivetrain_type->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $drivetrain_type->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($drivetrain_type) use ($fuelType) {
                    $drivetrain_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($drivetrain_type) use ($transmissionType) {
                    $drivetrain_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }

            // if (!empty($driveTrain)) {
            //     $drivetrain_type->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
            //         $query->select('cop_fv.model_id')
            //             ->from('cop_fv')
            //             ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
            //             ->where('cop_features_ms.features_name', '=', 'Drivetrain')
            //             ->whereIn('cop_fv.feature_value', $driveTrain);
            //     });
            // }

            if (!empty($safetyFeatures)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $bydrivetrainType = $drivetrain_type->groupBy('cop_fv.feature_value')
                ->havingRaw('model_count > 0')
                ->get()
                // dd($drivetrain_type->toSql())
                ->map(function ($data) {
                    $feature_value = $data->feature_value;
                    return [
                        'feature_value' => $feature_value,
                        'model_count' => $data->model_count,
                    ];
                });


            //Safety Features


            // $spec_id = 12;
            // $safety_features = DB::table('cop_models')
            //     ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
            //     ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            //     ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
            //     ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
            //     ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //     // ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_fv.spec_id')
            //     ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //     ->select(
            //         'cop_fv.feature_id as features_id',
            //         'cop_features_ms.features_name',
            //         DB::raw('COUNT(DISTINCT cop_fv.model_id) AS model_count')
            //     )
            //     ->where('cop_models.model_type', 0)
            //     ->where('cop_spec_ms.spec_name', '=', 'Safety')
            //     ->where('cop_fv.feature_value', '=', '1');

            $safety_features = Model::select('cop_features_ms.features_name', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_spec_ms.spec_name', '=', 'Safety')
                ->where('cop_fv.feature_value', '=', '1');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $safety_features->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $safety_features->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $safety_features->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $safety_features->whereIn('cop_fv.model_id', function ($safety_features) use ($fuelType) {
                    $safety_features->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $safety_features->whereIn('cop_fv.model_id', function ($safety_features) use ($transmissionType) {
                    $safety_features->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $safety_features->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }

            if (!empty($driveTrain)) {
                $safety_features->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            // if (!empty($safetyFeatures)) {
            //     $safety_features->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
            //         $query->select('cop_fv.model_id')
            //             ->from('cop_fv')
            //             ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //             ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //             ->where('cop_spec_ms.spec_name', '=', 'Safety')
            //             ->where('cop_fv.feature_value', '=', '1')
            //             ->whereIn('cop_features_ms.features_name', $safetyFeatures);
            //     });
            // }
            if (!empty($interiorFeatures)) {
                $safety_features->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $safety_features->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $bysafetyFeatures = $safety_features->groupBy('cop_features_ms.features_name')
                ->havingRaw('model_count > 0')
                ->get()
                // dd($safety_features->toSql())
                ->map(function ($data) {
                    return [
                        'features_name' => $data->features_name,
                        'model_count' => $data->model_count,
                    ];
                });

            //Interior


            // $spec_id = 10;
            // $f_interior = DB::table('cop_models')
            //     ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
            //     ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            //     ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
            //     ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
            //     ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //     ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //     ->select(
            //         'cop_fv.feature_id as features_id',
            //         'cop_features_ms.features_name',
            //         DB::raw('COUNT(DISTINCT cop_fv.model_id) AS model_count')
            //     )
            //     ->where('cop_models.model_type', 0)
            //     ->where('cop_spec_ms.spec_name', '=', 'Interior');
            //   ->where('cop_fv.feature_value', '!=', '-');
            $f_interior = Model::select('cop_features_ms.features_name', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_spec_ms.spec_name', '=', 'Interior')
                ->where('cop_fv.feature_value', '=', '1');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $f_interior->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $f_interior->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $f_interior->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $f_interior->whereIn('cop_fv.model_id', function ($f_interior) use ($fuelType) {
                    $f_interior->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $f_interior->whereIn('cop_fv.model_id', function ($f_interior) use ($transmissionType) {
                    $f_interior->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $f_interior->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }

            if (!empty($driveTrain)) {
                $f_interior->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $f_interior->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            // if (!empty($interiorFeatures)) {
            //     $f_interior->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
            //         $query->select('cop_fv.model_id')
            //             ->from('cop_fv')
            //             ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //             ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //             ->where('cop_spec_ms.spec_name', '=', 'Interior')
            //             ->where('cop_fv.feature_value', '=', '1')
            //             ->whereIn('cop_features_ms.features_name', $interiorFeatures);
            //     });
            // }

            if (!empty($exteriorFeatures)) {
                $f_interior->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $fInterior = $f_interior->groupBy('cop_features_ms.features_name')
                ->havingRaw('model_count > 0')
                ->get()
                // dd($f_interior->toSql())
                ->map(function ($data) {
                    //   $feature_value = $data->feature_value;
                    return [
                        // 'features_id' => $data->features_id,
                        'features_name' => $data->features_name,
                        'model_count' => $data->model_count,
                    ];
                });

            //Exterior


            // $spec_id = 11;
            // $f_exterior = DB::table('cop_models')
            //     ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
            //     ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            //     ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
            //     ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
            //     ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //     ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //     ->select(
            //         'cop_fv.feature_id as features_id',
            //         'cop_features_ms.features_name',
            //         DB::raw('COUNT(DISTINCT cop_fv.model_id) AS model_count')
            //     )
            //     ->where('cop_models.model_type', 0)
            //     ->where('cop_spec_ms.spec_name', '=', 'Exterior');
            //   ->where('cop_fv.feature_value', '!=', '-');

            $f_exterior = Model::select('cop_features_ms.features_name', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                ->where('cop_fv.feature_value', '=', '1');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $f_exterior->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $f_exterior->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $f_exterior->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($f_exterior) use ($fuelType) {
                    $f_exterior->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($f_exterior) use ($transmissionType) {
                    $f_exterior->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }

            if (!empty($driveTrain)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            // if (!empty($exteriorFeatures)) {
            //     $f_exterior->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
            //         $query->select('cop_fv.model_id')
            //             ->from('cop_fv')
            //             ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //             ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //             ->where('cop_spec_ms.spec_name', '=', 'Exterior')
            //             ->where('cop_fv.feature_value', '=', '1')
            //             ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
            //     });
            // }

            $fExterior = $f_exterior->groupBy('cop_features_ms.features_name')
                ->havingRaw('model_count > 0')
                ->get()
                // dd($f_exterior->toSql())
                ->map(function ($data) {
                    //   $feature_value = $data->feature_value;
                    return [
                        // 'features_id' => $data->features_id,
                        'features_name' => $data->features_name,
                        'model_count' => $data->model_count,
                    ];
                });

            $responseData = [
                'cardData' => $responseCardData,
                'filterData' => array(
                    'by_budget' => $show_prices,
                    'by_brand' => $byBrand,
                    'by_body_type' => $byBodyType,
                    'fuel_type' => $byfuelType,
                    'engine_capacity' => $engine_capacity,
                    'transmission_type' => $bytransmissionType,
                    'drivetrain_type' => $bydrivetrainType,
                    'safety_features' => $bysafetyFeatures,
                    'f_interior' => $fInterior,
                    'f_exterior' => $fExterior
                )
            ];


            return ResponseHelper::responseMessage('success', $responseData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRETNLY -> matchVariants) show matching variants in advanced search
    public function matchVariants(Request $request)
    {
        $modelNAme =  $request->model_name;
        $featureName = config('constant.TYPE_OF_FUEL');
        try {
            $matchVariant = Model::Join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                ->select(
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_fv.feature_value',
                    'cop_variants.variant_id',
                    'cop_variants.variant_name',
                    'cop_models.status',
                    'cop_brands_ms.status',
                    'cop_pe_ms.ex_showroom_price',
                    'cop_fv.status',
                )->where('cop_features_ms.features_name', $featureName)
                ->where('cop_models.model_name', $modelNAme)
                ->where('cop_models.status', '=', 1)
                ->where('cop_brands_ms.status', '=', 1)
                ->where('cop_fv.status', '=', 1)
                ->where('cop_features_ms.status', '=', 1)
                ->where('cop_variants.status', '=', 1)
                ->distinct()
                ->get();

            // dd($matchVariant);

            $formatData = $matchVariant->map(function ($item) {
                $data = [
                    'model_id' => encryptor('e',$item->model_id),
                    'model_name' => $item->model_name,
                    'variant_id' => $item->variant_id,
                    'variant_name' => $item->variant_name,
                    'feature_value' => $item->feature_value,
                    'ex_showroom_price' =>  convertToLakhCrore($item->ex_showroom_price),

                ];
                return  $data;
            });
            return ResponseHelper::responseMessage('success', $formatData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function by_budget_list(Request $request)
    {
        try {
            $budgetListWordsArr = config('constant.BUDGET_LIST_WORDS_ARR');

            $by_budget_list = [];
            foreach($budgetListWordsArr as $key => $item) {
                $by_budget_list[] = [
                    "price_range" => $key,
                    "price_in_words" => $item,
                ];
            }

            return ResponseHelper::responseMessage('success', $by_budget_list);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
