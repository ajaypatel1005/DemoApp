<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Specification;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class SpecificationApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> specification)
    public function specification()
    {
        try {

            $specs = Specification::select(
                'cop_spec_ms.spec_name','cop_spec_ms.spec_image','cop_spec_ms.spec_id','cop_sc_ms.sc_name'
            )
                ->leftJoin('cop_sc_ms', 'cop_spec_ms.sc_id', '=', 'cop_sc_ms.sc_id')
                ->where('cop_spec_ms.status', '!=', 0) // Filter out banners with status 0
                ->get();

            $specsData = $specs->map(function ($item) {
                $imagePath = public_path("Specification/{$item->spec_id}/{$item->spec_image}");
                $specImage = File::exists($imagePath) ? $this->imagePath . "Specification/{$item->spec_id}/{$item->spec_image}.webp" : null;
                return [
                    'spec_id' => $item->spec_id,
                    'sc_name' => $item->sc_name,
                    'spec_name' => $item->spec_name,
                    'spec_image' => $specImage,
                ];
            });
            return ResponseHelper::responseMessage('success', $specsData);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse('error');
            return ResponseHelper::errorResponse('error');
        }
    }
}
