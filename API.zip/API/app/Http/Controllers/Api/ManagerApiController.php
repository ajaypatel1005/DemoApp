<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Manager;
use App\Models\ManagerLanguage;
use Illuminate\Support\Facades\File;

class ManagerApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {

            $langs = ManagerLanguage::all();
            $managers = Manager::select(
                'cop_manager_ms.*',
                // 'cop_ml_ms.*',
                'cop_brands_ms.brand_name as brand_name',
            )
                ->leftJoin('cop_brands_ms', 'cop_manager_ms.brand_id', '=', 'cop_brands_ms.brand_id')

                ->where('cop_manager_ms.status', '!=', 0)
                ->get();

            $managerData = $managers->map(function ($item) use ($langs) {
                $imagePath = public_path("Manager/{$item->manager_id}/{$item->manager_id}.webp");
                $managerImage = File::exists($this->imagePath) ? $this->imagePath . "Manager/{$item->manager_id}/{$item->manager_id}.webp" : null;

                $langIds = explode(',', $item->lang_id);
                $langNames = [];

                foreach ($langIds as $langId) {
                    foreach ($langs as $lang) {
                        if ($lang->lang_id == $langId) {
                            $langNames[] = $lang->lang_name;
                            break;
                        }
                    }
                }

                return [
                    'manager_id' => $item->manager_id,
                    'brand_name' => $item->brand_name,
                    'lang_id' => $item->lang_id,
                    'lang_names' => implode(',', $langNames),
                    'first_name' => $item->first_name,
                    'last_name' => $item->last_name,
                    'm_image' => $managerImage,
                    'm_email' => $item->m_email,
                    'm_contact_no' => $item->m_contact_no,
                    'm_shift' => $item->m_shift,
                ];
            });

            return ResponseHelper::responseMessage('success', $managerData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('error');
        }
    }

}
