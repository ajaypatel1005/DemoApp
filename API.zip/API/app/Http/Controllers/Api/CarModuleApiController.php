<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Brand;
use App\Models\CarGraphic;
use App\Models\Color;
use App\Models\Feature;
use App\Models\Model;
use App\Models\City;
use App\Models\PriceEntry;
use App\Models\Specification;
use App\Models\SpecificationCategory;
use App\Models\Variant;
use Illuminate\Support\Facades\DB;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
class CarModuleApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    public function carModule(Request $request, $id)
    {
        try {
            // dd($id);
            $modelname = $id;
            $key_main = 0;
            if (!$request->has('city_id') && trim($request->input('city_id')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $city_id = encryptor('d', $request->input('city_id'));
            $auth_id = Auth::guard('api')->id();
            $carModule = Model::join('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->join('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
                ->select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_brands_ms.brand_logo',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_type',
                    'cop_models.model_image',
                    'cop_models.min_price',
                    'cop_models.max_price',
                    'cop_models.model_description',
                    'cop_msd.model_engine',
                    'cop_msd.model_bhp',
                    'cop_msd.model_transmission',
                    'cop_msd.model_mileage',
                    'cop_msd.model_fuel',
                    'cop_ratings.rating_id',
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                    'cop_variants.*',
                    'cop_pe_ms.ex_showroom_price',
                    'cop_city_ms.city_id',
                    'cop_city_ms.city_name',
                    DB::raw("(select wl_id from cop_wl where cop_wl.model_id=cop_models.model_id and customer_id = '" . $auth_id . "') as wl_id")
                )
                ->where('cop_models.status', '=', 1)
                ->where('cop_variants.status', '=', 1)
                ->where('cop_models.model_name', '=', $modelname)
                ->where('cop_city_ms.city_id', $city_id)
                ->orderBy('cop_pe_ms.ex_showroom_price','asc')
                ->distinct('cop_models.model_id')
                ->get();


            if ($carModule->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }


            foreach ($carModule as $item) {
                $modelname = $item->model_name;
                $variantId = $item->variant_id;
                $carGraphicTypeId = $item->gt_id;



                if (!isset($formattedData[$modelname])) {




                    $formattedData[$modelname] = [
                        'brand_id' => encryptor('e', $item->brand_id),
                        'model_id' => encryptor('e', $item->model_id),
                        'brand_name' => $item->brand_name,
                        'model_name' => $item->model_name,
                        'brand_logo' => $this->imagePath . "brands/{$item->brand_id}/{$item->brand_logo}",
                        'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_image}",
                        'min_price' =>  convertToLakhCrore($item->min_price),
                        'max_price' =>  convertToLakhCrore($item->max_price),
                        'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                        'model_engine' => $item->model_engine,
                        'model_bhp' => $item->model_bhp,
                        'model_description' => $item->model_description,
                        'model_transmission' => $item->model_transmission,
                        'model_mileage' => $item->model_mileage,
                        'model_fuel' => $item->model_fuel,
                        'rating_id' => $item->rating_id,
                        'rating_value' => $item->rating_value,
                        'rating_type_name' => $item->rating_type_name,
                        'variants' => [],
                        'car_graphic_type' => [],
                        'compare' => [],
                        'wishlist' => (!empty($item->wl_id) ? true : false),


                    ];
                }


                //variants

                if ($item->model_type == 0) {
                    $input_field = ['Displacement', 'Type of Transmission', 'Type of Fuel', 'Mileage', 'Power'];
                } else {
                    $input_field = ['Battery Capacity', 'Type of Transmission', 'Range', 'Power (EV)', 'Charging Time (AC)'];
                }


                $feature_value = Variant::join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                    ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                    ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                    ->select(
                        'cop_fv.feature_value',
                        'cop_features_ms.features_name',
                        'cop_su_ms.su_name'
                    )
                    ->where('cop_variants.variant_id', $item->variant_id)
                    ->whereIn('cop_features_ms.features_name', $input_field)
                    ->distinct()
                    // ->toSql();
                    // dd($feature_value);
                    ->get();


                foreach ($feature_value as $features) {
                    if ($features->features_name === 'Type of Transmission') {
                        $model_transmissions = $features->feature_value;
                    }
                    if ($features->features_name === 'Type of Fuel') {
                        $model_fuel = $features->feature_value;
                    }
                    if ($features->features_name === 'Displacement') {
                        $model_engine = $features->feature_value . ' ' . $features->su_name;
                    }
                    if ($features->features_name === 'Mileage') {
                        $model_mileage = $features->feature_value . ' ' . $features->su_name;
                    }
                    if ($features->features_name === 'Power') {
                        $checkBhpModel = check_bhp_exist($features->feature_value);
                        if($checkBhpModel){
                            $features_feature_value = extract_bhp($features->feature_value);
                            $model_power = $features_feature_value . ' ' . $features->su_name;
                        } else {
                            $model_power = $features->feature_value . ' ' . $features->su_name;
                        }
                    }
                    //ev car
                    if ($features->features_name === 'Battery Capacity') {
                        $variant_battery = $features->feature_value . ' ' . $features->su_name;
                    }

                    if ($features->features_name === 'Range') {
                        $variant_range = $features->feature_value . ' ' . $features->su_name;
                    }

                    if ($features->features_name === 'Power (EV)') {
                        $checkBhpModel = check_bhp_exist($features->feature_value);
                        if($checkBhpModel){
                            $features_feature_value = extract_bhp($features->feature_value);
                            $variant_power_ev = $features_feature_value . ' ' . $features->su_name;
                        } else {
                            $variant_power_ev = $features->feature_value . ' ' . $features->su_name;
                        }
                    }

                    if ($features->features_name === 'Charging Time (AC)') {
                        $variant_charging = $features->feature_value . ' ' . $features->su_name;
                    }
                }

                if (!isset($formattedData[$modelname]['variants'][$key_main])) {
                    $featutres_key = 0;
                    $formattedData[$modelname]['variants'][$key_main] = [
                        'variant_id' => encryptor('e', $item->variant_id),
                        'variant_name' => $item->variant_name,
                        'variant_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_id}.webp" ?? NULL,
                        'ex_showroom_price' => $item->ex_showroom_price,
                        'location' => $item->city_name,
                        'seating_capacity' => $item->seating_capacity,
                        'type_of_transmission' => $model_transmissions ?? null,
                        'type_of_fuel' => $model_fuel ?? null,
                        'displacement' => $model_engine ?? null,
                        'mileage' => $model_mileage ?? null,
                        'power' => $model_power ?? null,
                        'battery' => $variant_battery ?? null,
                        'range' => $variant_range ?? null,
                        'power_ev' => $variant_power_ev ?? null,
                        'charging_time' => $variant_charging ?? null,
                        'colors' => [],
                        'specification_cat' => [],
                        'price_entry' => [],
                        'key_highlight' => [],
                    ];
                }



                $model_transmissions = null;
                $model_fuel = null;
                $model_engine = null;
                $model_mileage = null;





                //end variants


                //compare start

                $Price = $item->min_price;

                $maxPrice = $Price + ($Price * 0.15);
                $minPrice = $Price - ($Price * 0.15);

                $compare = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                    ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                    // ->leftJoin('cop_colors', 'cop_colors.model_id', '=', 'cop_models.model_id')


                    ->select(
                        'cop_cs_ms.cs_id',
                        'cop_cs_ms.cs_name',
                        'cop_brands_ms.brand_id',
                        'cop_brands_ms.brand_name',
                        'cop_brands_ms.brand_logo',
                        'cop_models.model_id',
                        'cop_models.model_name',
                        'cop_models.model_type',
                        'cop_models.min_price',
                        'cop_models.max_price',
                        DB::raw('(SELECT `variant_id` FROM `cop_variants` WHERE `cop_variants`.`model_id` = `cop_models`.`model_id` AND `cop_variants`.`status` = 1 LIMIT 1) AS variant_id')
                    )
                    ->where('cop_models.status', '=', 1)
                    ->where('cop_models.min_price', '>', $minPrice)
                    ->where('cop_models.min_price', '<', $maxPrice)
                    ->where('cop_models.model_type', $item->model_type)
                    ->where('cop_cs_ms.cs_name', "Launched")

                    ->distinct()
                    ->orderByRaw('CASE WHEN `cop_models`.`model_id` = ' . $item->model_id . '  THEN 0 ELSE 1 END')

                    ->orderBy('cop_models.min_price', 'asc')
                    ->groupBy('cop_models.model_id', 'cop_models.model_id', 'cop_cs_ms.cs_id', 'cop_cs_ms.cs_name')
                    ->groupBy(
                        'cop_models.model_id',
                        'cop_models.model_name',
                        'cop_models.model_type',
                        'cop_models.model_image',
                        'cop_models.min_price',
                        'cop_models.max_price',
                        'cop_cs_ms.cs_id',
                        'cop_cs_ms.cs_name',
                        'cop_brands_ms.brand_id',
                        'cop_brands_ms.brand_name',
                        'cop_brands_ms.brand_logo'
                    )
                    // dd($compare);
                    ->get();

                // dd($compare);
                $formattedData[$modelname]['compare'] = [];

                $key_features = 0;
                foreach ($compare as $modelItem) {

                    $formattedData[$modelname]['compare'][] = [

                        'cs_name' => encryptor('e', $modelItem->cs_name),
                        'brand_name' => $modelItem->brand_name,
                        'model_id' => $modelItem->model_id,
                        'model_name' => $modelItem->model_name,
                        'model_type' => $modelItem->model_type == 0 ? 'Non EV' : 'EV',
                        'variant_id' => $modelItem->variant_id,
                        'model_image' => $this->imagePath . "brands/{$modelItem->brand_id}/{$modelItem->model_id}/{$modelItem->model_image}",
                        'ex_showroom' => $modelItem->min_price,
                        'features' => [],
                    ];

                    if ($modelItem->model_type == 0) {
                        $input_field = ['Displacement', 'Type of Transmission', 'Type of Fuel', 'Mileage', 'Power'];
                    } else {
                        $input_field = ['Battery Capacity', 'Type of Transmission', 'Range', 'Power (EV)', 'Charging Time (AC)'];
                    }


                    $feature = Variant::join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                        ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                        ->select(
                            'cop_fv.feature_value',
                            'cop_features_ms.features_name',
                            'cop_su_ms.su_name',
                            'cop_variants.variant_id',
                        )->where('cop_variants.variant_id', $modelItem->variant_id)
                        ->whereIn('cop_features_ms.features_name', $input_field)
                        ->distinct()

                        //   ->toSql();
                        //   dd($feature);
                        ->get();

                    $formattedData[$modelname]['compare'][$key_features]['features'] = [];

                    foreach ($feature as $feature_compare) {

                        if ($feature_compare->features_name === 'Type of Transmission') {
                            $variant_transmissions = $feature_compare->feature_value;
                        }
                        if ($feature_compare->features_name === 'Type of Fuel') {
                            $variant_fuel = $feature_compare->feature_value;
                        }
                        if ($feature_compare->features_name === 'Displacement') {
                            $variant_engine = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }
                        if ($feature_compare->features_name === 'Mileage') {
                            $variant_mileage = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }
                        if ($feature_compare->features_name === 'Power') {
                            $checkBhpVariant = check_bhp_exist($feature_compare->feature_value);
                            if($checkBhpVariant){
                                $feature_compare_feature_value = extract_bhp($feature_compare->feature_value);
                                $variant_power = $feature_compare_feature_value . ' ' . $feature_compare->su_name;
                            } else {
                                $variant_power = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                            }
                        }
                        //ev car
                        if ($feature_compare->features_name === 'Battery Capacity') {
                            $variant_battery = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }

                        if ($feature_compare->features_name === 'Range') {
                            $variant_range = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }

                        if ($feature_compare->features_name === 'Power (EV)') {
                            $checkBhpVariant = check_bhp_exist($feature_compare->feature_value);
                            if($checkBhpVariant){
                                $feature_compare_feature_value = extract_bhp($feature_compare->feature_value);
                                $variant_power_ev = $feature_compare_feature_value . ' ' . $feature_compare->su_name;
                            } else {
                                $variant_power_ev = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                            }

                            // $variant_power_ev = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }

                        if ($feature_compare->features_name === 'Charging Time (AC)') {
                            $variant_charging = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }
                    }

                    $formattedData[$modelname]['compare'][$key_features]['features'][] = [
                        // 'model_type' => $modelItem->model_type == 0 ? 'Non EV' : 'EV',
                        // 'variant_id' => $modelItem->variant_id,
                        // 'variant_name' => $feature_compare->variant_name,
                        'Transmission' => $variant_transmissions ?? null,
                        'Fuel' => $variant_fuel ?? null,
                        'Engine' => $variant_engine ?? null,
                        'Mileage' => $variant_mileage ?? null,
                        'Power' => $variant_power ?? null,
                        'Battery Capacity' => $variant_battery ?? null,
                        'Driving Range' => $variant_range ?? null,
                        'Power(Ev)' => $variant_power_ev ?? null,
                        'Charging Time(AC)' => $variant_charging ?? null,

                    ];

                    $key_features++;
                }




                $model_transmissions = null;
                $model_fuel = null;
                $model_engine = null;
                $model_mileage = null;
                // end compare model







                //key high lights

                if ($modelItem->model_type == 0) {
                    $input_field = ['Displacement', 'Type of Transmission', 'Type of Fuel', 'Mileage', 'Power'];
                } else {
                    $input_field = ['Battery Capacity', 'Type of Transmission', 'Range', 'Power (EV)', 'Charging Time (AC)'];
                }


                $feature = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                    ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                    ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')

                    ->whereIn('cop_features_ms.features_name', $input_field)

                    ->where('cop_fv.variant_id', '=', $item->variant_id)
                    ->get();

                $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Specs'] = [];


                foreach ($feature as $key_spec) {

                    $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Specs'][] = [

                        'features_name' => $key_spec->features_name,
                        'features_image' => $this->imagePath . "Feature/{$key_spec->feature_id}/{$key_spec->feature_id}.svg" ?? NULL,
                        'features_value' => $key_spec->feature_value,
                        'su_name' => $key_spec->su_name,


                    ];
                }

                $inputType = ['Parking Sensors', 'No Of Airbags', 'Anti Lock Braking System', 'Hill Assist', 'Child Safety Locks'];

                $feature = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                    ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                    ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')


                    ->whereIn('cop_features_ms.features_name', $inputType)
                    ->where('cop_fv.variant_id', '=', $item->variant_id)
                    ->get();


                $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Safety'] = [];


                foreach ($feature as $key_sefety) {

                    $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Safety'][] = [

                        'features_name' => $key_sefety->features_name,
                        'features_image' => $this->imagePath . "Feature/{$key_sefety->feature_id}/{$key_sefety->feature_id}.svg" ?? NULL,
                        'features_value' => $key_sefety->feature_value,
                        'su_name' => $key_sefety->su_name,


                    ];
                }



                // end key high lights


                //price entry

                $price_entry = PriceEntry::select(
                    'cop_pe_ms.*',
                    'cop_brands_ms.brand_name as brand_name',
                    'cop_models.model_name as model_name',
                    'cop_variants.variant_name as variant_name',
                    'cop_city_ms.city_name as city_name',
                    'cop_state_ms.state_name as state_name',
                    'cop_country_ms.country_name as country_name',
                    'cop_taxes_ms.tax_name as tax_name',
                    // 'cop_ut.ut_name as ut_name',
                )

                    ->leftJoin('cop_brands_ms', 'cop_pe_ms.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_models', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_variants', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')

                    ->leftJoin('cop_city_ms', 'cop_pe_ms.city_id', '=', 'cop_city_ms.city_id')
                    ->leftJoin('cop_state_ms', 'cop_pe_ms.state_id', '=', 'cop_state_ms.state_id')
                    ->leftJoin('cop_country_ms', 'cop_pe_ms.country_id', '=', 'cop_country_ms.country_id')
                    ->leftJoin('cop_taxes_ms', 'cop_pe_ms.tax_id', '=', 'cop_taxes_ms.tax_id')
                    // ->leftJoin('cop_ut', 'cop_pe_ms.ut_id', '=', 'cop_ut.ut_id')
                    ->where('cop_pe_ms.status', 1)
                    ->where('cop_variants.variant_id', $item->variant_id)
                    ->where('cop_city_ms.city_id', $city_id);


                $price_entry = $price_entry->get();

                $formattedData[$modelname]['variants'][$key_main]['price_entry'];

                foreach ($price_entry as $priceItem) {

                    $taxNames = \App\Models\AllTax::whereIn('tax_id', json_decode($priceItem->tax_id, true))
                        ->select('tax_id', 'tax_name')
                        ->get();

                    $taxCosts = json_decode($priceItem->tax_cost, true);

                    $taxInfo = [];
                    foreach ($taxNames as $taxName) {
                        $taxId = $taxName->tax_id;
                        $taxInfo[] = [
                            // 'tax_id' => $taxId,
                            'tax_name' => $taxName->tax_name,
                            'cost' => isset($taxCosts[$taxId]) ? (float)$taxCosts[$taxId] : null,

                        ];
                    }

                    $taxInfo[] = [
                        // 'tax_id' => $taxId,
                        'tax_name' => 'RTO',
                        'cost' => $priceItem->i_rto_price ? $priceItem->i_rto_price : null,
                    ];

                    $formattedData[$modelname]['variants'][$key_main]['price_entry'] = [



                        'price_entry_id' => $priceItem->pe_id,
                        'variant_id' => $priceItem->variant_id,
                        'variant_name' => $priceItem->variant_name,
                        'country_name' => $priceItem->country_name,
                        'state_name' => $priceItem->state_name,
                        'city_name' => $priceItem->city_name,
                        // 'ut_name' => $priceItem->ut_name,
                        'ex_showroom_price' => $priceItem->ex_showroom_price,
                        'tax_name' => $taxInfo,
                        'total_price' => $priceItem->total_price,
                    ];
                }

                //price entry end

                $colorData = Color::select(
                    'cop_colors.color_id',
                    'cop_colors.color_name',
                    'cop_colors.color_code',
                    'cop_colors.dual_color_code',
                    'cop_colors.variant_color_image_mob',
                    'cop_colors.variant_id',
                )
                    ->where('cop_colors.variant_id', '=', $item->variant_id)
                    ->distinct()
                    ->get();

                $formattedData[$modelname]['variants'][$key_main]['colors'] = [];

                foreach ($colorData as $colorItem) {
                    $formattedData[$modelname]['variants'][$key_main]['colors'][] = [
                        'color_id' => encryptor('e', $colorItem->color_id),
                        'variant_id' => encryptor('e', $colorItem->variant_id),
                        'color_name' => $colorItem->color_name,
                        'color_code' => $colorItem->color_code,
                        'dual_color_code' => $colorItem->dual_color_code ?? null,
                        'variant_color_image' => $colorItem->variant_color_image_mob,
                        'variant_color_image_path' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$colorItem->variant_color_image_mob}" ?? null,
                    ];
                }

                $specificationCategory = SpecificationCategory::all();

                $formattedData[$modelname]['variants'][$key_main]['specification_cat'] = [];

                $key_spec_cat = 0;
                foreach ($specificationCategory as $specItem) {
                    $formattedData[$modelname]['variants'][$key_main]['specification_cat'][] = [
                        'sc_id' => $specItem->sc_id,
                        'spec_cat_name' => $specItem->sc_name,
                    ];

                    $spec_cat = Specification::join('cop_sc_ms', 'cop_sc_ms.sc_id', '=', 'cop_spec_ms.sc_id')->where('cop_sc_ms.sc_name', $specItem->sc_name)->get();

                    $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'] = [];

                    $key_spec = 0;
                    foreach ($spec_cat as $spec) {
                        $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'][] = [
                            'spec_id' => $spec->spec_id,
                            'spec_name' => $spec->spec_name,
                            // 'spec_image' => $spec->spec_image,
                            'spec_image' => $this->imagePath . "Specification/{$spec->spec_id}/{$spec->spec_id}.svg" ?? NULL,
                        ];

                        $feature = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                            ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                            ->join('cop_models', 'cop_models.model_id', '=', 'cop_fv.model_id')
                            ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                            ->where('cop_features_ms.spec_id', '=', $spec->spec_id)
                            ->where('cop_fv.variant_id', '=', $item->variant_id)
                            ->where('cop_models.model_type', '=', $item->model_type)
                            ->get();


                        $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'][$key_spec]['features'] = [];

                        foreach ($feature as $featureItem) {

                            // $power = config('constant.POWER');
                            // $power_ev = config('constant.POWER_EV');
                            // if($featureItem->features_name == $power || $featureItem->features_name == $power_ev){
                                $checkBhp = check_bhp_exist($featureItem->feature_value);

                                if(!$checkBhp){
                                    $su_name = $featureItem->su_name;
                                } else {
                                    $su_name = null;
                                }
                            // }

                            $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'][$key_spec]['features'][] = [
                                'features_name' => $featureItem->features_name,
                                'feature_value' => $featureItem->feature_value,
                                'su_name' => $su_name,

                            ];
                        }
                        $key_spec++;
                    }
                    $key_spec_cat++;
                }





                $graphicData = CarGraphic::select(
                    'cop_graphics.model_id',
                    'cop_graphics.graphic_file_mob',
                    'cop_gt_ms.gt_name',
                    'cop_gt_ms.gt_id',
                )
                    ->leftJoin('cop_gt_ms', 'cop_gt_ms.gt_id', '=', 'cop_graphics.gt_id')
                    ->where('cop_graphics.model_id', '=', $item->model_id)
                    ->distinct()
                    ->get();

                $formattedData[$modelname]['car_graphic_type'] = [];
                $key_graphic = 0;
                foreach ($graphicData as $graphicItem) {
                    $abc = [
                        'model_id' => encryptor('e', $graphicItem->model_id),
                        'car_graphic_type_id' => encryptor('e', $graphicItem->gt_id),
                        'car_graphic_type_name' => $graphicItem->gt_name,
                        'car_graphics' => []
                    ];

                    $folderName = str_replace(' ','_',strtolower(trim($graphicItem->gt_name)));

                    if($graphicItem->graphic_file_mob){
                        $single_image = explode(',', $graphicItem->graphic_file_mob);
                        $arr = [];
                        for ($i = 0; $i < count($single_image); $i++) {
                            $arr[] = $this->imagePath . "car_graphics/{$graphicItem->model_id}/{$folderName}/mobile/{$single_image[$i]}";
                        }
                        $abc['car_graphics'] = $arr;
                    }

                    $formattedData[$modelname]['car_graphic_type'][$key_graphic] = $abc;

                    $key_graphic++;
                }


                $key_main++;
            }

            // if ($carModule->isEmpty()) {
            //     return ResponseHelper::errorResponse('data_not_found');
            // }

            $formattedData = array_values($formattedData);



            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }


    public function carModule_data(Request $request,$brand_slug, $model_slug, $variant_slug = null)
    {
        try {

            // $modelname = $id;
            $key_main = 0;
            if (!$request->has('city_id') && trim($request->input('city_id')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $city_id = encryptor('d', $request->input('city_id'));
            $auth_id = Auth::guard('api')->id();
            $carModule = Model::join('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->join('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
                ->select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_brands_ms.brand_logo',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_type',
                    'cop_models.model_image',
                    'cop_models.min_price',
                    'cop_models.max_price',
                    'cop_models.model_description',
                    'cop_msd.model_engine',
                    'cop_msd.model_bhp',
                    'cop_msd.model_transmission',
                    'cop_msd.model_mileage',
                    'cop_msd.model_fuel',
                    'cop_ratings.rating_id',
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                    'cop_variants.*',
                    'cop_pe_ms.ex_showroom_price',
                    'cop_city_ms.city_id',
                    'cop_city_ms.city_name',
                    DB::raw("(select wl_id from cop_wl where cop_wl.model_id=cop_models.model_id and customer_id = '" . $auth_id . "') as wl_id")
                )
                ->where('cop_models.status', '=', 1)
                ->where('cop_variants.status', '=', 1)
                // ->where('cop_models.model_name', '=', $modelname)
                ->where('cop_brands_ms.slug', $brand_slug)
                ->where('cop_models.slug', $model_slug)
                ->where('cop_city_ms.city_id', $city_id);
                if($variant_slug != ""){
                    $carModule->where('cop_variants.slug', $variant_slug);
                } 
                $carModule = $carModule->orderBy('cop_pe_ms.ex_showroom_price','asc')
                ->distinct('cop_models.model_id')
                ->get();


            if ($carModule->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }


            foreach ($carModule as $item) {
                $modelname = $item->model_name;
                $variantId = $item->variant_id;
                $carGraphicTypeId = $item->gt_id;



                if (!isset($formattedData[$modelname])) {

                    $formattedData[$modelname] = [
                        'brand_id' => encryptor('e', $item->brand_id),
                        'model_id' => encryptor('e', $item->model_id),
                        'brand_name' => $item->brand_name,
                        'model_name' => $item->model_name,
                        'brand_logo' => $this->imagePath . "brands/{$item->brand_id}/{$item->brand_logo}",
                        'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_image}",
                        'min_price' =>  convertToLakhCrore($item->min_price),
                        'max_price' =>  convertToLakhCrore($item->max_price),
                        'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                        'model_engine' => $item->model_engine,
                        'model_bhp' => $item->model_bhp,
                        'model_description' => $item->model_description,
                        'model_transmission' => $item->model_transmission,
                        'model_mileage' => $item->model_mileage,
                        'model_fuel' => $item->model_fuel,
                        'rating_id' => $item->rating_id,
                        'rating_value' => $item->rating_value,
                        'rating_type_name' => $item->rating_type_name,
                        'variants' => [],
                        'car_graphic_type' => [],
                        'compare' => [],
                        'wishlist' => (!empty($item->wl_id) ? true : false),


                    ];
                }


                //variants

                if ($item->model_type == 0) {
                    $input_field = ['Displacement', 'Type of Transmission', 'Type of Fuel', 'Mileage', 'Power'];
                } else {
                    $input_field = ['Battery Capacity', 'Type of Transmission', 'Range', 'Power (EV)', 'Charging Time (AC)'];
                }


                $feature_value = Variant::join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                    ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                    ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                    ->select(
                        'cop_fv.feature_value',
                        'cop_features_ms.features_name',
                        'cop_su_ms.su_name'
                    )
                    ->where('cop_variants.variant_id', $item->variant_id)
                    ->whereIn('cop_features_ms.features_name', $input_field)
                    ->distinct()
                    // ->toSql();
                    // dd($feature_value);
                    ->get();


                foreach ($feature_value as $features) {
                    if ($features->features_name === 'Type of Transmission') {
                        $model_transmissions = $features->feature_value;
                    }
                    if ($features->features_name === 'Type of Fuel') {
                        $model_fuel = $features->feature_value;
                    }
                    if ($features->features_name === 'Displacement') {
                        $model_engine = $features->feature_value . ' ' . $features->su_name;
                    }
                    if ($features->features_name === 'Mileage') {
                        $model_mileage = $features->feature_value . ' ' . $features->su_name;
                    }
                    if ($features->features_name === 'Power') {
                        $checkBhpModel = check_bhp_exist($features->feature_value);
                        if($checkBhpModel){
                            $features_feature_value = extract_bhp($features->feature_value);
                            $model_power = $features_feature_value . ' ' . $features->su_name;
                        } else {
                            $model_power = $features->feature_value . ' ' . $features->su_name;
                        }
                    }
                    //ev car
                    if ($features->features_name === 'Battery Capacity') {
                        $variant_battery = $features->feature_value . ' ' . $features->su_name;
                    }

                    if ($features->features_name === 'Range') {
                        $variant_range = $features->feature_value . ' ' . $features->su_name;
                    }

                    if ($features->features_name === 'Power (EV)') {
                        $checkBhpModel = check_bhp_exist($features->feature_value);
                        if($checkBhpModel){
                            $features_feature_value = extract_bhp($features->feature_value);
                            $variant_power_ev = $features_feature_value . ' ' . $features->su_name;
                        } else {
                            $variant_power_ev = $features->feature_value . ' ' . $features->su_name;
                        }
                    }

                    if ($features->features_name === 'Charging Time (AC)') {
                        $variant_charging = $features->feature_value . ' ' . $features->su_name;
                    }
                }

                if (!isset($formattedData[$modelname]['variants'][$key_main])) {
                    $featutres_key = 0;
                    $formattedData[$modelname]['variants'][$key_main] = [
                        'variant_id' => encryptor('e', $item->variant_id),
                        'variant_name' => $item->variant_name,
                        'variant_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_id}.webp" ?? NULL,
                        'ex_showroom_price' => $item->ex_showroom_price,
                        'location' => $item->city_name,
                        'seating_capacity' => $item->seating_capacity,
                        'type_of_transmission' => $model_transmissions ?? null,
                        'type_of_fuel' => $model_fuel ?? null,
                        'displacement' => $model_engine ?? null,
                        'mileage' => $model_mileage ?? null,
                        'power' => $model_power ?? null,
                        'battery' => $variant_battery ?? null,
                        'range' => $variant_range ?? null,
                        'power_ev' => $variant_power_ev ?? null,
                        'charging_time' => $variant_charging ?? null,
                        'colors' => [],
                        'specification_cat' => [],
                        'price_entry' => [],
                        'key_highlight' => [],
                    ];
                }



                $model_transmissions = null;
                $model_fuel = null;
                $model_engine = null;
                $model_mileage = null;





                //end variants


                //compare start

                $Price = $item->min_price;

                $maxPrice = $Price + ($Price * 0.15);
                $minPrice = $Price - ($Price * 0.15);

                $compare = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                    ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                    // ->leftJoin('cop_colors', 'cop_colors.model_id', '=', 'cop_models.model_id')


                    ->select(
                        'cop_cs_ms.cs_id',
                        'cop_cs_ms.cs_name',
                        'cop_brands_ms.brand_id',
                        'cop_brands_ms.brand_name',
                        'cop_brands_ms.brand_logo',
                        'cop_models.model_id',
                        'cop_models.model_name',
                        'cop_models.model_type',
                        'cop_models.min_price',
                        'cop_models.max_price',
                        DB::raw('(SELECT `variant_id` FROM `cop_variants` WHERE `cop_variants`.`model_id` = `cop_models`.`model_id` AND `cop_variants`.`status` = 1 LIMIT 1) AS variant_id')
                    )
                    ->where('cop_models.status', '=', 1)
                    ->where('cop_models.min_price', '>', $minPrice)
                    ->where('cop_models.min_price', '<', $maxPrice)
                    ->where('cop_models.model_type', $item->model_type)
                    ->where('cop_cs_ms.cs_name', "Launched")

                    ->distinct()
                    ->orderByRaw('CASE WHEN `cop_models`.`model_id` = ' . $item->model_id . '  THEN 0 ELSE 1 END')

                    ->orderBy('cop_models.min_price', 'asc')
                    ->groupBy('cop_models.model_id', 'cop_models.model_id', 'cop_cs_ms.cs_id', 'cop_cs_ms.cs_name')
                    ->groupBy(
                        'cop_models.model_id',
                        'cop_models.model_name',
                        'cop_models.model_type',
                        'cop_models.model_image',
                        'cop_models.min_price',
                        'cop_models.max_price',
                        'cop_cs_ms.cs_id',
                        'cop_cs_ms.cs_name',
                        'cop_brands_ms.brand_id',
                        'cop_brands_ms.brand_name',
                        'cop_brands_ms.brand_logo'
                    )
                    // dd($compare);
                    ->get();

                // dd($compare);
                $formattedData[$modelname]['compare'] = [];

                $key_features = 0;
                foreach ($compare as $modelItem) {

                    $formattedData[$modelname]['compare'][] = [

                        'cs_name' => encryptor('e', $modelItem->cs_name),
                        'brand_name' => $modelItem->brand_name,
                        'model_id' => $modelItem->model_id,
                        'model_name' => $modelItem->model_name,
                        'model_type' => $modelItem->model_type == 0 ? 'Non EV' : 'EV',
                        'variant_id' => $modelItem->variant_id,
                        'model_image' => $this->imagePath . "brands/{$modelItem->brand_id}/{$modelItem->model_id}/{$modelItem->model_image}",
                        'ex_showroom' => $modelItem->min_price,
                        'features' => [],
                    ];

                    if ($modelItem->model_type == 0) {
                        $input_field = ['Displacement', 'Type of Transmission', 'Type of Fuel', 'Mileage', 'Power'];
                    } else {
                        $input_field = ['Battery Capacity', 'Type of Transmission', 'Range', 'Power (EV)', 'Charging Time (AC)'];
                    }


                    $feature = Variant::join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                        ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                        ->select(
                            'cop_fv.feature_value',
                            'cop_features_ms.features_name',
                            'cop_su_ms.su_name',
                            'cop_variants.variant_id',
                        )->where('cop_variants.variant_id', $modelItem->variant_id)
                        ->whereIn('cop_features_ms.features_name', $input_field)
                        ->distinct()

                        //   ->toSql();
                        //   dd($feature);
                        ->get();

                    $formattedData[$modelname]['compare'][$key_features]['features'] = [];

                    foreach ($feature as $feature_compare) {

                        if ($feature_compare->features_name === 'Type of Transmission') {
                            $variant_transmissions = $feature_compare->feature_value;
                        }
                        if ($feature_compare->features_name === 'Type of Fuel') {
                            $variant_fuel = $feature_compare->feature_value;
                        }
                        if ($feature_compare->features_name === 'Displacement') {
                            $variant_engine = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }
                        if ($feature_compare->features_name === 'Mileage') {
                            $variant_mileage = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }
                        if ($feature_compare->features_name === 'Power') {
                            $checkBhpVariant = check_bhp_exist($feature_compare->feature_value);
                            if($checkBhpVariant){
                                $feature_compare_feature_value = extract_bhp($feature_compare->feature_value);
                                $variant_power = $feature_compare_feature_value . ' ' . $feature_compare->su_name;
                            } else {
                                $variant_power = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                            }
                        }
                        //ev car
                        if ($feature_compare->features_name === 'Battery Capacity') {
                            $variant_battery = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }

                        if ($feature_compare->features_name === 'Range') {
                            $variant_range = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }

                        if ($feature_compare->features_name === 'Power (EV)') {
                            $checkBhpVariant = check_bhp_exist($feature_compare->feature_value);
                            if($checkBhpVariant){
                                $feature_compare_feature_value = extract_bhp($feature_compare->feature_value);
                                $variant_power_ev = $feature_compare_feature_value . ' ' . $feature_compare->su_name;
                            } else {
                                $variant_power_ev = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                            }

                            // $variant_power_ev = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }

                        if ($feature_compare->features_name === 'Charging Time (AC)') {
                            $variant_charging = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                        }
                    }

                    $formattedData[$modelname]['compare'][$key_features]['features'][] = [
                        // 'model_type' => $modelItem->model_type == 0 ? 'Non EV' : 'EV',
                        // 'variant_id' => $modelItem->variant_id,
                        // 'variant_name' => $feature_compare->variant_name,
                        'Transmission' => $variant_transmissions ?? null,
                        'Fuel' => $variant_fuel ?? null,
                        'Engine' => $variant_engine ?? null,
                        'Mileage' => $variant_mileage ?? null,
                        'Power' => $variant_power ?? null,
                        'Battery Capacity' => $variant_battery ?? null,
                        'Driving Range' => $variant_range ?? null,
                        'Power(Ev)' => $variant_power_ev ?? null,
                        'Charging Time(AC)' => $variant_charging ?? null,

                    ];

                    $key_features++;
                }




                $model_transmissions = null;
                $model_fuel = null;
                $model_engine = null;
                $model_mileage = null;
                // end compare model







                //key high lights

                if ($modelItem->model_type == 0) {
                    $input_field = ['Displacement', 'Type of Transmission', 'Type of Fuel', 'Mileage', 'Power'];
                } else {
                    $input_field = ['Battery Capacity', 'Type of Transmission', 'Range', 'Power (EV)', 'Charging Time (AC)'];
                }


                $feature = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                    ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                    ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')

                    ->whereIn('cop_features_ms.features_name', $input_field)

                    ->where('cop_fv.variant_id', '=', $item->variant_id)
                    ->get();

                $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Specs'] = [];


                foreach ($feature as $key_spec) {

                    $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Specs'][] = [

                        'features_name' => $key_spec->features_name,
                        'features_image' => $this->imagePath . "Feature/{$key_spec->feature_id}/{$key_spec->feature_id}.svg" ?? NULL,
                        'features_value' => $key_spec->feature_value,
                        'su_name' => $key_spec->su_name,


                    ];
                }

                $inputType = ['Parking Sensors', 'No Of Airbags', 'Anti Lock Braking System', 'Hill Assist', 'Child Safety Locks'];

                $feature = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                    ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                    ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')


                    ->whereIn('cop_features_ms.features_name', $inputType)
                    ->where('cop_fv.variant_id', '=', $item->variant_id)
                    ->get();


                $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Safety'] = [];


                foreach ($feature as $key_sefety) {

                    $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Safety'][] = [

                        'features_name' => $key_sefety->features_name,
                        'features_image' => $this->imagePath . "Feature/{$key_sefety->feature_id}/{$key_sefety->feature_id}.svg" ?? NULL,
                        'features_value' => $key_sefety->feature_value,
                        'su_name' => $key_sefety->su_name,


                    ];
                }



                // end key high lights


                //price entry

                $price_entry = PriceEntry::select(
                    'cop_pe_ms.*',
                    'cop_brands_ms.brand_name as brand_name',
                    'cop_models.model_name as model_name',
                    'cop_variants.variant_name as variant_name',
                    'cop_city_ms.city_name as city_name',
                    'cop_state_ms.state_name as state_name',
                    'cop_country_ms.country_name as country_name',
                    'cop_taxes_ms.tax_name as tax_name',
                    // 'cop_ut.ut_name as ut_name',
                )

                    ->leftJoin('cop_brands_ms', 'cop_pe_ms.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_models', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_variants', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')

                    ->leftJoin('cop_city_ms', 'cop_pe_ms.city_id', '=', 'cop_city_ms.city_id')
                    ->leftJoin('cop_state_ms', 'cop_pe_ms.state_id', '=', 'cop_state_ms.state_id')
                    ->leftJoin('cop_country_ms', 'cop_pe_ms.country_id', '=', 'cop_country_ms.country_id')
                    ->leftJoin('cop_taxes_ms', 'cop_pe_ms.tax_id', '=', 'cop_taxes_ms.tax_id')
                    // ->leftJoin('cop_ut', 'cop_pe_ms.ut_id', '=', 'cop_ut.ut_id')
                    ->where('cop_pe_ms.status', 1)
                    ->where('cop_variants.variant_id', $item->variant_id)
                    ->where('cop_city_ms.city_id', $city_id);


                $price_entry = $price_entry->get();

                $formattedData[$modelname]['variants'][$key_main]['price_entry'];

                foreach ($price_entry as $priceItem) {

                    $taxNames = \App\Models\AllTax::whereIn('tax_id', json_decode($priceItem->tax_id, true))
                        ->select('tax_id', 'tax_name')
                        ->get();

                    $taxCosts = json_decode($priceItem->tax_cost, true);

                    $taxInfo = [];
                    foreach ($taxNames as $taxName) {
                        $taxId = $taxName->tax_id;
                        $taxInfo[] = [
                            // 'tax_id' => $taxId,
                            'tax_name' => $taxName->tax_name,
                            'cost' => isset($taxCosts[$taxId]) ? (float)$taxCosts[$taxId] : null,

                        ];
                    }

                    $taxInfo[] = [
                        // 'tax_id' => $taxId,
                        'tax_name' => 'RTO',
                        'cost' => $priceItem->i_rto_price ? $priceItem->i_rto_price : null,
                    ];

                    $formattedData[$modelname]['variants'][$key_main]['price_entry'] = [



                        'price_entry_id' => $priceItem->pe_id,
                        'variant_id' => $priceItem->variant_id,
                        'variant_name' => $priceItem->variant_name,
                        'country_name' => $priceItem->country_name,
                        'state_name' => $priceItem->state_name,
                        'city_name' => $priceItem->city_name,
                        // 'ut_name' => $priceItem->ut_name,
                        'ex_showroom_price' => $priceItem->ex_showroom_price,
                        'tax_name' => $taxInfo,
                        'total_price' => $priceItem->total_price,
                    ];
                }

                //price entry end

                $colorData = Color::select(
                    'cop_colors.color_id',
                    'cop_colors.color_name',
                    'cop_colors.color_code',
                    'cop_colors.dual_color_code',
                    'cop_colors.variant_color_image_mob',
                    'cop_colors.variant_id',
                )
                    ->where('cop_colors.variant_id', '=', $item->variant_id)
                    ->distinct()
                    ->get();

                $formattedData[$modelname]['variants'][$key_main]['colors'] = [];

                foreach ($colorData as $colorItem) {
                    $formattedData[$modelname]['variants'][$key_main]['colors'][] = [
                        'color_id' => encryptor('e', $colorItem->color_id),
                        'variant_id' => encryptor('e', $colorItem->variant_id),
                        'color_name' => $colorItem->color_name,
                        'color_code' => $colorItem->color_code,
                        'dual_color_code' => $colorItem->dual_color_code ?? null,
                        'variant_color_image' => $colorItem->variant_color_image_mob,
                        'variant_color_image_path' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$colorItem->variant_color_image_mob}" ?? null,
                    ];
                }

                $specificationCategory = SpecificationCategory::all();

                $formattedData[$modelname]['variants'][$key_main]['specification_cat'] = [];

                $key_spec_cat = 0;
                foreach ($specificationCategory as $specItem) {
                    $formattedData[$modelname]['variants'][$key_main]['specification_cat'][] = [
                        'sc_id' => $specItem->sc_id,
                        'spec_cat_name' => $specItem->sc_name,
                    ];

                    $spec_cat = Specification::join('cop_sc_ms', 'cop_sc_ms.sc_id', '=', 'cop_spec_ms.sc_id')->where('cop_sc_ms.sc_name', $specItem->sc_name)->get();

                    $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'] = [];

                    $key_spec = 0;
                    foreach ($spec_cat as $spec) {
                        $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'][] = [
                            'spec_id' => $spec->spec_id,
                            'spec_name' => $spec->spec_name,
                            // 'spec_image' => $spec->spec_image,
                            'spec_image' => $this->imagePath . "Specification/{$spec->spec_id}/{$spec->spec_id}.svg" ?? NULL,
                        ];

                        $feature = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                            ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                            ->join('cop_models', 'cop_models.model_id', '=', 'cop_fv.model_id')
                            ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                            ->where('cop_features_ms.spec_id', '=', $spec->spec_id)
                            ->where('cop_fv.variant_id', '=', $item->variant_id)
                            ->where('cop_models.model_type', '=', $item->model_type)
                            ->get();


                        $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'][$key_spec]['features'] = [];

                        foreach ($feature as $featureItem) {

                            // $power = config('constant.POWER');
                            // $power_ev = config('constant.POWER_EV');
                            // if($featureItem->features_name == $power || $featureItem->features_name == $power_ev){
                                $checkBhp = check_bhp_exist($featureItem->feature_value);

                                if(!$checkBhp){
                                    $su_name = $featureItem->su_name;
                                } else {
                                    $su_name = null;
                                }
                            // }

                            $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'][$key_spec]['features'][] = [
                                'features_name' => $featureItem->features_name,
                                'feature_value' => $featureItem->feature_value,
                                'su_name' => $su_name,

                            ];
                        }
                        $key_spec++;
                    }
                    $key_spec_cat++;
                }





                $graphicData = CarGraphic::select(
                    'cop_graphics.model_id',
                    'cop_graphics.graphic_file_mob',
                    'cop_gt_ms.gt_name',
                    'cop_gt_ms.gt_id',
                )
                    ->leftJoin('cop_gt_ms', 'cop_gt_ms.gt_id', '=', 'cop_graphics.gt_id')
                    ->where('cop_graphics.model_id', '=', $item->model_id)
                    ->distinct()
                    ->get();

                $formattedData[$modelname]['car_graphic_type'] = [];
                $key_graphic = 0;
                foreach ($graphicData as $graphicItem) {
                    $abc = [
                        'model_id' => encryptor('e', $graphicItem->model_id),
                        'car_graphic_type_id' => encryptor('e', $graphicItem->gt_id),
                        'car_graphic_type_name' => $graphicItem->gt_name,
                        'car_graphics' => []
                    ];

                    $folderName = str_replace(' ','_',strtolower(trim($graphicItem->gt_name)));

                    if($graphicItem->graphic_file_mob){
                        $single_image = explode(',', $graphicItem->graphic_file_mob);
                        $arr = [];
                        for ($i = 0; $i < count($single_image); $i++) {
                            $arr[] = $this->imagePath . "car_graphics/{$graphicItem->model_id}/{$folderName}/mobile/{$single_image[$i]}";
                        }
                        $abc['car_graphics'] = $arr;
                    }

                    $formattedData[$modelname]['car_graphic_type'][$key_graphic] = $abc;

                    $key_graphic++;
                }


                $key_main++;
            }

            // if ($carModule->isEmpty()) {
            //     return ResponseHelper::errorResponse('data_not_found');
            // }

            $formattedData = array_values($formattedData);



            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            \Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // to get the details of model, variants list and car-graphics
    public function car_module(Request $request)
    {
        try {
            // city_id input field
            if (!$request->has('city_id') && trim($request->input('city_id')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $city_id_dec = encryptor('d', $request->input('city_id'));
                if (!$city_id_dec) {
                    return ResponseHelper::errorResponse('error',$request->input('city_id') . ' city_id is not found');
                } else {
                    $city = City::find($city_id_dec);
 
                    if (!$city) {
                        return ResponseHelper::errorResponse('error',$request->input('city_id') . ' city_id is not found');
                    } else {
                        $city_id = $city_id_dec;
                    }
                }
            }
 
            // model_id input filed
            if (!$request->has('model_id') && trim($request->input('model_id')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $model_id_dec = encryptor('d', $request->input('model_id'));
                if (!$model_id_dec) {
                    return ResponseHelper::errorResponse('error',$request->input('model_id') . ' model_id is not found');
                } else {
                    $model = Model::find($model_id_dec);
 
                    if (!$model) {
                        return ResponseHelper::errorResponse('error',$request->input('model_id') . ' model_id is not found');
                    } else {
                        $model_id = $model_id_dec;
 
                    }
                }
            }
            $featureVal = [config('constant.DISPLACEMENT'), config('constant.POWER'), config('constant.TYPE_OF_TRANSMISSION'),  config('constant.BATTERY_CAPACITY'), config('constant.POWER_EV'), config('constant.RANGE'), config('constant.MILEAGE')];
            $imagePath=$this->imagePath;
            $auth_id = Auth::guard('api')->id();
            $carModule = Model::with(['car_graphics' => function ($query) {
                $query->join('cop_gt_ms', 'cop_graphics.gt_id', 'cop_gt_ms.gt_id')
                    ->select('model_id', 'graphic_file_mob', 'gt_name');
            }, 'variants' => function ($query) use ($city_id) {
                $query->select('cop_variants.model_id', 
                        'cop_variants.variant_id', 
                        'cop_variants.brand_id', 
                        'variant_name', 
                        'variant_image',
                        DB::raw("CASE WHEN cop_pe_ms.ex_showroom_price IS NULL THEN 0 ELSE cop_pe_ms.ex_showroom_price END as ex_showroom_price"),
                        DB::raw("(SELECT cop_fv.feature_value FROM cop_fv 
                                INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id 
                                WHERE cop_features_ms.features_name = '".config('constant.TYPE_OF_FUEL')."' 
                                AND cop_fv.variant_id = cop_variants.variant_id 
                                LIMIT 1) AS fuel_type")
                    )
                    ->leftJoin('cop_pe_ms', function ($join) use ($city_id) {
                        $join->on('cop_variants.variant_id', '=', 'cop_pe_ms.variant_id')
                            ->where('cop_pe_ms.city_id', '=', (int) $city_id);
                    })
                    ->where('cop_variants.status', 1)
                    // ->select('cop_variants.model_id','cop_variants.variant_id','cop_variants.brand_id','variant_name','variant_image','ex_showroom_price','fuel_type')
                    ->orderBy('ex_showroom_price', 'ASC');
            }, 'variants.featureValue' => function ($query) use ($featureVal) {
                $query
                    ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                    ->join('cop_spec_ms', 'cop_fv.spec_id', '=', 'cop_spec_ms.spec_id')
                    ->leftJoin('cop_su_ms', 'cop_features_ms.su_id', '=', 'cop_su_ms.su_id')
                    ->select('features_name','feature_value','model_id','variant_id')
                    ->whereIn('cop_features_ms.features_name', $featureVal);
            },])
                ->select(DB::raw("(select wl_id from cop_wl where cop_wl.model_id=cop_models.model_id and customer_id = '".$auth_id."') as wishlist"),'cop_msd.model_engine', 'cop_msd.model_bhp', 'cop_msd.model_transmission', 'cop_msd.model_mileage', 'cop_msd.model_fuel', 'min_price', 'max_price', 'cop_models.model_id', 'cs_name', 'model_description', 'model_type', 'cop_brands_ms.brand_id', 'brand_logo', 'brand_name', 'model_name', 'rating_value', 'rating_type_name')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_cs_ms', 'cop_cs_ms.cs_id', '=', 'cop_models.cs_id')
                ->leftJoin('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_ratings', 'cop_models.model_id', '=', 'cop_ratings.model_id')
                ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                ->where('cop_models.model_id', $model_id)
                ->first();
                // dd($carModule);
            if (empty($carModule)) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $carModule->wishlist =(!empty($carModule->wishlist)?true:false);
            $carModule->model_type =(($carModule->model_type == 0)?'Non EV':'EV');
            $carGraphics = $carModule->car_graphics;
            $formatData1 = [];
            $carGraphics->map(function ($graphic) use ($model_id, $formatData1,$imagePath) {
                $gtName = strtolower($graphic->gt_name);
                $graphic->model_id=encryptor('e', $graphic->model_id);
                $graphicFiles = explode(',', $graphic->graphic_file_mob);
                $formattedFiles = collect($graphicFiles)->map(function ($filename) use ($model_id, $graphic,$imagePath) {
                    return $imagePath .'car_graphics/' . $model_id . '/' . strtolower($graphic->gt_name) . '/mobile/' . $filename;
                });
                $formatData1['car_graphic_' . $gtName] = $formattedFiles->values()->toArray();
                $graphic->graphic_file_mob=$formatData1['car_graphic_' . $gtName];
                return $graphic;
            });
            $carModule->variants->map(function ($data) use($imagePath) {
                $data->featureValue->map(function($query){
                    $query->model_id = encryptor('e', $query->model_id);
                    $query->variant_id = encryptor('e', $query->variant_id);
                    return $query;
                });
                $data->variant_image= $imagePath .'brands/' .$data->brand_id. '/' .$data->model_id. '/' .$data->variant_id. '/' .$data->variant_image ;
                $data->brand_id = encryptor('e', $data->brand_id);
                $data->model_id = encryptor('e', $data->model_id);
                $data->variant_id = encryptor('e', $data->variant_id);
                return $data;
            });

           
            $carModule->brand_id = encryptor('e', $carModule->brand_id);
            $model_id = encryptor('e', $carModule->model_id);
            $formattedData[]=array_replace($carModule->toArray(),['model_id'=>$model_id]);
            



            // dd($formattedData);
 
            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error',$e->getMessage());
        }
    }

    // to get variant_specifications details, colors and color_variant_images, price_details with taxes
    public function car_module_specification(Request $request) 
    {
        try {
            // city_id input field
            if (!$request->has('city_id') && trim($request->city_id)==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $city_id_dec = encryptor('d',$request->city_id);
                if(!$city_id_dec){
                    return ResponseHelper::errorResponse('error',$request->city_id .' city_id is not found');
                } else {
                    $city = City::find($city_id_dec);

                    if(!$city) {
                        return ResponseHelper::errorResponse('error',$request->city_id .' city_id is not found');
                    } else {
                        $city_id = $city_id_dec;
                    }
                }
            }

            // model_id input filed
            $model_id = $request->input('model_id');
            if (empty($model_id)) {
                return ResponseHelper::errorResponse('missing_required_field');
            }

            $model_id_dec = encryptor('d', $model_id);
            if (!$model_id_dec || !$model = Model::find($model_id_dec)) {
                return ResponseHelper::errorResponse('error',"$model_id model_id is not found");
            }

            $model_id = $model_id_dec;

            // variant_id input field (if variant_id inputed)
            if ($request->has('variant_id')) {
                if(trim($request->variant_id) !== "") {
                    $variant_id = encryptor('d', $request->input('variant_id'));
                    $variant = Variant::select('variant_id', 'variant_name')
                        ->where('variant_id', $variant_id)
                        ->where('model_id', $model_id)
                        ->first();

                    if (!$variant) {
                        return ResponseHelper::errorResponse('error',
                            $request->variant_id." variant_id is not pertaining to ".$request->model_id." model_id"
                        );
                    }

                    $variant_name = $variant->variant_name;
                } else {
                    $base_variant_get = PriceEntry::select('cop_variants.variant_id', 'cop_variants.variant_name')
                        ->join('cop_variants', 'cop_variants.variant_id', '=', 'cop_pe_ms.variant_id')
                        ->where('cop_pe_ms.city_id', $city_id)
                        ->where('cop_pe_ms.model_id', $model_id)
                        ->orderBy('cop_pe_ms.ex_showroom_price', 'asc')
                        ->first();

                    if (!$base_variant_get) {
                        return ResponseHelper::errorResponse('error',
                            "No variant has been added for model_id = ".$request->model_id." and city_id = ".$request->city_id
                        );
                    }

                    $variant_id = $base_variant_get->variant_id;
                    $variant_name = $base_variant_get->variant_name;
                }
            }


            // basic details of varaints
            $data = [
                'variant_id' => encryptor('e',$variant_id),
                'variant_name' => $variant_name,
            ];

            // to get variant color details
            $colorGet = Color::select('color_name','color_code','dual_color_code','variant_color_image_mob','brand_id','model_id','variant_id')
                ->where('variant_id',$variant_id)
                ->get();

            foreach($colorGet as $color) {
                $data['color'][] = [
                    'color_name' => $color->color_name,
                    'color_code' => $color->color_code,
                    'dual_color_code' => ($color->dual_color_code == null || $color->dual_color_code == "") ? null : $color->dual_color_code,
                    'variant_color_image_path' => $this->imagePath . "brands/{$color->brand_id}/{$color->model_id}/{$color->variant_id}/{$color->variant_color_image_mob}"
                ];
            }
            
            // to get spec, spec_cat, features, features_value, su_name data
            $model_type = Model::select('model_type')->where('model_id',$model_id)->first(); // to know the model_type of selected variants

            $featuresData =  DB::table('cop_models as m')
                ->select([
                    'b.brand_id',
                    'b.brand_name',
                    'b.slug as brand_slug',
                    'm.model_id',
                    'm.model_name',
                    'm.slug as model_slug',
                    'v.variant_id',
                    'v.variant_name',
                    'v.variant_image',
                    'v.slug as variant_slug',
                    'm.model_type',
                    DB::raw("(SELECT Concat('[',Group_concat(Json_object('sc_name',spec.sc_name, 'sc_id',spec.sc_id,
                    'spec_data', (SELECT Concat('[',Group_concat(Json_object('spec_name',sm.spec_name, 'spec_image',sm.spec_image, 'spec_id',sm.spec_id, 
                    'features_name', (SELECT Concat('[',Group_concat(Json_object('features_name',fm.features_name, 'fuel_type',fm.fuel_type, 
                    'feature_value', (SELECT Concat('[', Group_concat(Json_object('feature_value',fv.feature_value, 'su_name', su.su_name)),']') FROM cop_fv fv LEFT JOIN cop_su_ms su ON fm.su_id = su.su_id WHERE fm.feature_id = fv.feature_id AND fv.variant_id = v.variant_id ) )),']') 
                    FROM cop_features_ms fm WHERE sm.spec_id = fm.spec_id AND fm.fuel_type IN (".$model_type->model_type.",2)) )),']') 
                    FROM cop_spec_ms sm WHERE sm.sc_id = spec.sc_id ) )),']') 
                    FROM cop_sc_ms spec) AS sc_data")
                    ])
                ->join('cop_brands_ms as b', 'b.brand_id', '=', 'm.brand_id')
                ->join('cop_variants as v', 'v.model_id', '=', 'm.model_id')
                ->where('v.variant_id',$variant_id)
                ->groupBy('b.brand_id', 'b.brand_name', 'm.model_id', 'm.model_name', 'v.variant_id', 'v.variant_name', 'v.variant_image', 'v.slug', 'b.slug', 'm.slug','m.model_type')
                ->get();

                $data['specification_cat'] = [];
                foreach ($featuresData as $variantData) {
                    if (!empty($variantData)) {
                        $decodedData = json_decode($variantData->sc_data, true);
                        
                        $key1 = 0;
                        foreach ($decodedData as $item) {
                            $data['specification_cat'][] = [
                                'sc_id' => $item['sc_id'],
                                'spec_cat_name' => $item['sc_name'],
                            ];
                            $data['specification_cat'][$key1]['spec'] = [];
                            
                            $spec_datas = json_decode($item['spec_data'], true);

                            $key2 = 0;
                            foreach ($spec_datas as $spec_data) {
                                $data['specification_cat'][$key1]['spec'][] = [
                                    'spec_id' => $spec_data['spec_id'],
                                    'spec_name' => $spec_data['spec_name'],
                                    'spec_image' => $this->imagePath . "Specification/".$spec_data['spec_id']."/".$spec_data['spec_image'],
                                ];
                                $data['specification_cat'][$key1]['spec'][$key2]['features'] = [];
                                
                                $feature_names = json_decode($spec_data['features_name']);

                                foreach ($feature_names as $feature) {
                                    $feature_values = json_decode($feature->feature_value, true);
                                        $data['specification_cat'][$key1]['spec'][$key2]['features'][] = [
                                            'features_name' => $feature->features_name,
                                            'feature_value' => $feature_values[0]['feature_value'] ?? "N/A",
                                            'su_name' => $feature_values[0]['su_name'] ?? null,
                                        ];
                                }
                                $key2++;
                            }
                            $key1++;
                        }
                    }
                }

                // to get price details
                $priceDataGet = PriceEntry::select('cop_city_ms.city_name','cop_pe_ms.i_rto_price','cop_pe_ms.c_rto_price','cop_pe_ms.ex_showroom_price','cop_pe_ms.total_price','cop_pe_ms.total_price_c', DB::raw('
                (
                    SELECT CONCAT("[",GROUP_CONCAT(
                        JSON_OBJECT(
                            "tax_name", cop_taxes_ms.tax_name,
                            "amt", JSON_EXTRACT(cop_pe_ms.tax_cost, CONCAT(\'$.\', cop_taxes_ms.tax_id))
                        )
                    ),"]")
                    FROM cop_taxes_ms
                    WHERE JSON_SEARCH(cop_pe_ms.tax_id, \'one\', CAST(cop_taxes_ms.tax_id AS CHAR)) IS NOT NULL
                ) AS tax_name
                '))
                ->join('cop_city_ms','cop_city_ms.city_id','=','cop_pe_ms.city_id')
                ->where('cop_pe_ms.variant_id', $variant_id)
                ->where('cop_pe_ms.status', 1)
                ->where('cop_pe_ms.city_id', $city_id)
                ->first();

                $tax_datas = json_decode($priceDataGet->tax_name);
                
                // all tax_cost data append in $tax_details
                $tax_details = [];
                foreach($tax_datas as $tax_data) {
                    $tax_details[] = [
                        'tax_name' => $tax_data->tax_name,
                        'tax_cost' => intval($tax_data->amt),
                    ];
                }

                // RTO (individual) data append in $tax_details
                $tax_details[] = [
                    'tax_name' => 'RTO',
                    'tax_cost' => $priceDataGet->i_rto_price
                ];

                // RTO (for compay) data append in $tax_details
                $tax_details[] = [
                    'tax_name' => 'RTO (for compay)',
                    'tax_cost' => $priceDataGet->c_rto_price
                ];

                $principal_amount = ($priceDataGet->ex_showroom_price * 95 / 100);
                $annual_interest_rate = 9;
                $monthly_interest_rate = ($annual_interest_rate / 100) / 12;
                $loan_tenure_months = 60;

                $emi_starting_from = $principal_amount * $monthly_interest_rate * pow((1 + $monthly_interest_rate), $loan_tenure_months) / (pow((1 + $monthly_interest_rate), $loan_tenure_months) - 1);

                // price entry data show
                $data['price_entry'][] = [
                    'ex_showroom_price' => $priceDataGet->ex_showroom_price,
                    'tax_details' => $tax_details,
                    'total_price' => $priceDataGet->total_price,
                    'total_price_company' => $priceDataGet->total_price_c,
                    'city_name' => $priceDataGet->city_name,
                    'emi_starting_from' => round($emi_starting_from,2),
                ];
                
                return ResponseHelper::responseMessage('success', $data);
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // to get all model list with info based on brand_name to view in news & blog details page
    public function news_blogs_model_list(Request $request)
    {
        try{
            if (!$request->has('brand_name') && trim($request->brand_name)==''){
                return ResponseHelper::errorResponse('missing_required_field');
            }

            $getModelData = Model::select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_brands_ms.slug as brand_slug',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_models.slug as model_slug',
                DB::raw('(SELECT cop_variants.variant_id FROM cop_variants WHERE cop_variants.model_id = cop_models.model_id AND cop_variants.status = 1 LIMIT 1) as variant_id'),
                DB::raw('(SELECT cop_variants.variant_image FROM cop_variants WHERE cop_variants.model_id = cop_models.model_id AND cop_variants.status = 1 LIMIT 1) as variant_image'),
                DB::raw('(SELECT MIN(cop_pe_ms.ex_showroom_price) FROM cop_pe_ms WHERE cop_pe_ms.model_id = cop_models.model_id AND cop_pe_ms.city_id = '.config('constant.NEWS_BLOGS_DEFAULT.CITY_ID').' AND cop_pe_ms.status = 1) as min_ex_showroom_price'),
                DB::raw('(SELECT MAX(cop_pe_ms.ex_showroom_price) FROM cop_pe_ms WHERE cop_pe_ms.model_id = cop_models.model_id AND cop_pe_ms.city_id = '.config('constant.NEWS_BLOGS_DEFAULT.CITY_ID').' AND cop_pe_ms.status = 1) as max_ex_showroom_price')
            )
            ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
            ->join('cop_variants','cop_variants.model_id','=','cop_models.model_id')
            ->where('cop_brands_ms.brand_name',$request->brand_name)
            ->where('cop_brands_ms.status',1)
            ->where('cop_models.status',1)
            ->distinct()
            ->get();

            if($getModelData->isEmpty()){
                return ResponseHelper::errorResponse('data_not_found');
            }

            $data = [];
            $getModelData->map(function ($item) use (&$data) {
                $data[] = array_merge(
                    $item->toArray(),
                    [
                        'brand_id' => encryptor('e',$item->brand_id),
                        'model_id' => encryptor('e',$item->model_id),
                        'variant_id' => encryptor('e',$item->variant_id),
                        'variant_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_image}",
                        'price' => formatAmount($item->min_ex_showroom_price, $item->max_ex_showroom_price)
                    ],
                );
            });
            return ResponseHelper::responseMessage('success', $data);

        } catch(Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    // to get model details based on model_name to view in news & blog details page
    public function news_blogs_model_description(Request $request)
    {
        try{
            if (!$request->has('model_name') && trim($request->model_name)==''){
                return ResponseHelper::errorResponse('missing_required_field');
            }

            $displacement = config('constant.DISPLACEMENT');
            $mileage = config('constant.MILEAGE');
            $transmission = config('constant.TYPE_OF_TRANSMISSION');
            $battery_capacity = config('constant.BATTERY_CAPACITY');
            $range = config('constant.RANGE');
            $power = config('constant.POWER');
            $power_ev = config('constant.POWER_EV');

            $getModelData = Model::select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_brands_ms.slug as brand_slug',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_models.model_type',
                'cop_models.slug as model_slug',
                'cop_variants.variant_id',
                'cop_variants.variant_image',
                DB::raw('(SELECT MIN(cop_pe_ms.ex_showroom_price) FROM cop_pe_ms WHERE cop_pe_ms.model_id = cop_models.model_id AND cop_pe_ms.city_id = '.config('constant.NEWS_BLOGS_DEFAULT.CITY_ID').' AND cop_pe_ms.status = 1) as min_ex_showroom_price'),
                DB::raw('(SELECT MAX(cop_pe_ms.ex_showroom_price) FROM cop_pe_ms WHERE cop_pe_ms.model_id = cop_models.model_id AND cop_pe_ms.city_id = '.config('constant.NEWS_BLOGS_DEFAULT.CITY_ID').' AND cop_pe_ms.status = 1) as max_ex_showroom_price'),
                DB::raw('(SELECT CONCAT("[",GROUP_CONCAT(JSON_OBJECT(
                            "color_id",cop_colors.color_id,
                            "color_name",cop_colors.color_name,
                            "color_code",cop_colors.color_code,
                            "dual_color_code", cop_colors.dual_color_code
                        )),"]") FROM cop_colors WHERE cop_colors.variant_id = cop_variants.variant_id) as variant_colors'),

                DB::raw('(SELECT CONCAT(MIN(CAST(cop_fv.feature_value AS DOUBLE)), " ", cop_su_ms.su_name) FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id LEFT JOIN cop_su_ms ON cop_su_ms.su_id = cop_features_ms.su_id WHERE cop_fv.variant_id = cop_variants.variant_id AND (cop_features_ms.features_name = "' . $displacement . '" OR cop_features_ms.features_name = "' . $battery_capacity . '") GROUP BY cop_su_ms.su_name) as displacement_or_battery_cap'),
                DB::raw('(SELECT CONCAT("[",GROUP_CONCAT(JSON_OBJECT(
                    "feature_id",cop_features_ms.feature_id,
                    "feature_image",cop_features_ms.features_image
                )),"]") FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id WHERE cop_fv.variant_id = cop_variants.variant_id AND (cop_features_ms.features_name = "' . $displacement . '" OR cop_features_ms.features_name = "' . $battery_capacity . '")) as displacement_or_battery_cap_data'),

                DB::raw('(SELECT CONCAT(MIN(CAST(cop_fv.feature_value AS DOUBLE)), " ", cop_su_ms.su_name) FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id LEFT JOIN cop_su_ms ON cop_su_ms.su_id = cop_features_ms.su_id WHERE cop_fv.variant_id = cop_variants.variant_id AND (cop_features_ms.features_name = "' . $mileage . '" OR cop_features_ms.features_name = "' . $range . '") GROUP BY cop_su_ms.su_name) as mileage_or_range'),
                DB::raw('(SELECT CONCAT("[",GROUP_CONCAT(JSON_OBJECT(
                    "feature_id",cop_features_ms.feature_id,
                    "feature_image",cop_features_ms.features_image
                )),"]") FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id WHERE cop_fv.variant_id = cop_variants.variant_id AND (cop_features_ms.features_name = "' . $mileage . '" OR cop_features_ms.features_name = "' . $range . '")) as mileage_or_range_data'),

                DB::raw('(SELECT CONCAT(MIN(CAST(cop_fv.feature_value AS DOUBLE)), " ", cop_su_ms.su_name) FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id LEFT JOIN cop_su_ms ON cop_su_ms.su_id = cop_features_ms.su_id WHERE cop_fv.variant_id = cop_variants.variant_id AND (cop_features_ms.features_name = "' . $power . '" OR cop_features_ms.features_name = "' . $power_ev . '") GROUP BY cop_su_ms.su_name) as power'),
                DB::raw('(SELECT CONCAT("[",GROUP_CONCAT(JSON_OBJECT(
                    "feature_id",cop_features_ms.feature_id,
                    "feature_image",cop_features_ms.features_image
                )),"]") FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id WHERE cop_fv.variant_id = cop_variants.variant_id AND (cop_features_ms.features_name = "' . $power . '" OR cop_features_ms.features_name = "' . $power_ev . '")) as power_data'),

                DB::raw('(SELECT cop_fv.feature_value FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id WHERE cop_fv.variant_id = cop_variants.variant_id AND cop_features_ms.features_name = "' . $transmission . '") as transmission'),
                DB::raw('(SELECT CONCAT("[",GROUP_CONCAT(JSON_OBJECT(
                    "feature_id",cop_features_ms.feature_id,
                    "feature_image",cop_features_ms.features_image
                )),"]") FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id WHERE cop_fv.variant_id = cop_variants.variant_id AND cop_features_ms.features_name = "' . $transmission . '") as transmission_data'),
            )
            ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
            ->join('cop_variants','cop_variants.model_id','=','cop_models.model_id')
            ->where('cop_models.model_name',$request->model_name)
            ->where('cop_brands_ms.status',1)
            ->where('cop_models.status',1)
            ->where('cop_variants.status',1)
            ->limit(1)
            ->get();

            if($getModelData->isEmpty()){
                return ResponseHelper::errorResponse('data_not_found');
            }

            $data = [];
            $getModelData->map(function ($item) use (&$data) {
                $variant_colors = $item->variant_colors ? json_decode($item->variant_colors, true) : [];
                $displacement_or_battery_data = $item->displacement_or_battery_cap_data ? json_decode($item->displacement_or_battery_cap_data, true) : [];
                $mileage_or_range_data = $item->mileage_or_range_data ? json_decode($item->mileage_or_range_data, true) : [];
                $power_data = $item->power_data ? json_decode($item->power_data, true) : [];
                $transmission_data = $item->transmission_data ? json_decode($item->transmission_data, true) : [];

                $data[] = array_merge(
                    $item->toArray(),
                    [
                        'brand_id' => encryptor('e',$item->brand_id),
                        'model_id' => encryptor('e',$item->model_id),
                        'variant_id' => encryptor('e',$item->variant_id),
                        'variant_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_image}",
                        'price' => formatAmount($item->min_ex_showroom_price, $item->max_ex_showroom_price),
                        'variant_colors' => $variant_colors,
                        'displacement_or_battery_image' => $displacement_or_battery_data ? $this->imagePath . "Feature/" . $displacement_or_battery_data[0]['feature_id'] ."/". $displacement_or_battery_data[0]['feature_image'] : null,
                        'mileage_or_range_image' => $mileage_or_range_data ? $this->imagePath . "Feature/" . $mileage_or_range_data[0]['feature_id'] ."/". $mileage_or_range_data[0]['feature_image'] : null,
                        'power_image' => $power_data ? $this->imagePath . "Feature/" . $power_data[0]['feature_id'] ."/". $power_data[0]['feature_image'] : null,
                        'transmission_image' => $transmission_data ? $this->imagePath . "Feature/" . $transmission_data[0]['feature_id'] ."/". $transmission_data[0]['feature_image'] : null,
                    ],
                );
            });
            return ResponseHelper::responseMessage('success', $data);

        } catch(Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error',$e->getMessage());
        }
    }
}