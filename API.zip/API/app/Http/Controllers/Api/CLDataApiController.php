<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CarListingData;
use Exception;
use Illuminate\Http\Request;

class CLDataApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {

            $cl_data = CarListingData::select(
                'cop_cl_data.*',
                'cop_cl_ms.cl_name as cl_name',
                'cop_brands_ms.brand_name as brand_name',
                'cop_models.model_name as model_name'
            )
                ->leftJoin('cop_cl_ms', 'cop_cl_data.cl_id', '=', 'cop_cl_ms.cl_id')
                ->leftJoin('cop_brands_ms', 'cop_cl_data.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_models', 'cop_cl_data.model_id', '=', 'cop_models.model_id')
                ->where('cop_cl_data.status', '!=', 0)
                ->where('cop_brands_ms.status', '!=', 0)
                ->where('cop_models.status', '!=', 0)
                ->get();

            if ($cl_data->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }


            $clData = $cl_data->map(function ($item) {

                $data = [
                    'cl_data_id' => encryptor('e',$item->cl_data_id),
                    'cl_name' => $item->cl_name,
                    'brand_name' => $item->brand_name,
                    'model_name' => $item->model_name,

                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $clData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('error');
        }
    }
}
