<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Customer;
use App\Models\Wishlist;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Model;

class WishlistApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    public function index(Request $request)
    {
        try {
            $customerId = Auth::guard('api')->id();
            // $customer = JWTAuth::parseToken()->authenticate();
            // return response()->json(['message' => 'Token is valid'], 200);

            $validator = Validator::make($request->all(), [
                'model_id' => 'required',
            ]);

            if ($validator->fails()) {
                return ResponseHelper::errorResponse('error',$validator->errors()->all());
            }
            $customer_id = $customerId;

            $checkCustomerExist = Customer::where('status',1)->where('contact_no','!=',null)->where('customer_id',$customerId)->first();

            if($checkCustomerExist){
                $model_id = encryptor('d',$request->model_id);
                $created_date = date('Y-m-d H:i:s');

                $user = Customer::find($customerId);
                if (!$user) {
                    return ResponseHelper::errorResponse('error','Customer not found!!');
                }
                //deletw wish list

                $existingWishlistItem = Wishlist::where('customer_id', $customer_id)
                    ->where('model_id', $model_id)
                    ->first();

                if ($existingWishlistItem) {
                    $existingWishlistItem->delete();
                    return ResponseHelper::responseMessage('success', $wishlist_status = False, 'Wishlist deleted successfully');
                }
                $wishlistAdd = new Wishlist();
                $wishlistAdd->customer_id = $customer_id;
                $wishlistAdd->model_id = $model_id;
                $wishlistAdd->created_date = $created_date;
                $wishlistAdd->save();
                return ResponseHelper::responseMessage('success', $wishlist_status = True, 'Wishlist Added successfully');
            } else {
                return ResponseHelper::errorResponse('unauthorized');
            }
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function customerWishlist(Request $request)
    {
        try {
            $customer_id = Auth::guard('api')->id();
            $checkCustomerExist = Customer::where('status',1)->where('contact_no','!=',null)->where('customer_id',$customer_id)->first();

            if($checkCustomerExist){
                $customerWishlist = Wishlist::select(
                    'cop_wl.customer_id',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_image',
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    DB::raw("CASE WHEN cop_models.model_type=0 THEN 'Non Ev' ELSE 'EV' END as model_type"),
                    DB::raw("( SELECT CONCAT('[',
                    GROUP_CONCAT( DISTINCT 
                                    JSON_OBJECT(
                                        CASE WHEN cop_models.model_type=0 THEN 
                                            CASE 
                                                WHEN cop_features_ms.features_name='Displacement' THEN 'engine'
                                                WHEN cop_features_ms.features_name='Type of Transmission' THEN 'transmission'
                                                WHEN cop_features_ms.features_name='Power' THEN 'power'
                                                WHEN cop_features_ms.features_name='Mileage' THEN 'mileage'
                                            END
                                        WHEN cop_models.model_type=1 THEN 
                                            CASE 
                                                WHEN cop_features_ms.features_name='Battery Capacity' THEN 'engine'
                                                WHEN cop_features_ms.features_name='Type of Transmission' THEN 'transmission'
                                                WHEN cop_features_ms.features_name='Power (EV)' THEN 'power'
                                                WHEN cop_features_ms.features_name='Mileage' THEN 'mileage'
                                            END 
                                        END, CONCAT(cop_fv.feature_value,' ', IF(cop_su_ms.su_name IS NOT NULL, cop_su_ms.su_name, ''))
                                    ) ),']') FROM cop_fv 
                                LEFT JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id
                                LEFT JOIN cop_su_ms ON cop_su_ms.su_id = cop_features_ms.su_id
                                WHERE cop_fv.variant_id = (select cop_pe_ms.variant_id from cop_pe_ms where cop_pe_ms.model_id=cop_models.model_id order by cop_pe_ms.ex_showroom_price ASC limit 1)
                                    AND (CASE WHEN cop_models.model_type=0 THEN cop_features_ms.features_name in('Type of Transmission','Displacement','Power','Mileage') ELSE cop_features_ms.features_name IN('Type of Transmission','Battery Capacity','Power (EV)','Mileage') END )  ) AS feature_json"),
                    DB::raw('(select min(ex_showroom_price) from cop_pe_ms where model_id=cop_models.model_id ) as min_price'),
                    DB::raw('(select max(ex_showroom_price) from cop_pe_ms where model_id=cop_models.model_id) as max_price')

                )
                    ->join('cop_models', 'cop_wl.model_id', '=', 'cop_models.model_id')
                    ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                    ->join('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->join('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                    ->where('cop_wl.customer_id', $customer_id)
                    ->get();

                $customer_wishlist = $customerWishlist->map(function ($item) {
                    $feature_json = json_decode($item->feature_json,true);
                    $engine=$power=$transmission=$mileage="";
                    foreach($feature_json as $key=>$feature){
                        if((array_key_exists('engine',$feature))){
                            $engine = trim(@$feature['engine']);
                        }
                        if((array_key_exists('power',$feature))){
                            $power = trim(@$feature['power']);
                        }
                        if((array_key_exists('transmission',$feature))){
                            $transmission = trim(@$feature['transmission']);
                        }
                        if((array_key_exists('mileage',$feature))){
                            $mileage = trim(@$feature['mileage']);
                        }
                    }
                    $data = [
                        'customer_id' => encryptor('e',$item->customer_id),
                        'brand_id' => encryptor('e',$item->brand_id),
                        'brand_name' => $item->brand_name,
                        'model_id' => encryptor('e',$item->model_id),
                        'model_name' => $item->model_name,
                        'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_image}",
                        'min_price' =>  convertToLakhCrore($item->min_price),
                        'max_price' =>  convertToLakhCrore($item->max_price),
                        'model_type' => $item->model_type,
                        'engine' => $engine,
                        'transmission' => $transmission,
                        'power' => $power,
                        'mileage' => $mileage,
                        'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : NULL,
                        'rating_type_name' => $item->rating_type_name ?? NULL,
                    ];
                    return  $data;
                });

                return ResponseHelper::responseMessage('success', $customer_wishlist);
            } else {
                return ResponseHelper::errorResponse('unauthorized');
            }
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
