<?php

namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\Country;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;

class CountryApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {
            $country = Country::where('status', '=', 1)->select('country_id','country_name')->get();
            if ($country->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }
            $countryData = $country->map(function ($item) {
                $data = [
                    'country_id ' => encryptor('e',$item->country_id),
                    'country_name' => $item->country_name,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $countryData);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse('error');
            return ResponseHelper::errorResponse('error');
        }
    }
}
