<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Brand;
use App\Models\Model;
use App\Models\City;
use App\Models\PriceEntry;
use App\Models\Color;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Feature;
use App\Models\FeatureValue;
use App\Models\Specification;
use App\Models\SpecificationCategory;
use App\Models\Variant;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Helpers\CommanFunctionApi;
use Hamcrest\Core\IsNot;
use App\Http\Controllers\Api\Crypt;

class CompareApiController extends Controller
{
    protected $commanFunctionApi;
    protected $imagePath;

    public function __construct(CommanFunctionApi $commanFunctionApi)
    {
        $this->commanFunctionApi = $commanFunctionApi;
        $this->imagePath = env('IMAGE_PATH');
    }

    // model list (app) (2-4-2024)
    public function compare_model(Request $request)
    {
        try {
            // city_id input field
            if (!$request->has('city_id') && trim($request->input('city_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $city_id_dec = encryptor('d',$request->input('city_id'));
                if(!$city_id_dec){
                    return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                } else {
                    $city = City::find($city_id_dec);

                    if(!$city) {
                        return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                    } else {
                        $city_id = $city_id_dec;
                    }
                }
            }

            // brand_id input filed
            if (!$request->has('brand_id') && trim($request->input('brand_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $brand_id_dec = encryptor('d',$request->input('brand_id'));
                if(!$brand_id_dec){
                    return ResponseHelper::errorResponse('error',$request->input('brand_id') .' brand_id is not found');
                } else {
                    $brand = Brand::find($brand_id_dec);

                    if(!$brand) {
                        return ResponseHelper::errorResponse('error',$request->input('brand_id') .' brand_id is not found');
                    } else {
                        $brand_id = $brand_id_dec;
                    }
                }
            }

            // car stage as launched
            $carStageLaunched = config('constant.CAR_STAGE_LAUNCHED');

            $models = Model::select('cop_ratings.rating_value', 'cop_brands_ms.brand_name', 'cop_models.model_id','cop_models.model_name','cop_brands_ms.brand_id','cop_models.model_image', 'cop_models.min_price', 'cop_models.max_price',
            DB::raw('(SELECT MIN(ex_showroom_price) FROM cop_pe_ms WHERE city_id = '.$city_id.' AND model_id = cop_models.model_id AND cop_pe_ms.status = 1) AS min_ex_showroom_price'),
            DB::raw('(SELECT MAX(ex_showroom_price) FROM cop_pe_ms WHERE city_id = '.$city_id.' AND model_id = cop_models.model_id AND cop_pe_ms.status = 1) AS max_ex_showroom_price'))
            ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
            ->join('cop_ratings','cop_ratings.model_id','=','cop_models.model_id')
            ->join('cop_rating_types','cop_rating_types.rating_type_id','=','cop_ratings.rating_type_id')
            ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
            ->where('cop_models.brand_id', $brand_id)
            ->where('cop_cs_ms.cs_name',$carStageLaunched)
            ->where('cop_brands_ms.status',1)
            ->where('cop_models.status',1)
            ->get();

            $formattedModels = $models->map(function ($model) {

                return [
                    'brand_name' => $model->brand_name,
                    'model_id' => encryptor('e',$model->model_id),
                    'model_image' => $this->imagePath . "/brands/{$model->brand_id}/{$model->model_id}/{$model->model_image}",
                    'model_name' => $model->model_name,
                    // 'price' => $this->commanFunctionApi->pricefilter($model->model_id),
                    'price' => [
                        'min_ex_showroom_price' => $model->min_ex_showroom_price ?  convertToLakhCrore($model->min_ex_showroom_price) : convertToLakhCrore($model->min_price),
                        'max_ex_showroom_price' => $model->max_ex_showroom_price ?  convertToLakhCrore($model->max_ex_showroom_price) : convertToLakhCrore($model->max_price),
                    ],
                    'rating_value' => $model->rating_value ? $model->rating_value : null
                ];
            });

            return ResponseHelper::responseMessage('success', $formattedModels);

        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // variant list (app) (2-4-23)
    public function compare_variant(Request $request)
    {
        try {

            $displacement = config('constant.DISPLACEMENT');
            $fuel = config('constant.TYPE_OF_FUEL');
            $mileage = config('constant.MILEAGE');
            $transmission = config('constant.TYPE_OF_TRANSMISSION');
            $battery_capacity = config('constant.BATTERY_CAPACITY');
            $range = config('constant.RANGE');

            // city_id input field
            if (!$request->has('city_id') && trim($request->input('city_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $city_id_dec = encryptor('d',$request->input('city_id'));
                if(!$city_id_dec){
                    return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                } else {
                    $city = City::find($city_id_dec);

                    if(!$city) {
                        return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                    } else {
                        $city_id = $city_id_dec;
                    }
                }
            }

            // model_id input filed
            if (!$request->has('model_id') && trim($request->input('model_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $model_id_dec = encryptor('d',$request->input('model_id'));
                if(!$model_id_dec){
                    return ResponseHelper::errorResponse('error',$request->input('model_id') .' model_id is not found');
                } else {
                    $model = Model::find($model_id_dec);

                    if(!$model) {
                        return ResponseHelper::errorResponse('error',$request->input('model_id') .' model_id is not found');
                    } else {
                        $model_id = $model_id_dec;
                    }
                }
            }

            // car stage as launched
            $carStageLaunched = config('constant.CAR_STAGE_LAUNCHED');

            $variants = Variant::select(
                'cop_variants.variant_id',
                'cop_variants.brand_id',
                'cop_brands_ms.brand_name',
                'cop_variants.model_id',
                'cop_models.model_name',
                'cop_variants.variant_name',
                'cop_variants.variant_image',
                'cop_pe_ms.ex_showroom_price',
                'cop_models.model_type',
                DB::raw('(SELECT CONCAT(MIN(CAST(cop_fv.feature_value AS DOUBLE)), " ", cop_su_ms.su_name) FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id LEFT JOIN cop_su_ms ON cop_su_ms.su_id = cop_features_ms.su_id WHERE cop_fv.variant_id = cop_variants.variant_id AND (cop_features_ms.features_name = "' . $displacement . '" OR cop_features_ms.features_name = "' . $battery_capacity . '") GROUP BY cop_su_ms.su_name) as displacement_battery_cap'),
                DB::raw('(SELECT CONCAT(MIN(CAST(cop_fv.feature_value AS DOUBLE)), " ", cop_su_ms.su_name) FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id LEFT JOIN cop_su_ms ON cop_su_ms.su_id = cop_features_ms.su_id WHERE cop_fv.variant_id = cop_variants.variant_id AND (cop_features_ms.features_name = "' . $mileage . '" OR cop_features_ms.features_name = "' . $range . '") GROUP BY cop_su_ms.su_name) as mileage_range'),
                DB::raw('(SELECT cop_fv.feature_value FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id WHERE cop_fv.variant_id = cop_variants.variant_id AND cop_features_ms.features_name = "' . $fuel . '") as fuel'),
                DB::raw('(SELECT cop_fv.feature_value FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id WHERE cop_fv.variant_id = cop_variants.variant_id AND cop_features_ms.features_name = "' . $transmission . '") as transmission')
            )
            ->leftJoin('cop_pe_ms', function($join) use ($city_id) {
                $join->on('cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                     ->where('cop_pe_ms.city_id', '=', $city_id)
                     ->where('cop_pe_ms.status', '=', 1);
            })
            ->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
            ->join('cop_brands_ms', 'cop_variants.brand_id', '=', 'cop_brands_ms.brand_id')
            ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
            ->where('cop_variants.model_id', $model_id)
            ->where('cop_cs_ms.cs_name',$carStageLaunched)
            ->where('cop_brands_ms.status',1)
            ->where('cop_models.status',1)
            ->where('cop_variants.status',1)
            ->orderBy('cop_pe_ms.ex_showroom_price','asc')
            ->distinct()
            ->get();
            
            if ($variants->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $variantData = $variants->map(function ($variant) {
                // $variantList = [
                $variantList = (object)[
                    'brand_id' => encryptor('e',$variant->brand_id),
                    'brand_name' => $variant->brand_name,
                    'model_id' => encryptor('e',$variant->model_id),
                    'model_name' => $variant->model_name,
                    'variant_id' => encryptor('e',$variant->variant_id),
                    'variant_name' => $variant->variant_name,
                    // 'variant_image' => asset("brands/{$variant->brand_id}/{$variant->model_id}/{$variant->variant_id}/{$variant->variant_image}") ?? NULL,
                    // 'variant_image' => $this->imagePath . "brands/{$variant->brand_id}/{$variant->model_id}/{$variant->variant_id}/{$variant->variant_image}" ?? null,
                    'variant_image' => $this->imagePath . "brands/{$variant->brand_id}/{$variant->model_id}/{$variant->variant_id}/{$variant->variant_image}",
                    'ex_showroom_price' =>  convertToLakhCrore($variant->ex_showroom_price),
                    'ex_showroom_price_integer' => $variant->ex_showroom_price,
                    'model_type' => $variant->model_type == 0 ? "Non-EV" : "EV",
                    'type_of_fuel' => $variant->fuel,
                    // 'features_name' => [],
                    'features_name' => (object)[],


                ];

                if ($variant->model_type == 0) {
                    // $variantList['features_name'][] = [
                    $variantList->features_name = (object)[
                        'displacement' => $variant->displacement_battery_cap,
                        'mileage' => $variant->mileage_range,
                        'type_of_transmission' => $variant->transmission,
                    ];
                } else {
                    // $variantList['features_name'][] = [
                    $variantList->features_name = (object)[
                        'displacement' => $variant->displacement_battery_cap,
                        'mileage' => $variant->mileage_range,
                        'type_of_transmission' => $variant->transmission,
                    ];
                }

                return $variantList;

            });

            return ResponseHelper::responseMessage('success', $variantData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // compare answer (app) (1-4-23 & 2-4-23)
    public function compare_answerP(Request $request)
    {
        try {

            // city_id input field
            if (!$request->has('city_id') && trim($request->input('city_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $city_id_dec = encryptor('d',$request->input('city_id'));
                if(!$city_id_dec){
                    return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                } else {
                    $city = City::find($city_id_dec);

                    if(!$city) {
                        return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                    } else {
                        $city_id = $city_id_dec;
                    }
                }
            }

            // variant_id input field
            if (!$request->has('variant_id') && trim($request->input('variant_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $encVariantIds = explode(',', $request->input('variant_id'));
                foreach($encVariantIds as $variantId){
                    $decVariantId = encryptor('d',$variantId);
                    if(!$decVariantId){
                        return ResponseHelper::errorResponse('error',$variantId.' variant_id is not found');
                    }
                    $variantIds[] = encryptor('d',$variantId);
                }

                if (count($variantIds) < 2) {
                    return ResponseHelper::errorResponse('error','At least two variant_ids are required.');
                }
            }

            $data = [];

            // To get data of selected variant to show variant card (like variant_name, variant_image, variant_id, etc)
            $car_details = [];
                foreach ($variantIds as $variantId) {

                    $compareCar = Variant::select(
                        'cop_brands_ms.brand_id',
                        'cop_brands_ms.brand_name',
                        'cop_models.model_id',
                        'cop_models.model_name',
                        'cop_variants.variant_id',
                        'cop_variants.variant_name',
                        'cop_variants.variant_image',
                    )
                        ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_variants.brand_id')
                        ->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
                        ->where('cop_variants.variant_id', $variantId)
                        ->where('cop_variants.status', '=', 1)
                        ->distinct()
                        ->get();

                    if ($compareCar->isEmpty()) {
                        return ResponseHelper::errorResponse('error','No data available for variant_id ' . encryptor('e',$variantId));
                    }

                    $formattedData = $compareCar->map(function ($item) {
                        $data = [
                            'brand_id' => encryptor('e',$item->brand_id),
                            'brand_name' => $item->brand_name,
                            'model_id' => encryptor('e',$item->model_id),
                            'model_name' => $item->model_name,
                            'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp" ?? null,
                            'variant_id' => encryptor('e',$item->variant_id),
                            'variant_name' => $item->variant_name,
                            'variant_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_image}",
                        ];

                        return $data;
                    });

                    $car_details[] = $formattedData[0];
                }

                // To check selected variants are EV, Non-EV or Both and append in one array
                foreach ($variantIds as $variantId) {
                    $checkFuelType = Variant::select('cop_models.model_type')->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
                        ->where('cop_variants.variant_id', $variantId)
                        ->first();

                    if (!empty($checkFuelType)) {
                        $variant_types[] = $checkFuelType->model_type == 1 ? "EV" : "Non-EV";
                    }
                }

                // To check selected variants are EV, Non-EV or Both using array_unique and assign it to 1 variable
                if (!empty($variant_types)) {
                    $unique_variant_types = array_unique($variant_types);

                    if (count($unique_variant_types) == 1) {
                        $overall_variant_type = reset($unique_variant_types);
                        $all_variant_type = $overall_variant_type;
                    } else {
                        $all_variant_type = 'Both';
                    }
                }

            // Basic Details Data Get
            $feature_data = [];

                // to get color & dual_color (inside basic_details)
                $color = [
                    'feature_name'=> 'Color',
                    'feature_value'=>[]
                ];
                foreach ($variantIds as $variantId) {
                    $getColor = Color::select(DB::raw('GROUP_CONCAT(IF(cop_colors.dual_color_code IS NULL OR cop_colors.dual_color_code = "", CONCAT(cop_colors.color_code, "-", "NULL"), CONCAT(cop_colors.color_code, "-", cop_colors.dual_color_code))) as color'))
                    ->where('cop_colors.variant_id', $variantId)
                    ->first();

                    $color['feature_value'][] =  $getColor->color;
                }
                $feature_data[] = $color;

                // to get ex_showroom price (inside basic_details)
                $ex_showroom_price = [
                    'feature_name'=> 'Ex Showroom Price',
                    'feature_value'=>[]
                ];
                foreach ($variantIds as $variantId) {
                    $getPrice = PriceEntry::select('ex_showroom_price')
                    ->where('cop_pe_ms.variant_id', $variantId)
                    ->where('cop_pe_ms.city_id', $city_id)
                    ->first();

                    if($getPrice){
                        $ex_showroom_price['feature_value'][] =  convertToLakhCrore($getPrice->ex_showroom_price);
                    } else {
                        $ex_showroom_price['feature_value'][] = "N/A";
                    }

                }
                $feature_data[] = $ex_showroom_price;

                // to get basic features (inside basic_detials)
                $nonEvFeaturesName = ['Displacement','Power','Type of Transmission','Mileage','Type of Fuel'];
                $evFeaturesName = ['Battery Capacity','Power (EV)','Type of Transmission','Range','Charging Time (AC)'];
                $bothFeaturesName = ['Displacement','Battery Capacity','Power','Power (EV)','Type of Transmission','Mileage','Range','Type of Fuel','Charging Time (AC)'];

                if($all_variant_type == 'Both'){
                    $features_name = Feature::select(
                        'features_name',
                        'fuel_type',
                        'feature_id'
                    )
                    ->whereIn('features_name',$bothFeaturesName)
                    ->groupBy(
                        'features_name',
                        'fuel_type',
                        'feature_id'
                    )
                    ->get();
                } else {
                    if($all_variant_type == 'EV'){ $featureNames = $evFeaturesName; }
                    if($all_variant_type == 'Non-EV'){ $featureNames = $nonEvFeaturesName; }

                    $features_name = Feature::select(
                        'features_name',
                        'fuel_type',
                        'feature_id'
                    )
                    ->whereIn('features_name',$featureNames)
                    ->groupBy(
                        'features_name',
                        'fuel_type',
                        'feature_id'
                    )
                    ->get();
                }

                
                foreach($features_name as $item){
                    $feature_array = [
                        'feature_name'=>$item->features_name,
                        'feature_value'=>[]
                    ];

                    $feature_array['feature_value'] = [];
                    foreach ($variantIds as $variantId) {
                        $feature_value = FeatureValue::select(
                            DB::raw('(CASE WHEN COUNT(cop_fv.feature_value) = 0 THEN "NULL" ELSE MAX(cop_fv.feature_value) END) AS feature_value'),
                            DB::raw('(CASE WHEN COUNT(cop_su_ms.su_name) = 0 THEN "NULL" ELSE MAX(cop_su_ms.su_name) END) AS su_name'),
                            DB::raw('(SELECT cop_models.model_type FROM cop_models INNER JOIN cop_variants ON cop_variants.model_id = cop_models.model_id WHERE cop_variants.variant_id = "'.$variantId.'") AS model_type')
                        )
                        ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->join('cop_variants', 'cop_variants.variant_id', '=', 'cop_fv.variant_id')
                        ->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
                        ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                        ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                        ->where('cop_variants.variant_id', $variantId)
                        ->where('cop_features_ms.feature_id', $item->feature_id)
                        ->first();
                    
                        if ($feature_value->feature_value != "NULL" && !empty($feature_value)) {
                            if($feature_value->su_name != "NULL"){
                                $power = config('constant.POWER');
                                $power_ev = config('constant.POWER_EV');
                                if($item->features_name == $power || $item->features_name == $power_ev){
                                    $checkBhp = check_bhp_exist($feature_value->feature_value);

                                    if($checkBhp){
                                        $fv_value = $feature_value->feature_value;
                                    } else {
                                        $fv_value = $feature_value->feature_value." ".$feature_value->su_name;
                                    }
                                } else {
                                    $fv_value = $feature_value->feature_value." ".$feature_value->su_name;
                                }
                            } else {
                                $fv_value = $feature_value->feature_value;
                            }
                        } else {
                            if($feature_value->model_type == "0" && ($item['fuel_type'] == '0' || $item['fuel_type'] == '2')){
                                $fv_value = 'N/A';
                            }
                            else if($feature_value->model_type == "1" && ($item['fuel_type'] == '1' || $item['fuel_type'] == '2')){
                                $fv_value = 'N/A';
                            } 
                            else {
                                $fv_value = 'NA';
                            }
                        }
                    
                        $feature_array['feature_value'][] = $fv_value;
                    }          

                    $feature_data[] = $feature_array;
                }

            // All feature_value data get
            $spec_cat = ['specification_category' => []];

                // get all specification category (LOOP 1)
                $spec_cat_data = SpecificationCategory::all();

                $key_spec_cat = 0;
                foreach ($spec_cat_data as $specCatItem) {

                    $spec_cat['specification_category'][] = [
                        'specification_catagory_name' => $specCatItem->sc_name,
                    ];

                    // get all specification (using above specification category) (LOOP 2)
                    $spec = Specification::join('cop_sc_ms', 'cop_sc_ms.sc_id', '=', 'cop_spec_ms.sc_id')
                        ->where('sc_name', $specCatItem->sc_name)->get();

                    $spec_cat['specification_category'][$key_spec_cat]['category'] = [];

                    $key_spec = 0;
                    foreach ($spec as $specItem) {
                        $spec_cat['specification_category'][$key_spec_cat]['category'][] = [
                            'specification_name' => $specItem->spec_name,
                            // 'spec_image' => asset("Specification/{$specItem->spec_id}/{$specItem->spec_image}") ?? "",
                            'spec_image' => $this->imagePath . "Specification/{$specItem->spec_id}/{$specItem->spec_image}" ?? null,
                        ];

                        // get all features (using above specification) (LOOP 3)
                        $featureQry = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                            ->where('cop_spec_ms.spec_name', $specItem->spec_name);

                        if ($all_variant_type == 'EV') {
                            $feature = $featureQry->whereIn('cop_features_ms.fuel_type', [1, 2])
                                ->get();
                        } else if ($all_variant_type == 'Non-EV') {
                            $feature = $featureQry->whereIn('cop_features_ms.fuel_type', [0, 2])
                                ->get();
                        } else {
                            $feature = $featureQry->get();
                        }

                        $spec_cat['specification_category'][$key_spec_cat]['category'][$key_spec]['name'] = [];

                        foreach ($feature as $featureItem) {

                            $spec_cat['specification_category'][$key_spec_cat]['category'][$key_spec]['name'][] = [
                                'feature_name' => $featureItem->features_name,
                                'feature_value' => []
                            ];

                            // get all feature-value (using above features_name and variant_id) (LOOP 4)
                            foreach ($variantIds as $variantId) {

                                $feature_value = FeatureValue::select(
                                    DB::raw('(CASE WHEN COUNT(cop_fv.feature_value) = 0 THEN "NULL" ELSE MAX(cop_fv.feature_value) END) AS feature_value'),
                                    DB::raw('(CASE WHEN COUNT(cop_su_ms.su_name) = 0 THEN "NULL" ELSE MAX(cop_su_ms.su_name) END) AS su_name'),
                                    DB::raw('(SELECT cop_models.model_type FROM cop_models INNER JOIN cop_variants ON cop_variants.model_id = cop_models.model_id WHERE cop_variants.variant_id = ' . $variantId . ') AS model_type')
                                )
                                    ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                                    ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                                    ->where('cop_features_ms.features_name', $featureItem->features_name)
                                    ->where('cop_fv.variant_id', $variantId)
                                    ->get();

                                // add all feature-value and su_name in 1 array
                                foreach ($feature_value as $fv_item) {

                                    if ($fv_item->model_type == 1 && ($featureItem->fuel_type == 1 || $featureItem->fuel_type == 2)) {
                                        if ($fv_item->feature_value == '' || $fv_item->feature_value == "NULL" || $fv_item->feature_value == null) {
                                            $value = 'N/A';
                                        } else {
                                            $value = $fv_item->feature_value;

                                            $power = config('constant.POWER');
                                            $power_ev = config('constant.POWER_EV');
                                            if($featureItem->features_name == $power || $featureItem->features_name == $power_ev){
                                                $checkBhp = check_bhp_exist($fv_item->feature_value);

                                                if(!$checkBhp){
                                                    if ($fv_item->su_name !== null && $fv_item->su_name !== "NULL") {
                                                        $value .= ' ' . $fv_item->su_name;
                                                    }
                                                }
                                            } else {
                                                if ($fv_item->su_name !== null && $fv_item->su_name !== "NULL") {
                                                    $value .= ' ' . $fv_item->su_name;
                                                }
                                            }
                                        }
                                    } else if ($fv_item->model_type == 0 && ($featureItem->fuel_type == 0 || $featureItem->fuel_type == 2)) {
                                        if ($fv_item->feature_value == '' || $fv_item->feature_value == "NULL" || $fv_item->feature_value == null) {
                                            $value = 'N/A';
                                        } else {
                                            $value = $fv_item->feature_value;

                                            $power = config('constant.POWER');
                                            $power_ev = config('constant.POWER_EV');
                                            if($featureItem->features_name == $power || $featureItem->features_name == $power_ev){
                                                $checkBhp = check_bhp_exist($fv_item->feature_value);

                                                if(!$checkBhp){
                                                    if ($fv_item->su_name !== null && $fv_item->su_name !== "NULL") {
                                                        $value .= ' ' . $fv_item->su_name;
                                                    }
                                                }
                                            } else {
                                                if ($fv_item->su_name !== null && $fv_item->su_name !== "NULL") {
                                                    $value .= ' ' . $fv_item->su_name;
                                                }
                                            }
                                        }
                                    } else {
                                        $value = 'NA';
                                    }

                                    $lastIndex = count($spec_cat['specification_category'][$key_spec_cat]['category'][$key_spec]['name']) - 1;
                                    $spec_cat['specification_category'][$key_spec_cat]['category'][$key_spec]['name'][$lastIndex]['feature_value'][] = $value;
                                }
                            }
                        }

                        $key_spec++;
                    }
                    $key_spec_cat++;
                }

            $data["card_data"] = $car_details;
            $data["basic_details"] = $feature_data;
            $data["specification_category"] = $spec_cat['specification_category'];

            return ResponseHelper::responseMessage('success', $data);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRETNLY -> compareModel) model list (website)
    public function compareModel(Request $request)
    {
        $expectedOrder = ['model_id', 'variant_id'];

        $selectedParameters = [];

        try {
            $compareCar = FeatureValue::select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_variants.variant_id',
                'cop_variants.variant_name',
                'cop_variants.variant_image',
                'cop_pe_ms.*',
            )
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_fv.brand_id')
                ->join('cop_models', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_variants', 'cop_variants.variant_id', '=', 'cop_fv.variant_id')
                ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                ->distinct('cop_variants,variant_id')
                ->where('cop_variants.status', '!=', 0);

            foreach ($expectedOrder as $parameter) {
                if ($request->has($parameter)) {
                    $compareCar->where('cop_fv.' . $parameter, $request->$parameter);
                    $selectedParameters[] = $parameter;
                } else {
                    break;
                }
            }
            // dd($compareCar->toSql());
            if (in_array('variant_id', $selectedParameters) && in_array('model_id', $selectedParameters)) {
                $compareCar = $compareCar->get();
                if ($compareCar->isEmpty()) {
                    // return ResponseHelper::responseMessage('error', 'Not Found');
                    return ResponseHelper::errorResponse('data_not_found');
                }

                $formattedData = $compareCar->map(function ($item) {

                    $data = [
                        'brand_id' => $item->brand_id,
                        'brand_name' => $item->brand_name,

                        'model_id' => $item->model_id,
                        'model_name' => $item->model_name,

                        'variant_id' => $item->variant_id,
                        'variant_name' => $item->variant_name,
                        'variant_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_image}" ?? null,
                    ];
                    return $data;
                });
                return ResponseHelper::responseMessage('success', $formattedData);
            }
            // Check if 'model_id' is selected
            if (in_array('model_id', $selectedParameters)) {
                $selectedModelId = $request->input('model_id');

                // Fetch variants matching with the selected model
                $variants = Variant::select('variant_id', 'variant_name')
                    ->where('model_id', $selectedModelId)
                    ->get();

                $variantData = [];
                foreach ($variants as $variant) {
                    $variantData[] = [
                        'variant_id' => $variant->variant_id,
                        'variant_name' => $variant->variant_name,
                    ];
                }

                // return response()->json(['variants' => $variantData]);
                return ResponseHelper::responseMessage('success', $variantData);
            } else {

                $data = [];
                $brands = Brand::select('brand_id', 'brand_name')
                    ->where('status', 1)
                    ->get();


                if (!empty($brands)) {
                    foreach ($brands as $brand) {
                        $brandData = [
                            'brand_id' => encryptor('e',$brand->brand_id),
                            'brand_name' => $brand->brand_name,
                            'models' => [],
                        ];

                        $models = Model::select('model_id', 'model_name')
                            ->where('brand_id', $brand->brand_id)
                            ->where('status', 1)
                            ->get();


                        foreach ($models as $model) {
                            $modelData = [
                                'model_id' => $model->model_id,
                                'model_name' => $model->model_name,
                                'variants' => [],
                            ];

                            $variants = Variant::select('variant_id', 'variant_name')
                                ->where('model_id', $model->model_id)
                                ->where('status', '=', 1)
                                ->get();

                            foreach ($variants as $variant) {
                                $variantData = [
                                    'variant_id' => $variant->variant_id,
                                    'variant_name' => $variant->variant_name,
                                ];

                                $modelData['variants'][] = $variantData;
                            }

                            $brandData['models'][] = $modelData;
                        }

                        $data['brands'][] = $brandData;
                    }
                }
            }
            return ResponseHelper::responseMessage('success', $data);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRETNLY -> compareAnswer) compare answer (website)
    public function compareAnswer(Request $request)
    {
        try {

            if (!$request->has('city_id') && trim($request->input('city_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $cityId = encryptor('d',$request->input('city_id'));
                if(!$cityId){
                    return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                }
            }

            if (!$request->has('variant_id') && trim($request->input('city_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $encVariantIds = explode(',', $request->input('variant_id'));
                foreach($encVariantIds as $variantId){
                    $decVariantId = encryptor('d',$variantId);
                    if(!$decVariantId){
                        return ResponseHelper::errorResponse('error',$variantId.' variant_id is not found');
                    }
                    $variantIds[] = encryptor('d',$variantId);
                }

                if (count($variantIds) < 2) {
                    return ResponseHelper::errorResponse('error','At least two variant_ids are required.');
                }
            }

            $data = [];
            $spec_cat = ['specification_category' => []];

            // $data = [
            //     'card_data' => [], // Initialize card_data as an empty array
            //     'basic_details' => [
            //         'ex_showroom_price' => '',
            //         'color_code' => [],
            //         'dual_color_code' => [],
            //     ],
            // ];
            // $spec_cat = [];

            // To get data of selected variant
            foreach ($variantIds as $variantId) {

                $compareCar = Variant::select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_variants.variant_id',
                    'cop_variants.variant_name',
                    'cop_variants.variant_image',
                )
                    ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_variants.brand_id')
                    ->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
                    ->where('cop_variants.variant_id', $variantId)
                    ->where('cop_variants.status', '=', 1)
                    ->distinct()
                    ->get();

                if ($compareCar->isEmpty()) {
                    return ResponseHelper::errorResponse('error','No data available for variant_id ' . $variantId);
                }

                $formattedData = $compareCar->map(function ($item) {
                    $data = [
                        'brand_id' => encryptor('e',$item->brand_id),
                        'brand_name' => $item->brand_name,
                        'model_id' => encryptor('e',$item->model_id),
                        'model_name' => $item->model_name,
                        // 'model_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp") ?? NULL,
                        'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp" ?? null,
                        'variant_id' => encryptor('e',$item->variant_id),
                        'variant_name' => $item->variant_name,
                        // 'variant_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_image}") ?? "",
                        'variant_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_image}" ?? null,

                        // 'basic_details' => [
                        //     'ex_showroom_price' => !empty($item->city_ex_showroom_price) ?  convertToLakhCrore($item->city_ex_showroom_price) : 'N/A',
                        //     'color_code' => [],
                        //     'dual_color_code' => [],
                        // ],

                    ];

                    // $colors = DB::table('cop_variants')
                    //     ->join('cop_colors', 'cop_variants.variant_id', '=', 'cop_colors.variant_id')
                    //     ->select('cop_colors.color_code', 'cop_colors.dual_color_code') // Corrected select statement
                    //     ->where('cop_colors.variant_id', $item->variant_id)
                    //     ->get();

                    // if (!empty($colors)) {
                    //     foreach ($colors as $color) {
                    //         $data['basic_details']['color_code'][] = $color->color_code;

                    //         $data['basic_details']['dual_color_code'][] = $color->dual_color_code   ?? null;
                    //     }
                    // }

                    return $data;
                });

                $data['card_data'][] = $formattedData[0];
            }

            // To check selected variants are EV, Non-EV or Both and append in one array
            foreach ($variantIds as $variantId) {
                $checkFuelType = Variant::select('cop_models.model_type')->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
                    ->where('cop_variants.variant_id', $variantId)
                    ->first();

                if (!empty($checkFuelType)) {
                    $variant_types[] = $checkFuelType->model_type == 1 ? "EV" : "Non-EV";
                }
            }

            // To check selected variants are EV, Non-EV or Both using array_unique and assign it to 1 variable
            if (!empty($variant_types)) {
                $unique_variant_types = array_unique($variant_types);

                if (count($unique_variant_types) == 1) {
                    $overall_variant_type = reset($unique_variant_types);
                    $all_variant_type = $overall_variant_type;
                } else {
                    $all_variant_type = 'Both';
                }
            }

            $spec_cat = ['specification_category' => []];

            // get all specification category (LOOP 1)
            $spec_cat_data = SpecificationCategory::all();

            $key_spec_cat = 0;
            foreach ($spec_cat_data as $specCatItem) {

                $spec_cat['specification_category'][] = [
                    'specification_catagory_name' => $specCatItem->sc_name,
                ];

                // get all specification (using above specification category) (LOOP 2)
                $spec = Specification::join('cop_sc_ms', 'cop_sc_ms.sc_id', '=', 'cop_spec_ms.sc_id')
                    ->where('sc_name', $specCatItem->sc_name)->get();

                $spec_cat['specification_category'][$key_spec_cat][$specCatItem->sc_name] = [];

                $key_spec = 0;
                foreach ($spec as $specItem) {
                    $spec_cat['specification_category'][$key_spec_cat][$specCatItem->sc_name][] = [
                        'specification_name' => $specItem->spec_name,
                        // 'spec_image' => asset("Specification/{$specItem->spec_id}/{$specItem->spec_image}") ?? "",
                        'spec_image' => $this->imagePath . "Specification/{$specItem->spec_id}/{$specItem->spec_image}" ?? null,
                    ];

                    // get all features (using above specification) (LOOP 3)
                    $featureQry = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', $specItem->spec_name);

                    if ($all_variant_type == 'EV') {
                        $feature = $featureQry->whereIn('cop_features_ms.fuel_type', [1, 2])
                            ->get();
                    } else if ($all_variant_type == 'Non-EV') {
                        $feature = $featureQry->whereIn('cop_features_ms.fuel_type', [0, 2])
                            ->get();
                    } else {
                        $feature = $featureQry->get();
                    }

                    $spec_cat['specification_category'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name] = [];

                    foreach ($feature as $featureItem) {

                        $spec_cat['specification_category'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name][] = [
                            'features_name' => $featureItem->features_name,
                            'feature_value' => []
                        ];

                        // get all feature-value (using above features_name and variant_id) (LOOP 4)
                        foreach ($variantIds as $variantId) {

                            $feature_value = FeatureValue::select(
                                DB::raw('(CASE WHEN COUNT(cop_fv.feature_value) = 0 THEN "NULL" ELSE MAX(cop_fv.feature_value) END) AS feature_value'),
                                DB::raw('(CASE WHEN COUNT(cop_su_ms.su_name) = 0 THEN "NULL" ELSE MAX(cop_su_ms.su_name) END) AS su_name'),
                                DB::raw('(SELECT cop_models.model_type FROM cop_models INNER JOIN cop_variants ON cop_variants.model_id = cop_models.model_id WHERE cop_variants.variant_id = ' . $variantId . ') AS model_type')
                            )
                                ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                                ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                                ->where('cop_features_ms.features_name', $featureItem->features_name)
                                ->where('cop_fv.variant_id', $variantId)
                                ->get();

                            // add all feature-value and su_name in 1 array
                            foreach ($feature_value as $fv_item) {

                                if ($fv_item->model_type == 1 && ($featureItem->fuel_type == 1 || $featureItem->fuel_type == 2)) {
                                    if ($fv_item->feature_value == '' || $fv_item->feature_value == "NULL" || $fv_item->feature_value == null) {
                                        $value = 'N/A';
                                    } else {
                                        $value = $fv_item->feature_value;

                                        if ($fv_item->su_name !== null && $fv_item->su_name !== "NULL") {
                                            $value .= ' ' . $fv_item->su_name;
                                        }
                                    }
                                } else if ($fv_item->model_type == 0 && ($featureItem->fuel_type == 0 || $featureItem->fuel_type == 2)) {
                                    if ($fv_item->feature_value == '' || $fv_item->feature_value == "NULL" || $fv_item->feature_value == null) {
                                        $value = 'N/A';
                                    } else {
                                        $value = $fv_item->feature_value;

                                        if ($fv_item->su_name !== null && $fv_item->su_name !== "NULL") {
                                            $value .= ' ' . $fv_item->su_name;
                                        }
                                    }
                                } else {
                                    $value = 'NA';
                                }

                                $lastIndex = count($spec_cat['specification_category'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name]) - 1;
                                $spec_cat['specification_category'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name][$lastIndex]['feature_value'][] = $value;
                            }
                        }
                    }

                    $key_spec++;
                }
                $key_spec_cat++;
            }



            $data["specification_category"] = $spec_cat['specification_category'];

            return ResponseHelper::responseMessage('success', $data);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
