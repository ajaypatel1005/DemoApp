<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class FeatureValueApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> This Controller)
}
