<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Model;
use App\Models\Variant;
use App\Models\CarStage;
use Exception;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Brand;
use App\Models\CarGraphic;
use App\Models\City;
use App\Models\CarListingData;
use App\Models\CarType;
use App\Models\Color;
use App\Models\Feature;
use App\Models\PriceEntry;
use App\Models\SpecificationCategory;
use App\Models\Specification;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Models\Wishlist;
use Illuminate\Support\Facades\Log;

class ModelApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    private function pricefilter($model_id)
    {
        try {
            // dd($model_id);
            $priceMinMax = Model::select(
                DB::raw('MIN(cop_pe_ms.ex_showroom_price) as min_ex_showroom_price'),
                DB::raw('MAX(cop_pe_ms.ex_showroom_price) as max_ex_showroom_price')
            )
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->where('cop_models.model_id', $model_id)
                // ->where('cop_models.model_type', '0')
                ->first();

            return [
                'price_filter' => $priceMinMax['min_ex_showroom_price'],
                'min_ex_showroom_price' =>  convertToLakhCrore($priceMinMax['min_ex_showroom_price']),
                'max_ex_showroom_price' =>  convertToLakhCrore($priceMinMax['max_ex_showroom_price']),
            ];
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function formatModel($models, $power, $engine, $wishlist)
    {
        try {
                // dd($power, $engine);
                $formattedData = $models->map(function ($item) use ($power, $engine) {
                $powerDetails = $power->where('model_id', $item->model_id)->first();
                $engineDetails = $engine->where('model_id', $item->model_id)->first();
                if ($powerDetails === null) {
                    dd("Power details are null for model name & ID: {$item->model_name} : {$item->model_id}");
                }

                if ($engineDetails === null) {
                    dd("Engine details are null for model name & ID: {$item->model_name} : {$item->model_id}");
                }
                $data = [
                    'model_id' => encryptor('e', $item->model_id),
                    'car_stage' => $item->cs_name,
                    'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp" ?? NULL,
                    'launch_date' => $item->launch_date,
                    'brand_name' => $item->brand_name,
                    'brand_description' => $item->brand_description,
                    'model_name' => $item->model_name,
                    'price' => $this->pricefilter($item->model_id),
                    // 'min_price' =>  convertToLakhCrore($item->min_price),
                    // 'max_price' =>  convertToLakhCrore($item->max_price),
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                    'rating_type_name' => $item->rating_type_name ?? NULL,
                    'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : NULL,
                    'wishlist' => $item->wishlist,

                    'power' => [
                        'feature_id' => $powerDetails->feature_id ?? null,
                        'features_image' =>  $this->imagePath . "Feature/{$powerDetails->feature_id}/{$powerDetails->feature_id}.svg" ?? NULL,
                        'feature_value' => $powerDetails->feature_value ?? NULL,
                        'su_name' => $powerDetails->su_name ?? NULL,
                    ],
                    'engine' => [
                        'feature_id' => $engineDetails->feature_id ?? null,
                        'features_image' => $this->imagePath . "Feature/{$engineDetails->feature_id}/{$engineDetails->feature_id}.svg" ?? NULL,
                        'feature_value' => $engineDetails->feature_value ?? NULL,
                        'su_name' => $engineDetails->su_name ?? NULL,
                    ],
                ];

                return $data;
            });

            return $formattedData;
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    private function getFeatureDetails($featureName)
    {
        try {
            $data = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                // ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_fv', 'cop_fv.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                ->select(
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_features_ms.feature_id',
                    'cop_features_ms.features_image',
                    'cop_fv.fv_id',
                    'cop_fv.feature_value',
                    'cop_su_ms.su_name',
                    'cop_models.status',
                    'cop_brands_ms.status',
                    'cop_fv.status',
                )->where('cop_features_ms.features_name', $featureName)
                ->where('cop_models.status', '=', 1)
                ->where('cop_brands_ms.status', '=', 1)
                ->where('cop_fv.status', '=', 1)
                ->where('cop_features_ms.status', '=', 1)
                ->distinct()

                ->get();
            // dd($data );

            if ($data->isEmpty()) {
                // return ResponseHelper::errorResponse('data_not_found');
                return ResponseHelper::errorResponse('data_not_found');
            }

            return $data;
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRENTLY -> trendingModel)
    public function trendingModel(Request $request)
    {
        try {
            if (!$request->has('model_id') && trim($request->type) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            }
            if ($request->type == 'Upcoming Car') {

                $currentDate = now()->toDateString();
                $date90DaysLater = now()->addDays(90)->toDateString();
                // dd($date90DaysLater);
                // dd($currentDate);

                $models = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                    ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')

                    ->leftJoin('cop_ratings', function ($join) {
                        $join->on('cop_ratings.model_id', '=', 'cop_models.model_id')
                            ->where('cop_cs_ms.cs_name', '!=', 'Upcoming');
                    })
                    ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                    ->select(
                        'cop_models.*',
                        'cop_cs_ms.cs_name',
                        'cop_brands_ms.brand_name',
                        'cop_brands_ms.brand_description',
                        'cop_ct_ms.ct_name',
                        DB::raw('COALESCE(cop_ratings.rating_value, NULL) as rating_value'),
                        'cop_rating_types.rating_type_name'
                    )
                    ->where('cop_cs_ms.cs_name', '=', 'Upcoming')
                    ->where('cop_models.launch_date', '>', $date90DaysLater)
                    ->where('cop_brands_ms.status', '=', 1)
                    ->where('cop_models.status', '=', 1)
                    ->distinct()
                    ->get();

                // if ($models->isEmpty()) {
                //     return ResponseHelper::errorResponse('data_not_found');
                // }

                $power = $this->getFeatureDetails('Power');
                $engine = $this->getFeatureDetails('Displacement');

                $powerEV = $this->getFeatureDetails('Power (EV)');
                // dd($powerEV);
                $range = $this->getFeatureDetails('Range');

                $responseArray = [];

                foreach ($models as $model) {

                    $model->power = $powerEV->where('model_id', $model->model_id)->first();
                    $model->range = $range->where('model_id', $model->model_id)->first();

                    $model->power = $power->where('model_id', $model->model_id)->first();
                    $model->engine = $engine->where('model_id', $model->model_id)->first();

                    $wishlistGet = Wishlist::where('model_id', $model->model_id)
                        ->where('customer_id', Auth::guard('api')->id())
                        ->exists();

                    $model->wishlist = $wishlistGet ? true : false;


                    $responseArray[] = $model;
                }

                $wishlist = [];
                $formattedData = $this->bugdetformatModel(collect($responseArray), $power, $engine, $powerEV, $range, $wishlist);


                return ResponseHelper::responseMessage('success', $formattedData);
            } else if ($request->type == 'Popular Car') {

                $models = CarListingData::select(
                    'cop_models.*',
                    'cop_msd.*',
                    'cop_cl_ms.cl_name',
                    'cop_brands_ms.brand_name',
                    'cop_brands_ms.brand_description',
                    'cop_ratings.rating_id',
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                )
                    ->leftJoin('cop_cl_ms', 'cop_cl_data.cl_id', '=', 'cop_cl_ms.cl_id')
                    ->leftJoin('cop_brands_ms', 'cop_cl_data.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_models', 'cop_cl_data.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                    ->where('cop_cl_data.status', '=', 1)
                    ->where('cop_brands_ms.status', '=', 1)
                    ->where('cop_models.status', '=', 1)
                    ->where('cop_cl_ms.cl_name', '=', 'Popular Cars')
                    ->distinct("cop_models.model_id")
                    ->get();
                $power = $this->getFeatureDetails('Power');
                $engine = $this->getFeatureDetails('Displacement');


                $responseArray = [];

                foreach ($models as $model) {
                    $model->power = $power->where('model_id', $model->model_id)->first();
                    $model->engine = $engine->where('model_id', $model->model_id)->first();

                    // dd(Auth::guard('api')->id());
                    $wishlistGet = Wishlist::where('model_id', $model->model_id)
                        ->where('customer_id', Auth::guard('api')->id())
                        ->exists();
                    // dd($wishlistGet);
                    $model->wishlist = $wishlistGet ? true : false;



                    $responseArray[] = $model;
                }
                $wishlist = [];
                // dd($responseArray);
                $formattedData = $this->formatModel(collect($responseArray), $power, $engine, $wishlist);


                return ResponseHelper::responseMessage('success', $formattedData);
            } else if ($request->type == 'Ev Car') {

                $models = CarListingData::select(
                    'cop_models.*',
                    'cop_msd.*',
                    'cop_cl_ms.cl_name as cl_name',
                    'cop_brands_ms.brand_name as brand_name',
                    'cop_brands_ms.brand_description',
                    'cop_ratings.rating_id',
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                )
                    ->leftJoin('cop_cl_ms', 'cop_cl_data.cl_id', '=', 'cop_cl_ms.cl_id')
                    ->leftJoin('cop_brands_ms', 'cop_cl_data.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_models', 'cop_cl_data.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                    ->where('cop_cl_data.status', '=', 1)
                    ->where('cop_brands_ms.status', '=', 1)
                    ->where('cop_models.status', '=', 1)
                    ->where('cop_cl_ms.cl_name', '=', 'EV Cars')
                    ->distinct("cop_models.model_id")
                    ->get();

                // if ($models->isEmpty()) {
                //     return ResponseHelper::errorResponse('data_not_found');
                // }

                $power = $this->getFeatureDetails('Power (EV)');
                $engine = $this->getFeatureDetails('Range');

                $responseArray = [];

                foreach ($models as $model) {
                    $model->power = $power->where('model_id', $model->model_id)->first();
                    $model->engine = $engine->where('model_id', $model->model_id)->first();
                    $wishlistGet = Wishlist::where('model_id', $model->model_id)
                        ->where('customer_id', Auth::guard('api')->id())
                        ->exists();

                    // Set the wishlist property directly on the model object
                    $model->wishlist = $wishlistGet ? true : false;
                    $responseArray[] = $model;
                }
                $wishlist = [];

                $formattedData = $this->formatModel(collect($responseArray), $power, $engine, $wishlist);


                return ResponseHelper::responseMessage('success', $formattedData);
            } else {

                return ResponseHelper::errorResponse('data_not_found');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    public function trending_model(Request $request)
    {
        try {
            if (!$request->has('type') && trim($request->type) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $city_id = ($request->has('city_id'))?encryptor('d',$request->input('city_id')):0;

            $auth_id=Auth::guard('api')->id();
            if ($request->type == 'Upcoming Car') {

                $currentDate = now()->toDateString();
                $date90DaysLater = now()->addDays(90)->toDateString();
                $models = Model::select('cop_models.model_id','cop_models.brand_id','cop_models.model_image','cop_models.model_name','cop_models.min_price','cop_models.max_price','cop_models.launch_date',DB::raw("CASE WHEN cop_models.model_type = 0 THEN 'Non Ev' ELSE 'EV' END AS get_model_type"),'cop_brands_ms.brand_name')
                ->leftJoin('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
                ->leftJoin('cop_msd','cop_msd.model_id','=','cop_models.model_id')
                ->leftJoin('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
                ->where('cop_cs_ms.cs_name', '=', 'Upcoming')
                ->where('cop_models.launch_date', '>=', $currentDate)
                ->where('cop_models.launch_date', '<=', $date90DaysLater)

                    ->where('cop_brands_ms.status', '=', 1)
                    ->where('cop_models.status', '=', 1)
                    ->limit(10);

                $formattedData = [];
                $res = $models->get()->map(function ($data) use (&$formattedData) {

                    $launchDateOnString = $data->launch_date;
                    $strToTime = strtotime($launchDateOnString);
                    $launch_date = date('d F, Y', $strToTime);
            
                    $formattedData[] = [
                        'model_id' => encryptor('e', $data->model_id),
                        'model_image' => $this->imagePath . "brands/{$data->brand_id}/{$data->model_id}/{$data->model_image}",
                        'launch_date' => $launch_date,
                        'model_name' => $data->model_name,
                        'price' => [
                            'min_ex_showroom_price' =>   convertToLakhCrore($data->min_price),
                            'max_ex_showroom_price' =>  convertToLakhCrore($data->max_price),
                        ],
                        'model_type' => $data->get_model_type,
                        'brand_name' => $data->brand_name
                    ];
                });
                return ResponseHelper::responseMessage('success', $formattedData);
            } else if ($request->type == 'Popular Car' || $request->type == 'EV Car') {
                $carType = '';
                if ($request->type == 'Popular Car') {
                    $carType = 'Popular Cars';
                } else {
                    $carType = 'EV Cars';
                }
                $displacement = config('constant.DISPLACEMENT');
                $power = config('constant.POWER');
                $range = config('constant.RANGE');
                $power_ev = config('constant.POWER_EV');
                $non_ev = config('constant.NONEV_CAR_TYPE');
                $ev = config('constant.EV_CAR_TYPE');
                if (!empty($city_id)) {
                    $minmaxQry = "(select min(ex_showroom_price) from cop_pe_ms where cop_pe_ms.model_id=cop_models.model_id and cop_pe_ms.city_id=$city_id) as min_price,(select max(ex_showroom_price) from cop_pe_ms where model_id=cop_models.model_id and cop_pe_ms.city_id=$city_id) as max_price";
                } else {
                    $minmaxQry = "(select min(ex_showroom_price) from cop_pe_ms where model_id=cop_models.model_id ) as min_price,(select max(ex_showroom_price) from cop_pe_ms where model_id=cop_models.model_id) as max_price";
                }
                $models = CarListingData::select(
                    'cop_models.model_id','cop_models.brand_id','cop_models.model_image','cop_models.model_name',
                    DB::raw("CASE WHEN cop_models.model_type = 0 THEN 'Non Ev' ELSE 'EV' END AS get_model_type"),'cop_cs_ms.cs_name','cop_models.launch_date',
                    'cop_cl_ms.cl_name','cop_brands_ms.brand_name','cop_brands_ms.brand_description',
                    'cop_ratings.rating_id', 'cop_ratings.rating_value', 'cop_rating_types.rating_type_name',
                    DB::raw("( SELECT CONCAT('[',GROUP_CONCAT( DISTINCT JSON_OBJECT( CASE WHEN cop_features_ms.features_name='".$power."' and cop_models.model_type=".$non_ev." THEN 'Power' WHEN cop_features_ms.features_name='".$displacement."' and cop_models.model_type=".$non_ev." THEN 'Engine' WHEN cop_features_ms.features_name='".$power_ev."' and cop_models.model_type=".$ev." THEN 'Power' WHEN cop_features_ms.features_name='".$range."' and cop_models.model_type=".$ev." THEN 'Engine' END,
                                JSON_OBJECT( 'feature_id', cop_features_ms.feature_id,
                                    'feature_name', cop_features_ms.features_name,
                                    'features_image', cop_features_ms.features_image,
                                    'feature_value', cop_fv.feature_value,
                                    'su_name', cop_su_ms.su_name
                                ) ) ),']') FROM cop_fv 
                            LEFT JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id
                            LEFT JOIN cop_su_ms ON cop_su_ms.su_id = cop_features_ms.su_id
                            WHERE cop_fv.variant_id = (SELECT cop_pe_ms.variant_id FROM cop_pe_ms WHERE cop_pe_ms.model_id = cop_models.model_id ORDER BY cop_pe_ms.ex_showroom_price ASC LIMIT 1)
                                AND ( CASE WHEN cop_models.model_type=0 THEN cop_features_ms.features_name in('".$power."','".$displacement."') ELSE cop_features_ms.features_name IN('".$power_ev."','".$range."') END ) ) AS feature_json"),
                        DB::raw($minmaxQry), DB::raw("(select wl_id from cop_wl where cop_wl.model_id=cop_models.model_id and customer_id = '".$auth_id."') as wl_id")
                )
                    ->leftJoin('cop_cl_ms', 'cop_cl_data.cl_id', '=', 'cop_cl_ms.cl_id')
                    ->leftJoin('cop_brands_ms', 'cop_cl_data.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_models', 'cop_cl_data.model_id', '=', 'cop_models.model_id')
                    ->join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                    ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                    ->where('cop_cl_data.status', '=', 1)
                    ->where('cop_brands_ms.status', '=', 1)
                    ->where('cop_models.status', '=', 1)
                    ->where('cop_cl_ms.cl_name', '=', $carType)
                    ->distinct("cop_models.model_id");
                    $formattedData=[];
                    $res = $models->get()->map(function($data) use(&$formattedData){
                        $feature_json = !empty($data->feature_json) ? json_decode($data->feature_json) : [];
                        $featureArr = [];
                        for($i=0;$i<count($feature_json);$i++){
                            foreach($feature_json[$i] as $featureKey=>$featureData){
                                $featureArr[$featureKey]=['feature_id'=>$featureData->feature_id,
                                                            'feature_image'=>$this->imagePath . "Feature/".$featureData->feature_id."/".$featureData->features_image,
                                                            'feature_value'=>$featureData->feature_value,
                                                            'su_name'=>$featureData->su_name
                                                        ];
                            }
                        }
                        $formattedData[]=[
                            'model_id' => encryptor('e',$data->model_id),
                            'car_stage' => $data->cs_name,
                            'model_image' => $this->imagePath . "brands/{$data->brand_id}/{$data->model_id}/{$data->model_image}",
                            'launch_date' => $data->launch_date,
                            'brand_name' => $data->brand_name,
                            'brand_description' => $data->brand_description,
                            'model_name' => $data->model_name,
                            'price' => ['min_ex_showroom_price' =>  convertToLakhCrore($data->min_price),
                                        'max_ex_showroom_price' =>  convertToLakhCrore($data->max_price)
                                        ],
                            'model_type' => $data->get_model_type,
                            'rating_type_name' => $data->rating_type_name ?? 'N/A',
                            'rating_value' => isset($data->rating_value) ? number_format((float)$data->rating_value, 1, '.', '') : 'N/A',
                            'wishlist' => (!empty($data->wl_id)?true:false),
                            'Engine'=>$featureArr['Engine']??"",
                            'Power'=>$featureArr['Power']??"",
                        ];
                    });
                return ResponseHelper::responseMessage('success', $formattedData);
            } else {
                return ResponseHelper::errorResponse('data_not_found');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('error');
        }
    }

    public function electric_Car(Request $request)
    {
        try {
            $city_id = ($request->has('city_id'))?encryptor('d',$request->input('city_id')):0;
            if (!empty($city_id)) {
                $minmaxQry = "(select min(ex_showroom_price) from cop_pe_ms where cop_pe_ms.model_id=cop_models.model_id and cop_pe_ms.city_id=$city_id) as min_price,(select max(ex_showroom_price) from cop_pe_ms where model_id=cop_models.model_id and cop_pe_ms.city_id=$city_id) as max_price";
            } else {
                $minmaxQry = "(select min(ex_showroom_price) from cop_pe_ms where model_id=cop_models.model_id ) as min_price,(select max(ex_showroom_price) from cop_pe_ms where model_id=cop_models.model_id) as max_price";
            }
            $evCar_models = Model::join('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_banners', 'cop_banners.model_id', '=', 'cop_models.model_id')
                ->join('cop_bc_ms', 'cop_bc_ms.bc_id', '=', 'cop_banners.bc_id')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->select(
                    'cop_brands_ms.brand_name',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_type',
                    'cop_models.min_price',
                    'cop_models.max_price',
                    'cop_msd.model_engine',
                    'cop_msd.model_bhp',
                    'cop_msd.model_transmission',
                    'cop_msd.model_mileage',
                    'cop_msd.model_fuel',
                    'cop_banners.banner_id',
                    'cop_banners.banner_image_mob',
                    DB::raw($minmaxQry)
                )
                ->where('cop_bc_ms.bc_name', '=', config('constant.EV_banner'))
                ->where('cop_banners.status', '=', 1)
                ->where('cop_brands_ms.status', '=', 1)
                ->where('cop_models.model_type', '=', 1)
                ->whereNotNull('cop_banners.model_id')
                ->where(function ($query) use ($request) {
                    $query->where('cop_models.model_name', 'like', '%' . $request->search . '%')
                        ->orWhere('cop_brands_ms.brand_name', 'like', '%' . $request->search . '%');
                })
                ->distinct()
                ->get();

            if ($evCar_models->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }
            $inputType = ['Battery Capacity', 'Power (EV)', 'Range', 'Charging Time (AC)'];

            $su_data = Feature::leftJoin('cop_su_ms', 'cop_features_ms.su_id', '=', 'cop_su_ms.su_id')
                ->whereIn('cop_features_ms.features_name', $inputType)
                ->select('cop_su_ms.su_id', 'cop_su_ms.su_name', 'cop_features_ms.features_image', 'cop_features_ms.feature_id', 'cop_features_ms.features_name')
                ->orderBy(DB::raw("CASE
                                    WHEN cop_features_ms.features_name = 'Battery Capacity' THEN 1
                                    WHEN cop_features_ms.features_name = 'Range' THEN 2
                                    WHEN cop_features_ms.features_name = 'Power (EV)' THEN 3
                                    WHEN cop_features_ms.features_name = 'Charging Time (AC)' THEN 4
                                    ELSE 6
                                END"))
                ->get();
            $format_data = $su_data->map(function ($item) {
                $feature = [
                    'su_id' => encryptor('e',$item->su_id) ?? NULL,
                    'feature_id' => encryptor('e',$item->feature_id),
                    'features_name' => $item->features_name,
                    'su_name' => $item->su_name ?? NULL,
                    'features_image' =>  $this->imagePath . "Feature/{$item->feature_id}/{$item->features_image}",
                ];
                return $feature;
            });

            $formattedData = $evCar_models->map(function ($item) {
                $data = [
                    'banner_id' => encryptor('e', $item->banner_id),
                    'model_id' => encryptor('e', $item->model_id),
                    'brand_name' => $item->brand_name,
                    'model_name' => $item->model_name,
                    'price' => [
                        'min_price' =>  convertToLakhCrore($item->min_price),
                        'max_price' =>  convertToLakhCrore($item->max_price),
                        ],
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                    'Battery_Capacity' => $item->model_engine, // battery capacity
                    'Power' => $item->model_bhp, // Power
                    'Type_of_Transmission' => $item->model_transmission, //
                    'Range' => $item->model_mileage, // Power
                    'Charging_Time' => $item->model_fuel, //
                    'banner_image' => $this->imagePath . "Banner/{$item->banner_id}/{$item->banner_image_mob}",
                ];
                return $data;
            });
            $combinedData = [
                'feature' => $format_data,
                'Ev_Car' => $formattedData,
            ];
            return ResponseHelper::responseMessage('success', $combinedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function bugdetformatModel($models, $power, $engine, $powerEV, $range, $wishlist)
    {
        try {
                // dd($power);
                $formattedData = $models->map(function ($item) use ($power, $engine, $powerEV, $range) {
                $powerDetails = $power->where('model_id', $item->model_id)->first();
                $engineDetails = $engine->where('model_id', $item->model_id)->first();
                $powerEVDetails = $powerEV->where('model_id', $item->model_id)->first();
                $rangeDetails = $range->where('model_id', $item->model_id)->first();
                //  dd($engineDetails);
                if ($powerDetails === null) {
                    // dd("Power details are null for model name & ID: {$item->model_name} : {$item->model_id}");
                }

                if ($engineDetails === null) {
                    // dd("Engine details are null for model name & ID: {$item->model_name} : {$item->model_id}");
                }

                // dd($powerDetails->feature_id);
                $feature_id = ($item->model_type == 0) ? (($powerDetails === null) ? '-' : $powerDetails->feature_id) : (($powerEVDetails === null) ? '-' : $powerEVDetails->feature_id);

                $feature_value = ($item->model_type == 0) ? (($powerDetails === null) ? '-' : $powerDetails->feature_value) : (($powerEVDetails === null) ? '-' : $powerEVDetails->feature_value);

                $su_name = ($item->model_type == 0) ? (($powerDetails === null) ? '-' : $powerDetails->su_name) : (($powerEVDetails === null) ? '-' : $powerEVDetails->su_name);


                $feature_iden = ($item->model_type == 0) ? (($engineDetails === null) ? '-' : $engineDetails->feature_id) : (($rangeDetails === null) ? '-' : $rangeDetails->feature_id);

                $feature_valueen = ($item->model_type == 0) ? (($engineDetails === null) ? '-' : $engineDetails->feature_value) : (($rangeDetails === null) ? '-' : $rangeDetails->feature_value);

                $su_nameen = ($item->model_type == 0) ? (($engineDetails === null) ? '-' : $engineDetails->su_name) : (($rangeDetails === null) ? '-' : $rangeDetails->su_name);


                $data = [
                    'model_id' => encryptor('e', $item->model_id),
                    'car_stage' => $item->cs_name,
                    'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp" ?? NULL,
                    'launch_date' => $item->launch_date,
                    'brand_name' => $item->brand_name,
                    'model_name' => $item->model_name,
                    'price' => $this->pricefilter($item->model_id),
                    // 'min_price' =>  convertToLakhCrore($item->min_price),
                    // 'max_price' =>  convertToLakhCrore($item->max_price),
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                    'rating_type_name' => $item->rating_type_name ?? NULL,
                    'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : NULL,
                    'wishlist' => $item->wishlist,
                    'power' => [
                        'feature_id' => $feature_id,
                        'features_image' =>  $this->imagePath . "Feature/{$feature_id}/{$feature_id}.svg" ?? NULL,
                        'feature_value' => $feature_value,
                        'su_name' => $su_name,
                    ],
                    'engine' => [
                        'feature_id' => $feature_iden,
                        'features_image' => $this->imagePath . "Feature/{$feature_iden}/{$feature_iden}.svg" ?? NULL,
                        'feature_value' => $feature_valueen,
                        'su_name' => $su_nameen,
                    ],
                ];
                // dd($data);
                return $data;
            });

            return $formattedData;
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // to get by_budget data on index page (6-4-24)
    public function budgetBy(Request $request)
    {
        try {
            // to get user id
            $auth_id = Auth::guard('api')->id();

            // city_id input field
            if ($request->has('city_id') && ($request->city_id != "" || $request->city_id != null)) {
                $city_id_dec = encryptor('d', $request->input('city_id'));
                if (!$city_id_dec) {
                    return ResponseHelper::errorResponse('error', $request->input('city_id') . ' city_id is not found');
                } else {
                    $city = City::find($city_id_dec);

                    if (!$city) {
                        return ResponseHelper::errorResponse('error', $request->input('city_id') . ' city_id is not found');
                    } else {
                        $city_id = $city_id_dec;
                    }
                }
            }

            // min_price input field
            if (!$request->has('min_price') && trim($request->input('min_price')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                if (!is_numeric($request->min_price)) {
                    return ResponseHelper::errorResponse('error', 'min_price should be numbers only');
                } else {
                    if ($request->min_price < 200000 || $request->min_price > 200000000) {
                        return ResponseHelper::errorResponse('error', 'min_price should be 2 lakh to 20 cr only');
                    } else {
                        $min_price = $request->min_price;
                    }
                }
            }

            // max_price input field
            if (!$request->has('max_price') && trim($request->input('max_price')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                if (!is_numeric($request->max_price)) {
                    return ResponseHelper::errorResponse('error', 'max_price should be numbers only');
                } else {
                    if ($request->max_price < 200000 || $request->max_price > 200000000) {
                        return ResponseHelper::errorResponse('error', 'max_price should be 2 lakh to 20 cr only');
                    } else {
                        $max_price = $request->max_price;
                    }
                }
            }

            // feature value
            $displacement = config('constant.DISPLACEMENT');
            $power = config('constant.POWER');
            $non_ev_model_type = config('constant.NONEV_CAR_TYPE');

            if ($request->city_id != "" || $request->city_id != null) {
                $minmaxQry = "(select min(ex_showroom_price) from cop_pe_ms where cop_pe_ms.model_id = cop_models.model_id and cop_pe_ms.city_id = $city_id) as min_price,
                (select max(ex_showroom_price) from cop_pe_ms where cop_pe_ms.model_id = cop_models.model_id and cop_pe_ms.city_id = $city_id) as max_price";
            } else {
                $minmaxQry = "(select min(ex_showroom_price) from cop_pe_ms where cop_pe_ms.model_id = cop_models.model_id ) as min_price,
                (select max(ex_showroom_price) from cop_pe_ms where cop_pe_ms.model_id = cop_models.model_id) as max_price";
            }

            // car_stage as launched
            $carStageLaunched = config('constant.CAR_STAGE_LAUNCHED');

            // query to get model data
            $query = Variant::select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_models.model_image',
                'cop_rating_types.rating_type_name',
                'cop_ratings.rating_value',
                DB::raw($minmaxQry),
                DB::raw("( SELECT CONCAT('[',GROUP_CONCAT( DISTINCT JSON_OBJECT( CASE WHEN cop_features_ms.features_name='" . $power . "' THEN 'Power' WHEN cop_features_ms.features_name='" . $displacement . "' THEN 'Engine' END,
                                JSON_OBJECT(
                                    'feature_id', cop_features_ms.feature_id,
                                    'feature_name', cop_features_ms.features_name,
                                    'features_image', cop_features_ms.features_image,
                                    'feature_value', cop_fv.feature_value,
                                    'su_name', cop_su_ms.su_name
                                )
                            )
                            ),']') FROM cop_fv
                            LEFT JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id
                            LEFT JOIN cop_su_ms ON cop_su_ms.su_id = cop_features_ms.su_id
                            WHERE cop_features_ms.features_name IN ('" . $displacement . "','" . $power . "') AND cop_fv.model_id = cop_models.model_id LIMIT 1
                        ) AS feature_json"),
                DB::raw("(select wl_id from cop_wl where cop_wl.model_id = cop_models.model_id and customer_id = '$auth_id') as wl_id")
            )
                ->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_rating_types', 'cop_rating_types.rating_type_id', '=', 'cop_ratings.rating_type_id')
                ->where('cop_models.model_type', $non_ev_model_type)
                ->where('cop_brands_ms.status', '=', 1)
                ->where('cop_models.status', '=', 1)
                ->where('cop_variants.status', '=', 1)
                ->where('brand_name', '!=', 'Force');

            if ($request->city_id != "" || $request->city_id != null) {
                $query->whereRaw("cop_variants.model_id IN (select min(model_id) from cop_pe_ms where city_id=$city_id and cop_pe_ms.status=1 and ex_showroom_price between $min_price and $max_price group by brand_id)");
            } else {
                $query->whereRaw("cop_variants.model_id IN (select min(model_id) from cop_pe_ms where cop_pe_ms.status=1 and ex_showroom_price between $min_price and $max_price group by brand_id)");
            }

            $modelData = $query->distinct()->limit(10)->get();

            // formate the data
            $by_budget_model_data = [];
            $featureArr = [];
            $modelData->map(function ($item) use (&$by_budget_model_data,&$featureArr) {
                $feature_json = json_decode($item->feature_json);
                
                $engine = true;
                $power = true;
                for ($i = 0; $i < count($feature_json); $i++) {
                    foreach ($feature_json[$i] as $featureKey => $featureData) {

                        if($featureKey == 'Engine' && $engine == true){
                            $featureArr[$featureKey] = [
                                'feature_id' => $featureData->feature_id,
                                'feature_image' => $this->imagePath . "Feature/" . $featureData->feature_id . "/" . $featureData->features_image,
                                'feature_value' => $featureData->feature_value,
                                'su_name' => $featureData->su_name
                            ];
                            $engine = false; // make this as false so that another engine data not enter herewith for same model_id
                        }

                        if($featureKey == 'Power' && $power == true){
                            $featureArr[$featureKey] = [
                                'feature_id' => $featureData->feature_id,
                                'feature_image' => $this->imagePath . "Feature/" . $featureData->feature_id . "/" . $featureData->features_image,
                                'feature_value' => $featureData->feature_value,
                                'su_name' => $featureData->su_name
                            ];
                            $power = false; // make this as false so that another power data not enter herewith for same model_id
                        }
                    }
                }

                $by_budget_model_data[] = [
                    'model_id' => encryptor('e', $item->model_id),
                    'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_image}",
                    'brand_name' => $item->brand_name,
                    'model_name' => $item->model_name,
                    'price' => [
                        'min_ex_showroom_price' =>  convertToLakhCrore($item->min_price),
                        'max_ex_showroom_price' =>  convertToLakhCrore($item->max_price)
                    ],
                    'rating_type_name' => $item->rating_type_name ?? 'N/A',
                    'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : 'N/A',
                    'wishlist' => $item->wl_id ? true : false,
                    'Engine' => $featureArr['Engine'],
                    'Power' => $featureArr['Power'],
                ];
            });


            // old code of budgetBy (change to above and currently commentout the below old code)

            // $cityName = $request->input('cityname');
            // if ($cityName == "" || $cityName == null) {
            //     $formattedData = ['cityname required'];
            //     return ResponseHelper::responseMessage('success', $formattedData);
            // }
            // $minPrice = $request->input('minprice');
            // $maxPrice = $request->input('maxprice');
            // $models = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
            //     ->leftjoin('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
            //     ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            //     ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
            //     ->leftJoin('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
            //     ->leftJoin('cop_city_ms', 'cop_pe_ms.city_id', '=', 'cop_city_ms.city_id')
            //     ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
            //     ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
            //     ->select([
            //         'cop_cs_ms.cs_id',
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_cs_ms.cs_name) as cs_name'),
            //         'cop_models.model_id',
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_models.model_name) as model_name'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_models.model_name) as model_name'),
            //         DB::raw('MAX(cop_models.min_price) as min_price'),
            //         DB::raw('MAX(cop_models.max_price) as max_price'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_msd.model_engine) as model_engine'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_msd.model_bhp) as model_bhp'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_msd.model_transmission) as model_transmission'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_msd.model_mileage) as model_mileage'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_msd.model_fuel) as model_fuel'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_brands_ms.brand_id) as brand_id'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_brands_ms.brand_name) as brand_name'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_ratings.rating_id) as rating_id'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_ratings.rating_value) as rating_value'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_rating_types.rating_type_name) as rating_type_name'),
            //         DB::raw('MAX(cop_pe_ms.ex_showroom_price) as ex_showroom_price'),
            //         DB::raw('GROUP_CONCAT(DISTINCT cop_city_ms.city_name) as city_name'),
            //     ])
            //     ->where('cop_brands_ms.status', '=', 1)
            //     ->where('cop_models.status', '=', 1)
            //     ->where('cop_variants.status', '=', 1)
            //     ->where('cop_pe_ms.status', '=', 1)
            //     ->where('cop_city_ms.status', '=', 1)
            //     ->where('cop_models.model_type', '=', 0)
            //     ->where('cop_city_ms.city_name', '=', $cityName)
            //     ->where('cop_cs_ms.cs_name', '=', 'Launched')
            //     ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
            //     ->groupBy('cop_models.model_id', 'cop_cs_ms.cs_id')
            //     ->distinct()
            //     ->limit(10)
            //     ->get();


            // // if ($models->isEmpty()) {
            // //     return ResponseHelper::errorResponse('data_not_found');
            // // }
            // $power = $this->getFeatureDetails('Power');
            // $engine = $this->getFeatureDetails('Displacement');

            // $powerEV = $this->getFeatureDetails('Power (EV)');
            // // dd($powerEV);
            // $range = $this->getFeatureDetails('Range');

            // $responseArray = [];

            // foreach ($models as $model) {



            //     $model->power = $powerEV->where('model_id', $model->model_id)->first();
            //     $model->range = $range->where('model_id', $model->model_id)->first();

            //     $model->power = $power->where('model_id', $model->model_id)->first();
            //     $model->engine = $engine->where('model_id', $model->model_id)->first();
            //     $wishlistGet = Wishlist::where('model_id', $model->model_id)
            //         ->where('customer_id', Auth::guard('api')->id())
            //         ->exists();

            //     // Set the wishlist property directly on the model object
            //     $model->wishlist = $wishlistGet ? true : false;

            //     $responseArray[] = $model;
            // }
            // $wishlist = [];

            // $formattedData = $this->bugdetformatModel(collect($responseArray), $power, $engine, $powerEV, $range, $wishlist);


            return ResponseHelper::responseMessage('success', $by_budget_model_data);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error',$e->getMessage());
        }
    }

    public function Model(Request $request)
    {
        try {
            $model = Model::Select('cop_models.model_id', 'cop_models.model_name')->select('model_id', 'model_name')->get();
            $formattedData = $model->map(function ($item) {
                return [

                    'model_id' => encryptor('e', $item->model_id),
                    'model_name' => $item->model_name,

                ];
            });
            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function allModel()
    {
        try {
            $all_models = Model::with(['variants' => function ($query) {
                $query->where('cop_variants.status', 1);
            }, 'variants.price_entry' => function ($q) {
                $q->where('cop_pe_ms.status', 1);
            }])->join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', 'cop_models.brand_id')
                ->select('cop_brands_ms.brand_id', 'cop_brands_ms.status', 'model_name', 'model_id', 'brand_name')
                ->where('cop_models.status', '=', 1)
                ->where('cop_brands_ms.status', '=', 1)
                ->where('cop_cs_ms.cs_name', '=', config('constant.CAR_STAGE_LAUNCHED'))
                ->get();
            if ($all_models->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }
            $result = [];
            foreach ($all_models as $model) {
                $brand_name = $model->brand_name;
                $variant_data = [];
                foreach ($model->variants as $variant) {
                    if (!empty($variant->price_entry)) {
                        $variant_data[] = [
                            'variant_id' => encryptor('e', $variant->variant_id),
                            'variantId' => $variant->variant_id,
                            'variant_name' => $variant->variant_name,
                        ];
                    }
                }
                $model_data = [
                    'model_id' => encryptor('e', $model->model_id),
                    'model_name' => $model->model_name,
                    'variants' => $variant_data,
                ];

                if (!isset($result[$brand_name])) {
                    $result[$brand_name] = [
                        'brand_id' => encryptor('e', $model->brand_id),
                        'brand_name' => $brand_name,
                        'models' => [],
                    ];
                }
                $result[$brand_name]['models'][] = $model_data;
            }

            $result = array_values($result);
            return ResponseHelper::responseMessage('success', $result);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
