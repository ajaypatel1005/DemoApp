<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\FuelStation;
use Exception;
use Illuminate\Support\Facades\Validator;

class FuelStationApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    public function index(Request $request)
    {
        // $f_station_Id = $request->f_station_id;

        try {
            // $validator = Validator::make($request->all(), [
            //     'city_id' => 'required',
            // ]);

            // if ($validator->fails()) {
            //     return ResponseHelper::errorResponse('missing_required_field');
            // }

            // $city_id = $request->city_id;
            if (!$request->has('city_id') && trim($request->input('city_id')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $city_id = ($request->has('city_id')) ? encryptor('d', $request->input('city_id')) : 0;

            $fuel_station_view = FuelStation::select(
                'cop_city_ms.city_name as city_name',
                'cop_state_ms.state_name as state_name',
                'cop_f_stations_ms.f_station_id',
                'cop_f_stations_ms.f_station_name',
                'cop_f_stations_ms.f_station_address',
                'cop_f_stations_ms.f_station_location',
                'cop_f_stations_ms.state_id',
                'cop_f_stations_ms.city_id',
                'cop_f_stations_ms.contact_no',
            )
                ->leftJoin('cop_city_ms', 'cop_f_stations_ms.city_id', '=', 'cop_city_ms.city_id')
                ->leftJoin('cop_state_ms', 'cop_f_stations_ms.state_id', '=', 'cop_state_ms.state_id')
                ->where('cop_f_stations_ms.status', '=', 1);

            if (!empty($city_id)) {
                $fuel_station_view->where('cop_f_stations_ms.city_id', $city_id);
            }
            $fuel_station_view = $fuel_station_view->paginate(12);

            if ($fuel_station_view->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $formattedData['fuel_station'] = $fuel_station_view->map(function ($item) {

                $data = [
                    'f_station_id' => encryptor('e', $item->f_station_id),
                    'f_station_name' => $item->f_station_name,
                    'f_station_address' => $item->f_station_address,
                    'f_station_location' => $item->f_station_location,
                    'state_id' => encryptor('e', $item->state_id),
                    'state_name' => $item->state_name,
                    'city_id' => encryptor('e', $item->city_id),
                    'city_name' => $item->city_name,
                    'contact_no' => $item->contact_no,
                ];
                return $data;
            });
            $formattedData['total_record'] = $fuel_station_view->total();
            $formattedData['current_page'] = $fuel_station_view->currentPage();
            $formattedData['last_page'] = $fuel_station_view->lastPage();

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function fuel_city(Request $request)
    {
        try {
            $fuel_city = FuelStation::join('cop_city_ms', 'cop_f_stations_ms.city_id', '=', 'cop_city_ms.city_id')
                ->select('cop_f_stations_ms.city_id', 'cop_city_ms.city_name',)
                ->DISTINCT()
                ->get();
            $respData = $fuel_city->map(function ($data) {
                return [
                    'city_id' => encryptor('e', $data->city_id),
                    'city_name' => $data->city_name,
                ];
            });
            return ResponseHelper::responseMessage('success', $respData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
