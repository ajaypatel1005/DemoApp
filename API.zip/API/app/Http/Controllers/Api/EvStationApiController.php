<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Models\EvStation;
use App\Http\Controllers\Helpers\ResponseHelper;

class EvStationApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    public function index(Request $request)
    {
        try {
            if (!$request->has('city_id') && trim($request->input('city_id')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $city_id = ($request->has('city_id')) ? encryptor('d', $request->input('city_id')) : 0;
            $ev_station = EvStation::select(
                'cop_city_ms.city_name as city_name',
                'cop_state_ms.state_name as state_name',
                'cop_evs_ms.evs_id',
                'cop_evs_ms.state_id',
                'cop_evs_ms.city_id',
                'evs_name',
                'evs_address',
                'evs_location',
                'evs_charging_slots',
                'evs_charging_port_type',
                'evs_charging_voltage',
                'evs_charging_rate',
                'evs_car_capacity',
                'evs_contact_number',

            )
                ->leftJoin('cop_city_ms', 'cop_evs_ms.city_id', '=', 'cop_city_ms.city_id')
                ->leftJoin('cop_state_ms', 'cop_evs_ms.state_id', '=', 'cop_state_ms.state_id')
                ->where('cop_evs_ms.status', '=', 1)
                ->where('cop_evs_ms.city_id', $city_id);
            $ev_station = $ev_station->paginate(12);
            if ($ev_station->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $formattedData['ev_station'] = $ev_station->map(function ($item) {

                $data = [
                    'ev_station_id' => encryptor('e', $item->evs_id),
                    'state_id' => encryptor('e', $item->state_id),
                    'state_name' => $item->state_name,
                    'city_id' => encryptor('e', $item->city_id),
                    'city_name' => $item->city_name,
                    'ev_station_name' => $item->evs_name,
                    'ev_station_address' => $item->evs_address,
                    'ev_station_location' => $item->evs_location,
                    'ev_station_charging_slots' => $item->evs_charging_slots,
                    'ev_station_charging_port_type' => $item->evs_charging_port_type,
                    'ev_station_charging_voltage' => $item->evs_charging_voltage,
                    'ev_station_charging_rate' => $item->evs_charging_rate,
                    'ev_station_car_capacity' => $item->evs_car_capacity,
                    'ev_station_contact_number' => $item->evs_contact_number,
                ];
                return $data;
            });
            $formattedData['total_record']=$ev_station->total();
            $formattedData['current_page']=$ev_station->currentPage();
            $formattedData['last_page']=$ev_station->lastPage();


            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function ev_city(Request $request)
    {
        try {
            $ev_city = EvStation::join('cop_city_ms', 'cop_evs_ms.city_id', '=', 'cop_city_ms.city_id')
                ->select('cop_evs_ms.city_id', 'cop_city_ms.city_name as city_name')
                ->DISTINCT()
                ->get();

            if ($ev_city->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }
            $formattedData = $ev_city->map(function ($data) {
                $data =  [
                    'city_id' => encryptor('e', $data->city_id),
                    'city_name' => $data->city_name
                ];
                return $data;
            });
            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
