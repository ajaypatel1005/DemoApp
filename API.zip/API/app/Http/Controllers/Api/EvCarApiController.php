<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Brand;
use App\Models\CarListingData;
use Illuminate\Support\Facades\Auth;
use App\Models\Wishlist;
use App\Models\Model;
use App\Models\City;
use App\Models\PriceEntry;
use Illuminate\Support\Facades\DB;

class EvCarApiController extends Controller
{
    protected $carStageLaunched;
    protected $imagePath;

    public function __construct()
    {
        // car stage as launched
        $this->carStageLaunched = config('constant.CAR_STAGE_LAUNCHED');
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index) for website
    public function index(Request $request)
    {
        try {
            if ($request->type == 'price_filter') {
                $minPrice = $request->input('minprice');
                $maxPrice = $request->input('maxprice');

                $cityName = $request->input('city_name');
                if ($cityName == "" || $cityName == null) {
                    $formattedData = ['city_name required'];
                    return ResponseHelper::responseMessage('success', $formattedData);
                }
                $models = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                    ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                    ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                    ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                    ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
                    ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')

                    ->select(
                        'cop_models.*',
                        'cop_cs_ms.cs_name',
                        'cop_brands_ms.brand_name',
                        'cop_ct_ms.ct_name',
                        'cop_variants.*',
                        'cop_pe_ms.ex_showroom_price',
                        'cop_city_ms.city_id',
                        'cop_city_ms.city_name',
                        'cop_ratings.rating_id',
                        'cop_ratings.rating_value',
                        'cop_rating_types.rating_type_name'

                    )->where('cop_cs_ms.cs_name', '=', 'Launched')
                    ->where(function ($query) use ($minPrice, $maxPrice) {
                        $query->where('cop_models.min_price', '>=', $minPrice)
                            ->where('cop_models.max_price', '<=', $maxPrice);
                    })
                    ->where('cop_models.model_type', '=', 1)
                    ->where('cop_city_ms.city_name', $cityName)

                    ->distinct()
                    ->get();


                // if ($models->isEmpty()) {
                //     return ResponseHelper::errorResponse('data_not_found');
                // }

                $power = $this->getFeatureDetails('Power (EV)');
                // dd($powerEV);
                $engine = $this->getFeatureDetails('Range');

                $responseArray = [];

                foreach ($models as $model) {
                    $model->power = $power->where('model_id', $model->model_id)->first();
                    $model->engine = $engine->where('model_id', $model->model_id)->first();

                    $wishlistGet = Wishlist::where('model_id', $model->model_id)
                        ->where('customer_id', Auth::guard('api')->id())
                        ->exists();

                    // Set the wishlist property directly on the model object
                    $model->wishlist = $wishlistGet ? true : false;
                    $responseArray[] = $model;
                }
                // dd($responseArray);
                $wishlist = [];
                $formattedData = $this->formatModel(collect($responseArray), $power, $engine, $wishlist);


                return ResponseHelper::responseMessage('success', $formattedData);
            } else if ($request->type == 'EV Cars') {

                $evCar = CarListingData::select(
                    'cop_models.*',
                    // 'cop_msd.*',
                    'cop_cl_ms.cl_name as cl_name',
                    'cop_brands_ms.brand_name as brand_name',
                    'cop_ratings.rating_id',
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                )
                    ->leftJoin('cop_cl_ms', 'cop_cl_data.cl_id', '=', 'cop_cl_ms.cl_id')
                    ->leftJoin('cop_brands_ms', 'cop_cl_data.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_models', 'cop_cl_data.model_id', '=', 'cop_models.model_id')
                    // ->leftJoin('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                    ->where('cop_cl_data.status', '=', 1)
                    ->where('cop_cl_ms.cl_name', '=', 'EV Cars')
                    ->distinct("cop_models.model_id")
                    ->get();


                if ($evCar->isEmpty()) {

                    return ResponseHelper::errorResponse('data_not_found');
                }

                $power = $this->getFeatureDetails('Power (EV)');
                // dd($powerEV);
                $engine = $this->getFeatureDetails('Range');


                $responseArray = [];

                foreach ($evCar as $model) {
                    $model->power = $power->where('model_id', $model->model_id)->first();
                    $model->engine = $engine->where('model_id', $model->model_id)->first();

                    $wishlistGet = Wishlist::where('model_id', $model->model_id)
                        ->where('customer_id', Auth::guard('api')->id())
                        ->exists();

                    // Set the wishlist property directly on the model object
                    $model->wishlist = $wishlistGet ? true : false;
                    $responseArray[] = $model;
                }
                // dd($responseArray);
                $wishlist = [];
                $formattedData = $this->formatModel(collect($responseArray), $power, $engine, $wishlist);


                return ResponseHelper::responseMessage('success', $formattedData);





                // } else {
                //     return ResponseHelper::errorResponse('error', 'Not Match');

            } else if ($request->type == 'all_ev_cars') {
                $models = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                    ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')

                    ->leftJoin('cop_ratings', function ($join) {
                        $join->on('cop_ratings.model_id', '=', 'cop_models.model_id')
                            ->where('cop_cs_ms.cs_name', '!=', 'Upcoming');
                    })
                    ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                    ->select(
                        'cop_models.*',
                        'cop_cs_ms.cs_name',
                        'cop_brands_ms.brand_name',
                        'cop_ct_ms.ct_name',

                    )->where('cop_cs_ms.cs_name', '=', 'Launched')
                    ->where('cop_models.model_type', '=', 1)
                    ->distinct()
                    ->get();



                if ($models->isEmpty()) {

                    return ResponseHelper::errorResponse('data_not_found');
                }

                $power = $this->getFeatureDetails('Power (EV)');
                // dd($powerEV);
                $engine = $this->getFeatureDetails('Range');

                $responseArray = [];

                foreach ($models as $model) {
                    $model->power = $power->where('model_id', $model->model_id)->first();
                    $model->engine = $engine->where('model_id', $model->model_id)->first();

                    $wishlistGet = Wishlist::where('model_id', $model->model_id)
                        ->where('customer_id', Auth::guard('api')->id())
                        ->exists();

                    // Set the wishlist property directly on the model object
                    $model->wishlist = $wishlistGet ? true : false;
                    $responseArray[] = $model;
                }
                $wishlist = [];
                // dd($responseArray);
                $formattedData = $this->formatModel(collect($responseArray), $power, $engine, $wishlist);


                return ResponseHelper::responseMessage('success', $formattedData);
            }
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // to get by_budget data of EV cars (for app) (3-4-2024 & 4-4-2024)
    public function ev_cars_by_budget(Request $request)
    {
        try {
            // to get user id
            $auth_id=Auth::guard('api')->id();

            // city_id input field
            if (!$request->has('city_id') && trim($request->input('city_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $city_id_dec = encryptor('d',$request->input('city_id'));
                if(!$city_id_dec){
                    return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                } else {
                    $city = City::find($city_id_dec);

                    if(!$city) {
                        return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                    } else {
                        $city_id = $city_id_dec;
                    }
                }
            }

            // min_price input field
            if (!$request->has('min_price') && trim($request->input('min_price'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                if(!is_numeric($request->min_price)) {
                    return ResponseHelper::errorResponse('error','min_price should be numbers only');
                } else {
                    if($request->min_price < 200000 || $request->min_price > 200000000){
                        return ResponseHelper::errorResponse('error','min_price should be 2 lakh to 20 cr only');
                    } else {
                        $min_price = $request->min_price;
                    }
                }
            }

            // max_price input field
            if (!$request->has('max_price') && trim($request->input('max_price'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                if(!is_numeric($request->max_price)) {
                    return ResponseHelper::errorResponse('error','max_price should be numbers only');
                } else {
                    if($request->max_price < 200000 || $request->max_price > 200000000){
                        return ResponseHelper::errorResponse('error','max_price should be 2 lakh to 20 cr only');
                    } else {
                        $max_price = $request->max_price;
                    }
                }
            }

            $evCarsByBudget = PriceEntry::select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_models.model_image',
                'cop_ratings.rating_value',
                'cop_rating_types.rating_type_name',
                DB::raw('(SELECT MIN(ex_showroom_price) FROM cop_pe_ms WHERE city_id = "'.$city_id.'" AND model_id = cop_models.model_id) AS min_ex_showroom_price'),
                DB::raw('(SELECT MAX(ex_showroom_price) FROM cop_pe_ms WHERE city_id = "'.$city_id.'" AND model_id = cop_models.model_id) AS max_ex_showroom_price'),
                DB::raw("(select wl_id from cop_wl where cop_wl.model_id = cop_models.model_id and customer_id = '$auth_id') as wl_id")
            )
            ->join('cop_variants','cop_variants.variant_id','=','cop_pe_ms.variant_id')
            ->join('cop_models','cop_models.model_id','=','cop_variants.model_id')
            ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
            ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
            ->join('cop_ratings','cop_ratings.model_id','=','cop_models.model_id')
            ->join('cop_rating_types','cop_rating_types.rating_type_id','=','cop_ratings.rating_type_id')
            ->where('cop_models.model_type',1)
            ->where('cop_cs_ms.cs_name',$this->carStageLaunched)
            ->whereBetween('cop_pe_ms.ex_showroom_price',[$min_price, $max_price])
            ->where('cop_pe_ms.city_id',$city_id)
            ->where('cop_brands_ms.status',1)
            ->where('cop_models.status',1)
            ->where('cop_variants.status',1)
            ->where('cop_pe_ms.status',1)
            ->distinct()
            ->get();

            if($evCarsByBudget->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $by_budget_cards_data = [];
            $evCarsByBudget->map(function ($item) use (&$by_budget_cards_data) {
                $by_budget_cards_data[] = [
                    'brand_id' => encryptor('e',$item->brand_id),
                    'brand_name' => $item->brand_name,
                    'model_id' => encryptor('e',$item->model_id),
                    'model_name' => $item->model_name,
                    'price' => [
                        'min_ex_showroom_price' => $item->min_ex_showroom_price ?  convertToLakhCrore($item->min_ex_showroom_price) : null,
                        'max_ex_showroom_price' => $item->max_ex_showroom_price ?  convertToLakhCrore($item->max_ex_showroom_price) : null,
                    ],
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                    'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_image}",
                    'rating_type_name' => $item->rating_type_name,
                    'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : null,
                    'wishlist' => $item->wl_id ? true : false,
                ];
            });

            return ResponseHelper::responseMessage('success', $by_budget_cards_data);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // to get all brands of ev-cars (for app) (3-4-2024)
    public function ev_cars_all_brands()
    {
        try {
            $evCarsBrands = Brand::select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_brands_ms.brand_logo'
            )
            ->join('cop_models','cop_models.brand_id','=','cop_brands_ms.brand_id')
            ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
            ->where('cop_models.model_type',1)
            ->where('cop_cs_ms.cs_name',$this->carStageLaunched)
            ->where('cop_brands_ms.status',1)
            ->where('cop_models.status',1)
            ->orderBy('cop_brands_ms.priority','asc')
            ->distinct()
            ->get();

            $ev_cars_brands = $evCarsBrands->map(function ($item) {
                return [
                    'brand_id' => encryptor('e',$item->brand_id),
                    'brand_name' => $item->brand_name,
                    'brand_logo' => $this->imagePath . "/brands/{$item->brand_id}/{$item->brand_logo}",
                ];
            });

            return ResponseHelper::responseMessage('success', $ev_cars_brands);
        } catch (\Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // to get by_brand data of EV cars (for app) (4-4-2024)
    public function ev_cars_by_brand(Request $request)
    {
        try {
            // to get user id
            $auth_id=Auth::guard('api')->id();

            // city_id input field
            if (!$request->has('city_id') && trim($request->input('city_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $city_id_dec = encryptor('d',$request->input('city_id'));
                if(!$city_id_dec){
                    return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                } else {
                    $city = City::find($city_id_dec);

                    if(!$city) {
                        return ResponseHelper::errorResponse('error',$request->input('city_id') .' city_id is not found');
                    } else {
                        $city_id = $city_id_dec;
                    }
                }
            }

            // brand_id input filed
            if (!$request->has('brand_id') && trim($request->input('brand_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $brand_id_dec = encryptor('d',$request->input('brand_id'));
                if(!$brand_id_dec){
                    return ResponseHelper::errorResponse('error',$request->input('brand_id') .' brand_id is not found');
                } else {
                    $brand = Brand::find($brand_id_dec);

                    if(!$brand) {
                        return ResponseHelper::errorResponse('error',$request->input('brand_id') .' brand_id is not found');
                    } else {
                        $brand_id = $brand_id_dec;
                    }
                }
            }

            $evCarsByBrand = Model::select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_models.model_image',
                'cop_ratings.rating_value',
                'cop_rating_types.rating_type_name',
                DB::raw('(SELECT MIN(ex_showroom_price) FROM cop_pe_ms WHERE city_id = "'.$city_id.'" AND model_id = cop_models.model_id) AS min_ex_showroom_price'),
                DB::raw('(SELECT MAX(ex_showroom_price) FROM cop_pe_ms WHERE city_id = "'.$city_id.'" AND model_id = cop_models.model_id) AS max_ex_showroom_price'),
                DB::raw("(select wl_id from cop_wl where cop_wl.model_id = cop_models.model_id and customer_id = '$auth_id') as wl_id")
            )
            ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
            ->join('cop_cs_ms','cop_cs_ms.cs_id','=','cop_models.cs_id')
            ->join('cop_ratings','cop_ratings.model_id','=','cop_models.model_id')
            ->join('cop_rating_types','cop_rating_types.rating_type_id','=','cop_ratings.rating_type_id')
            ->where('cop_models.model_type',1)
            ->where('cop_cs_ms.cs_name',$this->carStageLaunched)
            ->where('cop_brands_ms.brand_id',$brand_id)
            ->where('cop_brands_ms.status',1)
            ->where('cop_models.status',1)
            ->distinct()
            ->get();

            if($evCarsByBrand->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $by_brand_cards_data = [];
            $evCarsByBrand->map(function ($item) use (&$by_brand_cards_data) {
                $by_brand_cards_data[] = [
                    'brand_id' => encryptor('e',$item->brand_id),
                    'brand_name' => $item->brand_name,
                    'model_id' => encryptor('e',$item->model_id),
                    'model_name' => $item->model_name,
                    'price' => [
                        'min_ex_showroom_price' => $item->min_ex_showroom_price ?  convertToLakhCrore($item->min_ex_showroom_price) : null,
                        'max_ex_showroom_price' => $item->max_ex_showroom_price ?  convertToLakhCrore($item->max_ex_showroom_price) : null,
                    ],
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                    'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_image}",
                    'rating_type_name' => $item->rating_type_name,
                    'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : null,
                    'wishlist' => $item->wl_id ? true : false,
                ];
            });

            return ResponseHelper::responseMessage('success', $by_brand_cards_data);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }


    // Not used as per API routes hence commented currently
    // private function pricefilter($model_id)
    // {
    //     $priceMinMax = Model::select(
    //         DB::raw('MIN(cop_pe_ms.ex_showroom_price) as min_ex_showroom_price'),
    //         DB::raw('MAX(cop_pe_ms.ex_showroom_price) as max_ex_showroom_price')
    //     )
    //         ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
    //         ->where('cop_models.model_id', $model_id)
    //         ->where('cop_models.model_type', '0')
    //         ->first();

    //     return [
    //         'price_filter' => $priceMinMax['min_ex_showroom_price'],
    //         'min_ex_showroom_price' =>  convertToLakhCrore($priceMinMax['min_ex_showroom_price']),
    //         'max_ex_showroom_price' =>  convertToLakhCrore($priceMinMax['max_ex_showroom_price']),
    //     ];
    // }

    // public function formatModel($models, $power, $engine, $wishlist)
    // {
    //     // dd($power, $engine);
    //     $formattedData = $models->map(function ($item) use ($power, $engine) {
    //         $powerDetails = $power->where('model_id', $item->model_id)->first();
    //         $engineDetails = $engine->where('model_id', $item->model_id)->first();
    //         if ($powerDetails === null) {
    //             dd("Power details are null for model name & ID: {$item->model_name} : {$item->model_id}");
    //         }

    //         if ($engineDetails === null) {
    //             dd("Engine details are null for model name & ID: {$item->model_name} : {$item->model_id}");
    //         }
    //         $data = [
    //             'model_id' => encrypt($item->model_id),
    //             'car_stage' => $item->cs_name,
    //             'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp" ?? NULL,
    //             'launch_date' => $item->launch_date,
    //             'brand_name' => $item->brand_name,
    //             'model_name' => $item->model_name,
    //             'price' => $this->pricefilter($item->model_id),
    //             // 'min_price' =>  convertToLakhCrore($item->min_price),
    //             // 'max_price' =>  convertToLakhCrore($item->max_price),
    //             'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
    //             'rating_type_name' => $item->rating_type_name ?? NULL,
    //             'city_name' => $item->city_name ?? NULL,
    //             'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : NULL,
    //             'wishlist' => $item->wishlist,


    //             'power' => [
    //                 'feature_id' => $powerDetails->feature_id ?? null,
    //                 'features_image' =>  $this->imagePath . "Feature/{$powerDetails->feature_id}/{$powerDetails->feature_id}.svg" ?? NULL,
    //                 'feature_value' => $powerDetails->feature_value ?? NULL,
    //                 'su_name' => $powerDetails->su_name ?? NULL,
    //             ],
    //             'engine' => [
    //                 'feature_id' => $engineDetails->feature_id ?? null,
    //                 'features_image' => $this->imagePath . "Feature/{$engineDetails->feature_id}/{$engineDetails->feature_id}.svg" ?? NULL,
    //                 'feature_value' => $engineDetails->feature_value ?? NULL,
    //                 'su_name' => $engineDetails->su_name ?? NULL,
    //             ],
    //         ];

    //         return $data;
    //     });

    //     return $formattedData;
    // }

    // private function getFeatureDetails($featureName)
    // {
    //     $data = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
    //         ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
    //         ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
    //         // ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
    //         ->leftJoin('cop_fv', 'cop_fv.model_id', '=', 'cop_models.model_id')
    //         ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
    //         ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
    //         ->select(
    //             'cop_models.model_id',
    //             'cop_models.model_name',
    //             'cop_features_ms.feature_id',
    //             'cop_features_ms.features_image',
    //             'cop_fv.fv_id',
    //             'cop_fv.feature_value',
    //             'cop_su_ms.su_name'
    //         )->where('cop_features_ms.features_name', $featureName)
    //         // ->where('cop_models.model_type', '=', 1)
    //         ->distinct()

    //         ->get();

    //     // dd($data );

    //     if ($data->isEmpty()) {

    //         return ResponseHelper::errorResponse('data_not_found');
    //     }


    //     return $data;
    // }
}