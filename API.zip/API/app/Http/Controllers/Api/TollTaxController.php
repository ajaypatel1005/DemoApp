<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\FuelPrice;
use App\Models\SystemSetting;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class TollTaxController extends Controller
{
    //get toll tax
    public function getTollTax(Request $request)
    {
        try {

            $data = $request->all();
            $requiredFields = [
                'from_address', 'from_latitude', 'from_longitude', 'from_city_name',
                'from_country', 'from_state_code', 'from_state_name', 'from_uri',
                'to_address', 'to_latitude', 'to_longitude', 'to_city_name',
                'to_country', 'to_state_code', 'to_state_name', 'to_uri'
            ];

            foreach ($requiredFields as $field) {
                if (empty($data[$field])) {
                    return ResponseHelper::errorResponse('error', ucfirst(str_replace('_', ' ', $field)) . ' is required');
                }
            }



            $currentTime = Carbon::now()->format('Y-m-d\TH:i:sP');
            // Construct the complex JSON structure
            $jsonInput = [
                "0" => [
                    "json" => [
                        "from" => [
                            "address" => $data['from_address'],
                            "lat" => (float) $data['from_latitude'],
                            "lng" => (float) $data['from_longitude'],
                            "meta" => [
                                "city" => $data['from_city_name'],
                                "country" => $data['from_country'],
                                "state" => $data["from_state_code"],
                                "stateName" => $data["from_state_name"],
                                "uri" => $data["from_uri"]
                            ]
                        ],
                        "to" => [
                            "address" => $data['to_address'],
                            "lat" => (float) $data['to_latitude'],
                            "lng" => (float) $data['to_longitude'],
                            "meta" => [
                                "city" => $data['to_city_name'],
                                "country" => $data['to_country'],
                                "state" => $data['to_state_code'],
                                "stateName" => $data['to_state_name'],
                                "uri" => $data['to_uri']
                            ]
                        ],
                        // "waypoints" => [],
                        "vehicle" => [
                            "type" => "2AxlesAuto"
                        ],
                        "tags" => [],
                        "returnPath" => "herePath",
                        "returnFloats" => true,
                        "departure_time" => $currentTime,
                        "units" => [
                            "currencyUnit" => "INR",
                            "fuelUnit" => "Liter"
                        ],
                        "fuelOptions" => [
                            "fuelEfficiency" => [
                                "city" => 14,
                                "hwy" => 18,
                                "units" => "kmpl"
                            ],
                            "fuelCost" => [
                                "currency" => "INR",
                                "value" => 104.34,
                                "units" => "₹/liter"
                            ]
                        ]
                    ]
                ]
            ];
            // Convert the JSON object to a URL-encoded string with correct key preservation
            $jsonString = json_encode($jsonInput, JSON_FORCE_OBJECT);

            // Encode the JSON string for use in the URL
            $urlEncodedData = urlencode($jsonString);

            // Convert the JSON object to a URL-encoded string
            $url = 'https://www.tollguru.com/api/trpc/calc.getRoutes?batch=1&input=' . $urlEncodedData;

            $response = Http::get($url);
            if ($response->successful()) {
                $data = $response->json();
                $result = $data[0]["result"]["data"]["json"];
                if (!empty($result)) {
                    if ($result['status'] == "OK") {

                        $allRoutes = $result["routes"][0] ?? [];
                        if (!empty($allRoutes['tolls'])) {
                            return ResponseHelper::responseMessage('success', $result, 'Data has been retrieved successfully.');
                        } else {
                            return ResponseHelper::errorResponse('error', $result, 'No tolls found in this route.');
                        }
                    }
                }
            } else {
                $data = $response->json()[0]["error"]["json"]["message"];

                if (!empty($data)) {
                    $errorData = json_decode($data, true);
                    return ResponseHelper::errorResponse('error', $data, $errorData['value']);
                } else {
                    return ResponseHelper::errorResponse('error', [], 'Something went wrong. Please try again');
                }
            }
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }


    /**
     * @param Request $request
     */
    public function getApiKey(Request $request)
    {
        try {
            $old_key = $request->toll_key;
            if (empty($old_key)) {
                return ResponseHelper::errorResponse('error', 'Toll Key is required');
            }
            $keyName = SystemSetting::TOLL_GURU_KEY;
            SystemSetting::where('key', $keyName)->where('value', $old_key)->update(['is_expired' => 1]);
            $newValue = SystemSetting::where('is_expired', 0)->where('key', $keyName)->first();
            if (!empty($newValue)) {
                return ResponseHelper::responseMessage('success', ['key' => $newValue->value]);
            } else {
                return ResponseHelper::errorResponse('error', 'Key not found');
            }
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // get fuel price
    public function getFuelPrice(Request $request)
    {
        // city_name input filed
        if (!$request->has('city_name') && trim($request->input('city_name'))==''){
            return ResponseHelper::errorResponse('missing_required_field');
        } else {
            $city_name = $request->input('city_name');
        }

        if($city_name == "Bangalore"){
            $city_name = "Bengaluru";
        }

        $today_date = date('Y-m-d'); // to get the today date in formate of YYYY-MM-DD

        $fuel_price_get = FuelPrice::whereHas('fuelPriceCityData', function($query) use($city_name) {
            $query->where('city_api_name',$city_name);
        })
        ->where('as_on_date',$today_date)
        ->where('status',1)
        ->get();
        // $fuel_price_get = FuelPrice::where('city_api_name',$city_name)->active()->get();
        
        $data = [
            config('constant.FUEL_PRICE.PETROL') => "0",
            config('constant.FUEL_PRICE.DEISEL') => "0",
            config('constant.FUEL_PRICE.CNG') => "0",
        ];
        $fuel_price_get->map(function ($item)use(&$data){
            if($item->fuel_type == config('constant.FUEL_PRICE.PETROL')){
                $data[$item->fuel_type] = $item->retail_price;
            } else if($item->fuel_type == config('constant.FUEL_PRICE.DEISEL')){
                $data[$item->fuel_type] = $item->retail_price;
            } else if($item->fuel_type == config('constant.FUEL_PRICE.CNG')){
                $data[$item->fuel_type] = $item->retail_price;
            }
        });

        // return $fuel_price;
        return ResponseHelper::responseMessage('success', $data);
    }
}
