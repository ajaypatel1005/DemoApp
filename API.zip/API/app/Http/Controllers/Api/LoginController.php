<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Archive;
use App\Models\City;
use Illuminate\Support\Facades\DB;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use Illuminate\Validation\ValidationException;


class LoginController extends Controller
{
    protected $imagePath;

    public function __construct()
    {
        $this->imagePath = env('IMAGE_PATH');
    }

    public function index(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'contact_no' => 'required | string |regex:/^91[0-9]{10}$/',
            ]);
            if ($validator->fails()) {
                $formattedData = [
                    'message' => 'Contact Number required',
                    'token' => null,
                    'login_status' => false,
                    'contact_no' => null,
                    'first_name' => null,
                    'last_name' => null,
                    'address_1' => null,
                    'address_2' => null,
                    'email' => null,
                    'profile_pic' => null,
                    'selected_city_id' => null,
                    'selected_city_name' => null,
                    'toll_count' => 0,
                    'fuel_count' => 0,

                ];
                return ResponseHelper::responseMessage('success', $formattedData);
                // return ResponseHelper::errorResponse($validator->errors()->all(), ['Contact Number required']);
            }

            $contact_no = encryptor('e',$request->contact_no);
            $firstName = !empty($request->custFirstName) ? $request->custFirstName : '';
            $lastName = !empty($request->custLastName) ? $request->custLastName : '';
            $email = !empty($request->custEmail) ? $request->custEmail : '';

            $user = Customer::where('contact_no', $contact_no)->first();
            if (!empty($user)) {

                if((!empty($firstName) && !empty($lastName) && !empty($email))){

                    $fullName = encryptor('e',$firstName.' '.$lastName);
                    $firstName = encryptor('e',$firstName);
                    $lastName = encryptor('e',$lastName);
                    $email = encryptor('e',$email);

                    $checkUserExist = Customer::where('email', $email)->get();
                    if ($checkUserExist->count() > 0) {
                        $formattedData = [
                            'message' => 'Email already exist.',
                            'token' => null,
                            'login_status' => false,
                            'contact_no' => null,
                            'first_name' => null,
                            'last_name' => null,
                            'address_1' => null,
                            'address_2' => null,
                            'email' => null,
                            'profile_pic' => null,
                            'selected_city_id' => null,
                            'selected_city_name' => null,
                            'toll_count' => 0,
                            'fuel_count' => 0,
                        ];
                        return ResponseHelper::responseMessage('success', $formattedData);
                    } else {
                        $user->first_name = $fullName;
                        // $user->last_name = $lastName;
                        $user->email = $email;
                        $user->contact_no = $contact_no;
                        $user->save();

                        Auth::login($user);
                        $message = 'Customer registered and login successfully';
                        $accessToken = $user->createToken('authToken', ['*'], Carbon::now()->addDays(15))->plainTextToken;
                        $formattedData = [
                            'message' => $message,
                            'token' => $accessToken,
                            'login_status' => true,
                            'contact_no' => encryptor('d',$user->contact_no),
                            'first_name' => $firstName ? encryptor('d',$firstName) : "",
                            'last_name' => $lastName ? encryptor('d',$lastName) : "",
                            'email' => $user->email ? encryptor('d',$user->email) : "",
                            'address_1' => "",
                            'address_2' => "",
                            'toll_count' => $user->toll_count ?? 0,
                            'fuel_count' => $user->fuel_count ?? 0,
                        ];
                    }
                } else {
                    Auth::login($user);
                    $message = 'Customer login successfully';
                    $accessToken = $user->createToken('authToken', ['*'], Carbon::now()->addDays(15))->plainTextToken;
                    $selected_city_name = City::where('city_id', $user->selected_city_id)->first();

                    $customer_full_name = explode(' ',encryptor('d',$user->first_name));
                    $last_name = array_pop($customer_full_name);
                    $first_name = implode(" ", $customer_full_name);

                    $formattedData = [
                        'message' => $message,
                        'token' => $accessToken,
                        'login_status' => true,
                        'contact_no' => encryptor('d',$user->contact_no),
                        'first_name' => $first_name ? $first_name : "",
                        'last_name' => $last_name ? $last_name : "",
                        'address_1' => $user->address_1,
                        'address_2' => $user->address_2,
                        'email' => $user->email ? encryptor('d',$user->email) : "",
                        'profile_pic' => $user->profile_pic,
                        'selected_city_id' => $user->selected_city_id ? encryptor('e', $user->selected_city_id) : null,
                        'selected_city_name' => $selected_city_name == null ? null : $selected_city_name->city_name,
                        'toll_count' => $user->toll_count,
                        'fuel_count' => $user->fuel_count,
                    ];
                }
            } elseif (!empty($firstName) && !empty($lastName) && !empty($email)) {

                $fullName = encryptor('e',$firstName.' '.$lastName);
                $firstName = encryptor('e',$firstName);
                $lastName = encryptor('e',$lastName);
                $email = encryptor('e',$email);

                $checkUserExist = Customer::where('email', $email)->get();
                if ($checkUserExist->count() > 0) {
                    $formattedData = [
                        'message' => 'Email already exist.',
                        'token' => null,
                        'login_status' => false,
                        'contact_no' => null,
                        'first_name' => null,
                        'last_name' => null,
                        'address_1' => null,
                        'address_2' => null,
                        'email' => null,
                        'profile_pic' => null,
                        'selected_city_id' => null,
                        'selected_city_name' => null,
                        'toll_count' => 0,
                        'fuel_count' => 0,
                    ];
                    return ResponseHelper::responseMessage('success', $formattedData);
                } else {
                    $customer = new Customer();
                    $customer->first_name = $fullName;
                    // $customer->last_name = $lastName;
                    $customer->email = $email;
                    $customer->contact_no = $contact_no;
                    $customer->save();

                    Auth::login($customer);
                    $message = 'Customer registered and login successfully';
                    $accessToken = $customer->createToken('authToken', ['*'], Carbon::now()->addDays(15))->plainTextToken;
                    $formattedData = [
                        'message' => $message,
                        'token' => $accessToken,
                        'login_status' => true,
                        'contact_no' => encryptor('d',$customer->contact_no),
                        'first_name' => $firstName ? encryptor('d',$firstName) : "",
                        'last_name' => $lastName ? encryptor('d',$lastName) : "",
                        'email' => $customer->email ? encryptor('d',$customer->email) : "",
                        'address_1' => "",
                        'address_2' => "",
                        'toll_count' => $customer->toll_count ?? 0,
                        'fuel_count' => $customer->fuel_count ?? 0,
                    ];
                }
            } else {
                $formattedData = [
                    'message' => 'User does not exist.',
                    'token' => null,
                    'login_status' => false,
                    'contact_no' => null,
                    'first_name' => null,
                    'last_name' => null,
                    'address_1' => null,
                    'address_2' => null,
                    'email' => null,
                    'toll_count' => 0,
                    'fuel_count' => 0,
                ];
            }
            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function getUser(Request $request)
    {
        try {
            $customer_id = Auth::guard('api')->id();
            $customerData = Customer::where('customer_id', '=', $customer_id)->first();
            $customer_full_name = explode(' ',encryptor('d',$customerData['first_name']));
            $last_name = array_pop($customer_full_name);
            $first_name = implode(" ", $customer_full_name);

            $selectedCityName = City::where('city_id',$customerData['selected_city_id'])->first();

            $checkCustomerExist = Customer::where('status', 1)->where('contact_no', '!=', null)->where('customer_id', $customer_id)->first();

            if ($checkCustomerExist) {
                $formattedData = [
                    'customer_id' => encryptor('e', $customerData['customer_id']),
                    'first_name' => $first_name,
                    'last_name' => $last_name,
                    'email' => encryptor('d',$customerData['email']),
                    'address_1' => $customerData['address_1'],
                    'address_2' => $customerData['address_2'],
                    'contact_no' => encryptor('d',$customerData['contact_no']),
                    'profile_pic' => $customerData['profile_pic'],
                    'selected_city_id' => $customerData['selected_city_id'] ? encryptor('e', $customerData['selected_city_id']) : null,
                    'selected_city_name' => $selectedCityName == null ? null : $selectedCityName['city_name'],
                    'toll_count' => $customerData['toll_count'] ?? 0,
                    'fuel_count' => $customerData['fuel_count'] ?? 0,
                ];
                return ResponseHelper::responseMessage('success', $formattedData);
            } else {
                return ResponseHelper::errorResponse('unauthorized');
            }
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function updateCustomer(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'custFirstName' => 'required|string',
                'custLastName' => 'required|string',
                'custEmail' => 'required|email',
                'address_1' => 'nullable|string',
                'address_2' => 'nullable|string',
                // 'profile_pic' => 'nullable|image|max:2048|mimes:webp,jpg,jpeg,png'
                'profile_pic' => 'nullable|string'
            ]);
            // dd($request->input('profile_pic'));

            $customer_id = Auth::guard('api')->id();
            $checkCustomerExist = Customer::where('status', 1)->where('contact_no', '!=', null)->where('customer_id', $customer_id)->first();

            if ($checkCustomerExist) {
                $customer = Customer::where('customer_id', $customer_id)->firstOrFail();
                if (empty($customer)) {
                    return ResponseHelper::errorResponse("error", ['User not found']);
                }
                $checkUserExist = Customer::where('email', encryptor('e',$request->input('custEmail')))->where('customer_id','!=',$customer_id)->get();
                if ($checkUserExist->count() > 0) {
                    return ResponseHelper::errorResponse("error", ['Email already exist']);
                }

                $updateData = [
                    'first_name' => encryptor('e',$request->input('custFirstName').' '.$request->input('custLastName')),
                    // 'last_name' => encryptor('e',$request->input('custLastName')),
                    'email' => encryptor('e',$request->input('custEmail')),
                    'address_1' => $request->input('address_1'),
                    'address_2' => $request->input('address_2'),
                    // 'profile_pic' => $base64Iamge,
                ];

                if ($request->input('profile_pic')) {
                    $base64Iamge = $request->input('profile_pic');
                    // $base64Iamge = base64_encode(file_get_contents($request->file('profile_pic')->path()));
                    $updateData['profile_pic'] = $base64Iamge;
                }

                $customer->update($updateData);
                // if ($request->hasFile('profile_pic') && $customer->profile_pic) {
                //     // $oldImagePath = public_path('Customer_Profile_Pic/' . $customer->profile_pic);
                //     $oldImagePath = $this->imagePath . "'Customer_Profile_Pic/' . $customer->profile_pic" ?? null;

                //     if (File::exists($oldImagePath)) {
                //         File::delete($oldImagePath);
                //     }
                // }

                // if ($request->hasFile('profile_pic')) {
                //     $image = $request->file('profile_pic');
                //     $imageName = time() . '.' . $image->getClientOriginalExtension();
                //     // $image->move(public_path('Customer_Profile_Pic'), $imageName);
                //     $image->move($this->imagePath . "Customer_Profile_Pic',$imageName" ?? null);
                //     $customer->profile_pic = $imageName;
                //     $customer->save();
                // }
                return ResponseHelper::responseMessage('success', ['Customer information updated successfully']);
            } else {
                return ResponseHelper::errorResponse('unauthorized');
            }
        } catch (ValidationException $e) {
            $errors = $e->validator->errors()->messages();
            $errorMessages = [];

            foreach ($errors as $fieldErrors) {
                foreach ($fieldErrors as $errorMessage) {
                    $errorMessages[] = $errorMessage;
                }
            }
            return ResponseHelper::errorResponse('error', implode(' & ', $errorMessages));
        } catch (\Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function add_user_city(Request $request)
    {
        try {

            $validatedData = $request->validate([
                'city_id' => 'required|string',
            ]);

            $customerId = Auth::guard('api')->id();
            $checkCustomerExist = Customer::where('status', 1)->where('contact_no', '!=', null)->where('customer_id', $customerId)->first();

            if ($checkCustomerExist) {
                $cityId = encryptor('d', $request->city_id);
                if ($cityId) {
                    $value = array('selected_city_id' => $cityId);
                    Customer::where('customer_id', $customerId)->update($value);
                    return ResponseHelper::responseMessage('success', ['city_id updated successfully']);
                } else {
                    return ResponseHelper::errorResponse('error', 'Entered city_id not found');
                }
            } else {
                return ResponseHelper::errorResponse('unauthorized');
            }
        } catch (ValidationException $e) {
            $errors = $e->validator->errors()->messages();
            $errorMessages = [];

            foreach ($errors as $fieldErrors) {
                foreach ($fieldErrors as $errorMessage) {
                    $errorMessages[] = $errorMessage;
                }
            }
            return ResponseHelper::errorResponse('error', implode(' & ', $errorMessages));
        } catch (\Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function get_user_city(Request $request)
    {
        try {

            $customerId = Auth::guard('api')->id();

            $checkCustomerExist = Customer::where('status', 1)->where('contact_no', '!=', null)->where('customer_id', $customerId)->first();

            if ($checkCustomerExist) {
                $get_user_selected_city = Customer::select('cop_customers.selected_city_id', 'cop_city_ms.city_name')
                    ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_customers.selected_city_id')
                    ->where('cop_customers.customer_id', $customerId)
                    ->get();

                $user_selected_city_id = [];
                $get_user_selected_city->map(function ($item) use (&$user_selected_city_id) {
                    $user_selected_city_id[] = [
                        'selected_city_id' => $item->selected_city_id ? encryptor('e', $item->selected_city_id) : null,
                        'selected_city_name' => $item->city_name ? $item->city_name : null,
                    ];
                });

                return ResponseHelper::responseMessage('success', $user_selected_city_id);
            } else {
                return ResponseHelper::errorResponse('unauthorized');
            }
        } catch (\Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function deleteUser(Request $request)
    {
        try {
            $customer_id = Auth::guard('api')->id();
            $customerDataDelete = Customer::where('customer_id',$customer_id)->first();
            $formattedData=[];
            if(!empty($customerDataDelete)){

                $detailsArray = [
                    'contact_no' => $customerDataDelete->contact_no,
                    'email' => $customerDataDelete->email,
                ];

                // convert above array to json string
                // $jsonString = json_encode($detailsArray);
                $archiveCustomer = Archive::create([
                    'customer_id' => $customerDataDelete->customer_id,
                    'detail' => $detailsArray, // convert json string to normal json
                ]);

                // nullify the user contact_no and email & update status as 0
                $customerDataDelete->contact_no = null;
                $customerDataDelete->email = null;
                $customerDataDelete->status = 0;
                $customerDataDelete->save();

                $formattedData = ['Customer deleted successfully'];
            }
            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }



    /**
     * Update toll fuel count in the database.
     * @param Request $request
     * type : toll or fuel
     * count : count (INT)
     */

    public function updateTollFuelCount(Request $request)
    {

        try {
            $validator = Validator::make($request->all(), [
                'type' => 'required',
                'count' => 'required|numeric'
            ]);

            if ($validator->fails()) {
                return ResponseHelper::errorResponse('error', $validator->errors());
            }

            $customerId = Auth::guard('api')->id();
            $updateData = [];
            if ($request->type == 'fuel') {
                $updateData = ['fuel_count' =>  $request->count, 'fuel_date' => Carbon::now()];
            } elseif ($request->type == 'toll') {
                $updateData = ['toll_count' =>  $request->count, 'toll_date' => Carbon::now()];
            }
            Customer::where('customer_id', $customerId)->update($updateData);
            $data = Customer::where('customer_id', $customerId)->select('fuel_count', 'toll_count', 'fuel_date', 'toll_date')->first();
            return ResponseHelper::responseMessage('success', $data);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
