<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\PostCategoryData;
use App\Http\Controllers\Helpers\ResponseHelper;
use DateTime;
use Exception;
use Illuminate\Http\Request;
use Carbon\Carbon;
class NewsAndBlogsController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    // news and blogs recent and popular both data get (for app) (5-4-2024)
    public function news_and_blogs(Request $request)
    {
        try {
            // post_type input field
            if (!$request->has('post_type') && trim($request->input('post_type'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $post_type_lower_case = strtolower($request->post_type);
                if($post_type_lower_case == 'news' || $post_type_lower_case == 'blogs'){
                    $post_type = $post_type_lower_case == 'news' ? 0 : 1;
                } else {
                    return ResponseHelper::errorResponse('error','post_type should be News or Blogs only');
                }
            }

            $newsAndBlogsData = PostCategoryData::join('cop_pct_ms','cop_pct_ms.post_cat_id','=','cop_post.post_cat_id')
            ->where('cop_pct_ms.style',$post_type)
            ->where('cop_pct_ms.status',1)
            ->where('cop_post.status',1)
            ->get();

            if($newsAndBlogsData->isEmpty()){
                return ResponseHelper::errorResponse('error','No data available of '.$post_type.' !!');
            }

            $recent_news_blogs = [];
            $popular_news_blogs = [];
            $newsAndBlogsData->map(function ($item) use(&$recent_news_blogs, &$popular_news_blogs) {
                $postDateOnString = $item->post_date;
                $strToTime = strtotime($postDateOnString);
                $post_date = date('d F, Y', $strToTime);
                $dayOfWeek = date('l', $strToTime);

                $today_date = date("Y/m/d");
                $current_datetime = new DateTime($today_date);
                $past_datetime = new DateTime($item->post_date);
                $interval = $current_datetime->diff($past_datetime);
                $days_passed_no = $interval->days;

                if ($days_passed_no == 0) {
                    $days_passed = "Today";
                } elseif ($days_passed_no == 1) {
                    $days_passed = "Yesterday";
                } elseif ($days_passed_no < 30) {
                    $days_passed = "$days_passed_no Days";
                } elseif ($days_passed_no < 365) {
                    $months = $interval->m;
                    $days_passed = "$months Months & " . ($days_passed_no % 30) . " Days";
                } else {
                    $years = floor($days_passed_no / 365);
                    $remaining_days = $days_passed_no % 365;
                    $days_passed = "$years Years & $remaining_days Days";
                }
                
                // recent news/blogs append in rencent_news_blogs array
                if($days_passed_no <= 30){
                    $recent_news_blogs[] = [
                        'post_type' => $item->style == 0 ? 'News' : 'Blogs',
                        'category_name' => $item->post_cat_name,
                        'title' => $item->title,
                        'content_details' => $item->content,
                        'content_image' => $this->imagePath ."Post/{$item->post_id}/Post_image/{$item->post_image}",
                        'author_name' => $item->author,
                        'author_image' => $item->author_image ? $this->imagePath ."Post/{$item->post_id}/Author_image/{$item->author_image}" : null,
                        'date' => $post_date,
                        'day_of_week' => $dayOfWeek,
                        'days_passed' => $days_passed,
                    ];
                }
                
                // popular news/blogs append in popular_news_blogs array
                if($item->is_popular == 1){
                    $popular_news_blogs[] = [
                        'post_type' => $item->style == 0 ? 'News' : 'Blogs',
                        'category_name' => $item->post_cat_name,
                        'title' => $item->title,
                        'content_details' => $item->content,
                        'content_image' => $this->imagePath ."Post/{$item->post_id}/Post_image/{$item->post_image}",
                        'author_name' => $item->author,
                        'author_image' => $item->author_image ? $this->imagePath ."Post/{$item->post_id}/Author_image/{$item->author_image}" : null,
                        'date' => $post_date,
                        'day_of_week' => $dayOfWeek,
                        'days_passed' => $days_passed,
                    ];
                }
            });  
            
            $result = [
                'recent_post' => $recent_news_blogs,
                'popular_post' => $popular_news_blogs,
            ];

            return ResponseHelper::responseMessage('success', $result);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // recent news and blogs in New Car page
    public function new_car_news_and_blogs(Request $request)
    {
        try {
            $recentNewsAndBlogs = PostCategoryData::select('cop_post.title','cop_post.post_id','cop_post.post_image','cop_post.content','cop_post.author','cop_post.post_date','cop_pct_ms.post_cat_name','cop_pct_ms.style')
            ->join('cop_pct_ms','cop_post.post_cat_id','=','cop_pct_ms.post_cat_id')
            ->orderBy('cop_post.post_date','desc')
            ->limit(10)
            ->get();

            $recent_news_and_blogs = [];
            $recentNewsAndBlogs->map(function($item) use(&$recent_news_and_blogs) {
                $postDateOnString = $item->post_date;
                $strToTime = strtotime($postDateOnString);
                $post_date = date('d F, Y', $strToTime);
                $dayOfWeek = date('l', $strToTime);

                $givenCarbonDate = Carbon::createFromFormat('Y/m/d', $item->post_date); 
                $currentDate = Carbon::now(); 
                $interval = $givenCarbonDate->diff($currentDate);

                $days_passed_no = $interval->days;

                if ($days_passed_no == 0) {
                    $days_passed = "Today";
                } elseif ($days_passed_no == 1) {
                    $days_passed = "Yesterday";
                } elseif ($days_passed_no < 30) {
                    $days_passed = "$days_passed_no Days";
                } elseif ($days_passed_no < 365) {
                    $months = $interval->m;
                    $days_passed = "$months Months & " . ($days_passed_no % 30) . " Days";
                } else {
                    $years = floor($days_passed_no / 365);
                    $remaining_days = $days_passed_no % 365;
                    $days_passed = "$years Years & $remaining_days Days";
                }
                
                $recent_news_and_blogs[] = [
                    'post_type' => $item->style == 0 ? 'News' : 'Blogs',
                    'category_name' => $item->post_cat_name,
                    'title' => $item->title,
                    'content_details' => $item->content,
                    'content_image' => $this->imagePath ."Post/{$item->post_id}/Post_image/{$item->post_image}",
                    'author_name' => $item->author,
                    'author_image' => $item->author_image ? $this->imagePath ."Post/{$item->post_id}/Author_image/{$item->author_image}" : null,
                    'date' => $post_date,
                    'day_of_week' => $dayOfWeek,
                    'days_passed' => $days_passed,
                ];
            });

            return ResponseHelper::responseMessage('success', $recent_news_and_blogs);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
