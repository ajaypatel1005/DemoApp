<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Feature;
use App\Models\Model;
use App\Models\Specification;
use App\Models\SpecificationCategory;

class SpecificationCategoryApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {
            $specificationCategory = SpecificationCategory::where('status', '=', 1)->get();
            $formattedData = $specificationCategory->map(function ($item) {

                $data = [
                    'sc_id' => encryptor('e', $item->sc_id),
                    'spec_cat_name' => $item->sc_name,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse('error');
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRETNLY -> specfilter)
    public function specfilter($id)
    {
        $variantId = encryptor('d', $id);
        $specificationCategory = SpecificationCategory::select('sc_id', 'sc_name')->get();
        $formattedData = $specificationCategory->map(function ($item) {
            $data = [
                'sc_id' => encryptor('e', $item->sc_id),
                'spec_cat_name' => $item->sc_name,
            ];
            return $data;
        });

        $specs = Specification::select(
            'cop_spec_ms.sc_id',
            'cop_spec_ms.spec_id',
            'cop_spec_ms.spec_name',
            'cop_spec_ms.spec_image'
        )
            ->leftJoin('cop_sc_ms', 'cop_spec_ms.sc_id', '=', 'cop_sc_ms.sc_id')
            ->where('cop_spec_ms.status', '!=', 0)
            ->get();

        $formatted = $specs->map(function ($item) {
            $data = [
                'sc_id' => encryptor('e', $item->sc_id),
                'spec_id' => encryptor('e', $item->spec_id),
                'spec_name' => $item->spec_name,
                'spec_image' => asset("Specification/{$item->spec_id}/{$item->spec_image}"),
            ];
            return $data;
        });

        // $variantId = $request->variant_id; // Corrected typo
        $features = Model::join('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
            ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
            ->leftJoin('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
            ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
            ->select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_variants.variant_id',
                'cop_variants.variant_name',
                'cop_fv.feature_value',
                'cop_features_ms.features_name',
                'cop_fv.fv_id',
                'cop_fv.spec_id',
                'cop_fv.feature_value',
                'cop_su_ms.su_name'
            )
            ->where('cop_models.status', '=', 1)
            ->where('cop_variants.variant_id', '=', $variantId)
            ->distinct()
            ->get();

        if ($features->isEmpty()) {
            return ResponseHelper::errorResponse('data_not_found');
        }

        $data = [
            'spec_cat' => $formattedData->toArray(),
            'spec' => $formatted->toArray(),
            'Features' => $features->toArray(),
        ];
        return ResponseHelper::responseMessage('success', $data);
    }
}
