<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CarType;
use Exception;

class CarTypeApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    public function index()
    {
        try {
            $carType = CarType::select('cop_ct_ms.ct_id', 'cop_ct_ms.ct_name', 'cop_ct_ms.ct_image', 'cop_ct_ms.priority')
                ->orderBy('priority')
                ->get();
            if ($carType->isEmpty()) {
                // return ResponseHelper::errorResponse(['No data available']);
                return ResponseHelper::errorResponse('data_not_found');
            }

            $formattedData = $carType->map(function ($item) {

                $data = [
                    'ct_id' => encryptor('e',$item->ct_id),
                    'ct_name' => $item->ct_name,
                    // 'ct_image' => asset("car_types/{$item->ct_id}/{$item->ct_id}.svg"),
                    'ct_image' => $this->imagePath ."car_types/{$item->ct_id}/{$item->ct_id}.svg" ?? null,
                    'priority' => $item->priority,
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}