<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CarListing;
use Exception;

class CarListingApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {
            $car_listing = CarListing::all();

            if ($car_listing->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }

            $clData = $car_listing->map(function ($item) {

                $data = [
                    'cl_id' => encryptor('e',$item->cl_id),
                    'car_listing' => $item->cl_name,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $clData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('error');
        }
    }
}
