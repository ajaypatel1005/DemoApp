<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Customer;
use Exception;
use Illuminate\Support\Facades\Validator;

class OtpApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    public function sendOtp(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'contact_no' => 'required|min:12|max:12|regex:/^[0-9]+$/',

            ],
            [
                'contact_no.required' => 'The contact number field is required.',
                'contact_no.min' => 'The contact number must be exactly :min digits.',
                'contact_no.max' => 'The contact number must be exactly :max digits.',
                'contact_no.regex' => 'The contact number must contain only numeric digits.',
            ]
        );

        if ($validator->fails()) {
            $errors = $validator->errors()->all();
            $stringError = implode(',', $errors);
            return ResponseHelper::errorResponseSMS('error', $stringError);
        }

        try {
            $sendOtpURL = config('constant.API_URL.send_otp');
            $response = Http::post($sendOtpURL, [
                'template_id' => env('SMS_TEMPLATE_ID'),
                'mobile' => $request->contact_no,
                'authkey' => env('SMS_AUTH_KEY'),
                'otp_length' => 6,
                'otp_expiry' => 10
            ]);

            if ($response['type'] == 'success') {

                $exist_number = Customer::where('contact_no', encryptor('e',$request->contact_no))->count();

                if ($exist_number == 1) {
                    Customer::where('contact_no', encryptor('e',$request->contact_no))->update([
                        'is_verified' => false
                    ]);
                }
                return ResponseHelper::responseMessage('success', $response->json());
            } else {
                return ResponseHelper::errorResponseSMS('error', $response['message']);
            }
        } catch (Exception $e) {
            return ResponseHelper::errorResponseSMS('error', ['Something want wrong..!']);
        }
    }

    public function verifyOtp(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'contact_no' => 'required|min:12|max:12|regex:/^[0-9]+$/',
                'otp' => 'required|min:6|max:6|regex:/^[0-9]+$/',

            ],
            [
                'contact_no.required' => 'The contact number field is required.',
                'contact_no.min' => 'The contact number must be exactly :min digits.',
                'contact_no.max' => 'The contact number must be exactly :max digits.',
                'contact_no.regex' => 'The contact number must contain only numeric digits.',
                'otp.required' => 'The OTP field is required.',
                'otp.min' => 'The OTP must be exactly :min digits.',
                'otp.max' => 'The OTP must be exactly :max digits.',
                'otp.regex' => 'The OTP must contain only numeric digits.',
            ]
        );


        if ($validator->fails()) {
            $errors = $validator->errors()->all();
            $stringError = implode(',', $errors);
            return ResponseHelper::errorResponseSMS('error', $stringError);
        }

        try {

            $verifyOtpURL = config('constant.API_URL.verify_otp');

            $response = Http::withHeaders([
                'authkey' => env('SMS_AUTH_KEY'),
            ])->get($verifyOtpURL, [
                'otp' => $request->otp,
                'mobile' => $request->contact_no,
            ]);

            if ($response['type'] == 'success') {

                $cust = Customer::updateOrCreate([
                    'contact_no' => encryptor('e',$request->contact_no)

                ], [
                    'is_verified' => true
                ]);

                if ($cust) {
                    return ResponseHelper::responseMessage('success', $response->json());
                } else {
                    return ResponseHelper::errorResponseSMS('error', ['Something want wrong..!']);
                }
            } else {
                return ResponseHelper::errorResponseSMS('error', $response['message']);
            }
        } catch (Exception $e) {
            return ResponseHelper::errorResponseSMS('error', ['Something want wrong..!']);
        }
    }

    public function resendOtp(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'contact_no' => 'required|min:12|max:12|regex:/^[0-9]+$/',
                'otp' => 'min:6|max:6|regex:/^[0-9]+$/',

            ],
            [
                'contact_no.required' => 'The contact number field is required.',
                'contact_no.min' => 'The contact number must be exactly :min digits.',
                'contact_no.max' => 'The contact number must be exactly :max digits.',
                'contact_no.regex' => 'The contact number must contain only numeric digits.',
                'otp.min' => 'The OTP must be exactly :min digits.',
                'otp.max' => 'The OTP must be exactly :max digits.',
                'otp.regex' => 'The OTP must contain only numeric digits.',
            ]
        );

        if ($validator->fails()) {
            $errors = $validator->errors()->all();
            $stringError = implode(',', $errors);
            return ResponseHelper::errorResponse('error', $stringError);
        }

        try {
            $resendOtpURL = config('constant.API_URL.resend_otp');
            $response = Http::get($resendOtpURL, [
                'authkey' => env('SMS_AUTH_KEY'),
                'retrytype' => 'text',
                'mobile' => $request->contact_no,
            ]);


            if ($response['type'] == 'success') {

                $exist_number = Customer::where('contact_no', encryptor('e',$request->contact_no))->count();

                if ($exist_number == 1) {
                    Customer::where('contact_no', encryptor('e',$request->contact_no))->update([
                        'is_verified' => false
                    ]);
                }
                return ResponseHelper::responseMessage('success', $response->json());
            } else {
                return ResponseHelper::errorResponseSMS('error', $response['message']);
            }
        } catch (Exception $e) {
            return ResponseHelper::errorResponseSMS('error', ['Something want wrong..!']);
        }
    }
}
