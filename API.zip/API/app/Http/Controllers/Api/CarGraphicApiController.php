<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CarGraphic;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class CarGraphicApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {
            $cargrphic = CarGraphic::select(
                'cop_graphics.graphic_id','cop_graphics.graphic_file',
                'cop_gt_ms.gt_name',
                'cop_brands_ms.brand_name',
                'cop_models.model_name'
            )
                ->leftJoin('cop_gt_ms', 'cop_graphics.gt_id', '=', 'cop_gt_ms.gt_id')
                ->leftJoin('cop_brands_ms', 'cop_graphics.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_models', 'cop_graphics.model_id', '=', 'cop_models.model_id')
                ->where('cop_graphics.status', '!=', 0)
                ->get();


            if ($cargrphic->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }
            // dd($cargrphic);
            $cargrphicData = $cargrphic->map(function ($item) {
                if ($item->gt_name == 'Images') {
                    $single_image = explode(',', $item->graphic_file);
                    $graphicFiles = [];
                    for ($i = 0; $i < count($single_image); $i++) {
                        $graphicFiles[] = $this->imagePath ."car_graphics/{$item->model_id}/images/{$single_image[$i]}" ?? null;
                    }
                    return [
                        'graphic_id' => encryptor('e',$item->graphic_id),
                        'brand_name' => $item->brand_name,
                        'model_name' => $item->model_name,
                        'gt_name' => $item->gt_name,
                        'graphic_file' => $graphicFiles,
                    ];
                } elseif ($item->gt_name == 'Video') {
                    return [
                        'graphic_id' => encryptor('e',$item->graphic_id),
                        'brand_name' => $item->brand_name,
                        'model_name' => $item->model_name,
                        'gt_name' => $item->gt_name,
                        'graphic_file'=>$this->imagePath ."car_graphics/{$item->model_id}/videos/{$item->graphic_file}" ?? null,
                    ];
                } elseif ($item->gt_name == 'Images 360') {
                    $single_image = explode(',', $item->graphic_file);
                    $graphicFiles = [];
                    for ($i = 0; $i < count($single_image); $i++) {
                        $graphicFiles[] = $this->imagePath ."car_graphics/{$item->model_id}/360_images/{$single_image[$i]}" ?? null;
                    }

                    return [
                        'graphic_id' => encryptor('e',$item->graphic_id),
                        'brand_name' => $item->brand_name,
                        'model_name' => $item->model_name,
                        'gt_name' => $item->gt_name,
                        'graphic_file' => $graphicFiles,
                    ];
                } else {
                    return [
                        'graphic_id' => encryptor('e',$item->graphic_id),
                        'brand_name' => $item->brand_name,
                        'model_name' => $item->model_name,
                        'gt_name' => $item->gt_name,
                        'graphic_file' => null,
                    ];
                }
            });

            return ResponseHelper::responseMessage('success', $cargrphicData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('error');
        }
    }
}