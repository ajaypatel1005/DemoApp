<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\City;

class CityApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {
            $state = City::select(
                'cop_city_ms.city_id',
                'cop_city_ms.city_name',
                'cop_city_ms.city_image',
                'cop_state_ms.state_name as state_name'
            )
                ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
                ->where('cop_city_ms.status', '!=', 0)
                ->where('cop_state_ms.status', '!=', 0)
                ->get();

            if ($state->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }
            $stateData = $state->map(function ($item) {
                $data = [
                    'city_id' => encryptor('e', $item->city_id),
                    'state_name' => $item->state_name,
                    'city_name' => $item->city_name,
                    'city_image' => $this->imagePath . "city_image/{$item->city_id}/{$item->city_image}",
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $stateData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRETNLY -> index) to get city tier (for app & website both) (4-4-2024)
    public function city_tier(Request $request)
    {
        try {

            // month input field
            if (!$request->has('tier') && trim($request->input('tier')) == '') {
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                if (!is_numeric($request->tier)) {
                    return ResponseHelper::errorResponse('error','tier should be number only');
                } else {
                    if ($request->tier > 4 || $request->tier < 1) {
                        return ResponseHelper::errorResponse('error','tier should be 1 to 4 only');
                    } else {
                        $tier = $request->tier;
                    }
                }
            }

            $tierWiseCity = City::select(
                'cop_city_ms.city_id',
                'cop_city_ms.city_name',
                'cop_city_ms.city_image',
                'cop_state_ms.state_name'
            )
                ->join('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
                ->where('cop_city_ms.status', 1)
                ->where('cop_state_ms.status', 1)
                ->where('cop_city_ms.tier', $tier)
                ->get();

            if ($tierWiseCity->isEmpty()) {
                return ResponseHelper::errorResponse('error','No data available for tier ' . $tier . ' !!');
            }

            $tier_wise_city_data = [];
            $tierWiseCity->map(function ($item) use (&$tier_wise_city_data) {
                $tier_wise_city_data[] = [
                    'city_id' => encryptor('e', $item->city_id),
                    'state_name' => $item->state_name,
                    'city_name' => $item->city_name,
                    'city_image' => $this->imagePath . "city_image/{$item->city_id}/{$item->city_image}",
                ];
            });
            return ResponseHelper::responseMessage('success', $tier_wise_city_data);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
