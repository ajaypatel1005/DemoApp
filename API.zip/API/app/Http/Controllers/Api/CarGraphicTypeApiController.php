<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Models\CarGraphicType;
use App\Http\Controllers\Helpers\ResponseHelper;

class CarGraphicTypeApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRENTLY -> index)
    public function index()
    {
        try {
            $graphic_type = CarGraphicType::where('status', '=', 1)->select('gt_id','gt_name')->get();
            if ($graphic_type->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }
            $formattedData = $graphic_type->map(function ($item) {

                $data = [
                    'graphic_type_id' => encryptor('e',$item->gt_id),
                    'graphic_type_name' => $item->gt_name,
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('error');
        }
    }
}
