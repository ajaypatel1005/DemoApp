<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\State;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;

class StateApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {
            $state = State::select(
                'cop_state_ms.state_id',
                'cop_state_ms.state_name',
                'cop_country_ms.country_name as country_name'
            )
                ->leftJoin('cop_country_ms', 'cop_state_ms.country_id', '=', 'cop_country_ms.country_id')
                ->where('cop_state_ms.status', '!=', 0) // Filter out banners with status 0
                ->get();
            $stateData = $state->map(function ($item) {
                $data = [
                    'state_id' => encryptor('e', $item->state_id),
                    'country_name' => $item->country_name,
                    'state_name' => $item->state_name,
                ];
                return $data;
            });
            return ResponseHelper::responseMessage('success', $stateData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
