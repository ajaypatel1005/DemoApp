<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\WarningLight;

class WarningLightApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    public function index()
    {
        try {
            $imagePath = $this->imagePath;
            $warningLights = WarningLight::where('wl_status', '!=', 0)
                ->select('wl_id', 'wl_name', 'wl_icon', 'wl_video', 'wl_heading', 'wl_subheading', 'wl_info', 'wl_display_position')
                ->get()->map(function ($item) use ($imagePath) {
                    $item->wl_icon = $imagePath . "warning_light/{$item->wl_id}/{$item->wl_icon}" ?? null;
                    $item->wl_video = $imagePath . "warning_light/{$item->wl_id}/{$item->wl_video}" ?? null;
                    $item->wl_id = encryptor('e', $item->wl_id);

                    $subheading = json_decode($item->wl_subheading,true);
                    $info = json_decode($item->wl_info,true);

                    $item->indications = $info[0];
                    $item->precautions = $info[1];

                    // unset wl_subheading and wl_info that has been selected but to return
                    unset($item->wl_subheading);
                    unset($item->wl_info);

                    return $item;
                });
            if ($warningLights->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }


            return ResponseHelper::responseMessage('success', $warningLights);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // (NOT IN USE CURRETNLY -> wl_phone)
    public function wl_phone()
    {
        try {
            $imagePath = $this->imagePath;
            $warningLights = WarningLight::where('wl_status', '!=', 0)->select('wl_id', 'wl_name', 'wl_icon', 'wl_video', 'wl_heading', 'wl_info', 'wl_subheading', 'wl_display_position')->get()->map(function ($item) use ($imagePath) {
                $item->wl_icon = $imagePath . "warning_light/{$item->wl_id}/{$item->wl_icon}";
                $item->wl_video = $imagePath . "warning_light/{$item->wl_id}/{$item->wl_video}";
                $item->wl_subheading_info = $this->transformSubheadingInfo($item->wl_info, $item->wl_subheading);
                $item->wl_id = encryptor('e', $item->wl_id);
                return $item;
            });
            if ($warningLights->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }
            return ResponseHelper::responseMessage('success', $warningLights);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // private function transformSubheadingInfo($info, $subheading)
    // {
    //     $infoArray = is_string($info) ? json_decode($info, true) : $info;
    //     $subheadingArray = is_string($subheading) ? json_decode($subheading, true) : $subheading;

    //     $subheadingInfo = [];

    //     foreach ($infoArray as $index => $infoGroup) {
    //         $obj = [
    //             'wl_subheading' => isset($subheadingArray[$index]) ? $subheadingArray[$index] : null,
    //             'wl_info' => $infoGroup,
    //         ];
    //         $subheadingInfo[] = $obj;
    //     }

    //     return $subheadingInfo;
    // }
}
