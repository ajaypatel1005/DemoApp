<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\PageContent;
use Exception;
use Illuminate\Http\Request;

class PageContentApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRENTLY -> index)
    public function index(Request $request)
    {
        try {
            $pc_name = $request->search;
            $page_content = PageContent::where(function ($query) use ($request) {
                $query->orWhere('cop_pc.pc_name', 'like', '%' . $request->search . '%');
            })
                ->select('pc_id', 'pc_name', 'pc_title', 'pc_sub_title', 'pc_description', 'pc_m_title', 'pc_m_sub_title', 'pc_m_description', 'pc_b_text', 'pc_b_link', 'pc_b_type')
                ->where('cop_pc.pc_name', '=', $pc_name)
                ->where('cop_pc.status', '!=', 0)
                ->get();

            if ($page_content->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }
            $page_contentData = $page_content->map(function ($item) {
                $item->pc_id = encryptor('e', $item->pc_id);
                return $item;
            });
            return ResponseHelper::responseMessage('success', $page_contentData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
