<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\FeatureOption;

class FeatureOptionApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {
            $featureOption = FeatureOption::all();
            // dd($models);

            if ($featureOption->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }
            $featureOptionData = $featureOption->map(function ($item) {


                $data = [
                    'fo_id' => encryptor('e',$item->fo_id),
                    'fo_value' => $item->fo_value,
                       ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $featureOptionData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('error');
        }
    }

}
