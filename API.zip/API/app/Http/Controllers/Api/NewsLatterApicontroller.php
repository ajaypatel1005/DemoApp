<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\NewsLatter;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use Illuminate\Support\Facades\Validator;

class NewsLatterApicontroller extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'email' => 'Required|email',
        ], [
            'email.email' => 'The email must be a valid email address.',
        ]);
        if ($validator->fails()) {
            return ResponseHelper::errorResponse('error','The email must be a valid email address.');
        }
        $addnewsLatter = new NewsLatter();
        $addnewsLatter->email = $request->email;
        $addnewsLatter->status = $request->has('status') ? 1 : 0;
        $addnewsLatter->save();

        return ResponseHelper::responseMessage('success','Car On Phone Subscribe !!');
    }
}
