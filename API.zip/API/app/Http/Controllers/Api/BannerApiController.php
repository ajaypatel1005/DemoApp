<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Banner;
use Illuminate\Support\Facades\File;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

class BannerApiController extends Controller
{
    protected $imagePath;

    public function __construct()
    {
        $this->imagePath = env('IMAGE_PATH');
    }

    public function banner(Request $request)
    {  
        try {
            
            if(!($request->has('type')) && trim($request->input('type')) == "" ){
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $bcName = $request->type;
            $data = Banner::select('cop_banners.banner_id','cop_banners.bc_id','cop_banners.banner_heading','cop_banners.banner_description','cop_banners.banner_image_mob','cop_banners.btn_text','cop_banners.btn_link', 'cop_bc_ms.bc_name', 'cop_brands_ms.brand_name', 'cop_models.model_name', 'cop_variants.variant_name', 'cop_models.model_id', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_bc_ms', 'cop_banners.bc_id', '=', 'cop_bc_ms.bc_id')
                ->leftJoin('cop_brands_ms', 'cop_banners.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_models', 'cop_banners.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_variants', 'cop_banners.variant_id', '=', 'cop_variants.variant_id')
                ->where('cop_bc_ms.bc_name', '=', $bcName)
                ->where('cop_banners.status',1)
                ->orderBy('cop_banners.priority', 'asc')
                // ->orderByRaw( "
                //     CASE
                //         WHEN cop_brands_ms.brand_name = 'BMW' THEN 1
                //         WHEN cop_brands_ms.brand_name = 'Mahindra' THEN 2
                //         WHEN cop_brands_ms.brand_name = 'Maruti Suzuki' THEN 3
                //         WHEN cop_brands_ms.brand_name = 'BYD' THEN 4
                //         WHEN cop_brands_ms.brand_name = 'Lexus' THEN 5
                //         ELSE 6
                //     END
                // " )
                ->get();
            // dd($data);
            $formattedData = [];
            $base_url = config('constant.fronted_url');
            foreach ($data as $item) {
                $formattedData[] = [
                    'banner_id' => encryptor('e',$item->banner_id),
                    'bc_id' => encryptor('e',$item->bc_id),
                    'bc_name' => $item->banner_category->bc_name ?? NULL,
                    'brand_id' => $item->brand_id ? encryptor('e',$item->brand_id) : NULL,
                    'brand_name' => $item->brand_name ? $item->brand_name : NULL,
                    'model_id' => $item->model_id ? encryptor('e',$item->model_id) : NULL,
                    'model_name' => $item->model_name ? $item->model_name : NULL,
                    'banner_heading' => $item->banner_heading,
                    'banner_description' => $item->banner_description,
                    'banner_image' => $this->imagePath ."Banner/{$item->banner_id}/{$item->banner_image_mob}",
                    'btn_text' => $item->btn_text,
                    'btn_link' =>  $item->model_name ?? NULL,
                ];
            }
            if (count($data) > 0) {

                return ResponseHelper::responseMessage('success', $formattedData);
            } else {
                return ResponseHelper::errorResponse('data_not_found');
            }
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('error');
        }
    }
}
