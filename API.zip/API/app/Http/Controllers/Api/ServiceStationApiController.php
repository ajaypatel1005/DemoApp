<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\ServiceStation;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ServiceStationApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    public function index(Request $request)
    {
        try {
            if(!$request->has('brand_id') && trim($request->input('brand_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $brand_id = ($request->has('brand_id'))?encryptor('d',$request->input('brand_id')):0;
            
            
            if(empty($brand_id) || $brand_id == 0){
                return ResponseHelper::errorResponse('error','Invalid Brand');
            }
            
            if(!$request->has('city_id') && trim($request->input('city_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $city_id = ($request->has('city_id'))?encryptor('d',$request->input('city_id')):0;
            if(empty($city_id) || $city_id == 0){
                return ResponseHelper::errorResponse('error','Invalid City');
            }
            // $city_id = $request->city_id;
            // $brand_id = $request->brand_id;

            $service_station =  ServiceStation::select('cop_s_stations_ms.*', 'cop_brands_ms.brand_name as brand_name', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
                ->leftJoin('cop_brands_ms', 'cop_s_stations_ms.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_city_ms', 'cop_s_stations_ms.city_id', '=', 'cop_city_ms.city_id')
                ->leftJoin('cop_state_ms', 'cop_state_ms.state_id', '=', 'cop_city_ms.state_id')
                ->where('cop_s_stations_ms.status', 1)
                ->where('cop_s_stations_ms.city_id', '=', $city_id)
                ->when($brand_id, function ($query) use ($brand_id) {
                    return $query->whereExists(function ($subQuery) use ($brand_id) {
                        $subQuery->select(DB::raw(1))
                            ->from('cop_s_stations_ms')
                            ->whereColumn('cop_s_stations_ms.brand_id', '=', 'cop_brands_ms.brand_id')
                            ->where('cop_s_stations_ms.brand_id', '=', $brand_id);
                    });
                })
                ->paginate(12);

            if ($service_station->isEmpty()) {
                // return ResponseHelper::errorResponse('data_not_found');
                return ResponseHelper::errorResponse('data_not_found');
            }
            $formattedData['service_station'] = $service_station->map(function ($item) {
                $data = [
                    's_station_id' => encryptor('e',$item->s_station_id),
                    'brand_id' =>  encryptor('e',$item->brand_id),
                    'brand_name' =>  $item->brand_name,
                    's_station_name' => $item->s_station_name,
                    's_station_address' => $item->s_station_address,
                    's_station_location' => $item->s_station_location,
                    'state_name' => $item->state_name,
                    'city_name' => $item->city_name,
                    's_station_contact_number' => $item->contact_no,
                    's_station_emil' => $item->email,
                ];

                return $data;
            });
            $formattedData['total_record'] = $service_station->total();
            $formattedData['current_page'] = $service_station->currentPage();
            $formattedData['last_page'] = $service_station->lastPage();

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function s_station_brand(Request $request)
    {
        try {
            $s_station = ServiceStation::join('cop_brands_ms', 'cop_s_stations_ms.brand_id', '=', 'cop_brands_ms.brand_id')
                ->where('cop_brands_ms.status', 1)
                ->select('cop_brands_ms.brand_id', 'cop_brands_ms.brand_name')
                ->orderBy('priority', 'asc')
                ->distinct()
                ->get();

            if ($s_station->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $formattedData = $s_station->map(function ($item) {

                $data = [
                    'brand_id' => encryptor('e',$item->brand_id),
                    'brand_name' => $item->brand_name,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    public function s_station_city(Request $request)
    {
        try {
            // $brand_id = $request->input('brand_id');
            if(!$request->has('brand_id') && trim($request->input('brand_id'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            }
            $brand_id = ($request->has('brand_id'))?encryptor('d',$request->input('brand_id')):0;
            if(empty($brand_id) || $brand_id == 0){
                return ResponseHelper::errorResponse('error','Invalid Brand');
            }
            
            $s_station = ServiceStation::join('cop_city_ms', 'cop_s_stations_ms.city_id', '=', 'cop_city_ms.city_id')
                ->where('cop_s_stations_ms.brand_id', $brand_id)
                ->select('cop_city_ms.city_id', 'cop_city_ms.city_name')
                ->distinct()
                ->get();

            if ($s_station->isEmpty()) {
                return ResponseHelper::errorResponse('data_not_found');
            }

            $formattedData = $s_station->map(function ($item) {

                $data = [
                    'city_id' => encryptor('e',$item->city_id),
                    'city_name' => $item->city_name,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
