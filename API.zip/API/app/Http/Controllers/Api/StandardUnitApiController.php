<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\StandardUnit;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;

class StandardUnitApiController extends Controller
{
    // (NOT IN USE CURRETNLY -> imagePath)
    protected $imagePath;

    // (NOT IN USE CURRETNLY -> imagePath)
    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {
            $standardUnit = StandardUnit::all();
            // dd($models);
            $formattedData = $standardUnit->map(function ($item) {

                $data = [
                    'su_id' => $item->su_id,
                    'su_name' => $item->su_name,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse('error');
            return ResponseHelper::errorResponse('error');
        }
    }
}
