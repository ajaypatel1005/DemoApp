<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Model;
use Exception;
use Illuminate\Support\Facades\DB;

class UpcomingCarApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    // (NOT IN USE CURRENTLY -> upComingCar) upcoming cars data (website)
    public function upComingCar(Request $request)
    {
        try {
            $min_Price = $request->minprice;
            $max_Price = $request->maxprice;

            $currentDate = now()->toDateString();

            //brand by
            $modelCounts = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                ->select('cop_models.brand_id', 'cop_brands_ms.brand_name', DB::raw('COUNT(*) as model_count'))
                ->where('cop_cs_ms.cs_name', '=', 'Upcoming')
                ->where('cop_models.launch_date', '>', $currentDate)
                ->groupBy('cop_models.brand_id', 'cop_brands_ms.brand_name');


            if ($request->has('minprice')) {
                $modelCounts->where('cop_models.min_price', '>=', $min_Price);
            }

            if ($request->has('maxprice')) {
                $modelCounts->where('cop_models.max_price', '<=', $max_Price);
            }

            // if ($request->has('brand_id') && !empty($request->input('brand_id'))) {
            //     $brandId = $request->input('brand_id');
            //     $modelCounts->where('cop_models.brand_id', '=', $brandId);
            // }

            $modelscount = $modelCounts->distinct()->get();
            if ($request->has('ct_name') && !empty($request->input('ct_name'))) {
                $ct_name = explode(',', $request->input('ct_name'));
                $modelCounts->whereIn('cop_ct_ms.ct_name', $ct_name);
            }

            if ($request->has('month')) {
                $monthsAhead = (int) $request->input('month');

                if ($monthsAhead > 0) {
                    $currentMonth = now();
                    $endDate = $currentMonth->copy()->addMonths($monthsAhead)->startOfMonth()->subDay(); // Adjusted this line

                    $modelCounts->whereDate('cop_models.launch_date', '>=', $currentMonth)
                        ->whereDate('cop_models.launch_date', '<=', $endDate);
                } else {

                    return response()->json(['error' => 'Invalid value for month parameter'], 400);
                }
            }


            $modelscount = $modelCounts->distinct()->get();
            /// end brand counts

            // start car type


            $cartypeCounts = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                ->select('cop_models.ct_id', 'cop_ct_ms.ct_name', 'cop_ct_ms.ct_image', 'cop_brands_ms.brand_id', DB::raw('COUNT(*) as model_count'))
                ->where('cop_cs_ms.cs_name', '=', 'Upcoming')
                ->groupBy('cop_models.ct_id', 'cop_ct_ms.ct_name', 'cop_brands_ms.brand_id', 'cop_ct_ms.ct_image');
            // ->get();

            if ($request->has('minprice') && !empty($min_Price)) {
                $cartypeCounts->where('cop_models.min_price', '>=', $min_Price);
            }

            if ($request->has('maxprice') && !empty($max_Price)) {
                $cartypeCounts->where('cop_models.max_price', '<=', $max_Price);
            }


            // if ($request->has('ct_id') && !empty($request->input('ct_id'))) {
            //     $ct_id = explode(',', $request->input('ct_id'));
            //     $cartypeCounts->whereIn('cop_ct_ms.ct_id', $ct_id);
            // }
            // $cartype_counts = $cartypeCounts->distinct()->get();

            if ($request->has('brand_name') && !empty($request->input('brand_name'))) {
                $brand_name = explode(',', $request->input('brand_name'));
                $cartypeCounts->whereIn('cop_brands_ms.brand_name', $brand_name);
            }


            if ($request->has('month')) {
                $monthsAhead = (int) $request->input('month');

                if ($monthsAhead > 0) {
                    $currentMonth = now();
                    $endDate = $currentMonth->copy()->addMonths($monthsAhead)->startOfMonth()->subDay(); // Adjusted this line

                    $cartypeCounts->whereDate('cop_models.launch_date', '>=', $currentMonth)
                        ->whereDate('cop_models.launch_date', '<=', $endDate);
                } else {

                    return response()->json(['error' => 'Invalid value for month parameter'], 400);
                }
            }

            $cartype_counts = $cartypeCounts->distinct()->get();

            $groupedData = $cartype_counts->groupBy('ct_name');


            $aggregatedModelCounts = [];


            foreach ($groupedData as $brandName => $models) {
                $aggregatedModelCounts[] = [
                    'ct_id' => $models[0]->ct_id,
                    // 'ct_image' => $models[0]->ct_image,
                    'ct_image' => $this->imagePath . "car_types/{$models[0]->ct_id}/{$models[0]->ct_id}.svg" ?? null,
                    'ct_name' => $brandName,
                    'model_count' => $models->sum('model_count'),
                ];
            }




            /// end car type


            // price


            $price_counts = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                ->selectRaw('
                    CASE
                        WHEN ( (cop_models.min_price >= 200000 AND cop_models.min_price < 1000000) And (`cop_models`.`max_price` BETWEEN 200000 AND 1000000)) THEN "200000 - 1000000"
                        WHEN ( (cop_models.min_price >= 1000000 AND cop_models.min_price < 2500000) And (`cop_models`.`max_price` BETWEEN 1000000 AND 2500000)) THEN "1000000 - 2500000"
                        WHEN ( (cop_models.min_price >= 2500000 AND cop_models.min_price < 5000000) AND (`cop_models`.`max_price` BETWEEN 2500000 AND 5000000) ) THEN "2500000 - 5000000"
                        WHEN ( (cop_models.min_price >= 5000000 AND cop_models.min_price < 10000000) AND (`cop_models`.`max_price` BETWEEN 5000000 AND 10000000) ) THEN "5000000 - 10000000"
                        WHEN ( (cop_models.min_price > 10000000) ) THEN "10000000 - 990000000"
                    END AS price_range,
                    COUNT(*) AS model_count
                ')
                ->where('cop_cs_ms.cs_name', '=', 'Upcoming')

                ->groupBy('price_range')

                ->orderByRaw("FIELD(price_range, '200000 - 1000000', '1000000 - 2500000', '2500000 - 5000000', '5000000 - 10000000', '10000000 - 990000000')");


            // if ($request->has('minprice') && !empty($min_Price)) {
            //     $price_counts->where('cop_models.min_price', '>=', $min_Price);
            // }

            // if ($request->has('maxprice') && !empty($max_Price)) {
            //     $price_counts->where('cop_models.max_price', '<=', $max_Price);
            // }
            if ($request->has('ct_name') && !empty($request->input('ct_name'))) {
                $ct_name = explode(',', $request->input('ct_name'));
                $price_counts->whereIn('cop_ct_ms.ct_name', $ct_name);
            }

            if ($request->has('brand_name') && !empty($request->input('brand_name'))) {
                $brand_name = explode(',', $request->input('brand_name'));
                $price_counts->whereIn('cop_brands_ms.brand_name', $brand_name);
            }

            if ($request->has('month')) {
                $monthsAhead = (int) $request->input('month');

                if ($monthsAhead > 0) {
                    $currentMonth = now();
                    $endDate = $currentMonth->copy()->addMonths($monthsAhead)->startOfMonth()->subDay(); // Adjusted this line

                    $price_counts->whereDate('cop_models.launch_date', '>=', $currentMonth)
                        ->whereDate('cop_models.launch_date', '<=', $endDate);
                } else {

                    return response()->json(['error' => 'Invalid value for month parameter'], 400);
                }
            }


            $price_count = $price_counts->get();



            $show_prices = []; // Initialize an array to store all price range data

            foreach ($price_count as $price) {
                switch ($price->price_range) {
                    case "200000 - 1000000":
                        $show_keyword = "2 - 10 lakh";
                        break;
                    case "1000000 - 2500000":
                        $show_keyword = "10 - 25 lakh";
                        break;
                    case "2500000 - 5000000":
                        $show_keyword = "25 - 50 lakh";
                        break;
                    case "5000000 - 10000000":
                        $show_keyword = "50 lakh  - 1 crore";
                        break;
                    case "10000000 - 990000000":
                        $show_keyword = "1 Cr+";
                        break;
                    default:
                        $show_keyword = "Unknown";
                }

                $show_prices[] = [
                    "price_range" => $price->price_range,
                    "model_count" => $price->model_count,
                    "show_keyword" => $show_keyword
                ];
            }


            // dd( $price_count);
            /// end price

            $currentDate = now()->toDateString();
            $upcomingModel = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                ->select(
                    'cop_brands_ms.brand_id',
                    'cop_models.model_id',
                    'cop_ct_ms.ct_id',
                    'cop_ct_ms.ct_name',
                    'cop_ct_ms.ct_image',
                    'cop_brands_ms.brand_name',
                    'cop_models.model_name',
                    'cop_models.launch_date',
                    'cop_cs_ms.cs_name',
                    'cop_models.model_image',
                    'cop_models.min_price',
                    'cop_models.max_price',
                    'cop_models.model_type',
                )
                ->where('cop_cs_ms.cs_name', '=', 'Upcoming')
                ->where('cop_models.launch_date', '>', $currentDate);

            if ($request->has('month')) {
                $monthsAhead = (int) $request->input('month');

                if ($monthsAhead > 0) {
                    $currentMonth = now();
                    $endDate = $currentMonth->copy()->addMonths($monthsAhead)->startOfMonth()->subDay();

                    $upcomingModel->whereDate('cop_models.launch_date', '>=', $currentMonth)
                        ->whereDate('cop_models.launch_date', '<=', $endDate);
                } else {

                    return response()->json(['error' => 'Invalid value for month parameter'], 400);
                }
            }

            if ($request->has('brand_name') && !empty($request->input('brand_name'))) {

                $brand_name = explode(',', $request->input('brand_name'));
                $upcomingModel->whereIn('cop_brands_ms.brand_name', $brand_name);
            }

            if ($request->has('ct_name') && !empty($request->input('ct_name'))) {
                $ct_name = explode(',', $request->input('ct_name'));
                $upcomingModel->whereIn('cop_ct_ms.ct_name', $ct_name);
            }

            if (!empty($min_Price) && !empty($max_Price)) {

                $upcomingModel->where('cop_models.min_price', '>=', $min_Price)
                    ->where('cop_models.max_price', '<=', $max_Price);
            }

            $models = $upcomingModel->distinct()->get();
            // if ($models->isEmpty()) {
            //     return ResponseHelper::errorResponse('data_not_found');
            // }



            $formattedData = $models->map(function ($item) {
                return [

                    'brand_id' => encryptor('e',$item->brand_id),
                    'ct_id' => encryptor('e',$item->ct_id),
                    'ct_name' => $item->ct_name,
                    'ct_image' => $this->imagePath . "car_types/{$item->ct_id}/{$item->ct_id}.svg" ?? null,
                    'brand_name' => $item->brand_name,
                    'model_name' => $item->model_name,
                    'launch_date' => date('d M, Y', strtotime($item->launch_date)),
                    'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp" ?? NULL,
                    'min_price' =>  convertToLakhCrore($item->min_price),
                    'max_price' =>  convertToLakhCrore($item->max_price),
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                ];
            });


            $combineData = [
                'brand' => $modelscount,
                'cartype' => $aggregatedModelCounts,
                'price_counts' => $show_prices,
            ];


            $responseData = [
                'countdata' => $combineData,
                'upcoming_model' => $formattedData,
            ];

            return ResponseHelper::responseMessage('success', $responseData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // upcoming months (app) (3-4-24)
    public function upcoming_months()
    {
        try {
            $months = ['3 months', '6 months', '9 months', '12 months'];
            $data['months'] = $months;

            return ResponseHelper::responseMessage('success', $data);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // upcoming cars data (app) (3-4-24)
    public function upcoming_car_data(Request $request)
    {
        try {
            // month input field
            if (!$request->has('within_months') && trim($request->input('within_months'))==''){
                return ResponseHelper::errorResponse('missing_required_field');
            } else {
                $month_explode = explode(' ',$request->input('within_months'));

                if(!is_numeric($month_explode[0])) {
                    return ResponseHelper::errorResponse('error','within_months should be 3 months to 12 months only');
                } else {
                    if($month_explode[0] > 12 || $month_explode[0] < 3){
                        return ResponseHelper::errorResponse('error','within_months should be 3 months to 12 months only');
                    } else {
                        $within_months = $month_explode[0];
                    }
                }
            }

            // car stage as upcoming
            $carStage = config('constant.UPCOMING');

            // count next date as per the input of within_months
            $currentDate = now()->toDateString();
            $nextDate = date('Y-m-d', strtotime("+".$within_months." months", strtotime($currentDate)));

            // get data
            $upcomingModel = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.launch_date',
                    'cop_models.model_image',
                    'cop_models.model_type',
                    'cop_models.min_price',
                    'cop_models.max_price',
                    'cop_cs_ms.cs_name',
                )
                ->where('cop_cs_ms.cs_name', $carStage)
                ->where('cop_models.launch_date', '>', $currentDate)
                ->where('cop_models.launch_date', '<=', $nextDate)
                ->where('cop_models.status',1)
                ->where('cop_brands_ms.status',1)
                ->orderBy('launch_date','asc')
                ->get();

                $formattedData = $upcomingModel->map(function ($item) {
                    return [
                        'brand_id' => encryptor('e',$item->brand_id),
                        'brand_name' => $item->brand_name,
                        'model_id' => encryptor('e',$item->model_id),
                        'model_name' => $item->model_name,
                        'launch_date' => date('d M, Y', strtotime($item->launch_date)),
                        'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_image}",
                        'min_price' => $item->min_price ?  convertToLakhCrore($item->min_price) : null,
                        'max_price' => $item->max_price ?  convertToLakhCrore($item->max_price) : null,
                        'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                    ];
                });

            // $carStagee = config('constant.UPCOMING');

            // $upcomingSilder = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
            //     ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            //     ->select(
            //         'cop_models.model_image',
            //         'cop_brands_ms.brand_id',
            //         'cop_models.model_id',
            //     )
            //     ->where('cop_cs_ms.cs_name', '=', $carStagee)
            //     ->get();

            // // dd($upcomingSilder);

            // $formatSilderData = $upcomingSilder->map(function ($item) {
            //     return [
            //         'model_image' => $this->imagePath . "brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp" ?? NULL,

            //     ];
            // });


            $data = [
                'car_data' => $formattedData
                // 'modelSilder' => $formatSilderData
            ];


            return ResponseHelper::responseMessage('success', $data);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }    
}
