<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\PriceEntry;

class PriceEntryApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }
    
    // (NOT IN USE CURRETNLY -> index)
    public function index(Request $request)
    {
        $variantId = encryptor('e', $request->variant_id);
        $cityname = $request->has('city_name');
        // dd($variantId);
        if ($cityname == "" || $cityname == null) {
            $formattedData = ['cityname required'];
            return ResponseHelper::responseMessage('success', $formattedData);
        }

        try {
            $price_entry = PriceEntry::select(
                'cop_pe_ms.*',
                'cop_brands_ms.brand_name as brand_name',
                'cop_models.model_name as model_name',
                'cop_variants.variant_name as variant_name',
                'cop_city_ms.city_name as city_name',
                'cop_state_ms.state_name as state_name',
                'cop_country_ms.country_name as country_name',
                'cop_taxes_ms.tax_name as tax_name',
                'cop_ut.ut_name as ut_name',
            )

                ->leftJoin('cop_brands_ms', 'cop_pe_ms.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_models', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_variants', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')

                ->leftJoin('cop_city_ms', 'cop_pe_ms.city_id', '=', 'cop_city_ms.city_id')
                ->leftJoin('cop_state_ms', 'cop_pe_ms.state_id', '=', 'cop_state_ms.state_id')
                ->leftJoin('cop_country_ms', 'cop_pe_ms.country_id', '=', 'cop_country_ms.country_id')
                ->leftJoin('cop_taxes_ms', 'cop_pe_ms.tax_id', '=', 'cop_taxes_ms.tax_id')
                ->leftJoin('cop_ut', 'cop_pe_ms.ut_id', '=', 'cop_ut.ut_id')
                ->where('cop_pe_ms.status', 1)
                ->where('cop_variants.variant_id', $variantId)
                ->where('cop_city_ms.city_name', $cityname);



            $price_entry = $price_entry->get();


            if ($price_entry->isEmpty()) {

                // return ResponseHelper::responseMessage('error', 'Price not available');
                return ResponseHelper::errorResponse('data_not_found');
            }

            $formattedData = $price_entry->map(function ($item) {
                $taxNames = \App\Models\AllTax::whereIn('tax_id', json_decode($item->tax_id, true))
                    ->select('tax_id', 'tax_name')
                    ->get();

                $taxCosts = json_decode($item->tax_cost, true);

                $taxInfo = [];
                foreach ($taxNames as $taxName) {
                    $taxId = $taxName->tax_id;
                    $taxInfo[] = [
                        'tax_id' => $taxId,
                        'tax_name' => $taxName->tax_name,
                        'cost' => isset($taxCosts[$taxId]) ? (int)$taxCosts[$taxId] : null,

                    ];
                }

                $data = [
                    'price_entry_id' => $item->pe_id,
                    'brand_id' => $item->brand_id,
                    'brand_name' => $item->brand_name,
                    'model_id' => $item->model_id,
                    'model_name' => $item->model_name,
                    'variant_id' => $item->variant_id,
                    'variant_name' => $item->variant_name,
                    'country_name' => $item->country_name,
                    'state_name' => $item->state_name, // Make sure 'state_name' is selected in your query
                    'city_name' => $item->city_name,
                    'ut_name' => $item->ut_name,
                    'ex_showroom_price' => $item->ex_showroom_price,
                    'tax_name' => $taxInfo,
                    'total_price' => $item->total_price,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }

    // to get city list for those price entry has been done (pratik 2-4-2024)
    public function price_city()
    {
        try {
            $city_price_entry = PriceEntry::select('cop_pe_ms.city_id', 'cop_city_ms.city_name as city_name')
                ->join('cop_city_ms', 'cop_pe_ms.city_id', '=', 'cop_city_ms.city_id')
                ->distinct()
                ->select('cop_city_ms.city_id', 'cop_city_ms.city_name')
                ->get();

            $formateCityPriceData = $city_price_entry->map(function ($item) {
                $data = [
                    'city_id' => encryptor('e', $item->city_id),
                    'city_name' => $item->city_name,
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $formateCityPriceData);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('error');
        }
    }
}
