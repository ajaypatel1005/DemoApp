<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Helpers\ResponseHelper;
use App\Http\Controllers\Controller;
use App\Models\Feature;
use App\Models\Model;
use App\Models\Variant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Exception;
use Illuminate\Support\Facades\DB;

class FeatureApiController extends Controller
{
    protected $imagePath;

    public function __construct(){
        $this->imagePath = env('IMAGE_PATH');
    }

    // (NOT IN USE CURRETNLY -> index)
    public function index()
    {
        try {
            $featureLists = Feature::select('cop_features_ms.*', 'cop_spec_ms.spec_name as spec_name', 'cop_fo_ms.fo_value as fo_value', 'cop_su_ms.su_name as su_name')
                ->leftJoin('cop_spec_ms', 'cop_features_ms.spec_id', '=', 'cop_spec_ms.spec_id')
                ->leftJoin('cop_fo_ms', 'cop_features_ms.fo_id', '=', 'cop_fo_ms.fo_id')
                ->leftJoin('cop_su_ms', 'cop_features_ms.su_id', '=', 'cop_su_ms.su_id')
                ->where('cop_features_ms.status', '!=', 0)
                ->get();

            if ($featureLists->isEmpty()) {

                return ResponseHelper::errorResponse('data_not_found');
            }

            $formattedData = $featureLists->map(function ($item) {

                $fuelTypeLabel = '';

                switch ($item->fuel_type) {
                    case 0:
                        $fuelTypeLabel = 'Non EV';
                        break;
                    case 1:
                        $fuelTypeLabel = 'EV';
                        break;
                    case 2:
                        $fuelTypeLabel = 'Both';
                        break;
                    default:

                        break;
                }

                $data = [
                    'feature_id' => encryptor('e',$item->feature_id),
                    'fuel_type' => $fuelTypeLabel,
                    'spec_name' => $item->spec_name,
                    'feature_option_name' => $item->fo_value,
                    'su_name' => $item->su_name,
                    'features_name' => $item->features_name,
                    'features_image' => $this->imagePath . "Feature/{$item->feature_id}/{$item->feature_id}.webp" ?? NULL,
                ];

                return $data;
            });


            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('error');
        }
    }

    public function keyhighLight(Request $request)
    {
        try {
            $variantID = $request->variant_id;
            $variant_id = encryptor('e',$variantID);
            // dd($variant_id);
            $model_type_get = Variant::join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')->where('cop_variants.variant_id', $variant_id)->first();

            if ($model_type_get->model_type == 1) {
                $inputType = ['Battery Capacity', 'Power', 'Range', 'Charging Time (AC)', 'Type of Transmission', 'No Of Airbags', 'Parking Sensors', 'Anti Lock Braking System', 'Hill Assist'];
            } else {
                $inputType = ['Displacement', 'Power', 'Type of Fuel', 'Mileage', 'Type of Transmission', 'No Of Airbags', 'Parking Sensors', 'Anti Lock Braking System', 'Hill Assist'];
            }

            // dd($variant_id);
            $key_highLight = Variant::join('cop_brands_ms', 'cop_variants.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_models', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->leftJoin('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                ->select(
                    'cop_brands_ms.brand_name',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_type',
                    'cop_variants.variant_id',
                    'cop_variants.variant_name',
                    'cop_fv.feature_value',
                    'cop_features_ms.feature_id',
                    'cop_features_ms.features_name',
                    'cop_features_ms.features_image',
                    'cop_su_ms.su_name'
                )
                ->whereIn('cop_features_ms.features_name', $inputType)
                ->where('cop_models.status', '=', 1)
                ->where('cop_variants.variant_id', '=', $variant_id)
                ->distinct()
                ->get();

            // dd($key_highLight);
            $formatted = $key_highLight->map(function ($item) {

                $data = [
                    'model_id' => $item->model_id,
                    'brand_name' => $item->brand_name,
                    'model_name' => $item->model_name,
                    'variant_id' => $item->variant_id,
                    'variant_name' => $item->variant_name,
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                    'feature_id' => $item->feature_id,
                    'features_name' => $item->features_name,
                    'features_image' => asset("Feature/{$item->feature_id}/{$item->feature_id}.svg") ?? NULL,
                    'feature_value' => $item->feature_value,
                    'su_name' => $item->su_name,
                ];
                return $data;
            });




            return ResponseHelper::responseMessage('success', $formatted);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse('error');
            return ResponseHelper::errorResponse('error');
        }
    }
}
