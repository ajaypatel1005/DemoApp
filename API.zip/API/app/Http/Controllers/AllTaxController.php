<?php

namespace App\Http\Controllers;

use App\Models\FuelStation;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\AllTax;
use App\Models\City;
use App\Models\PriceEntry;
use Illuminate\Support\Facades\Log;
use Exception;
use App\Models\TaxValue;

class AllTaxController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_all_tax', 'view_all_tax'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $all_tax_view = AllTax::get();
        $city = City::active()->get();
        return view('all_tax.create', compact('all_tax_view', 'city'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_all_tax'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'condition_status' => 'required',
            'tax_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:20|unique:cop_taxes_ms,tax_name',
            'display_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:150|unique:cop_taxes_ms,display_name',
            'amount' => $request->condition_status == "1" ? 'required' : '',
            'percent1' => $request->condition_status == "1" ? 'required' : '',
            'condition1' => $request->condition_status == "1" ? 'required' : '',
            'percent2' => $request->condition_status == "1" ? 'required' : '',
            'condition2' => $request->condition_status == "1" ? 'required' : '',
            // 'percent' => $request->condition_status == "0" ? 'required' : '',
            'percent' => $request->value == "" ? 'required' : '',
            'value' => $request->percent == "" ? 'required' : '',

        ], [
            'condition_status.required' => 'Please select condition status',
            'tax_name.required' => 'Tax name is required',
            'tax_name.regex' => 'Only Alphabets are allowed in Tax Name',
            'tax_name.min' => 'Minimum 2 Characters are required',
            'tax_name.max' => 'Maximum 20 Characters are allowed in Tax Name',
            'tax_name.unique' => 'Tax Name already Exists',
            'display_name.required' => 'Display name is required',
            'display_name.regex' => 'Only Alphabets are allowed in Display Name',
            'display_name.min' => 'Minimum 2 Characters are required',
            'display_name.max' => 'Maximum 150 Characters are allowed in Display Name',
            'display_name.unique' => 'Display Name already Exists',
            'amount.required' => 'Amount is required',
            'percent1.required' => 'Tax Percent is required',
            'condition1.required' => 'Please select condition',
            'percent2.required' => 'Tax Percent is required',
            'condition2.required' => 'Please select condition',
            'percent.required' => 'Tax Percent is required',
            'value.required' => 'Tax Value is required',

        ]);
        DB::beginTransaction();
        $all_tax_store = new AllTax();

        try {

            $all_tax_store->tax_name = $request->tax_name;
            $all_tax_store->display_name = $request->display_name;
            $all_tax_store->city_id = $request->city_id;
            $all_tax_store->condition_status = $request->condition_status;
            if ($request->condition_status == "0") {
                if (!empty($request->percent)) {
                    $all_tax_store->percent = $request->percent;
                } else {
                    $all_tax_store->value = $request->value;
                }
            }
            $all_tax_store->status = $request->has('status') ? 1 : 0;
            $all_tax_store->save();
            if ($request->condition_status == "1") {
                //greater than condtion
                $tax_value = new TaxValue();
                $tax_value->tax_id = $all_tax_store->tax_id;
                $tax_value->condition =  $request->condition1;
                $tax_value->amount = $request->amount;
                $tax_value->percent = $request->percent1;
                $tax_value->save();

                //less than condtion
                $tax_value = new TaxValue();
                $tax_value->tax_id = $all_tax_store->tax_id;
                $tax_value->condition =  $request->condition2;
                $tax_value->amount = $request->amount;
                $tax_value->percent = $request->percent2;
                $tax_value->save();
            }

            DB::commit();
            session()->flash('success', 'All Tax Added Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('all_tax.create');
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_all_tax', 'view_all_tax'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $all_tax_view = AllTax::get();
        $all_tax_edit = AllTax::where('tax_id', decrypt($id))->first();
        if ($all_tax_edit->condition_status == 1) {
            $tax_value = TaxValue::where('tax_id', decrypt($id))->get();
        } else {
            $tax_value = [];
        }

        $city = City::active()->get();
        return view('all_tax.edit', compact('all_tax_view', 'all_tax_edit', 'city', 'tax_value'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_all_tax'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'condition_status' => 'required',
            'tax_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:20|unique:cop_taxes_ms,tax_name,' . decrypt($id) . ',tax_id',
            'display_name' => 'regex:/^[A-Za-z\s]+$/|min:2|max:150|unique:cop_taxes_ms,display_name,' . decrypt($id) . ',tax_id',
            'amount' => $request->condition_status == "1" ? 'required' : '',
            'percent1' => $request->condition_status == "1" ? 'required' : '',
            'condition1' => $request->condition_status == "1" ? 'required' : '',
            'percent2' => $request->condition_status == "1" ? 'required' : '',
            'condition2' => $request->condition_status == "1" ? 'required' : '',
            // 'percent' => $request->condition_status == "0" ? 'required' : '',
            'percent' => $request->value == "" ? 'required' : '',
            'value' => $request->percent == "" ? 'required' : '',
        ], [
            'condition_status.required' => 'Please select condition status',
            'tax_name.required' => 'Tax name is required',
            'tax_name.regex' => 'Only Alphabets are allowed in Tax Name',
            'tax_name.min' => 'Minimum 2 Characters are required',
            'tax_name.max' => 'Maximum 20 Characters are allowed in Tax Name',
            'tax_name.unique' => 'Tax Name already Exists',
            'amount.required' => 'Amount is required',
            'display_name.required' => 'Display name is required',
            'display_name.regex' => 'Only Alphabets are allowed in Display Name',
            'display_name.min' => 'Minimum 2 Characters are required',
            'display_name.max' => 'Maximum 150 Characters are allowed in Display Name',
            'display_name.unique' => 'Display Name already Exists',
            'percent1.required' => 'Tax Percent is required',
            'condition1.required' => 'Please select condition',
            'percent2.required' => 'Tax Percent is required',
            'condition2.required' => 'Please select condition',
            'percent.required' => 'Tax Percent is required',
            'value.required' => 'Tax Value is required',

        ]);

        DB::beginTransaction();
        $all_tax_update = AllTax::where('tax_id', decrypt($id))->first();
        try {
            $all_tax_update->tax_name = $request->tax_name;
            $all_tax_update->display_name = $request->display_name;
            $all_tax_update->city_id = $request->city_id;
            $all_tax_update->condition_status = $request->condition_status;
            if ($request->condition_status == "0") {
                $tax_values = TaxValue::where('tax_id', '=', decrypt($id))->get();

                if (!empty($tax_values)) {

                    $tax_values->each(function ($tax_value) {
                        $tax_value->delete();
                    });
                }
                if (!empty($request->percent)) {
                    $all_tax_update->percent = $request->percent;
                    $all_tax_update->value = null;
                } else {
                    $all_tax_update->value = $request->value;
                    $all_tax_update->percent = null;
                }
            }else{
                $all_tax_update->value = null;
                $all_tax_update->percent = null;
            }
            $all_tax_update->status = $request->has('status') ? 1 : 0;
            $all_tax_update->save();
            if ($request->condition_status == "1") {
                //greater than condtion
                if (!empty($request->tax_value_id1)) {
                    $tax_value = TaxValue::where('tax_value_id', decrypt($request->tax_value_id1))->first();
                } else {
                    $tax_value =  new TaxValue();
                }
                $tax_value->tax_id = $all_tax_update->tax_id;
                $tax_value->condition =  $request->condition1;
                $tax_value->amount = $request->amount;
                $tax_value->percent = $request->percent1;
                $tax_value->save();

                //less than condtion
                if (!empty($request->tax_value_id2)) {
                    $tax_value = TaxValue::where('tax_value_id', decrypt($request->tax_value_id2))->first();
                } else {
                    $tax_value =  new TaxValue();
                }
                $tax_value->tax_id = $all_tax_update->tax_id;
                $tax_value->condition =  $request->condition2;
                $tax_value->amount = $request->amount;
                $tax_value->percent = $request->percent2;
                $tax_value->save();
            }
            DB::commit();
            session()->flash('success', 'All Tax Updated Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }


        return redirect()->route('all_tax.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_all_tax'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        $all_tax_destroy = AllTax::where('tax_id', decrypt($id))->first();
        try {
            if (!empty($all_tax_destroy)) {


                $decryptedId = decrypt($id);

                $checkPrice = PriceEntry::where('tax_id', 'like', '%"' . $decryptedId . '"%')
                    ->orWhere('tax_id', 'like', '"' . $decryptedId . '",%')
                    ->orWhere('tax_id', 'like', '"' . $decryptedId . '"')
                    ->get();

                if ($checkPrice->isNotEmpty()) {
                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('all_tax.create');
                }

                $tax_values = TaxValue::where('tax_id', '=', $decryptedId)->get();
                if (!empty($tax_value)) {
                    $tax_values->each(function ($tax_value) {
                        $tax_value->delete();
                    });
                }
                $all_tax_destroy->delete();

                DB::commit();
                session()->flash('success', 'Tax Deleted Successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('all_tax.create');
    }


    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_taxes_ms')
            ->where('tax_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
}
