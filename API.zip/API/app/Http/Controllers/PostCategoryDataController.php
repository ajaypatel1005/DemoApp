<?php

namespace App\Http\Controllers;

use App\Models\PostCategoryData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Exception;


class PostCategoryDataController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_post', 'view_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $post_view = PostCategoryData::select('cop_post.*', 'cop_pct_ms.post_cat_name as post_cat_name')
            ->leftJoin('cop_pct_ms', 'cop_post.post_cat_id', '=', 'cop_pct_ms.post_cat_id')
            ->get();
        $post_cat_type = DB::select('select * from cop_pct_ms where status = 1');
        return view('post.create', compact('post_cat_type',  'post_view'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //  dd($request->all());

        if (!hasAnyPermission(['create_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'post_cat_id' => 'required|numeric',
            'title' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:50',
            'content' => 'required|min:2|max:1000',
            'post_image' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
            'author' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:50',
            'author_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'post_date' => 'required',
        ], [
            'post_cat_id.required' => 'Select Post Category Name is required',
            'title.required' => 'Title is required',
            'title.regex' => 'Title is invalid',
            'content.required' => 'The Content is required.',
            'content.min' => 'The Content must be at least :min characters.',
            'content.max' => 'The Content must not exceed :max characters.',
            'post_image.required' => 'Post Image is required',
            'post_image.max' => 'Post Image cannot be greater than 2 MB',
            'post_image.mimes' => 'Post Image must be a PNG, JPG, JPEG, or WebP file.',

            'author.required' => 'Author is required',
            'author.regex' => 'Author is invalid',
            'author_image.nullable' => 'Author Image is required',
            'author_image.max' => 'Author Image cannot be greater than 2 MB',
            'author_image.mimes' => 'Author Image must be a PNG, JPG, JPEG, or WebP file.',
        ]);
        DB::beginTransaction();
        try {
            $slug = \Illuminate\Support\Str::slug(strtolower($request->slug), '-') ?: \Illuminate\Support\Str::slug(strtolower($request->title), '-');
            // dd($slug);
            $post_store = new PostCategoryData();
            $post_store->post_cat_id = $request->post_cat_id;
            $post_store->title = $request->title;
            $post_store->slug = $slug;
            $post_store->content = $request->content;
            $post_store->author = $request->author;
            $post_store->post_date = $request->post_date;
            $post_store->created_by = auth()->id();     //description
            $post_store->status = $request->has('status') ? 1 : 0;
            $post_store->save();

            $post_update = PostCategoryData::find($post_store->post_id);

            if ($post_update) {
                $post_id = $post_update->post_id;
                $uploadedImage = $request->file('post_image');
                $webpImageName = $post_id . '_post.webp';
                $uploadedImage->move(public_path('Post') . '/' . $post_id . '/Post_image/', $webpImageName);
                $post_update->post_image = $webpImageName;

                if ($request->hasFile('author_image')) {
                    $authorImageName = $post_id . '_author.webp';
                    $request->file('author_image')->move(public_path('Post') . '/' . $post_id . '/Author_image/', $authorImageName);
                    $post_update->author_image = $authorImageName;
                }
                $post_update->update();

                session()->flash('success', 'Post Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.' . $e);
        }

        return redirect()->route('post.create');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_post', 'view_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $post_view = PostCategoryData::select('cop_post.*', 'cop_pct_ms.post_cat_name as post_cat_name')
            ->leftJoin('cop_pct_ms', 'cop_post.post_cat_id', '=', 'cop_pct_ms.post_cat_id')
            ->get();

        $post_edit = PostCategoryData::where('post_id', decrypt($id))->first();
        $post_cat_type = DB::select('select * from cop_pct_ms where status = 1');
        return view('post.edit', compact('post_edit', 'post_cat_type',  'post_view'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'post_cat_id' => 'required|numeric',
            'title' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:50',
            'content' => 'required|min:2|max:1000',
            'post_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048|unique:cop_post,post_image,' . decrypt($id) . ',post_id',
            'author' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:50',
            'author_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048|unique:cop_post,author_image,' . decrypt($id) . ',post_id',
            'post_date' => 'required',

        ], [
            'post_cat_id.required' => 'Select Post Category Name is required',
            'title.required' => 'Title is required',
            'title.regex' => 'Title is invalid',
            'content.required' => 'The Content is required.',
            'content.min' => 'The Content must be at least :min characters.',
            'content.max' => 'The Content must not exceed :max characters.',
            'post_image.required' => 'Post Image is required',
            'post_image.max' => 'Post Image cannot be greater than 2 MB',
            'post_image.mimes' => 'Post Image must be a PNG, JPG, JPEG, or WebP file.',
            'author.required' => 'Author is required',
            'author.regex' => 'Author is invalid',
            'author_image.nullable' => 'Author Image is required',
            'author_image.max' => 'Author Image cannot be greater than 2 MB',
            'author_image.mimes' => 'Author Image must be a PNG, JPG, JPEG, or WebP file.',

        ]);
        DB::beginTransaction();
        try {
            $post_update = PostCategoryData::where('post_id', decrypt($id))->first();
            // dd($post_update);
            $imagePath = 'Post/' . $post_update->post_id;

            if ($post_update) {
                if (isset($request->post_image)) {
                    // File::deleteDirectory($imagePath);
                    if (File::exists($imagePath . '/Post_image/' . $post_update->post_image)) {
                        File::delete($imagePath . '/Post_image/' . $post_update->post_image);
                    }

                    $post_id = $post_update->post_id;
                    $uploadedImage = $request->file('post_image');
                    $webpImageName = $post_id . '_post.webp';
                    $uploadedImage->move(public_path('Post') . '/' . $post_id . '/Post_image/', $webpImageName);
                    $post_update->post_image = $webpImageName;
                }

                // Handle Author Image update
                if (isset($request->author_image)) {
                    if (File::exists($imagePath . '/Author_image/' . $post_update->author_image)) {
                        File::delete($imagePath . '/Author_image/' . $post_update->author_image);
                    }
                    $authorImageName = $post_update->post_id . '_author.webp';
                    $request->file('author_image')->move(public_path('Post') . '/' . $post_update->post_id . '/Author_image/', $authorImageName);
                    $post_update->author_image = $authorImageName;
                }

                // Update other fields

                $slug = \Illuminate\Support\Str::slug(strtolower($request->slug), '-') ?: \Illuminate\Support\Str::slug(strtolower($request->title), '-');

                $post_update->post_cat_id = $request->post_cat_id;
                $post_update->title = $request->title;
                $post_update->slug = $slug;
                $post_update->content = $request->content;
                $post_update->author = $request->author;
                $post_update->post_date = $request->post_date;
                $post_update->updated_by = auth()->id();
                $post_update->status = $request->has('status') ? 1 : 0;
                $post_update->update();

                session()->flash('success', 'Post Updated Successfully.');
            } else {
                session()->flash('error', 'Record Not Found.');
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('post.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $post_destroy = PostCategoryData::where('post_id', decrypt($id))->first();
            $imagePath = 'Post/' . $post_destroy->post_id;

            if (!empty($post_destroy)) {
                if (File::isDirectory($imagePath)) {

                    File::deleteDirectory($imagePath);
                    $post_destroy->delete();
                    DB::commit();
                }

                session()->flash('success', 'Post Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong!');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('post.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_post')
            ->where('post_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
}
