<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\unionTerritory;
use App\Models\Country;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class UnionTerritoriesController extends Controller
{
    //    Show the form for creating a new resource.
    public function create()
    {
        if (!hasAnyPermission(['create_state', 'view_state'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $cop_ut_ms = unionTerritory::select('cop_ut_ms.*', 'cop_country_ms.country_name as country_name')
            ->leftJoin('cop_country_ms', 'cop_ut_ms.country_id', '=', 'cop_country_ms.country_id')
            ->where('cop_country_ms.status', '=', 1)
            ->get();

        $countries = Country::active()->get();
        return view('union_territories.create', compact('cop_ut_ms', 'countries'));
    }

    //    Store a newly created resource in storage.
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_state'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'ut_name' => 'required|regex:/^[()A-Za-z\s]+$/|unique:cop_ut_ms,ut_name|min:2|max:30',
            'country_id' => 'required',
            // 'rto_per' => 'required|numeric|max:100',
            // 'cbu_rto' => 'required|numeric|max:100'
        ], [
            'ut_name.regex' => 'Union Territory Name contain only letters and spaces.',
            'ut_name.required' => 'Union Territory Name is required',
            'ut_name.unique' => 'Union Territory Name has already been taken',
            'ut_name.min' => 'Union Territory Name must be at least :min characters.',
            'ut_name.max' => 'Union Territory Name must not exceed :max characters.',
            'country_id.required' => 'Country Selection is required',
            // 'rto_per.required' => 'RTO Percentage is required.',
            // 'rto_per.numeric' => 'RTO Percentage must be a number.',
            // 'rto_per.max' => 'RTO Percentage must not exceed :max.',
            // 'cbu_rto.required' => 'CBU Percentage is required.',
            // 'cbu_rto.numeric' => 'CBU Percentage must be a number.',
            // 'cbu_rto.max' => 'CBU Percentage must not exceed :max.'

        ]);
        DB::beginTransaction();
        try {
            $cop_ut_ms_store = new unionTerritory;
            if (!empty($cop_ut_ms_store)) {
                $cop_ut_ms_store->ut_name = $request->ut_name;
                // $cop_ut_ms_store->rto_per = $request->rto_per;
                // $cop_ut_ms_store->cbu_rto = $request->cbu_rto;
                $cop_ut_ms_store->country_id = $request->country_id;
                $cop_ut_ms_store->status = $request->has('status') ? 1 : 0;
                DB::commit();
                $cop_ut_ms_store->save();
                session()->flash('success', 'Union Territory Added Successfully');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('union_territories.create');
    }

    //    Show the form for editing the specified resource.
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_state', 'view_state'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $cop_ut_ms_edit = unionTerritory::where('ut_id', decrypt($id))->first();
        // $cop_ut_ms = unionTerritory::get();
        // $countries = Country::active()->get();
        $cop_country_ms_edit = Country::active()->get();
        $cop_ut_ms = unionTerritory::select('cop_ut_ms.*', 'cop_country_ms.country_name as country_name')
            ->leftJoin('cop_country_ms', 'cop_ut_ms.country_id', '=', 'cop_country_ms.country_id')
            ->where('cop_country_ms.status', '=', 1)
            ->get();
        return view('union_territories.edit', compact('cop_country_ms_edit', 'cop_ut_ms_edit', 'cop_ut_ms'));
    }

    //    Update the specified resource in storage.
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_state'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'ut_name' => 'required|regex:/^[()A-Za-z\s]+$/|unique:cop_ut_ms,ut_name,' . decrypt($id) . ',ut_id|min:2|max:30',
                'country_id' => 'required',
                // 'rto_per' => 'required|numeric|max:100',
                // 'cbu_rto' => 'required|numeric|max:100'
            ],
            [
                'ut_name.regex' => 'Union Territory Name contain only letters and spaces.',
                'ut_name.required' => 'Union Territory Name is required',
                'ut_name.unique' => 'Union Territory Name has already been taken',
                'ut_name.min' => 'Union Territory Name must be at least :min characters.',
                'ut_name.max' => 'Union Territory Name must not exceed :max characters.',
                'country_id.required' => 'Country Name is required',
                // 'rto_per.required' => 'RTO Percentage is required.',
                // 'rto_per.numeric' => 'RTO Percentage must be a number.',
                // 'rto_per.max' => 'RTO Percentage must not exceed :max.',
                // 'cbu_rto.required' => 'CBU Percentage is required.',
                // 'cbu_rto.numeric' => 'CBU Percentage must be a number.',
                // 'cbu_rto.max' => 'CBU Percentage must not exceed :max.',
            ]
        );
        DB::beginTransaction();
        try {
            $cop_ut_ms_update = unionTerritory::where('ut_id', decrypt($id))->first();
            if (!empty($cop_ut_ms_update)) {

                $cop_ut_ms_update->ut_name = $request->ut_name;
                // $cop_ut_ms_update->rto_per = $request->rto_per;
                // $cop_ut_ms_update->cbu_rto = $request->cbu_rto;
                $cop_ut_ms_update->country_id = $request->country_id;
                $cop_ut_ms_update->status = $request->has('status') ? 1 : 0;
                $cop_ut_ms_update->save();
                DB::commit();
                session()->flash('success', 'Union Territory Name Updated Successfully');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('union_territories.create');
    }

    //    Remove the specified resource from storage.
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_state'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $cop_ut_ms_destroy = unionTerritory::where('ut_id', decrypt($id))->first();
            if ($cop_ut_ms_destroy) {
                if ($cop_ut_ms_destroy->s_station->isNotEmpty() || $cop_ut_ms_destroy->f_station->isNotEmpty() || $cop_ut_ms_destroy->ev_station->isNotEmpty() || $cop_ut_ms_destroy->price_entry->isNotEmpty() || $cop_ut_ms_destroy->city->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('union_territories.create');
                }



                $cop_ut_ms_destroy->delete();
                DB::commit();
                session()->flash('success', 'Union Territory Name Deleted Successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('union_territories.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_ut_ms')
            ->where('ut_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status Updated Successfully']);
    }
}
