<?php

namespace App\Http\Controllers;

use App\Models\SpecificationCategory;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SpecificationCategoryController extends Controller
{

    public function index()
    {
        if (!hasAnyPermission(['create_specification_category', 'view_specification_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $specificationCategory = SpecificationCategory::all();
        return view('specification_category.index', compact('specificationCategory'));
    }

    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_specification_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'sc_name' => 'required|min:2|max:20|unique:cop_sc_ms,sc_name',
        ], [
            'sc_name.required' => 'The Specification Category Name is required',
            'sc_name.unique' => 'The Specification Category Name is already exist',
            'sc_name.min' => 'The Specification Category Name must be at least :min characters.',
            'sc_name.max' => 'The Specification Category Name must not exceed :max characters.',
        ]);
        DB::beginTransaction();
        try {
            SpecificationCategory::create([
                'sc_name' => $request->sc_name,
                'status' => $request->has('status') ? 1 : 0
            ]);
            DB::commit();
            session()->flash('success', 'Specification Category Added Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('spec_cat.index');
    }

    public function edit($id)
    {
        if (!hasAnyPermission(['edit_specification_category', 'view_specification_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $spec_cat_edit = SpecificationCategory::where('sc_id', decrypt($id))->first();
        $specificationCategory = SpecificationCategory::all();
        return view('specification_category.edit', ['spec_cat_edit' => $spec_cat_edit, 'specificationCategory' => $specificationCategory]);
    }

    public function updateCategory(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_specification_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'sc_name' => 'required|min:2|max:20|unique:cop_sc_ms,sc_name,' . decrypt($id) . ',sc_id',
        ], [
            'sc_name.required' => 'The Specification Category Name is required',
            'sc_name.unique' => 'The Specification Category Name is already exist',
            'sc_name.min' => 'The Specification Category Name must be at least :min characters.',
            'sc_name.max' => 'The Specification Category Name must not exceed :max characters.',
        ]);
        DB::beginTransaction();
        try {
            $spec_cat_update = SpecificationCategory::where('sc_id', decrypt($id))->first();
            if (!empty($spec_cat_update)) {
                $spec_cat_update->sc_name = $request->sc_name;
                $spec_cat_update->status = $request->has('status') ? 1 : 0;
                $spec_cat_update->update();
                session()->flash('success', 'Specification Category Updated Successfully.');
                DB::commit();
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('spec_cat.index');
    }

    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_specification_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $deleteCategory = SpecificationCategory::where('sc_id', decrypt($id))->first();
            if (!empty($deleteCategory)) {
                if ($deleteCategory->specification->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('spec_cat.index');
                }
                $deleteCategory->delete();
                DB::commit();
                session()->flash('success', 'Specification Category Deleted Successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('spec_cat.index');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        // Perform the database update logic
        DB::table('cop_sc_ms')
            ->where('sc_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);

        return response()->json(['message', 'Status Updated Successfully']);
    }
}
