<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Facades\JWTAuth;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\Helpers\ResponseHelper;
class JWTMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle($request, Closure $next)
    {
        try {
            $customer = JWTAuth::parseToken()->authenticate();
        } catch (\Exception $e) {
            // return response()->json();
            return ResponseHelper::responseMessage('error','Unauthorized');
        }

        return $next($request);
    }
}
