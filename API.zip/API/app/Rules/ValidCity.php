<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Support\Facades\DB;
use App\Models\City;
use App\Models\Rto;
use App\Models\State;

class ValidCity implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */

    protected $stateName;


    public function __construct($stateName = null)
    {
        $this->stateName = $stateName;
    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if ($attribute == 'state') {
            $state = State::where('state_name', $value)->where('status', '=', '1')->first();
            if (empty($state)) {
                $fail("State/UT does not exist or disabled");
            }
           
        }
        if($attribute=='price'){
            $state = State::where('state_name', $this->stateName )->where('status', '=', '1')->first();
            if (!empty($state)) {
                $rto = Rto::where('state_id', $state->state_id)->first();
                if (empty($rto)) {
                    $fail("RTO does not exist");
                }
            }
        }
        

        if ($attribute == 'city' && !empty($this->stateName)) {
            $state = State::where('state_name', $this->stateName)->where('status', '=', '1')->first();
            if (!empty($state)) {
                $isUt = $state->is_ut;
                if ($isUt == 0) {
                    if (!$value) {
                        $fail("City is required");
                    }
                    $cityExists = City::where('city_name', 'like', trim($value))
                        ->where('status', 1)
                        ->exists();

                    if (!empty($cityExists)) {
                        $state =   DB::table('cop_city_ms')
                            ->select('cop_state_ms.state_name')
                            ->join('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
                            ->where('cop_city_ms.city_name', 'LIKE', trim($value))
                            ->first();

                        if (strtolower($state->state_name) != strtolower($this->stateName)) {
                            $fail("City does not belong to the specified State.");
                        }
                    } else {
                        $fail("City does not exist or disabled");
                    }
                }
            }
        }
    }
}
