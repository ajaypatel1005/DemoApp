<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Contracts\Validation\Rule;
use App\Models\PriceEntry;
use App\Models\City;

class UniquePriceEntry implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */

    protected $pe_id;

    public function __construct($pe_id)
    {
        if($pe_id != null){
            $this->pe_id = $pe_id;
        }
    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        // Retrieve the values of the fields
        $brandId = request()->input('brand_id');
        $modelId = request()->input('model_id');
        $variantId = request()->input('variant_id');
        $countryId = request()->input('country_id');
        $stateId = request()->input('state_id');
        $utId = request()->input('ut_id');
        $cityIdArray = request()->input('city_id');
        
        $existingEntries = [];
        // Query the database to check for uniqueness
        if(is_array($cityIdArray)){
            $cityId = $cityIdArray;
        } else {
            $cityId = [];
            $cityId[] = $cityIdArray;
        }

        foreach($cityId as $city_id){
            $existsQuery = PriceEntry::where('brand_id', $brandId)
                ->where('model_id', $modelId)
                ->where('variant_id', $variantId)
                ->where('country_id', $countryId);
                
                if (request()->input('ut_id')) {
                    $existsQuery->where('state_id', $utId);
                } else {
                    $existsQuery->where('state_id', $stateId)->where('city_id', $city_id);
                }

                if($this->pe_id){
                    $existsQuery->where('pe_id','!=', $this->pe_id);
                }

                $exists = $existsQuery->exists();

                if ($exists) {
                    if (request()->input('ut_id')) {
                        $existingEntries[] = $utId;
                    } else {
                        $existingEntries[] = $city_id;
                    }
                }
        }

        if(!empty($existingEntries)){
            if (request()->input('ut_id')) {
                $fail("The variant has already been entered for selected union territories");
            } else {
                $cityNameList = [];
                foreach($existingEntries as $city_id){
                    $cityName = City::where('city_id',$city_id)->first();
                    $cityNameList[] = $cityName->city_name;
                }

                $cityExist = implode(',',$cityNameList);
                $fail("The variant has already been entered for location : $cityExist");
            }
        }
    }
}
