<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use App\Models\Brand;
use App\Models\Model;
use App\Models\Variant;
use Illuminate\Support\Facades\DB;

class ValidBrand implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */

    protected $brandName;
    protected $modelName;


    public function __construct($brandName = null, $modelName = null)
    {
        $this->brandName = $brandName;
        $this->modelName = $modelName;
    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        // Check if the provided brand_id exists
        if($attribute=='brand_name' || $attribute=='Brand Name'){
            $brand=DB::table('cop_brands')
            ->select('cop_brands_ms')
            ->where('brand_name','LIKE', trim($value))
            ->where('cop_brands_ms.status','=','1');
            if (!$brand) {
                $fail("Brand Name does not exist or disabled");
            }
        }
        if ($attribute == 'model_name' || $attribute == 'Model Name') {
            $model =   DB::table('cop_models')
            ->select('cop_models.model_name','cop_brands_ms.brand_name')
            ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
            ->where('model_name','LIKE', trim($value))
            ->where('cop_models.status','=','1')
            ->first();

            if (!$model) {
       

                $fail("Model Name does not exist or disabled");
            }
            else{
                if (strtolower($model->brand_name) != strtolower(trim($this->brandName))) {

                    $fail("The Model does not belong to the specified Brand.");}
            }

        } elseif ($attribute == "variant_name" || $attribute == 'Variant Name') {
            $variant = Variant::where('variant_name','like',trim($value))->where('status','=','1')->first();
            if (!$variant) {
                $fail("Variant name does not exist or disabled");
            }else{
            $variants = DB::table('cop_variants')
                ->select('cop_models.model_name','cop_brands_ms.brand_name')
                ->join('cop_models', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_variants.brand_id')

                ->where('cop_variants.variant_name','like', trim($value))
                ->where('cop_models.model_name','like', trim($this->modelName))
                ->get();

                foreach ($variants as $variant) {
                     if ($variant->model_name != trim($this->modelName)) {
                $fail("Variant Name does not belong to the specified Model.");

            }

            if (strtolower($variant->brand_name) != strtolower(trim($this->brandName))) {
                $fail("Variant Name does not belong to the specified Brand.");

            }
            }

        }

        }
    }
}
