<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;


class GoogleMapsURL implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @param  \Closure  $fail
     * @return void
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        // Check if the URL is from Google Maps
        if (strpos($value, 'https://www.google.com/maps/') !== false || strpos($value, 'https://maps.app.goo.gl') !== false) {
            return;
        }

        $fail("The $attribute must be a valid Google Maps URL.");
    }
}
