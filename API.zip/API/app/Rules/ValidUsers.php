<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\Rule;
use App\Models\Manager;
use App\Models\User;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Support\Facades\DB;
class ValidUsers implements ValidationRule
{
    protected $username;
    public function __construct($username = null)
    {
        $this->username = $username;
    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
{
    if ($this->username === null ) {
        return;
    }
    if ($this->username !== null && $attribute === 'name' ) {
        $User = User::where('name', 'LIKE', trim($value))->exists();

        if (!$User) {
            $fail("User Name does not exist or disabled");
        }
    }
}


        // class ValidUsers implements Rule
        // {
            // public function passes($attribute, $value)
            // {
            //     //   if($value==null){
            // //     return true;
            // //     }
            //     // Check if the provided manager exists
            //     $User = User::where('name', 'LIKE', trim($value))->exists();

            //     return $User;
            // }



//     public function message()
//     {
//         return 'The User does not exist.';
//     }
}
