<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use App\Models\Model;
use App\Models\Variant;
// use Illuminate\Support\Facades\DB;

class ValidModelVariantUnique implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */

    protected $modelName;

    public function __construct($modelName)
    {
        $this->modelName = $modelName;
    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        $model = Model::where('model_name','like', trim($this->modelName))->first();
        // dd($model);

        if (!$model) {
            $fail('The specified model does not exist.');
            return;
        }

            // Check if the combination of variant_name and model_name is unique
            $model_variant = Variant::where('model_id', $model->model_id)
            ->where('variant_name','like', trim($value))
            ->get();

            if (!$model_variant->isEmpty()) {
            $fail('The :attribute and model name combination already been updated.');
        }
    }

}
