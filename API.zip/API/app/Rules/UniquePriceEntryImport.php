<?php

namespace App\Rules;

use App\Models\Model;
use App\Models\Variant;
use App\Models\State;
use App\Models\City;
use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Contracts\Validation\Rule;
use App\Models\PriceEntry;

class UniquePriceEntryImport implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */

    protected $modelName;
    protected $variantName;
    protected $stateName;
    protected $cityName;

    public function __construct($modelName = null,$variantName = null,$stateName = null,$cityName = null)
    {
        $this->modelName = $modelName;
        $this->variantName = $variantName;
        $this->stateName = $stateName;
        $this->cityName = $cityName;
    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        // Retrieve the values of the fields
        $modelId = Model::where('model_name',$this->modelName)->where('status','=','1')->first();
        $variantId = Variant::where('variant_name',$this->variantName)->where('status','=','1')->first();
        $stateId = State::where('state_name',$this->stateName)->where('status','=','1')->first();
        $cityId = City::where('city_name',$this->cityName)->where('status','=','1')->first();
        
        if(!empty($modelId) && !empty($variantId) && !empty($stateId) && !empty($cityId)){
            $priceEntry = PriceEntry::where('model_id',$modelId->model_id)
                            ->where('variant_id',$variantId->variant_id)
                            ->where('state_id',$stateId->state_id)
                            ->where('city_id',$cityId->city_id)
                            ->first();
            // dd($priceEntry);
            if(!empty($priceEntry)){
                $fail("The entered variant ($this->variantName) is already exist for this location ($this->cityName)");
            }
        }
    }
}
