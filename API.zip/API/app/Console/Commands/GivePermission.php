<?php

namespace App\Console\Commands;
use Spatie\Permission\Models\Permission;
use App\Models\User;
use Illuminate\Console\Command;

class GivePermission extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'add:permission';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add all Permission to  Superadmin';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $permissions = Permission::pluck('id', 'id')->all();
        $admin = User::where("email", 'LIKE', "admin@admin.com")->first();
        if (!empty($admin)) {
            $admin->syncPermissions($permissions);
        }
    }
}
