<?php

if (!function_exists('hasAnyPermission')) {
    /**
     * Check if the authenticated user has any permission from the given array.
     *
     * @param array $permissions
     * @return bool
     */
    function hasAnyPermission(array $permissions)
    {
        // Get the authenticated user
        $user = auth()->user();

        // Check if the user has any of the given permissions
        return $user && $user->hasAnyPermission($permissions);
    }
}

//////// Do Not Edit Above /////////
if (!function_exists('encryptor')) {
    function encryptor($action, $string)
    {
        $secret_key = 'iWPPtLfcVTZtb1rJlGY2eL958g9dfhQpt797BU8LMfS2WvEkwI';
        $secret_iv = 'm4iSFgKgxwVMWuTyOjUUTCGjJSJKJShH';

        $output = false;
        $encrypt_method = "AES-256-CBC";
        // hash
        $key = hash('sha256', $secret_key);
        // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        $iv = substr(hash('sha256', $secret_iv), 0, 16);

        //do the encyption given text/string/number
        if ($action == 'e') {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output = base64_encode($output);
        } else if ($action == 'd') {
            //decrypt the given text/string/number
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        }

        return $output;
    }
}

if (!function_exists('formatAmount')) {
    function formatAmount($min, $max)
    {
        if ($min <= 0 && $max <= 0) {
            return "0";
        }

        if ($min === 0) {
            $min = $max;
        }
        if ($max === 0) {
            $max = $min;
        }

        $minScale = ($min >= 10000000) ? 'Cr' : 'Lakh';
        $maxScale = ($max >= 10000000) ? 'Cr' : 'Lakh';

        if ($minScale === 'Lakh') {
            $formattedMin = $min / 100000;
        } else if ($minScale === 'Cr') {
            $formattedMin = $min / 10000000;
        } else {
            $formattedMin = 'Invalid';
        }

        if ($maxScale === 'Lakh') {
            $formattedMax = $max / 100000;
        } else if ($maxScale === 'Cr') {
            $formattedMax = $max / 10000000;
        } else {
            $formattedMax = 'Invalid';
        }


        if (strpos($formattedMin, ".") == false) {
            $formattedMin = $formattedMin . '.00';
        }
        if (strpos($formattedMax, ".") == false) {
            $formattedMax = $formattedMax . '.00';
        }
        if ($minScale === $maxScale) {
            $arrMin = explode('.', strval($formattedMin));
            $arrMax = explode('.', strval($formattedMax));
            if (strlen($arrMin[1]) == 1) {
                $arrMin[1] = $arrMin[1] . '0';
            }
            if (strlen($arrMax[1]) == 1) {
                $arrMax[1] = $arrMax[1] . '0';
            }
            if ($min === $max) {
                $value = '₹ ' . $arrMax[0] . '.' . substr($arrMax[1], 0, 2) . ' ' . $maxScale;
            } else {
                $value = '₹ ' . $arrMin[0] . '.' . substr($arrMin[1], 0, 2) . '-' . $arrMax[0] . '.' . substr($arrMax[1], 0, 2) . ' ' . $maxScale;
            }
        } else {
            $arrMin = explode('.', strval($formattedMin));
            $arrMax = explode('.', strval($formattedMax));
            if (strlen($arrMin[1]) == 1) {
                $arrMin[1] = $arrMin[1] . '0';
            }
            if (strlen($arrMax[1]) == 1) {
                $arrMax[1] = $arrMax[1] . '0';
            }
            if ($min === $max) {
                $value = '₹ ' . $arrMax[0] . '.' . substr($arrMax[1], 0, 2) . ' ' . $maxScale;
            } else {
                $value = '₹ ' . $arrMin[0] . '.' . substr($arrMin[1], 0, 2) . ' ' . $minScale . '-' . $arrMax[0] . '.' . substr($arrMax[1], 0, 2) . ' ' . $maxScale;
            }
        }
        return $value;
    }
}

if (!function_exists('convertRangeToWords')) {
    function convertRangeToWords($range)
    {
        list($start, $end) = explode(' to ', $range);

        $startWords = convertToWords($start);
        $endWords = convertToWords($end);

        return $startWords . ' to ' . $endWords;
    }
}
if (!function_exists('convertToWords')) {
    function convertToWords($number)
    {
        $crore = floor($number / 10000000);
        $lakh = floor(($number % 10000000) / 100000);

        $words = '';

        if ($crore > 0) {
            $words .= $crore . ' cr';
        }

        if ($lakh > 0) {
            $words .= ($words ? ' ' : '') . $lakh . ' lakh';
        }

        return $words ? $words : '0';
    }
}

// if (!function_exists('convertToLakhCrore')) {
//     function convertToLakhCrore($price)
//     {
//         if ($price >= 10000000) {
//             return number_format($price / 10000000, 2) . ' Cr';
//         } elseif ($price >= 100000) {
//             return number_format($price / 100000, 2) . ' Lakh';
//         } else {
//             return $price;
//         }
//     }
// }

if (!function_exists('extract_bhp')) {
    function extract_bhp($str)
    {
        // Regular expression pattern to match "bhp" followed by a number
        $pattern = '/(\d+(\.\d+)?)(?=\s*bhp)/i';

        // Match the pattern in the string
        if (preg_match($pattern, $str, $matches)) {
            // Convert the matched string to a float number
            $bhp = (float)$matches[0];
            return $bhp;
        } else {
            return $str;
        }
    }
}

if (!function_exists('check_bhp_exist')) {
    function check_bhp_exist($str)
    {
        // Regular expression pattern to match "bhp" followed by a number
        $pattern = '/(\d+(\.\d+)?)(?=\s*bhp)/i';

        // Match the pattern in the string
        if (preg_match($pattern, $str, $matches)) {
            // Convert the matched string to a float number
            return true;
        }
        return false;
    }
}

if (!function_exists('convertToLakhCrore')) {
    function convertToLakhCrore($min, $max=0)
    {
        if ($min <= 0 && $max <= 0) {
            return "0";
        }

        if ($min === 0) {
            $min = $max;
        }
        if ($max === 0) {
            $max = $min;
        }

        $minScale = ($min >= 10000000) ? 'Cr' : 'Lakh';
        $maxScale = ($max >= 10000000) ? 'Cr' : 'Lakh';

        if ($minScale === 'Lakh') {
            $formattedMin = $min / 100000;
        } else if ($minScale === 'Cr') {
            $formattedMin = $min / 10000000;
        } else {
            $formattedMin = 'Invalid';
        }

        if ($maxScale === 'Lakh') {
            $formattedMax = $max / 100000;
        } else if ($maxScale === 'Cr') {
            $formattedMax = $max / 10000000;
        } else {
            $formattedMax = 'Invalid';
        }


        if (strpos($formattedMin, ".") == false) {
            $formattedMin = $formattedMin . '.00';
        }
        if (strpos($formattedMax, ".") == false) {
            $formattedMax = $formattedMax . '.00';
        }
        if ($minScale === $maxScale) {
            $arrMin = explode('.', strval($formattedMin));
            $arrMax = explode('.', strval($formattedMax));
            if (strlen($arrMin[1]) == 1) {
                $arrMin[1] = $arrMin[1] . '0';
            }
            if (strlen($arrMax[1]) == 1) {
                $arrMax[1] = $arrMax[1] . '0';
            }
            if ($min === $max) {
                $value = $arrMax[0] . '.' . substr($arrMax[1], 0, 2) . ' ' . $maxScale;
            } else {
                $value = $arrMin[0] . '.' . substr($arrMin[1], 0, 2) . '-' . $arrMax[0] . '.' . substr($arrMax[1], 0, 2) . ' ' . $maxScale;
            }
        } else {
            $arrMin = explode('.', strval($formattedMin));
            $arrMax = explode('.', strval($formattedMax));
            if (strlen($arrMin[1]) == 1) {
                $arrMin[1] = $arrMin[1] . '0';
            }
            if (strlen($arrMax[1]) == 1) {
                $arrMax[1] = $arrMax[1] . '0';
            }
            if ($min === $max) {
                $value = $arrMax[0] . '.' . substr($arrMax[1], 0, 2) . ' ' . $maxScale;
            } else {
                $value = $arrMin[0] . '.' . substr($arrMin[1], 0, 2) . ' ' . $minScale . '-' . $arrMax[0] . '.' . substr($arrMax[1], 0, 2) . ' ' . $maxScale;
            }
        }
        return $value;
    }
}

if (!function_exists('padWithZeros')) {
    function padWithZeros($number, $length = 6)
    {
        return sprintf("%0{$length}d", $number);
    }
}