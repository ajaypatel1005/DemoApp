<?php

namespace App\Exports;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromView;

class VariantsExport implements FromView
{
    public function view(): View
    { 

        $variants = DB::table('cop_variants')
            ->select('cop_brands_ms.brand_name', 'cop_models.model_name', 'cop_variants.variant_name')
            ->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
            ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
            ->orderBy('cop_brands_ms.brand_name')
            ->orderBy('cop_models.model_name')
            ->orderBy('cop_variants.variant_name')
            ->get();
            return view('exports.variant_view', [
                'variants' => $variants
            ]);
    }

}
