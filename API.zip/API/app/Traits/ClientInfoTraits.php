<?php
namespace App\Traits;
use Illuminate\Support\Facades\Session;

trait ClientInfoTraits{

public function getClientIpAddress()
{
    return request()->getClientIp();
}

public function getClientSessionId()
{
    return Session::getId();
}
}



?>