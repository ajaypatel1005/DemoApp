<?php

namespace App\Imports;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Rules\ValidateArrayImage;
use App\Rules\ValidBrand;

use App\Models\Model;
use App\Models\CarGraphicType;
use App\Models\Brand;
use App\Models\CarGraphic;
// use Carbon\Carbon;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
// use Illuminate\Validation\ValidationException;

class CarGraphicsImagesImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            $uniqueModel = [];

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {

                if (isset($row['model_name'])) {
                    $model_name = trim($row['model_name']);
                    if (in_array($model_name, $uniqueModel)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'model_name')),
                            'message' => "Duplicate entry found for Model Name within the Excel sheet.",
                        ];
                    } else {
                        $uniqueModel[] = $model_name;
                    }
                }

                $brandName = trim($row['brand_name']);

                $carGraphicImages = CarGraphic::join('cop_gt_ms','cop_gt_ms.gt_id','=','cop_graphics.gt_id')->join('cop_models','cop_models.model_id','=','cop_graphics.model_id')->where('cop_models.model_name','like', trim($row['model_name']))->where('cop_gt_ms.gt_name','=','Images')->first();

                if(!empty($carGraphicImages)){
                    $this->validationErrors[] = [
                        'row' => $index + 2,
                        'field' => ucwords(str_replace('_', ' ', 'model_name')),
                        'message' => "Images entry already exist in car graphics for specified Model",
                    ];
                }

                $carGraphicStatus = CarGraphicType::where('gt_name','=','Images')->where('status','=','1')->first();

                if(empty($carGraphicStatus)){
                    $this->validationErrors[] = [
                        'row' => $index + 2,
                        'field' => ucwords(str_replace('_', ' ', 'For All Fields')),
                        'message' => "Images has been disbaled or not found in Car Graphic Type (Kindy enable or enter Images as Car Graphic Type)",
                    ];
                }

                $rules = [
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => ['required', new ValidBrand($brandName)],
                    'car_images'=> ['required', new ValidateArrayImage()],
                ];

                $errorMessages = [
                    'brand_name.required'=> 'Brand Name is required',
                    'brand_name.exists'=> 'Brand Name does not exist or disabled',

                    'model_name.required'=>'Model Name is required',

                    'car_images.required' => 'Car Images are required.',
                ];

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {
                try {

                    $brand = Brand::where('brand_name', 'like',trim($row['brand_name']))->first();
                    $model = Model::where('model_name','like', trim($row['model_name']))->where('brand_id',$brand->brand_id)->first();
                    $carGraphicType = CarGraphicType::where('gt_name', 'Images')->first();

                    DB::beginTransaction();
                    $car_graphic_images = CarGraphic::create(
                        [
                            'brand_id' => $brand->brand_id,
                            'model_id' => $model->model_id,
                            'gt_id' => $carGraphicType->gt_id,
                            'created_by'=>auth()->id()
                        ]
                    );

                    // Upload Image
                    $baseDirectory = public_path('car_graphics') . '/' . $model->model_id;

                    if (!File::isDirectory($baseDirectory)) {
                        File::makeDirectory($baseDirectory, 0755, true, true);
                    }
                    if (!File::isDirectory($baseDirectory . '/images')) {
                        File::makeDirectory($baseDirectory . '/images', 0755, true, true);
                    }

                    // if (!File::isDirectory(public_path('car_graphics') . '/' . $model->model_id . '/images')) {
                    //     File::makeDirectory(public_path('car_graphics') . '/' . $model->model_id . '/images', 0755, true, true);
                    // }

                    $all_images = explode(',',trim($row['car_images']));
                    $new_images = [];

                    for($i=0; $i<count($all_images); $i++)
                    {
                        $time = date('dmYHis');
                        $imageWebpImageName = $model->model_id . '_' . $time . '_' . $i . '.webp';
                        $model_image_path = public_path('car_graphics') . '/' . $model->model_id . '/' . 'images/' . $imageWebpImageName;
                        File::copy($all_images[$i], $model_image_path);

                        $new_images[] = $imageWebpImageName;
                    }

                    $car_graphics_images_for_db = implode(',', $new_images);

                    $car_graphic_images->update(['graphic_file' => $car_graphics_images_for_db]);

                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count.' data has been imported successfully.');

                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                    // dd("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}

