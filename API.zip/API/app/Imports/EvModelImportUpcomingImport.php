<?php

namespace App\Imports;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Rules\ValidImagePath;
use App\Rules\ValidBrand;

use App\Models\Model;
use App\Models\CarStage;
use App\Models\CarType;
use App\Models\Brand;
use App\Models\ModelSpecDisplay;
use Carbon\Carbon;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
// use Illuminate\Validation\ValidationException;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class EvModelImportUpcomingImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try{
            $uniqueModel = [];

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }
            
            foreach ($rows as $index => $row) {

                if (isset($row['model_name'])) {
                    $model_name = trim($row['model_name']);
                    if (in_array($model_name, $uniqueModel)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'model_name')),
                            'message' => "Duplicate entry found for Model Name within the Excel sheet.",
                        ];
                    } else {
                        $uniqueModel[] = $model_name;
                    }
                }

                $launchDate = trim($row["launch_date"]);
                date_default_timezone_set('Asia/Kolkata');
                $today_date = date('Y-m-d');
                if($launchDate < $today_date)
                {
                    $this->validationErrors[] = [
                        'row' => $index + 2, // Adjust the row number to start from 1-based index
                        'field' => ucwords(str_replace('_', ' ', 'model_year')),
                        'message' => "Launch date should be greater than Today's date (i.e. greater than $today_date).",
                    ];
                }

                $rules = [
                    // 'car_stage' => 'required',
                    'launch_date' => 'required|date_format:Y-m-d',
                    'car_type' => 'required|exists:cop_ct_ms,ct_name',
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => 'required|min:2|max:30|unique:cop_models,model_name',
                    'model_image' => ['required', new ValidImagePath()],
                    'model_description' => 'required|min:2|max:1000',
                    'min_price' => 'required|numeric|min:200000|max:500000000',
                    'max_price' => 'required|numeric|min:200000|max:500000000|gt:min_price',
                    // 'model_type' => 'required',
                    'battery_capacity' => 'required|min:2|max:20',
                    'model_power' => 'required|min:2|max:20',
                    'model_transmission' => 'required|min:2|max:20',
                    'driving_range' => 'required|min:2|max:20',
                    'charging_time' => 'required|min:2|max:20',
                ];

                $errorMessages = [
                    'launch_date.required'=> 'Launch Date is required',
                    'launch_date.date_format'=> 'Launch Date formate should be YYYY-MM-DD  only',

                    'car_type.required'=> 'Car Type is required',
                    'car_type.exists'=> 'Car Type does not exist',

                    'brand_name.required'=> 'Brand Name is required',
                    'brand_name.exists'=> 'Brand Name does not exist or disabled',

                    'model_name.required'=>'Model Name is required',
                    'model_name.unique'=>'Model Name is already exist',

                    'model_image.required'=>'Model Image is required',

                    'model_description.required'=>'Model Description is required',
                    'model_description.min' => 'Model Description must be at least :min characters.',
                    'model_description.max' => 'Model Description must not exceed :max characters.',

                    'min_price.required' => 'Min Price is required.',
                    'min_price.numeric' => 'Min Price should be number only.',
                    'min_price.min' => 'Min Price must be at least :min or greater than this.',
                    'min_price.max' => 'Min Price must not exceed :max.',

                    'max_price.required' => 'Max Price is required.',
                    'max_price.numeric' => 'Max Price should be number only.',
                    'max_price.min' => 'Max Price must be at least :min or greater than this.',
                    'max_price.max' => 'Max Price must not exceed :max.',
                    'max_price.gt' => 'Max Price should be greater than :min.',

                    'battery_capacity.required' => 'Battery Capacity is required.',
                    'battery_capacity.min' => 'Battery Capacity must be at least :min characters.',
                    'battery_capacity.max' => 'Battery Capacity must not exceed :max characters.',

                    'model_power.required' => 'Model Power is required.',
                    'model_power.min' => 'Model Power must be at least :min characters.',
                    'model_power.max' => 'Model Power must not exceed :max characters.',

                    'model_transmission.required' => 'Model Transmission is required.',
                    'model_transmission.min' => 'Model Transmission must be at least :min characters.',
                    'model_transmission.max' => 'Model Transmission must not exceed :max characters.',

                    'driving_range.required' => 'Driving Range is required.',
                    'driving_range.min' => 'Driving Range must be at least :min characters.',
                    'driving_range.max' => 'Driving Range must not exceed :max characters.',

                    'charging_time.required' => 'Charging Time is required.',
                    'charging_time.min' => 'Charging Time must be at least :min characters.',
                    'charging_time.max' => 'Charging Time must not exceed :max characters.',
                ];

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }
        

        if (empty($this->validationErrors)) {
            $count = 0;
            $manager = new ImageManager(new Driver());
            foreach ($rows as $index => $row) {
                try {

                    $carStage = CarStage::where('cs_name', 'Upcoming')->first();
                    $carType = CarType::where('ct_name','like', trim($row['car_type']))->first();
                    $brandName = Brand::where('brand_name','like', trim($row['brand_name']))->first();

                    $parsedDate = Carbon::createFromFormat("Y-m-d", $row["launch_date"])->format("Y-m-d");
                    $model_year_get = explode('-',trim($row["launch_date"]));

                    DB::beginTransaction();
                    $model = Model::create(
                        [
                            'brand_id' => $brandName->brand_id,
                            'model_name' => trim($row['model_name']),

                            'cs_id' => $carStage->cs_id,
                            'launch_date' => $parsedDate,
                            'ct_id' => $carType->ct_id,

                            'model_description' => trim($row['model_description']),
                            'min_price' => trim($row['min_price']),
                            'max_price' => trim($row['max_price']),
                            'model_year' => $model_year_get[0],
                            'model_type' => '1',

                            'created_by'=>auth()->id()
                        ]
                    );

                    // Upload Image
                    if (!File::isDirectory(public_path('brands') . '/' . $model->brand_id . '/' . $model->model_id)) {
                        File::makeDirectory(public_path('brands') . '/' . $model->brand_id . '/' . $model->model_id);
                    }

                    $model_image = trim($row['model_image']);
                    $webpImageNameModel = $model->model_id . '.webp';
                    $model_image_path = public_path('brands') . '/' . $model->brand_id . '/' . $model->model_id . '/' . $webpImageNameModel;
                    // File::copy($model_image, $model_image_path);
                    $model_image_folder_path = public_path('brands') . '/' . $model->brand_id . '/' . $model->model_id;
                    $urlImage = @file_get_contents($model_image);
                    if($urlImage === false){
                    }else{
                        $image = $manager->read($urlImage);
                        $image->toWebp()->save($model_image_path);
        
                        // Thumbnail image
                        if(!is_dir($model_image_folder_path.'/thumb')){
                            mkdir($model_image_folder_path.'/thumb', 0777, true);
                        }
                        $image->resize(333,206);
                        $image->toWebp()->save($model_image_folder_path.'/thumb/'.$webpImageNameModel);
                    }
                    $model->update(['model_image' => $webpImageNameModel]);


                    $model_spec_display = ModelSpecDisplay::create(
                        [
                            'model_id' => $model->model_id,

                            'model_engine' => trim($row['battery_capacity']),
                            'model_bhp' => trim($row['model_power']),
                            'model_transmission' => trim($row['model_transmission']),
                            'model_mileage' => trim($row['driving_range']),
                            'model_fuel' => trim($row['charging_time']),
                        ]
                    );

                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count.' data has been imported successfully.');

                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}

