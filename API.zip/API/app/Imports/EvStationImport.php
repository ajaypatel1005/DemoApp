<?php

namespace App\Imports;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Rules\GoogleMapsURL;
use App\Rules\ValidCity;

use App\Models\EvStation;
use App\Models\City;
use App\Models\State;
// use Carbon\Carbon;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
// use Illuminate\Validation\ValidationException;

class EvStationImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try{
            $uniqueLocations = [];
            $uniqueAddresses = [];
            // $uniqueContactNos = [];
            
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }
        
            foreach ($rows as $index => $row) {
                $stateName = trim($row['state']);

                if (isset($row['location'])) {
                    $location = trim($row['location']);
                    if (in_array($location, $uniqueLocations)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'location')),
                            'message' => "Duplicate entry found for Location within the Excel sheet.",
                        ];
                    } else {
                        $uniqueLocations[] = $location;
                    }
                }

                if (isset($row['address'])) {
                    $address = trim($row['address']);
                    if (in_array($address, $uniqueAddresses)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'address')),
                            'message' => "Duplicate entry found for Address within the Excel sheet.",
                        ];
                    } else {
                        $uniqueAddresses[] = $address;
                    }
                }

                // if (isset($row['contact_no'])) {
                //     $contactNo = trim($row['contact_no']);
                //     if (in_array($contactNo, $uniqueContactNos)) {
                //         $this->validationErrors[] = [
                //             'row' => $index + 2,
                //             'field' => ucwords(str_replace('_', ' ', 'contact_no')),
                //             'message' => "Duplicate entry found for Contact No. within the Excel sheet.",
                //         ];
                //     } else {
                //         $uniqueContactNos[] = $contactNo;
                //     }
                // }

                $rules = [
                    'ev_station_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:2|max:30',
                    'address' => 'required|min:15|max:700|unique:cop_evs_ms,evs_address',
                    'location' => ['required', 'string','unique:cop_evs_ms,evs_location', new GoogleMapsURL()],
                    'state' => ['required', new ValidCity()],
                    'city'=> [ new ValidCity($stateName)],
                    // 'charging_slots'=> 'required|regex:/^[A-Za-z0-9\s]+$/|min:1|max:30',
                    // 'charging_port_type'=> 'required|min:1|max:30',
                    // 'charging_voltage'=> 'required|min:1|max:30',
                    // 'charging_rate'=> 'required|min:1|max:30',
                    // 'car_capacity'=> 'required|regex:/^[A-Za-z0-9\s]+$/|min:1|max:30',
                    // 'contact_no' => 'required|digits:10|numeric|unique:cop_evs_ms,evs_contact_number',
                    'evs_charging_slots' => 'min:0|max:30',
                    'evs_charging_port_type' => 'min:0|max:30',
                    'evs_charging_voltage' => 'min:0|max:30',
                    'evs_charging_rate' => 'min:0|max:30',
                    'evs_car_capacity' => 'min:0|max:30',
                    'evs_contact_number' => '',
                ];

                $errorMessages = [
                    'state.required'=> 'State is required',
                    'state.exists'=> 'State does not exist or disabled',

                    'city.required'=>'City is required',

                    'ev_station_name.required' => 'The EVS name is required.',
                    'ev_station_name.regex' => 'The EVS name must contain only letters, numbers, and spaces.',
                    'ev_station_name.min' => 'The EVS name must be at least :min characters.',
                    'ev_station_name.max' => 'The EVS name must not exceed :max characters.',
                    
                    'address.required' => 'The EVS address is required.',
                    'address.min' => 'The EVS address  must be at least :min characters.',
                    'address.max' => 'The EVS address  must not exceed :max characters.',
                    'address.unique' => 'The EVS address has already been taken by another EVS station.',

                    'location.required' => 'The EVS location address is required.',
                    'location.string' => 'The EVS location must be a string.',
                    'location.custom' => 'The EVS location is not a valid Google Maps URL.',
                    'location.unique' => 'The EVS location has already been taken by another EVS station.',

                    'charging_slots.required' => 'The EVS charging slots is required.',
                    'charging_slots.regex' => 'The EVS charging slots must contain only letters, numbers, and spaces.',
                    'charging_slots.min' => 'The EVS charging slots must be at least :min characters.',
                    'charging_slots.max' => 'The EVS charging slots must not exceed :max characters.',

                    'charging_port_type.required' => 'The EVS port type is required.',
                    'charging_port_type.min' => 'The EVS port type must be at least :min characters.',
                    'charging_port_type.max' => 'The EVS port type must not exceed :max characters.',

                    'charging_voltage.required' => 'The EVS charging voltage is required.',
                    
                    'charging_voltage.min' => 'The EVS charging voltage must be at least :min characters.',
                    'charging_voltage.max' => 'The EVS charging voltage must not exceed :max characters.',

                    'charging_rate.required' => 'The EVS charging rate is required.',
                    'charging_rate.min' => 'The EVS charging rate must be at least :min characters.',
                    'charging_rate.max' => 'The EVS charging rate must not exceed :max characters.',

                    'car_capacity.required' => 'The EVS capacity is required.',
                    'car_capacity.regex' => 'The EVS capacity must contain only letters, numbers, and spaces.',
                    'car_capacity.min' => 'The EVS capacity must be at least :min characters.',
                    'car_capacity.max' => 'The EVS capacity must not exceed :max characters.',

                    'contact_no.required' => 'The contact number is required.',
                    'contact_no.numeric' => 'The contact number must be a number.',
                    'contact_no.digits' => 'The contact number must be 10 digits.',
                    'contact_no.unique' => 'The contact number has already been taken by another EVS station.',
                ];                

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }
        

        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {
                try {

                    $stateId = State::where('state_name','like', trim($row['state']))->first();
                    $cityId = City::where('city_name','like', trim($row['city']))->first();

                    DB::beginTransaction();
                    $ev_station = EvStation::create(
                        [
                            'evs_name' => trim($row['ev_station_name']),
                            'evs_location' => trim($row['location']),
                            'evs_address' => trim($row['address']),
                            'state_id' => $stateId->state_id,
                            'city_id' => $cityId->city_id,
                            'evs_charging_slots' => trim($row['charging_slots']),
                            'evs_charging_port_type' => trim($row['charging_port_type']),
                            'evs_charging_voltage' => trim($row['charging_voltage']),
                            'evs_charging_rate' => trim($row['charging_rate']),
                            'evs_car_capacity' => trim($row['car_capacity']),
                            'evs_contact_number' => trim($row['contact_no']),
                            'created_by'=>auth()->id()
                        ]
                    );

                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count.' data has been imported successfully.');

                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    // private function checkUniqueness($row, $field, $uniqueValues, $errorMessage, $index)
    // {
    //     if (isset($row[$field])) {
    //         $value = $row[$field];
    //         if (in_array($value, $uniqueValues)) {
    //             $this->validationErrors[] = [
    //                 'row' => $index + 2,
    //                 'field' => ucwords(str_replace('_', ' ', $field)),
    //                 'message' => $errorMessage,
    //             ];
    //         } else {
    //             $uniqueValues[] = $value;
    //         }
    //     }
    // }
    
    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}

