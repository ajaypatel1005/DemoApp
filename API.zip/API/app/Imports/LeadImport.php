<?php

namespace App\Imports;

use App\Models\Brand;
use App\Models\Model;
use App\Models\CRM\Lead;
use App\Models\CRM\LeadSource;
use App\Models\CRM\LeadType;
use App\Models\Manager;
use App\Models\User;
use App\Rules\LeadsValidBrand;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Rules\ValidBrand;
use App\Rules\ValidManager;
use App\Rules\ValidUsers;

class LeadImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {
                $brandName = trim($row['brand_name']);
                $modelName = trim($row['model_name']);
                $manager_name = trim($row['manager_name']);
                $assigned = trim($row['assign_to']);

                $rules = [
                    'lead_name' => 'required',
                    'lead_contact' => 'required',
                    'manager_name' => [new ValidManager($manager_name)],
                    'assign_to' => [new ValidUsers()],
                ];

                // Only add validation rules for brand_name and model_name if they are not empty
                if (!empty($brandName) || $brandName!=null || $brandName!="") {
                    $rules['brand_name'] = [new LeadsValidBrand()];
                }

                if (!empty($modelName) || $modelName!=null || $modelName!="") {
                    $rules['model_name'] = [new LeadsValidBrand($brandName)];
                }

                $validator = Validator::make($row->toArray(), $rules);



                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }

        if (empty($this->validationErrors)) {
                // If validation passes, create and save the lead
            $count = 0;
            foreach ($rows as $index => $row) {

                $brand = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                $model = Model::where('model_name', 'like', trim($row['model_name']))->first();
                $manager = Manager::where('first_name', 'like', trim($row['manager_name']))->first();
                $assign = User::where('name', 'like', trim($row['assign_to']))->first();
                $lead_type = LeadType::where('lt_name', 'like', trim("New"))->first();
                $lead_source = LeadSource::where('ls_name', 'like', trim("Excel Sheet"))->first();

                DB::beginTransaction();
                Lead::create(
                    [
                        'lead_name'=>$row['lead_name'],
                        'campaign_id' => $row['campaign_id'],
                        'lead_email' => $row['lead_email'],
                        'lead_contact' => $row['lead_contact'],
                        'lead_address' => $row['lead_address'],
                        'lead_budget' => $row['lead_budget'],
                        'remark' => $row['remark'],
                        'assign_id' => $assign ? $assign->id : null,
                        'manager_id' => $manager ? $manager->manager_id : null,
                        'brand_id' => $brand ? $brand->brand_id : null,
                        'model_id' => $model ? $model->model_id : null,
                        'lt_id' => $lead_type ? $lead_type->lt_id : null,
                        'lp_id' => 1,
                        'ls_id' => $lead_source ? $lead_source->ls_id : null,

                    ]
                );

                DB::commit();
                $count++;
            }

            session()->flash('import_success', $count . ' data has been imported successfully.');
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
