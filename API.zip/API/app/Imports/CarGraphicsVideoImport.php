<?php

namespace App\Imports;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Rules\ValidVideoPath;
use App\Rules\ValidBrand;

use App\Models\Model;
use App\Models\CarGraphicType;
use App\Models\Brand;
use App\Models\CarGraphic;
// use Carbon\Carbon;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
// use Illuminate\Validation\ValidationException;

class CarGraphicsVideoImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try{
            $uniqueModel = [];

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {

                if (isset($row['model_name'])) {
                    $model_name = trim($row['model_name']);
                    if (in_array($model_name, $uniqueModel)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'model_name')),
                            'message' => "Duplicate entry found for Model Name within the Excel sheet.",
                        ];
                    } else {
                        $uniqueModel[] = $model_name;
                    }
                }

                $brandName = trim($row['brand_name']);

                $carGraphicVideo = CarGraphic::join('cop_gt_ms','cop_gt_ms.gt_id','=','cop_graphics.gt_id')->join('cop_models','cop_models.model_id','=','cop_graphics.model_id')->where('cop_models.model_name','like',trim($row['model_name']))->where('cop_gt_ms.gt_name','=','Video')->first();

                if(!empty($carGraphicVideo)){
                    $this->validationErrors[] = [
                        'row' => $index + 2,
                        'field' => ucwords(str_replace('_', ' ', 'model_name')),
                        'message' => "Video entry already exist in car graphics for specified Model",
                    ];
                }

                $carGraphicStatus = CarGraphicType::where('gt_name','=','Video')->where('status','=','1')->first();

                if(empty($carGraphicStatus)){
                    $this->validationErrors[] = [
                        'row' => $index + 2,
                        'field' => ucwords(str_replace('_', ' ', 'For All Fields')),
                        'message' => "Video has been disbaled or not found in Car Graphic Type (Kindy enable or enter Video as Car Graphic Type)",
                    ];
                }

                $rules = [
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => ['required', new ValidBrand($brandName)],
                    'car_video'=>['required', new ValidVideoPath()],
                ];

                $errorMessages = [
                    'brand_name.required'=> 'Brand Name is required',
                    'brand_name.exists'=> 'Brand Name does not exist or disabled',

                    'model_name.required'=>'Model Name is required',

                    'car_video.required' => 'Car Video is required.',
                ];

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {
                try {

                    $brandName = Brand::where('brand_name', trim($row['brand_name']))->first();
                    $modelName = Model::where('model_name', trim($row['model_name']))->where('brand_id',$brandName->brand_id)->first();
                    $carGraphicType = CarGraphicType::where('gt_name', 'Video')->first();

                    DB::beginTransaction();
                    $car_graphic_video = CarGraphic::create(
                        [
                            'brand_id' => $brandName->brand_id,
                            'model_id' => $modelName->model_id,
                            'gt_id' => $carGraphicType->gt_id,

                            'created_by'=>auth()->id()
                        ]
                    );

                    // Upload Video
                    $baseDirectory = public_path('car_graphics') . '/' . $modelName->model_id;

                    if (!File::isDirectory($baseDirectory)) {
                        File::makeDirectory($baseDirectory, 0755, true, true);
                    }
                    if (!File::isDirectory($baseDirectory . '/videos')) {
                        File::makeDirectory($baseDirectory . '/videos', 0755, true, true);
                    }

                    $car_graphic_video_get_path = trim($row['car_video']);
                    $time = date('dmYHis');
                    $imageVideoName = $modelName->model_id . '_' . $time . '_video.mp4';

                    $car_graphic_video_path = public_path('car_graphics') . '/' . $modelName->model_id . '/' . 'videos/' . $imageVideoName;
                    File::copy($car_graphic_video_get_path, $car_graphic_video_path);

                    $car_graphic_video->update(['graphic_file' => $imageVideoName]);

                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count.' data has been imported successfully.');

                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}

