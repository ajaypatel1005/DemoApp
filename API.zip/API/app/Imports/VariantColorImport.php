<?php

namespace App\Imports;

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Rules\ValidImagePath;
use App\Models\Variant;
use App\Models\Color;
use App\Models\Brand;
use App\Models\Model;
use App\Rules\ValidBrand;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class VariantColorImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try{
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {

                $brandName = trim($row['brand_name']);
                $modelName = trim($row['model_name']);
                $validator=Validator::make($row->toArray(), [
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => ['required', new ValidBrand($brandName) ],
                    'variant_name' => ['required',new ValidBrand($brandName,$modelName)],
                    'color_code' => 'required',
                    'color_name' => 'required',
                    'variant_color_image' => ['required', new ValidImagePath()],

                ]);
                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }


        if (empty($this->validationErrors)) {
        $count=0;
        $manager = new ImageManager(new Driver());
        foreach ($rows as $index => $row) {

            try {
                $brand_id = Brand::where('brand_name','like', trim($row['brand_name']))->first();
                $brand_id = $brand_id->brand_id;
                $model_id = Model::where('model_name','like', trim($row['model_name']))->where('brand_id',$brand_id)->first();
                $model_id = $model_id->model_id;
                $variant_id = Variant::where('variant_name','like', trim($row['variant_name']))->where('brand_id', $brand_id)->where('model_id', $model_id)->first();
                $variant_id = $variant_id->variant_id;
                DB::beginTransaction();
                $variantColor = Color::updateOrCreate(
                    [
                        'brand_id' => $brand_id,
                        'model_id' => $model_id,
                        'variant_id' => $variant_id,
                        'color_name' => trim($row['color_name']),
                    ],
                    [
                        'color_code' => trim($row['color_code']),
                        'dual_color_code' => trim($row['dual_color_code']),

                        'created_by' => auth()->id()
                    ]
                );

                // Upload Brand Banner
                if (!File::isDirectory(public_path('brands') . '/' . $brand_id . '/' . $model_id . '/' . $variant_id)) {

                    File::makeDirectory(public_path('brands') . '/' . $brand_id . '/' . $model_id . '/' . $variant_id,0777,true);
                }


                $variant_color_image = trim($row['variant_color_image']);
                $webpImageNameBanner = $variant_id . '_' . (time() + $index) . '.webp';
                $variant_color_image_path = public_path('brands') . '/' . $brand_id . '/' . $model_id . '/' . $variant_id . '/' . $webpImageNameBanner;
                $variant_color_folder_path = public_path('brands') . '/' . $brand_id . '/' . $model_id . '/' . $variant_id;
                
                $urlImage =@file_get_contents($variant_color_image);
                if($urlImage === false){
                }else{
                    $image = $manager->read($urlImage);
                    $image->toWebp()->save($variant_color_folder_path.'/'.$webpImageNameBanner);

                    // Thumbnail image
                    if(!is_dir($variant_color_folder_path.'/thumb')){
                        mkdir($variant_color_folder_path.'/thumb', 0777, true);
                    }
                    $image->resize(676,348);
                    $image->toWebp()->save($variant_color_folder_path.'/thumb/'.$webpImageNameBanner);
                }
                // File::copy($variant_color_image, $variant_color_image_path);

                // Update Brand with Banner
                $variantColor->update(['variant_color_image' => $webpImageNameBanner]);
                DB::commit();
                $count++;
                session()->flash('import_success', $count.' data has been imported successfully.');

            } catch (Exception $e) {
                DB::rollBack();

                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                session()->flash('import_error', $e->getMessage());
            }
        }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}

