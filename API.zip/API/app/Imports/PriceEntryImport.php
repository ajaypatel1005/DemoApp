<?php

namespace App\Imports;

use App\Models\AllTax;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\Variant;
use App\Models\Brand;
use App\Models\City;
use App\Models\Country;
use App\Models\Model;
use App\Models\PriceEntry;
use App\Models\Rto;
use App\Models\State;
use App\Rules\ValidBrand;
use App\Rules\ValidCity;
use App\Rules\UniquePriceEntryImport;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;

class PriceEntryImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {

        try {
            $uniquePriceEntry = [];

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }


            foreach ($rows as $index => $row) {

                $brandName = trim($row['brand_name']);
                $modelName = trim($row['model_name']);
                $variantName = trim($row['variant_name']);
                $stateName = trim($row['state']);
                $cityName = trim($row['city']);

                if (isset($brandName) && isset($modelName) && isset($variantName) && isset($stateName) && isset($cityName)) {
                    $data = $brandName.''.$modelName.''.$variantName.''.$stateName.''.$cityName;
                    if (in_array($data, $uniquePriceEntry)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'city')),
                            'message' => "Duplicate entry found for same variant and same city within the Excel sheet.",
                        ];
                    } else {
                        $uniquePriceEntry[] = $data;
                    }
                }

                $validator = Validator::make($row->toArray(), [
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => ['required', new ValidBrand($brandName)],
                    'variant_name' => ['required', new ValidBrand($brandName, $modelName)],
                    'state' => ['required', new ValidCity()],
                    'city'=> [ new ValidCity($stateName)],
                    'price' => [
                        'required',new ValidCity($stateName),new UniquePriceEntryImport($modelName,$variantName,$stateName,$cityName),
                        function ($attribute, $value, $fail) {
                            // Remove commas and spaces from the value
                            $value = str_replace([',', ' '], '', $value);
                    
                            // Check if the modified value is numeric
                            if (!is_numeric($value)) {
                                $fail($attribute . ' must be a valid number.');
                            }
                        },
                    ],
                    

                ]);
                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }


        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {

                try {
                    $brand_id = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                    $brand_id = $brand_id->brand_id;
                    $model_id = Model::where('model_name', 'like', trim($row['model_name']))->where('brand_id', $brand_id)->first();
                    $model_id = $model_id->model_id;
                    $variant_id = Variant::where('variant_name', 'like', trim($row['variant_name']))->where('brand_id', $brand_id)->where('model_id', $model_id)->first();
                    
                    $country_id = Country::where('country_name', 'like', 'India')->first();
                    $state_id = State::where('state_name', 'like', trim($row['state']))->first();

                    if($state_id->is_ut == 1){
                        $state_id = $state_id->state_id;
                        $city_id = null;
                    } else {
                        $city_id = City::where('city_name', 'like', trim($row['city']))->first();
                        $state_id = $state_id->state_id;
                        $city_id = $city_id->city_id;
                    }

                    $variant_id = $variant_id->variant_id;                    

                    $ex_showroom_price = str_replace([',', ' '], '', $row['price']);
                    $ex_showroom_price = intval($ex_showroom_price);
                    $tcsAmt = 0;
                    DB::beginTransaction();
                    $price_entry = new PriceEntry();

                    $price_entry->brand_id = $brand_id;
                    $price_entry->model_id = $model_id;
                    $price_entry->variant_id = $variant_id;
                    $price_entry->country_id = $country_id->country_id;
                    $price_entry->state_id = $state_id;
                    $price_entry->city_id = $city_id;
                    $price_entry->ex_showroom_price = $ex_showroom_price;

            if (!empty($ex_showroom_price)) {

            $checkRTOready = true;
            $carExShorRoomPrice = $ex_showroom_price;
            $rto_value_i = 0;
            $rto_value_c = 0;
            
            // For individual purchase
            $RTOrateInd = Rto::where('state_id',$state_id)->where('rto_type','=','I')->get();
            foreach($RTOrateInd as $rtocheck){

                // If rto check with the CC (No amount)
                if($rtocheck->cc == 1){
                    $checkRTOready = false;

                    $getCC = Variant::join('cop_fv','cop_fv.variant_id','=','cop_variants.variant_id')->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')->where('cop_features_ms.features_name','=','Displacement')->where('cop_variants.variant_id',$variant_id)->first();

                    if(!empty($getCC)){
                        $checkRTOready = true;
                        $carExShorRoomPrice = $getCC->feature_value;
                    }
                }
                
                // If RTO check with Fuel-type and Amount both
                if($rtocheck->fuel_type != null){
                    $checkRTOready = false;

                    $modelIdEvCheck = Model::select('model_type')->where('model_id',$model_id)->first();

                    if($modelIdEvCheck->model_type == 1){
                        if($rtocheck->fuel_type == 'EV'){
                            $checkRTOready = true;
                        }
                    } else {
                        $getFuelType = Variant::select('cop_fv.feature_value')->join('cop_fv','cop_fv.variant_id','=','cop_variants.variant_id')->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')->where('cop_features_ms.features_name','=','Type of Fuel')->where('cop_variants.variant_id',$variant_id)->first();

                        if(!empty($getFuelType) && $getFuelType->feature_value == $rtocheck->fuel_type){
                            $checkRTOready = true;
                        }
                    }
                }
                
                // If RTO check with only Amount
                if($checkRTOready == true){
                    $preCondition = $rtocheck->pre_condition;
                    $preAmount = $rtocheck->pre_amount;
                    $postCondition = $rtocheck->post_condition;
                    $postAmount = $rtocheck->post_amount;
                    $rtoPer = $rtocheck->percentage;

                    if($preCondition == null && $preAmount == null && $postCondition == null && $postAmount == null) {
                        $rto_value_i = $ex_showroom_price * $rtoPer / 100;
                    } else if($postCondition == null && $postAmount == null){
                        if (
                            ($preCondition === '<' && $carExShorRoomPrice < $preAmount) ||
                            ($preCondition === '>' && $carExShorRoomPrice > $preAmount) ||
                            ($preCondition === '<=' && $carExShorRoomPrice <= $preAmount) ||
                            ($preCondition === '>=' && $carExShorRoomPrice >= $preAmount)
                        ) {
                            $rto_value_i = $ex_showroom_price * $rtoPer / 100;
                        } 
                    } else {
                        if (
                            ($preCondition === '>' && $postCondition === '<=' && $carExShorRoomPrice > $preAmount && $carExShorRoomPrice <= $postAmount) ||
                            ($preCondition === '>=' && $postCondition === '<=' && $carExShorRoomPrice >= $preAmount && $carExShorRoomPrice <= $postAmount) ||
                            ($preCondition === '>=' && $postCondition === '<' && $carExShorRoomPrice >= $preAmount && $carExShorRoomPrice < $postAmount) ||
                            ($preCondition === '>' && $postCondition === '<' && $carExShorRoomPrice > $preAmount && $carExShorRoomPrice < $postAmount)
                        ) {
                            $rto_value_i = $ex_showroom_price * $rtoPer / 100;
                        }
                    }
                }

                // rto double for cbu cars in gujarat
                $cpuType = Model::select('cbu_status')->where('model_id',$model_id)->first();
                $stateName = State::select('state_name')->where('state_id',$state_id)->first();
                if($cpuType->cbu_status == '1' && $stateName->state_name == 'Gujarat'){
                    // $RTOrate = State::where('state_id',$state_id)->select('cbu_rto')->first();
                    // $rto_per = $RTOrate->cbu_rto;
                    $rto_value_i = $rto_value_i * 2;
                    // $rto_value_c = $exShorRoomPrice * $rto_per * 2 / 100;
                }
            }
              
            // For company purchase
            $RTOrateCor = Rto::where('state_id',$state_id)->where('rto_type','=','C')->get();
            if ($RTOrateCor->count() == 0){
                $rto_value_c = $rto_value_i * 2;
            } else {
                $checkRTOready = true;
                foreach($RTOrateCor as $rtocheck){

                    // If rto check with the CC (No amount)
                    if($rtocheck->cc == 1){
                        $checkRTOready = false;

                        $getCC = Variant::join('cop_fv','cop_fv.variant_id','=','cop_variants.variant_id')->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')->where('cop_features_ms.features_name','=','Displacement')->where('cop_variants.variant_id',$variant_id)->first();

                        if(!empty($getCC)){
                            $checkRTOready = true;
                            $carExShorRoomPrice = $getCC->feature_value;
                        }
                    }
                    
                    // If RTO check with Fuel-type and Amount both
                    if($rtocheck->fuel_type != null){
                        $checkRTOready = false;
    
                        $modelIdEvCheck = Model::select('model_type')->where('model_id',$model_id)->first();
    
                        if($modelIdEvCheck->model_type == 1){
                            if($rtocheck->fuel_type == 'EV'){
                                $checkRTOready = true;
                            }
                        } else {
                            $getFuelType = Variant::select('cop_fv.feature_value')->join('cop_fv','cop_fv.variant_id','=','cop_variants.variant_id')->join('cop_features_ms','cop_features_ms.feature_id','=','cop_fv.feature_id')->where('cop_features_ms.features_name','=','Type of Fuel')->where('cop_variants.variant_id',$variant_id)->first();
    
                            if(!empty($getFuelType) && $getFuelType->feature_value == $rtocheck->fuel_type){
                                $checkRTOready = true;
                            }
                        }
                    }
                    
                    // If RTO check with only Amount
                    if($checkRTOready == true){
                        $preCondition = $rtocheck->pre_condition;
                        $preAmount = $rtocheck->pre_amount;
                        $postCondition = $rtocheck->post_condition;
                        $postAmount = $rtocheck->post_amount;
                        $rtoPer = $rtocheck->percentage;

                        if($preCondition == null && $preAmount == null && $postCondition == null && $postAmount == null) {
                            $rto_value_c = $ex_showroom_price * $rtoPer / 100;
                        } else if($postCondition == null && $postAmount == null){
                            if (
                                ($preCondition === '<' && $carExShorRoomPrice < $preAmount) ||
                                ($preCondition === '>' && $carExShorRoomPrice > $preAmount) ||
                                ($preCondition === '<=' && $carExShorRoomPrice <= $preAmount) ||
                                ($preCondition === '>=' && $carExShorRoomPrice >= $preAmount)
                            ) {
                                $rto_value_c = $ex_showroom_price * $rtoPer / 100;
                                // $rto_value_c = 0;
                            } 
                        } else {
                            if (
                                ($preCondition === '>' && $postCondition === '<=' && $carExShorRoomPrice > $preAmount && $carExShorRoomPrice <= $postAmount) ||
                                ($preCondition === '>=' && $postCondition === '<=' && $carExShorRoomPrice >= $preAmount && $carExShorRoomPrice <= $postAmount) ||
                                ($preCondition === '>=' && $postCondition === '<' && $carExShorRoomPrice >= $preAmount && $carExShorRoomPrice < $postAmount) ||
                                ($preCondition === '>' && $postCondition === '<' && $carExShorRoomPrice > $preAmount && $carExShorRoomPrice < $postAmount)
                            ) {
                                $rto_value_c = $ex_showroom_price * $rtoPer / 100;
                                // $rto_value_c = 0;
                            }
                        }
                    }

                    // rto double for cbu cars in gujarat
                    $cpuType = Model::select('cbu_status')->where('model_id',$model_id)->first();
                    $stateName = State::select('state_name')->where('state_id',$state_id)->first();
                    if($cpuType->cbu_status == '1' && $stateName->state_name == 'Gujarat'){
                        // $RTOrate = State::where('state_id',$state_id)->select('cbu_rto')->first();
                        // $rto_per = $RTOrate->cbu_rto;
                        // $rto_value_c = $exShorRoomPrice * $rto_per * 2 / 100;
                        $rto_value_c = $rto_value_c * 2;
                    }
                }
            }
                        // RTO
                        // $cpuType = Model::select('cbu_status')->where('model_id', $model_id)->first();
                        // if ($cpuType->cbu_status == '1') {
                        //     $i_rto_price = $ex_showroom_price * 6 * 2 / 100;
                        //     $c_rto_price = $ex_showroom_price * 12 * 2 / 100;
                        // } else {
                        //     $i_rto_price = $ex_showroom_price * 6 / 100;
                        //     $c_rto_price = $ex_showroom_price * 12 / 100;
                        // }

                        $price_entry->i_rto_price = $rto_value_i;
                        $price_entry->c_rto_price = $rto_value_c;



                        // TCS and insurance
                        $getTCStaxId = AllTax::where('tax_name', '=', 'TCS')->first();
                        $getInsurancetax = AllTax::where('tax_name', '=', 'Insurance')->first();
                        $insuranceAmt = (float)$ex_showroom_price * $getInsurancetax->percent / 100;

                        if ($ex_showroom_price > 1000000) {
                            $tcsAmt = (float)$ex_showroom_price * 1 / 100;
                            $price_entry->tax_id  = json_encode([(string)$getTCStaxId->tax_id, (string)$getInsurancetax->tax_id]);
                            $price_entry->tax_cost = json_encode([$getTCStaxId->tax_id => (string)(float)$tcsAmt, $getInsurancetax->tax_id => (string)(float)$insuranceAmt]);
                        } else {
                            $price_entry->tax_id  = json_encode([(string)$getInsurancetax->tax_id]);
                            $price_entry->tax_cost = json_encode([$getInsurancetax->tax_id => (string)(float)$insuranceAmt]);
                        }

                        $price_entry->total_price  = $ex_showroom_price + $rto_value_i + $tcsAmt + $insuranceAmt;
                        $price_entry->total_price_c = $ex_showroom_price + $rto_value_c + $tcsAmt + $insuranceAmt;
                    }
                    $price_entry->created_by = auth()->id();

                    $price_entry->save();




                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count . ' data has been imported successfully.');
                } catch (Exception $e) {
                    DB::rollBack();

                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', $e->getMessage());
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
