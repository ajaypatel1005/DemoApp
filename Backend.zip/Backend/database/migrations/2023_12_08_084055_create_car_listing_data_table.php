<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_cl_data', function (Blueprint $table) {
            $table->id('cl_data_id');
            $table->unsignedBigInteger('cl_id');
            $table->unsignedBigInteger('brand_id');
            $table->unsignedBigInteger('model_id');
            $table->tinyInteger('status')->default(1);
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();

            $table->foreign('cl_id')->references('cl_id')->on('cop_cl_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('brand_id')->references('brand_id')->on('cop_brands_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('model_id')->references('model_id')->on('cop_models')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_cl_data');
    }
};
