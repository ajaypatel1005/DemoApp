<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_lead_history', function (Blueprint $table) {
            $table->id('lh_id');
            $table->unsignedBigInteger('lead_id');
            $table->unsignedBigInteger('lp_id');
            $table->unsignedBigInteger('lps_id')->nullable();
            $table->unsignedBigInteger('lcl_id')->nullable();
            $table->unsignedBigInteger('ln_id')->nullable();
            $table->unsignedBigInteger('ls_status_id')->nullable();
            $table->unsignedBigInteger('lt_id')->nullable();
            $table->unsignedBigInteger('la_id')->nullable();
            $table->string('lh_type',50)->nullable(); //activity,call_log,notes,document,email
            $table->text('remarks')->nullable(); //remarks for lost lead reason
            $table->datetime('reminder_date')->nullable();//for display whene On Hold lead at lead history display
            $table->unsignedBigInteger('created_by');
            $table->timestamps();
            $table->foreign('lead_id')->references('lead_id')->on('cop_leads')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('lp_id')->references('lp_id')->on('cop_lead_pipeline_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('lps_id')->references('lps_id')->on('cop_lead_pipeline_stage_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('lcl_id')->references('lcl_id')->on('cop_lead_call_log')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('ln_id')->references('ln_id')->on('cop_lead_notes')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('ls_status_id')->references('ls_status_id')->on('cop_lead_status_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('lt_id')->references('lt_id')->on('cop_lead_type_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('la_id')->references('la_id')->on('cop_lead_activity')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_lead_history');
    }
};
