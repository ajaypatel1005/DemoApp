<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_evs_ms', function (Blueprint $table) {
            $table->id('evs_id');

            $table->unsignedBigInteger('state_id');
            $table->unsignedBigInteger('city_id');
            $table->string('evs_name');
            $table->text('evs_address');
            $table->text('evs_location');
            $table->string('evs_charging_slots');
            $table->string('evs_charging_port_type');
            $table->string('evs_charging_voltage');
            $table->string('evs_charging_rate');
            $table->string('evs_car_capacity');
            $table->string('evs_contact_number');
            $table->tinyInteger('status')->default(1);
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();

            $table->foreign('state_id')->references('state_id')->on('cop_state_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('city_id')->references('city_id')->on('cop_city_ms')->onDelete('cascade')->onUpdate('cascade');
              $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_evs');
    }
};
