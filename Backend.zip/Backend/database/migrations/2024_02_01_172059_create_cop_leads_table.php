<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_leads', function (Blueprint $table) {
            $table->id('lead_id');
            $table->bigInteger('campaign_id')->nullable();
            $table->string('lead_name')->nullable();
            $table->string('lead_contact');
            $table->string('lead_email')->nullable();
            $table->string('lead_address')->nullable();
            $table->unsignedBigInteger('brand_id')->nullable();
            $table->unsignedBigInteger('model_id')->nullable();
            $table->unsignedBigInteger('variant_id')->nullable();
            $table->unsignedBigInteger('manager_user_id')->nullable();
            $table->unsignedBigInteger('assign_id')->nullable();
            $table->string('lead_budget')->nullable();
            $table->unsignedBigInteger('country_id')->nullable();
            $table->unsignedBigInteger('state_id')->nullable();
            $table->unsignedBigInteger('city_id')->nullable();
            $table->unsignedBigInteger('lp_id')->nullable();
            $table->unsignedBigInteger('lps_id')->nullable();
            $table->unsignedBigInteger('ls_id')->nullable();
            $table->unsignedBigInteger('ls_status_id')->nullable();
            $table->unsignedBigInteger('lt_id')->nullable();
            $table->unsignedBigInteger('customer_id')->nullable();
            $table->string('exp_end_date')->nullable();
            $table->string('start_date')->nullable();
            $table->string('end_date')->nullable();
            $table->datetime('hold_reminder_date')->nullable();
            $table->string('remark')->nullable();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();

            $table->foreign('brand_id')->references('brand_id')->on('cop_brands_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('model_id')->references('model_id')->on('cop_models')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('variant_id')->references('variant_id')->on('cop_variants')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('manager_user_id')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('country_id')->references('country_id')->on('cop_country_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('state_id')->references('state_id')->on('cop_state_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('city_id')->references('city_id')->on('cop_city_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('lp_id')->references('lp_id')->on('cop_lead_pipeline_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('lps_id')->references('lps_id')->on('cop_lead_pipeline_stage_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('ls_id')->references('ls_id')->on('cop_lead_source_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('ls_status_id')->references('ls_status_id')->on('cop_lead_status_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('lt_id')->references('lt_id')->on('cop_lead_type_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('assign_id')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('customer_id')->references('customer_id')->on('cop_customers')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_leads');
    }
};
