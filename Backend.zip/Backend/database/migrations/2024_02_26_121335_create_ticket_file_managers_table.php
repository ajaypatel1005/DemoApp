<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ticket_file_managers', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('path');
            $table->unsignedBigInteger('ticket_id')->nullable();
            $table->timestamps();
            $table->unsignedBigInteger('conversation_id')->nullable();
            $table->foreign('ticket_id')->references('id')->on('ticket')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('conversation_id')->references('id')->nullable()->on('ticket_conversation')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ticket_file_managers');
    }
};
