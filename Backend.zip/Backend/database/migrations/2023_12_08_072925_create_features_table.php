<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_features_ms', function (Blueprint $table) {
            $table->id('feature_id');

            $table->unsignedBigInteger('spec_id');
            $table->unsignedBigInteger('fo_id');
            $table->unsignedBigInteger('su_id')->nullable();

            $table->string('features_name');
            $table->string('features_image')->nullable();
            $table->tinyInteger('status')->default(1);

            $table->timestamps();

            $table->foreign('spec_id')->references('spec_id')->on('cop_spec_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('su_id')->references('su_id')->on('cop_su_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('fo_id')->references('fo_id')->on('cop_fo_ms')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_mf');
    }
};
