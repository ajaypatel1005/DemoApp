<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_pe_ms', function (Blueprint $table) {
            $table->double('i_rto_price')->after('against_city_id');
            $table->double('c_rto_price')->after('i_rto_price');
            $table->double('total_price_c')->after('total_price');            
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_pe_ms', function (Blueprint $table) {
            $table->dropColumn('i_rto_price');
            $table->dropColumn('c_rto_price');
            $table->dropColumn('total_price_c');
        });
    }
};
