<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ticket', function (Blueprint $table) {
            $table->id();
            $table->string('ticket_no');
            $table->string('title');
            $table->text('description');
            $table->unsignedBigInteger('category_id');
            $table->unsignedBigInteger('buynow_id')->nullable();
            $table->unsignedBigInteger('test_drive_id')->nullable();
            $table->foreign('test_drive_id')->references('btest_id')->nullable()->on('cop_book_test_drives')->onDelete('cascade')->onUpdate('cascade');
            $table->integer('status')->comment('Open = 0, In-Progress = 1,Cancelled = 2,On-Hold = 3,Closed = 4,Resolved = 5,Re-Open = 6');
            $table->integer('priority')->comment('Low = 1, Medium = 2,High = 3,Critical = 4');
            $table->unsignedBigInteger('created_by_agent')->nullable();
            $table->unsignedBigInteger('created_by_customer')->nullable();
            $table->unsignedBigInteger('status_change_by_agent')->nullable();
            $table->unsignedBigInteger('status_change_by_customer')->nullable();
            $table->unsignedBigInteger('assigned_by')->nullable();
            $table->unsignedBigInteger('assigned_to')->nullable();
            $table->softDeletes();
            $table->timestamps();
            $table->foreign('category_id')->references('id')->on('ticket_category_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('created_by_agent')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('created_by_customer')->references('customer_id')->on('cop_customers')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('status_change_by_agent')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('status_change_by_customer')->references('customer_id')->on('cop_customers')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('assigned_by')->references('id')->nullable()->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('assigned_to')->references('id')->nullable()->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('buynow_id')->references('buynow_id')->on('cop_buy_now')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ticket');
    }
};
