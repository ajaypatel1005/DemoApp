<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_spec_ms', function (Blueprint $table) {
            $table->id('spec_id');

            $table->unsignedBigInteger('sc_id');
            $table->string('spec_name');
            $table->string('spec_image')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->timestamps();
            $table->foreign('sc_id')->references('sc_id')->on('cop_sc_ms')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_spec_ms');
    }
};
