<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_state_ms', function (Blueprint $table) {
            //
            $table->dropColumn("rto_per");
            $table->enum('is_ut',['0','1'])->comment('0=State,1=UT');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_state_ms', function (Blueprint $table) {
            //
            $table->decimal("rto_per")->after('state_name');
            $table->dropColumn("is_ut");
        });
    }
};
