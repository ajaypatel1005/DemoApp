<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_models', function (Blueprint $table) {
            $table->id('model_id');

            $table->unsignedBigInteger('cs_id');
            $table->date('launch_date')->nullable();
            $table->unsignedBigInteger('ct_id');
            $table->unsignedBigInteger('brand_id');

            $table->string('model_name');
            $table->string('model_image')->nullable();
            $table->text('model_description');
            $table->integer('min_price');
            $table->integer('max_price');
            $table->string('model_year');
            $table->string('model_type');
            $table->tinyInteger('status')->default(1);
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();

            $table->foreign('cs_id')->references('cs_id')->on('cop_cs_ms')->onUpdate('cascade')->onDelete('cascade');
            $table->foreign('ct_id')->references('ct_id')->on('cop_ct_ms')->onUpdate('cascade')->onDelete('cascade');
            $table->foreign('brand_id')->references('brand_id')->on('cop_brands_ms')->onUpdate('cascade')->onDelete('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_models');
    }
};
