<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_lead_pipeline_stage_ms', function (Blueprint $table) {
            $table->id('lps_id');
            $table->unsignedBigInteger('lp_id');
            $table->string('lps_name',70);
            $table->string('win_probability');
            $table->integer('display_order');
            $table->tinyInteger('status')->default(1);
            $table->timestamps();
            $table->foreign('lp_id')->references('lp_id')->on('cop_lead_pipeline_ms')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_lead_pipeline_stage_ms');
    }
};
