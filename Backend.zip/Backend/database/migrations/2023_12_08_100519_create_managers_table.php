<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_manager_ms', function (Blueprint $table) {
            $table->id('manager_id');

            $table->unsignedBigInteger('brand_id');
            $table->unsignedBigInteger('lang_id');

            $table->string('first_name');
            $table->string('last_name');

            $table->string('m_image')->nullable();
            $table->string('m_email');
            $table->string('m_contact_no');
            $table->string('m_shift');


            $table->tinyInteger('status')->default(1);
            $table->timestamps();

            $table->foreign('brand_id')->references('brand_id')->on('cop_brands_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('lang_id')->references('lang_id')->on('cop_ml_ms')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_manager_ms');
    }
};
