<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_msd', function (Blueprint $table) {
            $table->id('msd_id');
            $table->unsignedBigInteger('model_id');
            $table->string('model_engine');
            $table->string('model_bhp');
            $table->string('model_transmission');
            $table->string('model_mileage');
            $table->string('model_fuel');
            $table->timestamps();
            $table->foreign('model_id')->references('model_id')->on('cop_models')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_msd');
    }
};
