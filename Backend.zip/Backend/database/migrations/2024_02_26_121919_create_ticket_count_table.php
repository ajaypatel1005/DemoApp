<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_ticket_count', function (Blueprint $table) {
            $table->id();
            $table->integer('buynow_count')->default(0);
            $table->integer('test_drive_count')->default(0);
            $table->integer('total_digit')->default(4);
            $table->timestamps();
        });
        DB::table('cop_ticket_count')->insert([
            'buynow_count' => 0,
            'test_drive_count' => 0,
            'total_digit' => 4
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ticket_count');
    }
};
