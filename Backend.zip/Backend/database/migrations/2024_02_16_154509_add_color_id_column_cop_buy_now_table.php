<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_buy_now', function (Blueprint $table) {
            $table->unsignedBigInteger('color_id');
            $table->foreign('color_id')->references('color_id')->on('cop_colors')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_buy_now', function (Blueprint $table) {
            $table->dropForeign(['color_id']); // Drop foreign key constraint
            $table->dropIndex('cop_buy_now_color_id_foreign'); // Drop index on color_id
            $table->dropColumn('color_id'); // Drop the color_id column
        });
    }
};
