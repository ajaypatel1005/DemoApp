<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_buy_now', function (Blueprint $table) {
            // Make manager_id column nullable
            $table->unsignedBigInteger('manager_id')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_buy_now', function (Blueprint $table) {
            // Revert the nullable change if needed
            $table->unsignedBigInteger('manager_id')->nullable(false)->change();
        });
    }
};
