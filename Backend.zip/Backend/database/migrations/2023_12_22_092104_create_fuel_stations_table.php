<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_f_stations_ms', function (Blueprint $table) {
            $table->id('f_station_id');
            $table->string('f_station_name');
            $table->text('f_station_address');
            $table->string('f_station_location');
            $table->unsignedBigInteger('state_id');
            $table->unsignedBigInteger('city_id');
            // $table->string('f_slots');
            // $table->string('f_type');
            // $table->string('f_rate');
            // $table->string('car_capacity');
            $table->string('contact_no');
            $table->tinyInteger('status')->default(1);
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();

            $table->foreign('state_id')->references('state_id')->on('cop_state_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('city_id')->references('city_id')->on('cop_city_ms')->onDelete('cascade')->onUpdate('cascade');

            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_f_stations_ms');
    }
};
