<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_evs_ms', function (Blueprint $table) {
            $table->string('evs_charging_slots')->nullable()->change();
            $table->string('evs_charging_port_type')->nullable()->change();
            $table->string('evs_charging_voltage')->nullable()->change();
            $table->string('evs_charging_rate')->nullable()->change();
            $table->string('evs_car_capacity')->nullable()->change();
            $table->string('evs_contact_number')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_evs_ms', function (Blueprint $table) {
            //
        });
    }
};
