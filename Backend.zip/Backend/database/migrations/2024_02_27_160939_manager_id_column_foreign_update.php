<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_book_test_drives',function(Blueprint $table){
            $table->dropForeign(['manager_id']);
            $table->dropColumn(['manager_id']);
            $table->unsignedBigInteger('manager_user_id')->nullable()->after('model_id');
            $table->foreign('manager_user_id')->references('user_id')->on('cop_manager_ms')->onUpdate('cascade')->onDelete('cascade');
        });

        Schema::table('cop_buy_now',function(Blueprint $table){
            $table->dropForeign(['manager_id']);
            $table->dropColumn(['manager_id']);
            $table->unsignedBigInteger('manager_user_id')->nullable()->after('variant_id');
            $table->foreign('manager_user_id')->references('user_id')->on('cop_manager_ms')->onUpdate('cascade')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_book_test_drives', function (Blueprint $table) {
            $table->dropForeign(['manager_user_id']);
            $table->dropColumn(['manager_user_id']);
            $table->unsignedBigInteger('manager_id')->nullable();
            $table->foreign('manager_id')->references('manager_id')->on('cop_manager_ms')->onUpdate('cascade')->onDelete('cascade');
        });

        Schema::table('cop_buy_now', function (Blueprint $table) {
            $table->dropForeign(['manager_user_id']);
            $table->dropColumn(['manager_user_id']);
            $table->unsignedBigInteger('manager_id')->nullable();
            $table->foreign('manager_id')->references('manager_id')->on('cop_manager_ms')->onUpdate('cascade')->onDelete('cascade');
        });
    }
};
