<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_s_stations_ms', function (Blueprint $table) {
            $table->id('s_station_id');
            $table->unsignedBigInteger('brand_id');
            $table->string('s_station_name');
            $table->text('s_station_address');
            $table->string('s_station_location');
            $table->unsignedBigInteger('state_id');
            $table->unsignedBigInteger('city_id');
            $table->string('contact_no');
            $table->string('email');
            $table->tinyInteger('status')->default(1);
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->foreign('brand_id')->references('brand_id')->on('cop_brands_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('state_id')->references('state_id')->on('cop_state_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('city_id')->references('city_id')->on('cop_city_ms')->onDelete('cascade')->onUpdate('cascade');

            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_s_stations_ms');
    }
};
