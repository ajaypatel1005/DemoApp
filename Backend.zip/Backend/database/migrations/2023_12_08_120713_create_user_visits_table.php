<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_uvisit', function (Blueprint $table) {
            $table->id('visit_id');
            $table->unsignedBigInteger('id');

            $table->string('visit_link');
            $table->string('visited_count');
            $table->string('referral');

            $table->tinyInteger('status')->default(1);
            $table->timestamps();
            $table->foreign('id')->references('id')->on('users')
            ->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_uvisit');
    }
};
