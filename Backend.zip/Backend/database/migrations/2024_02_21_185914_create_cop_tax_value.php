<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Permission;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_tax_value', function (Blueprint $table) {
            $table->id('tax_value_id');
            $table->unsignedBigInteger('tax_id');
            $table->string('condition');
            $table->integer('amount');
            $table->double('percent');
            $table->timestamps();
            $table->foreign('tax_id')->references('tax_id')->on('cop_taxes_ms')->onDelete('cascade')->onUpdate('cascade');;
        });
        Permission::updateorCreate(['name'=>'tax_value'],['guard_name'=>'web']);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_tax_value');
        Permission::where('name','LIKE','tax_value')->delete();

    }
};
