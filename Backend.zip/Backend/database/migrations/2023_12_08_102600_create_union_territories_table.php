<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_ut', function (Blueprint $table) {
            $table->id('ut_id');
            $table->unsignedBigInteger('country_id');
            // $table->unsignedBigInteger('state_id');
          $table->string('ut_name');
            $table->tinyInteger('status')->default(1);
            $table->timestamps();

            // $table->foreign('state_id')->references('state_id')->on('cop_state_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('country_id')->references('country_id')->on('cop_country_ms')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_ut');
    }
};
