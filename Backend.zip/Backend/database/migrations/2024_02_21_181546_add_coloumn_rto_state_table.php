<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cop_taxes_ms', function (Blueprint $table) {
            $table->string('display_name')->after('tax_name')->nullable();
            $table->tinyInteger('condition_status');
            $table->double('percent')->nullable();
            $table->unsignedBigInteger("city_id")->nullable();
            $table->foreign("city_id")->references("city_id")->on("cop_city_ms")->onDelete("cascade")->onUpdate("cascade");
        });

        Schema::table('cop_state_ms', function (Blueprint $table) {
            $table->decimal("rto_per")->after('state_name');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cop_taxes_ms', function (Blueprint $table) {
            $table->dropColumn('display_name'); // Drop the color_id column
            $table->dropColumn('condition_status');
            $table->dropColumn('percent');
            $table->dropForeign(["city_id"]);
            $table->dropColumn("city_id");
        });

        Schema::table('cop_state_ms', function (Blueprint $table) {
            $table->dropColumn("rto_per");

        });
    }
};
