<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cop_pe_ms', function (Blueprint $table) {
            $table->id('pe_id');

            $table->unsignedBigInteger('brand_id');
            $table->unsignedBigInteger('model_id');
            $table->unsignedBigInteger('variant_id');
            $table->unsignedBigInteger('country_id');
            $table->unsignedBigInteger('state_id')->nullable();
            $table->unsignedBigInteger('city_id')->nullable();
            $table->unsignedBigInteger('ut_id')->nullable();
            $table->string('tax_id');

            $table->string('ex_showroom_price');
            $table->string('tax_cost');
            $table->string('total_price');

            $table->tinyInteger('status')->default(1);
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();

            $table->timestamps();

            $table->foreign('brand_id')->references('brand_id')->on('cop_brands_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('model_id')->references('model_id')->on('cop_models')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('variant_id')->references('variant_id')->on('cop_variants')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('country_id')->references('country_id')->on('cop_country_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('state_id')->references('state_id')->on('cop_state_ms')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('city_id')->references('city_id')->on('cop_city_ms')->onDelete('cascade')->onUpdate('cascade');

            $table->foreign('ut_id')->references('ut_id')->on('cop_ut')->onDelete('cascade')->onUpdate('cascade');
//            $table->foreign('ut_id')
//                ->references('ut_id')->on('cop_ut')
//                ->onDelete('set null')
//                ->onUpdate('set null');
              $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cop_pe_ms');
    }
};
