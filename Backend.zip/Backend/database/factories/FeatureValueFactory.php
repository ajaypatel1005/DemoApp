<?php

namespace Database\Factories;

use App\Models\Brand;
use Faker\Generator as Faker;
use App\Models\FeatureValue;
use App\Models\Model;
use App\Models\Variant; // Assuming you have a Variant model
use Illuminate\Database\Eloquent\Factories\Factory;

class FeatureValueFactory extends Factory
{
    protected $model = FeatureValue::class;

    public function definition()
    {
        $variantCount = Variant::count();
        $variants = Variant::all();
        return [
            'brand_id' => Brand::inRandomOrder()->first()->brand_id,
            'model_id' => Model::inRandomOrder()->first()->model_id,
            // 'variant_id' => $variants->random()->variant_id,
            'spec_id' => 2,
            'feature_id' => 9,
//            'su_id' => 1,
            'feature_value' => $this->faker->randomElement(['Petrol', 'Diesel','CNG','Hybrid']),
            'key_highlight' => 0,
            'status' => 1,
            // Add other fields as needed
        ];
    }
}
//trans
// 'spec_id' => 3,
// 'feature_id' => 15,
// 'feature_value' => $this->faker->randomElement(['Auto','Manual','ACT'])

//drive
// 'spec_id' => 3,
// 'feature_id' => 17,
// 'feature_value' => $this->faker->randomElement(['AWD','4WD','FWD','RWD'])

//cc
// 'spec_id' => 1,
// 'feature_id' => 2,
// 'feature_value' =>  $this->faker->numberBetween(500, 3000)

//Interior
// 'spec_id' => 10,
// 'feature_id' =>  $this->faker->numberBetween(53, 140)
// 'feature_value' =>   $this->faker->randomElement([0,1])

//Exterior
// 'spec_id' => 11,
// 'feature_id' =>  $this->faker->numberBetween(141, 179)
// 'feature_value' =>   $this->faker->randomElement([0,1])

//Safety
// 'spec_id' => 12,
// 'feature_id' =>  $this->faker->numberBetween(180, 221)
// 'feature_value' =>   $this->faker->randomElement([0,1])
