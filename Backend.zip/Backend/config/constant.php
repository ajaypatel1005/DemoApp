<?php

return [
    'LAUNCHED' => 'Launched',
    'UPCOMING' => 'Upcoming',

    'fronted_url' => 'ewrerere', // banner api
    'popular_cars' => 'Popular Cars', // trending api
    'API Token' => '6IlFnSlBLZy9BZlhENHNXOXVwZFBtV3c9PSIsInZhbHVlIjoidGxLYmR3YTdMSjNmR2ZiajdRWFA3Zz09IiwibWFjIjoiNDA3NTUxNGQ1YzU2ODdmNDRjZTI4ZGU4MTgwMDljZDM4MzI1OTUwMGExZTRhYWEzNzc3M2Y5MmFiZmRhYWY5NS',
    // token verify in Static
    'CRM_ROLE' => [
        'SUPER_ADMIN' => 'Superadmin',
        'ADMIN' => 'Admin',
        'RELATIONSHIP_MANAGER' => 'Relationship Manager',
        'TELECALLER' => 'Telecaller',
        'DEALER' => 'Dealer',
        'COP_SPOC_PERSON' => 'Spoc Person', //For CRM user
        'DEALER_SPOC_PERSON' => 'Dealer Spoc Person', //for dealer spoc person
        'DEALER_SALESMAN' => 'Dealer Salesman' //For dealer salesman
    ],

    'PIPELINE' => [
        'SALES_PIPELINE' => 1,
    ],

    'LEAD_SOURCE' => [
        'BUY_NOW' => 1,
        'BOOK_TEST_DRIVE' => 2,
        'SOCIAL_MEDIA' => 3,
        'TELECALLER' => 4,
        'SALES_TEAM' => 5,
        'WHATSAPP' => 6,
        'EMAIL' => 7,
        'EXCEL_SHEET' => 2,
    ],

    'LEAD_STATUS' => [
        'NEW' => 1,
        'ASSIGNED' => 2,
        'IN_PROGRESS' => 3,
        'WIN' => 4,
        'LOST' => 5,
        'ON_HOLD' => 6,
        'REOPEN' => 7,
        'TRANSFER' => 8, //Use for Dealer lead assign,LEAD_HISTORY_TYPE
        'TEST_DRIVE' => 9, //using for follow up,FOLLOWUP_TYPE
        'BOOKING' => 10,
        'PURCHASE' => 11,
        'OTHER' => 12, //for extra input by salesman or both spoc
        'ONLY_RESEARCH' => 13

    ],
    'SPOC_TYPE' => [
        'COP_SPOC_PERSON' => 0,
        'DEALER_SPOC_PERSON' => 1,
        'DEALER_SALESMAN' => 2
    ],

    'LEAD_TYPE' => [
        'COLD' => 1,
        'WARM' => 2,
        'HOT' => 3
    ],

    'SPOC_VALUE' => [
        'SPOC' => 'SPOC',
        'SALESMAN' => "Salesman"
    ],
    // 'LEAD_HISTORY_TYPE'=>[
    //     'TRANSFER'=>0,
    //     'ASSIGNED'=>1,
    //     'FOLLOWUP'=>2,
    //     'IN_PROGRESS'=>3,
    // ],
    // 'FOLLOWUP_TYPE'=>[
    //     'TEST_DRIVE'=>0,
    //     'BOOKING'=>2,
    //     'PURCHASE'=>3,
    //     'LOST'=>4
    // ],


    'NOTIFICATION_TYPE' => [
        'PRICE_ALERT' => 0,
    ],
    // 'IMAGE_PATH' => sprintf(
    //     'https://%s.%s',
    //     env('DO_SPACES_BUCKET'),
    //     str_replace('https://', '', env('DO_SPACES_ENDPOINT'))
    // ),
    'IMAGE_PATH' => env('IMAGE_PATH'),

    'BANNER_CATEGORY' => [
        'HEAD_BANNER' => 'Head Banner',
        'UPCOMING_BANNER' => 'Upcoming Banner',
        'EV_BANNER' => 'EV Banner'
    ],

    'SEO_TYPE' => [
        'BRAND_TYPE' => '1',
        'MODEL_TYPE' => '2',
        'VARIANT_TYPE' => '3',
        'PAGE_TYPE' => '4',
    ],

    'SEO_TAG' => [
        'META_TITLE' => 'title',
        'META_DESCRIPTION' => 'description',
        'OG_TITLE' => 'og:title',
        'OG_DESCRIPTION' => 'og:description',
    ],

    'SEO_PAGE' => [
        'ALL_BRANDS' => 'All Brands',
        'CAR_MODULE' => 'Car Module'
    ],

    'SEO_CAR_MODUL_SUB_PAGE' => [
        'Specifications',
        'Mileage',
        'Variants',
        'Price',
        'Images',
        'Service Center',
        'Rating and Review',
    ]
];
