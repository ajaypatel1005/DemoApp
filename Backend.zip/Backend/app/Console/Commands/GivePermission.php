<?php

namespace App\Console\Commands;

use Spatie\Permission\Models\Permission;
use App\Models\User;
use Illuminate\Console\Command;
use Spatie\Permission\Models\Role;

class GivePermission extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'add:permission';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add all Permission to  Superadmin';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $permissions = Permission::pluck('id', 'id')->all();
        $role = Role::where('name', 'Superadmin')->first();
        if (!empty($role)) {
            $role->syncPermissions($permissions);
        }
        $user = User::role('Superadmin')->first();
        // Check if the user exists and assign the role
        if ($user) {
            $user->assignRole($role);
        }
    }
}
