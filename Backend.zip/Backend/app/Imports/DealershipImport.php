<?php

namespace App\Imports;

use App\Models\Brand;
use Exception;
use Illuminate\Support\Facades\Log;
use App\Rules\GoogleMapsURL;
use App\Rules\ValidCity;
use App\Rules\ValidBrand;

use Illuminate\Support\Facades\DB;
use App\Models\ServiceStation;
use App\Models\City;
use App\Models\Dealership;
use App\Models\State;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;

class DealershipImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            $uniqueLocations = [];
            $uniqueAddresses = [];
            $uniqueContactNos = [];
            $uniqueEmail = [];

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }


            foreach ($rows as $index => $row) {
                $stateName = trim($row['state']);
                // if (isset($row['location'])) {
                //     $location = trim($row['location']);
                //     if (in_array($location, $uniqueLocations)) {
                //         $this->validationErrors[] = [
                //             'row' => $index + 2,
                //             'field' => ucwords(str_replace('_', ' ', 'location')),
                //             'message' => "Duplicate entry found for Location within the Excel sheet.",
                //         ];
                //     } else {
                //         $uniqueLocations[] = $location;
                //     }
                // }

                // if (isset($row['address'])) {
                //     $address = trim($row['address']);
                //     if (in_array($address, $uniqueAddresses)) {
                //         $this->validationErrors[] = [
                //             'row' => $index + 2,
                //             'field' => ucwords(str_replace('_', ' ', 'address')),
                //             'message' => "Duplicate entry found for Address within the Excel sheet.",
                //         ];
                //     } else {
                //         $uniqueAddresses[] = $address;
                //     }
                // }

                // if (isset($row['contact_no'])) {
                //     $contactNo = trim($row['contact_no']);
                //     if (in_array($contactNo, $uniqueContactNos)) {
                //         $this->validationErrors[] = [
                //             'row' => $index + 2,
                //             'field' => ucwords(str_replace('_', ' ', 'contact_no')),
                //             'message' => "Duplicate entry found for Contact No. within the Excel sheet.",
                //         ];
                //     } else {
                //         $uniqueContactNos[] = $contactNo;
                //     }
                // }
                $rules = [
                    'brand_name' => ['required', new ValidBrand()],
                    'company' => 'required',
                    'dealer' => 'required',
                    'address' => 'required',
                    'location' => ['required', 'string', new GoogleMapsURL()],
                    'state' => ['required', new ValidCity()],
                    'city' => [new ValidCity($stateName)],
                    // 'contact_no' => 'required',
                ];
                $errorMessages = [
                    'brand_name.required' => 'Brand is required.',
                    'brand_name.exists' => 'Brand does not exists or disabled.',
                    'company.required' => 'Company is required.',
                    'dealer.required' => 'Dealer name is required.',
                    'dealer.regex' => 'Dealer name must contain only letters, numbers, and spaces.',
                    'dealer.min' => 'Dealer name must be at least :min characters.',
                    'address.required' => 'Address is required.',
                    'address.min' => 'Address must be at least :min characters.',
                    'location.required' => 'Location is required.',
                    'location.string' => 'Location must be a string.',
                    'location.custom' => 'Location is not a valid Google Maps URL.',
                    'state.required' => 'State is required.',
                    'state.exists' => 'State does not exists or disabled.',
                    'city.required' => 'City is required.',
                ];

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);
                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {
                try {
                    $brandId = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                    $stateId = State::where('state_name', 'like', trim($row['state']))->first();
                    $cityId = City::where('city_name', 'like', trim($row['city']))->first();


                    DB::beginTransaction();

                    $dealer = Dealership::create(
                        [
                            'company_name' => trim($row['company']),
                            'dealer_name' => trim($row['dealer']),
                            'address' => trim($row['address']),
                            'map_location' => trim($row['location']),
                            'state_id' => $stateId->state_id,
                            'city_id' => $cityId->city_id,
                            'brand_id' => $brandId->brand_id,
                            'phone_no' => trim($row['contact_no'] ?? ''),
                            'email' => $row['email'] ?? ''
                        ]
                    );
                    DB::commit();

                    $count++;
                    session()->flash('import_success', $count . ' data has been imported successfully.');
                } catch (Exception $e) {
                    DB::rollBack();

                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
