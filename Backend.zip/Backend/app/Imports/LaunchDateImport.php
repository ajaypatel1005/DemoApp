<?php

namespace App\Imports;

use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Rules\ValidImagePath;
use App\Models\Brand;
use App\Models\Model;
use App\Rules\ValidBrand;
use App\Rules\ValidModelVariantUnique;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class LaunchDateImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            // dd($rows);
            foreach ($rows as $index => $row) {
                $brandName = trim($row['brand_name']);
                $modelName = trim($row['model_name']);
                $rules = [
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => ['required', new ValidBrand($brandName)],
                    'launch_date' => 'required|date_format:d-m-Y|before:today'
                ];

                $errorMessages = [
                    'brand_name.required' => 'The brand name is required.',
                    'model_name.required' => 'The model name is required.',

                ];

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {
                try {
                    DB::beginTransaction();

                    $brand_id = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                    $brand_id = $brand_id->brand_id;
                    $model = Model::where('model_name', 'like', trim($row['model_name']))
                        ->where('brand_id', $brand_id)
                        ->first();
                    $launchDate = Carbon::createFromFormat('d-m-Y', trim($row['launch_date']))->format('Y-m-d');
                    $model->update([
                        'launch_date' => $launchDate,
                    ]);
                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count . ' data has been imported successfully.');
                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
