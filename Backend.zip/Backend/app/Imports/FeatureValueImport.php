<?php

namespace App\Imports;

use App\Models\{Feature,Model,Brand,FeatureValue};
use Exception;
use Illuminate\Support\Facades\{Log,DB};
use App\Rules\ValidBrand;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\{ToCollection,WithHeadingRow};
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Imports\HeadingRowFormatter;

HeadingRowFormatter::default('none');
class FeatureValueImport implements ToCollection,WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try{
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }


            foreach ($rows as $index => $row) {
                $brandName = trim($row['Brand Name']);
                $modelName =trim( $row['Model Name']);
                $validator=Validator::make($row->toArray(), [
                    'Brand Name' => 'required|exists:cop_brands_ms,brand_name',
                    'Model Name' => ['required', new ValidBrand($brandName) ],
                    'Variant Name' => ['required',new ValidBrand($brandName,$modelName)],

                ]);
                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }


        if (empty($this->validationErrors)) {
        foreach ($rows as $index => $row) {
            try {


                $brand_id = Brand::where('brand_name','like',trim($row['Brand Name']) )->first();

                $model_id = Model::where('model_name','like', trim($row['Model Name']))->where('brand_id',$brand_id->brand_id)->first();
                $variant_id = DB::table('cop_variants')
                    ->select('cop_variants.variant_id')
                    ->join('cop_models', 'cop_variants.model_id', '=', 'cop_models.model_id')
                    ->where('cop_variants.variant_name', '=', trim($row['Variant Name']))
                    ->where('cop_models.model_id', '=', $model_id['model_id'])
                    ->value('cop_variants.variant_id');
                $featureValues = collect($row)->slice(3, count($row));
                $featureValues->map(function ($data, $index) use ($brand_id, $model_id, $variant_id) {
                    $index = strtolower(str_replace('_', ' ', $index));

                    $featureId = Feature::where('features_name', 'LIKE', "$index")->first();

                    if (!empty($data)) {

                        if (!empty($featureId)) {
                            if (strtolower($data) == 'yes') {

                                $data = 'Yes';
                            } elseif (strtolower($data) == 'no') {

                                $data = 'No';
                            } else {

                                $data;
                            }
                            $featureValue = FeatureValue::updateOrCreate(
                                [
                                    'brand_id' => $brand_id['brand_id'],
                                    'model_id' => $model_id['model_id'],
                                    'variant_id' => $variant_id,
                                    'spec_id' => $featureId['spec_id'],
                                    'feature_id' => $featureId['feature_id'],
                                ],
                                [
                                    'feature_value' => trim($data),
                                    'created_by' => auth()->id()
                                ]
                            );

                        }

                    }else{
                        FeatureValue::where('feature_id',$featureId['feature_id'])->where('variant_id',$variant_id)->delete();
                    }
                });

                session()->flash('import_success', 'Import Successfully.');

            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                session()->flash('import_error', 'Something went wrong.');
            }

        }
    }}

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}

