<?php

namespace App\Imports;

use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Rules\ValidBrand;
use App\Rules\ValidModelVariantUnique;
use App\Rules\ValidImagePath;
use App\Models\Brand;
use App\Models\Model;
use App\Models\Variant;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class ModelVariantImageUpdate implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            // dd($rows);
            foreach ($rows as $index => $row) {
                $brandName = trim($row['brand_name']);
                $modelName = trim($row['model_name']);
                $hasModelImage = array_key_exists('model_image_mob', $row->toArray());
                $hasVariantImage = array_key_exists('variant_image_mob', $row->toArray());
                $rules = [
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => ['required', new ValidBrand($brandName)],

                ];

                if ($hasModelImage) {
                    $rules['model_image_mob'] = ['required', new ValidImagePath()];
                }
                if ($hasVariantImage) {
                    $rules['variant_name'] = ['required', new ValidBrand($brandName, $modelName)];
                    $rules['variant_image_mob'] = ['required', new ValidImagePath()];
                }
                $validator = Validator::make($row->toArray(), $rules);
                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            $manager = new ImageManager(new Driver());
            foreach ($rows as $index => $row) {
                $hasModelImage = array_key_exists('model_image_mob', $row->toArray());
                $hasVariantImage = array_key_exists('variant_image_mob', $row->toArray());
                try {
                    $brand = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();

                    if ($hasModelImage) {

                        DB::beginTransaction();
                        $model = Model::updateOrCreate(
                            [
                                'brand_id' => $brand->brand_id,
                                'model_name' => trim($row['model_name'])
                            ]
                        );
                        // Upload Image
                        if (!File::isDirectory(public_path('brands') . '/' . $model->brand_id . '/' . $model->model_id)) {
                            File::makeDirectory(public_path('brands') . '/' . $model->brand_id . '/' . $model->model_id);
                        }
                        $model_image_mob = trim($row['model_image_mob']);
                        $webpImageNameModel = $model->model_id . '_mob' . '.webp';
                        $model_image_mob_path = public_path('brands') . '/' . $model->brand_id . '/' . $model->model_id . '/' . $webpImageNameModel;
                        $urlImage = @file_get_contents($model_image_mob);
                        if ($urlImage === false) {
                        } else {
                            $image = $manager->read($urlImage);
                            $image->toWebp()->save($model_image_mob_path);
                        }
                        $model->update(['model_image_mob' => $webpImageNameModel]);
                        DB::commit();
                    }
                    if ($hasVariantImage) {
                        $brand_id = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                        $brand_id = $brand_id->brand_id;
                        $model_id = Model::where('model_name', 'like', trim($row['model_name']))->where('brand_id', $brand_id)->first();
                        $model_id = $model_id->model_id;
                        DB::beginTransaction();
                        $variant = Variant::updateOrCreate(
                            [
                                'brand_id' => $brand_id,
                                'model_id' => $model_id,
                                'variant_name' => trim($row['variant_name']),
                            ]
                        );

                        if (!File::isDirectory(public_path('brands') . '/' . $brand_id . '/' . $model_id . '/' . $variant->variant_id)) {

                            File::makeDirectory(public_path('brands') . '/' . $brand_id . '/' . $model_id . '/' . $variant->variant_id);
                        }


                        $variant_image_mob = trim($row['variant_image_mob']);
                        $webpImageNameBanner = $variant->variant_id .'_mob'. '.webp';
                        $variant_image_mob_path = public_path('brands') . '/' . $brand_id . '/' . $model_id . '/' . $variant->variant_id . '/' . $webpImageNameBanner;
                        $variant_folder_path = public_path('brands') . '/' . $brand_id . '/' . $model_id . '/' . $variant->variant_id;
                        $urlImage = @file_get_contents($variant_image_mob);
                        if ($urlImage === false) {
                        } else {
                            $image = $manager->read($urlImage);
                            $image->toWebp()->save($variant_folder_path . '/' . $webpImageNameBanner);
                        }
                        $variant->update(['variant_image_mob' => $webpImageNameBanner]);
                        DB::commit();
                    }
                    $count++;
                    session()->flash('import_success', $count . ' data has been imported successfully.');
                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
