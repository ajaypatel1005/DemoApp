<?php

namespace App\Imports;

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Rules\ValidImagePath;
use App\Models\Variant;
use App\Models\Color;
use App\Models\Brand;
use App\Models\Model;
use App\Rules\ValidBrand;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class VariantColorImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {
                $hasColorCode = array_key_exists('color_code', $row->toArray());
                $hasColorImage = array_key_exists('variant_color_image', $row->toArray());


                $brandName = trim($row['brand_name']);
                $modelName = trim($row['model_name']);
                $rules = [
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => ['required', new ValidBrand($brandName)],
                    'variant_name' => ['required', new ValidBrand($brandName, $modelName)],
                    // 'color_code' => 'required',
                    'color_name' => 'required',
                    'variant_color_image_mob' => ['required', new ValidImagePath()],
                ];
                if ($hasColorCode) {
                    $rules['color_code'] = 'required';
                }
                if ($hasColorImage) {
                    $rules['variant_color_image'] = ['required', new ValidImagePath()];
                }
                $validator = Validator::make($row->toArray(), $rules);
                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }


        if (empty($this->validationErrors)) {
            $count = 0;
            $manager = new ImageManager(new Driver());
            foreach ($rows as $index => $row) {
                $hasColorCode = array_key_exists('color_code', $row->toArray());
                $hasDualColorCode = array_key_exists('dual_color_code', $row->toArray());
                $hasColorImage = array_key_exists('variant_color_image', $row->toArray());

                try {
                    $brand_id = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                    $brand_id = $brand_id->brand_id;
                    $model_id = Model::where('model_name', 'like', trim($row['model_name']))->where('brand_id', $brand_id)->first();
                    $model_id = $model_id->model_id;
                    $variant_id = Variant::where('variant_name', 'like', trim($row['variant_name']))->where('brand_id', $brand_id)->where('model_id', $model_id)->first();
                    $variant_id = $variant_id->variant_id;
                    DB::beginTransaction();
                    $variantColorData = [
                        'created_by' => auth()->id()

                    ];
                    $bucketFolder = 'brands/' . $brand_id . '/' . $model_id . '/' . $variant_id . '/';
                    // Conditionally include 'dual_color_code' if the column exists
                    if ($hasColorCode) {
                        $variantColorData['color_code'] = trim($row['color_code']);
                        // $variantColorData['dual_color_code'] = trim($row['dual_color_code']);

                    }
                    if ($hasDualColorCode) {
                        $variantColorData['dual_color_code'] = trim($row['dual_color_code']);
                    }
                    $variantColor = Color::updateOrCreate(
                        [
                            'brand_id' => $brand_id,
                            'model_id' => $model_id,
                            'variant_id' => $variant_id,
                            'color_name' => trim($row['color_name']),

                        ],
                        $variantColorData
                    );
                    if ($variantColor->wasRecentlyCreated) {
                    } else {

                        if ($hasColorImage) {
                            if (!empty($row['variant_color_image']) && !empty($variantColor->variant_color_image)) {
                                $bucketImage = $bucketFolder . '/' . $variantColor->variant_color_image;
                                Storage::disk('digitalocean')->delete($bucketImage);
                            }
                        }
                        if (!empty($row['variant_color_image_mob'])  && !empty($variantColor->variant_color_image)) {
                            $bucketMobImage = $bucketFolder . '/' . $variantColor->variant_color_image_mob;
                            Storage::disk('digitalocean')->delete($bucketMobImage);
                        }
                    }
                    $variantColor->save();

                    if ($hasColorImage) {
                        $variant_color_image = trim($row['variant_color_image']);
                        $webpImage = $variant_id . '_' . (time() + $index) . '.webp';


                        $urlImage = @file_get_contents($variant_color_image);
                        if ($urlImage === false) {
                        } else {

                            $image = $manager->read($urlImage);
                            Storage::disk('digitalocean')->put($bucketFolder . $webpImage, $image->toWebp(), 'public');

                            // Thumbnail image
                            $image->resize(676, 348);
                            Storage::disk('digitalocean')->put($bucketFolder . 'thumb/' . $webpImage, $image->toWebp(), 'public');
                        }
                        // Update Brand with Banner
                        $variantColor->update(['variant_color_image' => $webpImage]);
                    }



                    $variant_color_image_mob = trim($row['variant_color_image_mob']);
                    $webpImageMob = $variant_id . '_' . (time() + $index) . '_' . '.webp';

                    $urlImage = @file_get_contents($variant_color_image_mob);
                    if ($urlImage === false) {
                    } else {
                        $image = $manager->read($urlImage);
                        Storage::disk('digitalocean')->put($bucketFolder . $webpImageMob, $image->toWebp(), 'public');
                    }
                    $variantColor->update(['variant_color_image_mob' => $webpImageMob]);
                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count . ' data has been imported successfully.');
                } catch (Exception $e) {
                    DB::rollBack();

                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', $e->getMessage());
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
