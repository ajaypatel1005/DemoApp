<?php

namespace App\Imports;

use App\Models\Brand;
use Exception;
use Illuminate\Support\Facades\Log;
use App\Rules\GoogleMapsURL;
use App\Rules\ValidCity;
use App\Rules\ValidBrand;

use Illuminate\Support\Facades\DB;
use App\Models\ServiceStation;
use App\Models\City;
use App\Models\State;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ServiceStationImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            $uniqueLocations = [];
            $uniqueAddresses = [];
            $uniqueContactNos = [];
            $uniqueEmail = [];
            $uniqueServiceStation = [];

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }


            foreach ($rows as $index => $row) {
                $stateName = trim($row['state']);
                if (isset($row['service_station_name']) && isset($row['state']) && isset($row['brand_name']) && isset($row['city'])) {
                    $service_station_name = trim($row['service_station_name']);
                    $state = trim($row['state']);
                    $brand_name = trim($row['brand_name']);
                    $city = trim($row['city']);

                    $service_station = $service_station_name . '_' . $state . '_' . $brand_name . '_' . $city;
                    if (in_array($service_station, $uniqueServiceStation)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'location')),
                            'message' => "Duplicate entry found for service station with same Brand and City within the sheet.",
                        ];
                    } else {
                        $uniqueServiceStation[] = $service_station;
                    }
                }
                // if (isset($row['location'])) {
                //     $location = trim($row['location']);
                //     if (in_array($location, $uniqueLocations)) {
                //         $this->validationErrors[] = [
                //             'row' => $index + 2,
                //             'field' => ucwords(str_replace('_', ' ', 'location')),
                //             'message' => "Duplicate entry found for Location within the Excel sheet.",
                //         ];
                //     } else {
                //         $uniqueLocations[] = $location;
                //     }
                // }

                // if (isset($row['address'])) {
                //     $address = trim($row['address']);
                //     if (in_array($address, $uniqueAddresses)) {
                //         $this->validationErrors[] = [
                //             'row' => $index + 2,
                //             'field' => ucwords(str_replace('_', ' ', 'address')),
                //             'message' => "Duplicate entry found for Address within the Excel sheet.",
                //         ];
                //     } else {
                //         $uniqueAddresses[] = $address;
                //     }
                // }

                // if (isset($row['contact_no'])) {
                //     $contactNo = trim($row['contact_no']);
                //     if (in_array($contactNo, $uniqueContactNos)) {
                //         $this->validationErrors[] = [
                //             'row' => $index + 2,
                //             'field' => ucwords(str_replace('_', ' ', 'contact_no')),
                //             'message' => "Duplicate entry found for Contact No. within the Excel sheet.",
                //         ];
                //     } else {
                //         $uniqueContactNos[] = $contactNo;
                //     }
                // }
                // if (isset($row['email'])) {
                //     $email = trim($row['email']);
                //     if (in_array($email, $uniqueEmail)) {
                //         $this->validationErrors[] = [
                //             'row' => $index + 2,
                //             'field' => ucwords(str_replace('_', ' ', 'email')),
                //             'message' => "Duplicate entry found for Email within the Excel sheet.",
                //         ];
                //     } else {
                //         $uniqueEmail[] = $email;
                //     }
                // }

                $brandId = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                $stateId = State::where('state_name', 'like', trim($row['state']))->first();
                $cityId = City::where('city_name', 'like', trim($row['city']))->first();

                $rules = [
                    'service_station_name' => 'required|min:2|max:50',
                    'state' => ['required', new ValidCity()],
                    'brand_name' => ['required', new ValidBrand()],
                    'city' => [new ValidCity($stateName)],
                    'address' => 'required|min:2|max:1000',
                    'location' => ['required', 'string', new GoogleMapsURL()],
                    'contact_no' => 'nullable',
                    'email' => 'nullable',
                ];
                if ($row['email'] !== null && $row['email'] !== "") {
                    $rules['email'] = 'email';
                }
                if ($row['contact_no'] !== null && $row['contact_no'] !== "") {
                    $rules['contact_no'] = 'numeric|digits:10';
                }
                $errorMessages = [
                    'state.required' => 'State is required.',
                    'state.exists' => 'State does not exists or disabled.',
                    'city.required' => 'City is required.',
                    'brand_name.required' => 'Brand is required.',
                    'brand_name.exists' => 'Brand does not exists or disabled.',
                    // 'email.required' => 'Email is required ',
                    'email.email' => 'Please enter a valid email address',
                    // 'email.unique' => 'This Email has already been taken.',
                    // 'contact_no.required' => 'The contact number is required.',
                    'contact_no.numeric' => 'The contact number must be a number.',
                    'contact_no.digits' => 'The contact number must be 10 digits.',
                    'contact_no.unique' => 'The contact number has already been taken by another service station.',
                    'address.required' => 'The service station address is required.',
                    'address.min' => 'The service station address  must be at least :min characters.',
                    'address.max' => 'The service station address  must not exceed :max characters.',
                    'address.unique' => 'The service station address has already been taken by another service station.',
                    'location.required' => 'The service station location address is required.',
                    'location.string' => 'The service station location must be a string.',
                    'location.custom' => 'The service station location is not a valid Google Maps URL.',
                    'location.unique' => 'The service station location has already been taken by another service station.',
                    's_station_name.required' => 'The service station name is required.',
                    // 's_station_name.regex' => 'The service station name must contain only letters, numbers, and spaces.',
                    's_station_name.min' => 'The service station name must be at least :min characters.',
                    's_station_name.max' => 'The service station name must not exceed :max characters.',
                ];

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);
                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {
                try {
                    $brandId = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                    $stateId = State::where('state_name', 'like', trim($row['state']))->first();
                    $cityId = City::where('city_name', 'like', trim($row['city']))->first();


                    DB::beginTransaction();

                    $service_station = ServiceStation::updateOrCreate(
                        [
                            's_station_name' => trim($row['service_station_name']),
                            'state_id' => $stateId->state_id,
                            'city_id' => $cityId->city_id,
                            'brand_id' => $brandId->brand_id,
                        ],
                        [
                            's_station_address' => trim($row['address']),
                            's_station_location' => trim($row['location']),

                            'contact_no' => trim($row['contact_no']),
                            'email' => trim($row['email']),

                            'created_by' => auth()->id()
                        ]
                    );
                    DB::commit();

                    $count++;
                    session()->flash('import_success', $count . ' data has been imported successfully.');
                } catch (Exception $e) {
                    DB::rollBack();

                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
