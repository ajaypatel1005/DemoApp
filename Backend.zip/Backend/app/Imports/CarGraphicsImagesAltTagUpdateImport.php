<?php

namespace App\Imports;

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\CarGraphic;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class CarGraphicsImagesAltTagUpdateImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            ini_set('max_execution_time', 300);

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {
                $rules = [
                    'brand_name' => 'required',
                    'model_name' => 'required',
                    'car_images_alt' => 'required',
                    'car_images_mobile_alt' => 'required',
                    'images_type' => 'required',
                ];
                $errorMessages = [
                    'brand_name.required' => 'Brand Name is required',
                    'model_name.required' => 'Model Name is required',
                    'car_images_alt.required' => 'Car Images alt tag required',
                    'car_images_mobile_alt.required' => 'Car Images for Mobile alt tag required',
                    'images_type.required' => 'Images Type is required.'
                ];

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }

                // to check that same entry exist in database or not
                $modelName = trim($row['model_name']);
                $imagesType = trim($row['images_type']);

                $carGraphicImages = CarGraphic::join('cop_gt_ms', 'cop_gt_ms.gt_id', '=', 'cop_graphics.gt_id')
                ->join('cop_models', 'cop_models.model_id', '=', 'cop_graphics.model_id')
                ->where('cop_models.model_name', $modelName)
                ->where('cop_gt_ms.gt_name', $imagesType)
                ->first();

                if (empty($carGraphicImages)) {
                    $this->validationErrors[] = [
                        'row' => $index + 2,
                        'field' => ucwords(str_replace('_', ' ', 'model_name')),
                        'message' => "$imagesType of $modelName is not exist in car graphics hence not able to update alt tag",
                    ];
                } else {
                    // count images and its alt tag
                    $car_images_count = count(explode(',', $carGraphicImages['graphic_file']));
                    $car_images_alt_count = count(explode(',', $row['car_images_alt']));

                    if ($car_images_count !== $car_images_alt_count) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'car_images_alt')),
                            'message' => "Images of $modelName - $imagesType are '" . $car_images_count . "' but Entered images Alt tags are '" . $car_images_alt_count . "', the count should be same",
                        ];
                    }

                    // count mobile images and its alt tag
                    $car_images_mob_count = count(explode(',', $carGraphicImages['graphic_file_mob']));
                    $car_images_mob_alt_count = count(explode(',', $row['car_images_mobile_alt']));

                    if ($car_images_mob_count !== $car_images_mob_alt_count) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'car_images_mobile_alt')),
                            'message' => "Images of $modelName - $imagesType are '" . $car_images_mob_count . "' but Entered mobile images Alt tags are '" . $car_images_mob_alt_count . "', the count should be same",
                        ];
                    }

                    // check that any black alt tag inputed for desktop or not
                    $desktop_img_array = explode(',', $row['car_images_alt']);
                    $trimmedArrayDesk = array_map('trim', $desktop_img_array);
                    $filteredArrayDesk = array_filter($trimmedArrayDesk, function ($value) {
                        return $value === '';
                    });
                    if (!empty($filteredArrayDesk)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'car_images_alt')),
                            'message' => "Blank alt tags are not allowed",
                        ];
                    }

                    // check that any black alt tag inputed for mobile or not
                    $mobile_img_array = explode(',', $row['car_images_mobile_alt']);
                    $trimmedArrayMob = array_map('trim', $mobile_img_array);
                    $filteredArrayMob = array_filter($trimmedArrayMob, function ($value) {
                        return $value === '';
                    });
                    if (!empty($filteredArrayMob)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'car_images_mobile_alt')),
                            'message' => "Blank alt tags are not allowed",
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong');
        }

        if (empty($this->validationErrors)) {
            $count = 0;

            foreach ($rows as $index => $row) {
                try {
                    $modelName = trim($row['model_name']);
                    $imagesType = trim($row['images_type']);

                    $car_graphic_images_alt_tags = CarGraphic::join('cop_gt_ms', 'cop_gt_ms.gt_id', '=', 'cop_graphics.gt_id')
                    ->join('cop_models', 'cop_models.model_id', '=', 'cop_graphics.model_id')
                    ->where('cop_models.model_name', $modelName)
                    ->where('cop_gt_ms.gt_name', $imagesType)
                    ->first();

                    $all_images_alt = preg_replace('/\s*,\s*/', ',', $row['car_images_alt']);
                    $all_images_mob_alt = preg_replace('/\s*,\s*/', ',', $row['car_images_mobile_alt']);

                    DB::beginTransaction();
                    $car_graphic_images_alt_tags->update(
                        [
                            'graphic_file_alt' => $all_images_alt,
                            'graphic_file_mob_alt' => $all_images_mob_alt,
                            'updated_by' => auth()->id()
                        ]
                    );

                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count . ' data has been imported/updated successfully.');
                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
