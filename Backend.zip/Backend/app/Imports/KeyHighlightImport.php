<?php

namespace App\Imports;

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Rules\ValidImagePath;
use App\Models\Variant;
use App\Models\Color;
use App\Models\Brand;
use App\Models\Feature;
use App\Models\FeatureValue;
use App\Models\Model;
use App\Rules\ValidBrand;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;

class KeyHighlightImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {

        try{
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }


            foreach ($rows as $index => $row) {

                $brandName = trim($row['brand_name']);
                $modelName = trim($row['model_name']);
                $validator=Validator::make($row->toArray(), [
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => ['required', new ValidBrand($brandName) ],
                    'variant_name' => ['required',new ValidBrand($brandName,$modelName)],
                    'feature_name' => 'required',
                ]);
                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }


        if (empty($this->validationErrors)) {
        $count=0;
        foreach ($rows as $index => $row) {

            try {
                $brand_id = Brand::where('brand_name','like', trim($row['brand_name']))->first();
                $brand_id = $brand_id->brand_id;
                $model_id = Model::where('model_name','like', trim($row['model_name']))->where('brand_id', $brand_id)->first();
                $model_id = $model_id->model_id;
                $variant_id = Variant::where('variant_name','like', trim($row['variant_name']))->where('brand_id', $brand_id)->where('model_id', $model_id)->first();
                $feature_id = Feature::where('features_name','like', trim($row['feature_name']))->first();

                $variant_id = $variant_id->variant_id;
                $feature_id = $feature_id->feature_id;


                DB::beginTransaction();
                $key_highlight = FeatureValue::where([
                    'brand_id' => $brand_id,
                    'model_id' => $model_id,
                    'variant_id' => $variant_id,
                    'feature_id'=>$feature_id
                ])->first();

                if ($key_highlight) {
                    $key_highlight->key_highlight = 1;
                    $key_highlight->update();
                }



                DB::commit();
                $count++;
                session()->flash('import_success', $count.' data has been imported successfully.');

            } catch (Exception $e) {
                DB::rollBack();

                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                session()->flash('import_error', $e->getMessage());
            }
        }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}

