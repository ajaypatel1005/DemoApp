<?php

namespace App\Imports;

use App\Models\Brand;
use App\Models\City;
use App\Models\Model;
use App\Models\SEO\MetaTag;
use App\Models\SEO\Page;
use App\Models\SEO\Seo;
use App\Models\State;
use App\Models\Variant;
use App\Rules\ValidBrand;
use Exception;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class SeoImport implements ToCollection, WithHeadingRow
{
    /**
    * @param Collection $collection
    */
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach($rows as $index => $row) {
                $brandName = trim($row['brand_name']);
                $modelName = '';
                $rules = [
                    'brand_name' => ['required', new ValidBrand()],
                    'meta_title' => 'required',
                    'meta_description' => 'required'
                ];

                $errorMessages = [
                    'brand_name.required' => 'Brand name is required',
                    'meta_title.required' => 'Meta Title is required',
                    'meta_description.required' => 'Meta Description is required'
                ];

                
                if($row['model_name']){
                    $modelName = trim($row['model_name']);
                    $rules['model_name'] = ['required',new ValidBrand($brandName)];
                    $errorMessages['model_name.required'] = 'Model name is required';
                }
                if($row['variant_name']){
                    $rules['variant_name'] = ['required',new ValidBrand($brandName, $modelName)];
                    $errorMessages['variant_name.required'] = 'Variant name is required';
                }

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);
                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {
                try {
                    $brand_id = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                    $seoTitleTag = MetaTag::where('meta_tag_name','=',config('constant.SEO_TAG.META_TITLE'))->where('status',1)->first();
                    $seoDescriptionTag = MetaTag::where('meta_tag_name','=',config('constant.SEO_TAG.META_DESCRIPTION'))->where('status',1)->first();
                    $seoOgTitleTag = MetaTag::where('meta_tag_name','=',config('constant.SEO_TAG.OG_TITLE'))->where('status',1)->first();
                    $seoOgDescriptionTag = MetaTag::where('meta_tag_name','=',config('constant.SEO_TAG.OG_DESCRIPTION'))->where('status',1)->first();

                    DB::beginTransaction();

                    if($row['brand_name'] && !$row['model_name'] && !$row['variant_name']){
                        $seoPage = Page::where('page_name','=',config('constant.SEO_PAGE.ALL_BRANDS'))->where('status',1)->first();
                        $seoType = config('constant.SEO_TYPE.BRAND_TYPE');

                        if($row['meta_title']){
                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoTitleTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_title'],
                                'status' => 1
                            ]);

                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoOgTitleTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_title'],
                                'status' => 1
                            ]);
                        }

                        if($row['meta_description']){
                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoDescriptionTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_description'],
                                'status' => 1
                            ]);

                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoOgDescriptionTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_description'],
                                'status' => 1
                            ]);
                        }
                    } else if ($row['brand_name'] && $row['model_name'] && !$row['variant_name']){
                        $model_id = Model::where('model_name', 'like', trim($row['model_name']))->where('brand_id', $brand_id->brand_id)->first();
                        $seoPage = Page::where('page_name','=',config('constant.SEO_PAGE.CAR_MODULE'))->where('status',1)->first();
                        $seoType = config('constant.SEO_TYPE.MODEL_TYPE');

                        if($row['meta_title']){
                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'model_id' => $model_id->model_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoTitleTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_title'],
                                'status' => 1
                            ]);

                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'model_id' => $model_id->model_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoOgTitleTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_title'],
                                'status' => 1
                            ]);
                        }

                        if($row['meta_description']){
                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'model_id' => $model_id->model_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoDescriptionTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_description'],
                                'status' => 1
                            ]);

                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'model_id' => $model_id->model_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoOgDescriptionTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_description'],
                                'status' => 1
                            ]);
                        }
                    } else if ($row['brand_name'] && $row['model_name'] && $row['variant_name']){
                        $model_id = Model::where('model_name', 'like', trim($row['model_name']))->where('brand_id', $brand_id->brand_id)->first();
                        $variant_id = Variant::where('variant_name', 'like', trim($row['variant_name']))->where('brand_id', $brand_id->brand_id)->where('model_id', $model_id->model_id)->first();
                        $seoPage = Page::where('page_name','=',config('constant.SEO_PAGE.CAR_MODULE'))->where('status',1)->first();
                        $seoType = config('constant.SEO_TYPE.VARIANT_TYPE');

                        if($row['meta_title']){
                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'model_id' => $model_id->model_id,
                                'variant_id' => $variant_id->variant_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoTitleTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_title'],
                                'status' => 1
                            ]);

                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'model_id' => $model_id->model_id,
                                'variant_id' => $variant_id->variant_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoOgTitleTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_title'],
                                'status' => 1
                            ]);
                        }

                        if($row['meta_description']){
                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'model_id' => $model_id->model_id,
                                'variant_id' => $variant_id->variant_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoDescriptionTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_description'],
                                'status' => 1
                            ]);

                            Seo::updateOrCreate([
                                'brand_id' => $brand_id->brand_id,
                                'model_id' => $model_id->model_id,
                                'variant_id' => $variant_id->variant_id,
                                'page_id' => $seoPage->page_id,
                                'meta_tag_id' => $seoOgDescriptionTag->meta_tag_id,
                                'seo_type' => $seoType
                            ],[
                                'tag_content' => $row['meta_description'],
                                'status' => 1
                            ]);
                        }
                    }

                    DB::commit();

                    $count++;
                    session()->flash('import_success', $count . ' data has been imported successfully.');
                } catch (Exception $e) {
                    DB::rollBack();

                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
