<?php

namespace App\Imports;

use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Rules\ValidImagePath;
use App\Models\Brand;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class BrandImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            // dd($rows);
            foreach ($rows as $index => $row) {
                $rules = [
                    'brand_name' => 'required|unique:cop_brands_ms,brand_name|min:2|max:25',
                    'brand_description' => 'required|min:2|max:1000',
                    'brand_banner' => ['required', new ValidImagePath()],
                    'brand_logo' => ['required', new ValidImagePath()],
                ];

                $errorMessages = [
                    'brand_name.required' => 'Brand Name is required',
                    'brand_name.unique' => 'Brand Name should be unique',
                    'brand_name.min' => 'Brand Name must be at least :min characters.',
                    'brand_name.max' => 'Brand Name must not exceed :max characters.',

                    'brand_description.required' => 'Brand Descriptin is required',
                    'brand_description.min' => 'Brand Descriptin must be at least :min characters.',
                    'brand_description.max' => 'Brand Descriptin must not exceed :max characters.',

                    'brand_banner.required' => 'Brand Banner is required',

                    'brand_logo.required' => 'Brand Logo is required.',
                ];

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            $manager = new ImageManager(new Driver());
            foreach ($rows as $index => $row) {
                try {
                    DB::beginTransaction();
                    $brand = Brand::create(
                        [
                            'brand_name' => trim($row['brand_name']),
                            'slug' => DB::raw("LOWER(REPLACE(brand_name, ' ', '-'))"),
                            'brand_description' => trim($row['brand_description']),
                            'created_by' => auth()->id()
                        ]
                    );

                    $brandBucketFolder = 'brands/' . $brand->brand_id . '/';

                    $brand_banner = trim($row['brand_banner']);
                    $webpImageNameBanner = $brand->brand_id . '_banner.webp';
                    $urlImage = @file_get_contents($brand_banner);
                    if ($urlImage === false) {
                    } else {
                        $image = $manager->read($urlImage);
                        Storage::disk('digitalocean')->put($brandBucketFolder . $webpImageNameBanner, $image->toWebp(), 'public');
                        // Thumbnail image
                        $image->resize(1920, 724);
                        Storage::disk('digitalocean')->put($brandBucketFolder .'thumb/'. $webpImageNameBanner, $image->toWebp(), 'public');
                    }
                    // Update Brand with Banner
                    $brand->update(['brand_banner' => $webpImageNameBanner]);

                    // Upload Brand Logo
                    $brand_logo = trim($row['brand_logo']);
                    $webpImageNameLogo = $brand->brand_id . '.webp';
                    $urlImage = @file_get_contents($brand_logo);
                    if ($urlImage === false) {
                    } else {
                        $image = $manager->read($urlImage);
                        Storage::disk('digitalocean')->put($brandBucketFolder . $webpImageNameLogo, $image->toWebp(), 'public');

                        //thumb
                        $image->resize(300, 200);
                        Storage::disk('digitalocean')->put($brandBucketFolder .'thumb/'. $webpImageNameLogo, $image->toWebp(), 'public');
                    }

                    // Update Brand with Logo
                    $brand->update(['brand_logo' => $webpImageNameLogo]);
                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count . ' data has been imported successfully.');
                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
