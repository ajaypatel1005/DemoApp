<?php

namespace App\Imports;

use App\Models\Brand;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\Model as CarModel;
use App\Models\ModelDescription;
use App\Models\ModelSafety;
use App\Rules\ValidBrand;
use App\Rules\ValidImagePath;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use Illuminate\Support\Facades\Storage;


class ModelSafetyImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {

                // Trim input values to ensure clean data
                $brandName = $row['brand_name'];
                $modelName = $row['model_name'];
                $heading = $row['heading'];
                $desc = $row['description'];
                $img = $row['image'];
                // dd(  $brandName ,  $modelName , $heading , $desc  , $img );
                // Define validation rules for each field
                // $rules = [
                //     'brand_name' => ['required', 'string', 'max:255', new ValidBrand()],
                //     'model_name' => ['required', 'string', 'max:255', new ValidBrand($brandName)],
                //     'heading' => ['required', 'string', 'min:1', 'max:1000'],
                //     'description' => ['required', 'string', 'min:1', 'max:1000'],
                //     'image' => ['required', new ValidImagePath()],
                // ];

                // Define custom error messages for each field
                // $errorMessages = [
                //     'brand_name.required' => 'The brand name is required.',
                //     'brand_name.string' => 'The brand name must be a valid string.',
                //     'brand_name.max' => 'The brand name cannot exceed 255 characters.',
                //     'model_name.required' => 'The model name is required.',
                //     'model_name.string' => 'The model name must be a valid string.',
                //     'model_name.max' => 'The model name cannot exceed 255 characters.',
                //     'heading.required' => 'The heading is required.',
                //     'heading.string' => 'The heading must be a valid string.',
                //     'heading.min' => 'The heading must be at least 1 character.',
                //     'heading.max' => 'The heading cannot exceed 1000 characters.',
                //     'description.required' => 'The description is required.',
                //     'description.string' => 'The description must be a valid string.',
                //     'description.min' => 'The description must be at least 1 character.',
                //     'description.max' => 'The description cannot exceed 1000 characters.',
                //     'image.required' => 'The image is required.',
                //     'image.image' => 'The image must be a valid image file.',
                //     'image.valid_image_path' => 'The image path is invalid.',
                // ];


                // // Validate the row data
                // $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                // // If validation fails, add the errors to the validationErrors array
                // if ($validator->fails()) {
                //     $validationErrors = $validator->errors()->toArray();

                //     foreach ($validationErrors as $field => $messages) {
                //         $this->validationErrors[] = [
                //             'row' => $index + 2, // Adjust row number to start from 1-based index
                //             'field' => ucwords(str_replace('_', ' ', $field)),
                //             'message' => implode(', ', $messages),
                //         ];
                //     }
                // }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            $manager = new ImageManager(new Driver());
            foreach ($rows as $index => $row) {

                try {
                    // Fetch brand and model
                    $brand = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                    if (!$brand) {
                        throw new Exception("Brand not found for {$row['model_name']}");
                    }
                    $brand_id = $brand->brand_id;
                
                    $model = CarModel::where('model_name', 'like', trim($row['model_name']))
                        ->where('brand_id', $brand_id)
                        ->first();
                    if (!$model) {
                        throw new Exception("Model not found for {$row['model_name']} under brand {$row['brand_name']}");
                    }
                    $model_id = $model->model_id;
                    $heading = isset($row['heading']) ? trim($row['heading']) : '';
                    $desc = isset($row['description']) ? trim($row['description']) : '';
                    $img = isset($row['image']) ? trim($row['image']) : '';
                
                    DB::beginTransaction();
                    $safetyBucketFolder = 'model_safety/' . $brand->brand_id . '/' . $model->model_id . '/';
                
                    $image = $row['image'];
                    $webpImageNameLogo = $model->model_id . '_' . time() . '.webp';
                
                    // Debug: Check if image URL is valid
                    Log::info("Attempting to fetch image from URL: {$image}");
                
                    // Try to get the image content
                    $urlImage = @file_get_contents($image);
                    if ($urlImage === false) {
                        Log::error("Failed to fetch image from URL: {$image}");
                        throw new Exception("Unable to fetch image from {$image}");
                    } else {
                        Log::info("Image fetched successfully from URL: {$image}");
                    }
                
                    // Check if image is being processed correctly
                    try {
                        $image = $manager->read($urlImage);
                        Log::info("Image processing successful.");
                    } catch (Exception $e) {
                        Log::error("Failed to process image. Error: {$e->getMessage()}");
                        throw $e;
                    }
                
                    // Store image on DigitalOcean
                    try {
                        $storagePath = $safetyBucketFolder . $webpImageNameLogo;
                        Storage::disk('digitalocean')->put($storagePath, $image->toWebp(), 'public');
                        Log::info("Image stored successfully on DigitalOcean at: {$storagePath}");
                    } catch (Exception $e) {
                        Log::error("Failed to store image on DigitalOcean. Error: {$e->getMessage()}");
                        throw $e;
                    }
                
                    // Update the database record
                    ModelSafety::updateOrCreate(
                        [
                            'brand_id' => $brand_id,
                            'model_id' => $model_id,
                            'heading' => $heading,
                            'description' => $desc,
                            'image' => $webpImageNameLogo,
                        ],
                        [
                            'status' => 1,
                            'created_by' => auth()->id()
                        ]
                    );
                
                    // Commit transaction
                    DB::commit();
                    $count++;
                } catch (Exception $e) {
                    DB::rollBack();
                    // Log detailed error message for debugging
                    Log::emergency("File: {$e->getFile()} LN No: {$e->getLine()} Msg: {$e->getMessage()}");
                    session()->flash('import_error', 'Error occurred: ' . $e->getMessage());
                }
                
            }

            // Provide feedback
            if ($count > 0) {
                session()->flash('import_success', "{$count} data has been imported successfully.");
            } else {
                session()->flash('import_error', 'No data was imported.');
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
