<?php

namespace App\Imports;

use App\Models\Brand;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\Model as CarModel;
use App\Models\ModelDescription;
use App\Models\Variant;
use App\Rules\ValidBrand;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;

class ModelDescImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {
            
                // Trim input values to ensure clean data
                $brandName = $row['brand_name'];
                $modelName = $row['model_name'];
                $variantName = $row->has('variant_name') ? trim($row->get('variant_name')) : null;
                
                $desc = $row['description'];
                $like = $row['things_we_like'];
                $unlike = $row['can_be_better'];

                // Define validation rules for each field
                $rules = [
                    'brand_name' => ['required', 'string', 'max:255', new ValidBrand()],
                    'model_name' => ['required', 'max:255', new ValidBrand($brandName)],
                    'description' => ['required', 'string', 'min:1', 'max:1000'],
                    'things_we_like' => ['nullable', 'string', 'max:1000'],
                    'can_be_better' => ['nullable', 'string', 'max:1000'],
                ];
                
                if($variantName){
                    
                    $rules['variant_name'] = ['required',new ValidBrand($brandName, $modelName)];
                    $errorMessages['variant_name.required'] = 'Variant name is required';
                }

              

                // Define custom error messages for each field
                $errorMessages = [
                    'brand_name.required' => 'The brand name is required.',
                    'brand_name.string' => 'The brand name must be a valid string.',
                    'brand_name.max' => 'The brand name cannot exceed 255 characters.',
                    'model_name.required' => 'The model name is required.',
                    // 'model_name.string' => 'The model name must be a valid string.',
                    'model_name.max' => 'The model name cannot exceed 255 characters.',
                    'description.required' => 'The description is required.',
                    'description.string' => 'The description must be a valid string.',
                    'description.min' => 'The description must be at least 1 character.',
                    'description.max' => 'The description cannot exceed 1000 characters.',
                    // 'things_we_like.required' => 'The "Things we like" field is required.',
                    'things_we_like.string' => 'The "Things we like" field must be a valid string.',
                    'things_we_like.max' => 'The "Things we like" field cannot exceed 1000 characters.',
                    // 'can_be_better.required' => 'The "Can be better" field is required.',
                    'can_be_better.string' => 'The "Can be better" field must be a valid string.',
                    'can_be_better.max' => 'The "Can be better" field cannot exceed 1000 characters.',
                ];
                

                // Validate the row data
                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                // If validation fails, add the errors to the validationErrors array
                if ($validator->fails()) {
                    $validationErrors = $validator->errors()->toArray();

                    foreach ($validationErrors as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {
      
                try {
                    // Fetch brand and model
                    $brand = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                    if (!$brand) {
                        throw new Exception("Brand not found for {$row['model_name']}");
                    }
                    $brand_id = $brand->brand_id;

                    $model = CarModel::where('model_name', 'like', trim($row['model_name']))
                        ->where('brand_id', $brand_id)
                        ->first();
                    if (!$model) {
                        throw new Exception("Model not found for {$row['model_name']} under brand {$row['brand_name']}");
                    }
                    $model_id = $model->model_id;
                    $desc = isset($row['description']) ? trim($row['description']) : '';
                    $like = isset($row['things_we_like']) ? trim($row['things_we_like']) : '';
                    $unlike = isset($row['can_be_better']) ? trim($row['can_be_better']) : '';

                    // Begin DB transaction
                    DB::beginTransaction();
                    
                    $variantName = $row->has('variant_name') ? trim($row->get('variant_name')) : null;

                    

                    if ($brand_id && $model_id && empty($variantName)) {
                    // Update or create ModelDescription
                    // dd("hello");
                    $data =  ModelDescription::updateOrCreate(
                        [
                            'brand_id' => $brand_id,
                            'model_id' => $model_id,
                            'variant_id' => null
                        ],
                        [
                            'brand_id' => $brand_id,
                            'model_id' => $model_id,
                            'description' => $desc,
                            'thing_like' => $like,
                            'thing_improve' => $unlike,
                            'status' => 1,
                            'created_by' => auth()->id()
                            ]
                        );
                    }
                    else
                    {
                        // Begin:: if variant exist in excel sheet
                        $variantData = Variant::where('variant_name', 'like', trim($row['variant_name']))->where('brand_id', $brand_id)->where('model_id', $model_id)->first();
                        
                        if (!$variantData) {
                            throw new Exception("Variant not found for '{$row['variant_name']}' under model '{$row['model_name']}' and brand '{$row['brand_name']}'");
                        };
                      
                        $data =  ModelDescription::updateOrCreate(
                            [
                                'brand_id' => $brand_id,
                                'model_id' => $model_id,
                                'variant_id' => $variantData->variant_id
                            ],
                            [
                                'brand_id' => $brand_id,
                                'model_id' => $model_id,
                                'variant_id' => $variantData->variant_id,
                                'description' => $desc,
                                'thing_like' => $like,
                                'thing_improve' => $unlike,
                                'status' => 1,
                                'created_by' => auth()->id()
                                ]
                            );
                        // End:: if variant exist in excel sheet
                            
                    }
                    // Commit transaction
                    DB::commit();
                    $count++;
                } catch (Exception $e) {
                    // Rollback in case of error
                    DB::rollBack();
                    Log::emergency("File: {$e->getFile()} LN No: {$e->getLine()} Msg: {$e->getMessage()}");
                    session()->flash('import_error', 'Error occurred: ' . $e->getMessage());
                }
            }

            // Provide feedback
            if ($count > 0) {
                session()->flash('import_success', "{$count} data has been imported successfully.");
            } else {
                session()->flash('import_error', 'No data was imported.');
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
