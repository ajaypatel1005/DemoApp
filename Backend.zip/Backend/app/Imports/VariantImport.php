<?php

namespace App\Imports;

use Exception;
use Illuminate\Support\Facades\Log;
use App\Rules\ValidImagePath;
use App\Rules\ValidModelVariantUnique;

use App\Models\Variant;
use Illuminate\Support\Facades\DB;
use App\Models\Brand;
use App\Models\Model;
use App\Rules\ValidBrand;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class VariantImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            $uniqueModel = [];

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {

                if (isset($row['variant_name'])) {
                    $variant_name = trim($row['variant_name']);
                    $model_name = trim($row['model_name']);
                    if (in_array($model_name . '' . $variant_name, $uniqueModel)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'model_name')),
                            'message' => "Duplicate entry found for same Model and Variant Name within the Excel sheet.",
                        ];
                    } else {
                        $uniqueModel[] = $model_name . '' . $variant_name;
                    }
                }

                $brandName = trim($row['brand_name']);
                $modelName = trim($row['model_name']);
                $rules = [
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => ['required', new ValidBrand($brandName)],
                    'variant_name' => ['required', 'min:2', new ValidModelVariantUnique($modelName)],
                    'variant_image' => ['required', new ValidImagePath()],
                    'variant_image_mob' => ['required', new ValidImagePath()],
                    'seating_capacity' => 'required|numeric|between:2,13',
                ];

                $errorMessages = [
                    'brand_name.required' => 'The brand name is required.',
                    'brand_name.exists' => 'The brand name does not exist or disabled.',

                    'model_name.required' => 'The model name is required.',

                    'variant_name.required' => 'The variant name is required.',
                    'variant_name.min' => 'The variant name must be at least :min characters.',

                    'variant_image.required' => 'The variant image is required.',
                    'variant_image_mob.required' => 'The variant image is required.',

                    'seating_capacity.required' => 'The seating capacity is required.',
                    'seating_capacity.numeric' => 'The seating capacity must be a number.',
                ];

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }



        if (empty($this->validationErrors)) {
            $count = 0;
            $manager = new ImageManager(new Driver());
            foreach ($rows as $index => $row) {
                try {

                    $brand_id = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                    $brand_id = $brand_id->brand_id;
                    $model_id = Model::where('model_name', 'like', trim($row['model_name']))->where('brand_id', $brand_id)->first();
                    $model_id = $model_id->model_id;
                    DB::beginTransaction();
                    $variant = Variant::updateOrCreate(
                        [
                            'brand_id' => $brand_id,
                            'model_id' => $model_id,
                            'variant_name' => trim($row['variant_name']),
                        ],
                        [
                            'seating_capacity' => trim($row['seating_capacity']),
                            'slug' => DB::raw("LOWER(REGEXP_REPLACE(LOWER(REPLACE(REPLACE(variant_name, ' ', '-'), '+', 'plus')), '[^a-zA-Z0-9-]+', ''))"),
                            'created_by' => auth()->id()
                        ]
                    );


                    $variant_image = trim($row['variant_image']);
                    $webpImageName = $variant->variant_id . '.webp';
                    $urlImage = @file_get_contents($variant_image);
                    $bucketFolder = 'brands/' . $brand_id . '/' . $model_id . '/' . $variant->variant_id . '/';
                    if ($urlImage === false) {
                    } else {
                        $image = $manager->read($urlImage);
                        Storage::disk('digitalocean')->put($bucketFolder . $webpImageName, $image->toWebp(), 'public');
                        // Thumbnail image

                        $image->resize(216, 102);
                        Storage::disk('digitalocean')->put($bucketFolder . 'thumb/' . $webpImageName, $image->toWebp(), 'public');
                    }
                    $variant->update(['variant_image' => $webpImageName]);


                    $variant_image_mob = trim($row['variant_image_mob']);
                    $webpImageNameMob = $variant->variant_id . '_mob' . '.webp';
                    $urlImageMob = @file_get_contents($variant_image_mob);
                    if ($urlImageMob === false) {
                    } else {
                        $imageMob = $manager->read($urlImageMob);
                        Storage::disk('digitalocean')->put($bucketFolder . $webpImageNameMob, $imageMob->toWebp(), 'public');

                    }
                    $variant->update(['variant_image_mob' => $webpImageNameMob]);

                    // Update Brand with Banner
                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count . ' data has been imported successfully.');
                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', $e->getMessage());
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
