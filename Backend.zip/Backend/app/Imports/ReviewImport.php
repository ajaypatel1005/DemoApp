<?php

namespace App\Imports;

use Exception;
use Illuminate\Support\Facades\Log;
use App\Rules\ValidImagePath;
use App\Rules\ValidModelVariantUnique;

use App\Models\Variant;
use Illuminate\Support\Facades\DB;
use App\Models\Brand;
use App\Models\Customer;
use App\Models\Model;
use App\Models\RatingType;
use App\Models\Review;
use App\Rules\ValidBrand;
use App\Rules\ValidCustomer;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class ReviewImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            $uniqueModel = [];

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {


                // if (isset($row['last_name'])) {   
                //     $last_name = trim($row['last_name']);
                //     $first_name = trim($row['first_name']);
                //     if (in_array($first_name . '' . $last_name, $uniqueModel)) {
                //         $this->validationErrors[] = [
                //             'row' => $index + 2,
                //             'field' => ucwords(str_replace('_', ' ', 'first_name')),
                //             'message' => "Duplicate entry found for same Name within the Excel sheet.",
                //         ];
                //     } else {
                //         $uniqueModel[] = $first_name . '' . $last_name;
                //     }
                // }
                // $firstName = trim($row['first_name']);
                $brandName = trim($row['brand_name']);
                $modelName = trim($row['model_name']);
                $rules = [
                    // 'first_name'=>['required'],
                    // 'last_name'=>['required',new ValidCustomer($firstName)],
                    // 'brand_name' => ['required', new ValidBrand()],
                    // 'model_name' => ['required', new ValidBrand($brandName)],
                    // 'rating' => ['required', 'numeric', 'min:1', 'max:5'],
                    // 'review' => ['required'],
                ];

                $errorMessages = [
                    // 'first_name.required' => 'The first name is required.',
                    // 'last_name.required' => 'The last name is required.',
                    // 'brand_name.required' => 'The brand name is required.',
                    // 'brand_name.exists' => 'The brand name does not exist or disabled.',
                    // 'model_name.required' => 'The model name is required.',
                    // 'review.required' => 'The review is required.',
                    // 'rating.required' => 'The rating is required.',
                    // 'rating.numeric' => 'The rating must be a number.',
                    // 'rating.min' => 'The rating must be greater than or equal to 1.',
                    // 'rating.max' => 'The rating must be less than or equal to 5.',


                ];

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }


        // dd(empty($this->validationErrors));

        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {
                try {

                    // dd($row);
                    // dd($row['looks']);
                    // $customer_id = Customer::where('first_name', 'like', trim($row['first_name']))->where('last_name', trim($row['last_name']))->first();
                    // $customer_id = $customer_id->customer_id;
                    $brand_id = Brand::where('brand_name', 'like', trim($row['brand_name']))->first();
                    $brand_id = $brand_id->brand_id;
                    
                    $model_id = Model::where('model_name', 'like', trim($row['model_name']))->where('brand_id', $brand_id)->first();
                    $model_id = $model_id->model_id;
                    // $rating = $row['rating'];
                    // dd($model_id);


                    $ratingFields = [
                        'Looks' => $row['looks'],
                        'Performance' => $row['performance'],
                        'Comfort' => $row['comfort'],
                        'Efficiency' => $row['efficiency'],
                        'Safety' => $row['safety']
                    ];
                    
                    // Initialize an array to store the rating data
                    $ratings = [];
                    
                    foreach ($ratingFields as $ratingName => $ratingValue) {
                       
                        $ratingType=RatingType::where('rating_type_name',$ratingName)->first();
              
                        if ($ratingType) {
                            $ratings[(int) $ratingType->rating_type_id] = (int) trim($ratingValue);
                        }
                    }

                    $jsonRatings = json_encode($ratings);

                 
                    DB::beginTransaction();
                    $review = Review::updateOrCreate(
                        [
                           
                            'brand_id' => $brand_id,
                            'model_id' => $model_id,
                        ],
                        [
                            'rating' => $jsonRatings,
                            'review' => trim($row['review']),
                            'created_by'=>1,
                            'status' => 1
                        ]
                    );
                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count . ' data has been imported successfully.');
                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', $e->getMessage());
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
