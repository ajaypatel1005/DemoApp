<?php

namespace App\Imports;

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Rules\ValidImagePath;

use App\Models\Feature;
use App\Models\FeatureOption;
use App\Models\Specification;
use App\Models\StandardUnit;
// use Carbon\Carbon;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
// use Illuminate\Validation\ValidationException;

class FeaturesImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try{
            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }
        
            
            foreach ($rows as $index => $row) {

                $rules = [
                    'fuel_type' => 'required',
                    'spec_name' => 'required',
                    'feature_option' => 'required',
                    'feature_name' => 'required',
                    // 'feature_image'=>[new ValidImagePath()],
                ];

                $validator = Validator::make($row->toArray(), $rules);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong.');
        }

        

        if (empty($this->validationErrors)) {
            $count = 0;
            foreach ($rows as $index => $row) {
                try {

                    if ($row['fuel_type'] == 'Non-EV') {
                        $fuelType = 0;
                    } else if ($row['fuel_type'] == 'EV') {
                        $fuelType = 1;
                    } else {
                        $fuelType =2;
                    }
                    $specId = Specification::where('spec_name', $row['spec_name'])->first();
                    $featureOptionId = FeatureOption::where('fo_value', $row['feature_option'])->first();

                    if ($row['standard_unit'] != "") {
                        $standardUnit = StandardUnit::where('su_name', $row['standard_unit'])->first();
                        $standardUnitId = $standardUnit->su_id;
                    } else {
                        $standardUnitId = null;
                    }

                    DB::beginTransaction();
                    $features = Feature::updateOrCreate(
                        [
                            'fuel_type' => $fuelType,
                            'features_name' => $row['feature_name'],
                        ],
                        [
                            'spec_id' => $specId->spec_id,
                            'fo_id' => $featureOptionId->fo_id,
                            'su_id' => $standardUnitId,
                        ]
                    );
                    if (!empty($row['feature_image'])) {

                        // Upload Image
                        if (!File::isDirectory(public_path('Feature'))) {
                            File::makeDirectory(public_path('Feature'));
                        }
                        if (!File::isDirectory(public_path('Feature') . '/' . $features->feature_id)) {
                            File::makeDirectory(public_path('Feature') . '/' . $features->feature_id);
                        }

                        $feature_image = $row['feature_image'];
                        $webpImageNameFeatures = $features->feature_id . '.webp';
                        $features_image_path = public_path('Feature') . '/' . $features->feature_id . '/' . $webpImageNameFeatures;
                        File::copy($feature_image, $features_image_path);

                        $features->update(['features_image' => $webpImageNameFeatures]);
                    }


                    DB::commit();
                    session()->flash('import_success', 'Import Successfully.');
                } catch (Exception $e) {
                    DB::rollBack();
                    
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                    // dd("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}
