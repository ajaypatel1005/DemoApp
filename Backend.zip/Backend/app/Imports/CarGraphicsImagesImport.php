<?php

namespace App\Imports;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Rules\ValidateArrayImage;
use App\Rules\ValidBrand;

use App\Models\Model;
use App\Models\CarGraphicType;
use App\Models\Brand;
use App\Models\CarGraphic;
// use Carbon\Carbon;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
// use Illuminate\Validation\ValidationException;

use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class CarGraphicsImagesImport implements ToCollection, WithHeadingRow
{
    private $validationErrors = [];

    public function collection(Collection $rows)
    {
        try {
            ini_set('max_execution_time', 300);

            $uniqueModel = [];

            if (count($rows) === 0) {
                $this->validationErrors[] = [
                    'row' => 'All',
                    'field' => 'All',
                    'message' => 'Import Error - The Excel file appears to be empty. Make sure there is valid data in the file and try again.',
                ];
            }

            foreach ($rows as $index => $row) {

                // To check that same entry found in exale sheet or not
                if (isset($row['model_name'])) {
                    $model_name = trim($row['model_name']).''.trim($row['images_type']);
                    if (in_array($model_name, $uniqueModel)) {
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'model_name')),
                            'message' => "Duplicate entry found for same Model Name & Image Type within the Excel sheet.",
                        ];
                    } else {
                        $uniqueModel[] = $model_name;
                    }
                }

                $brandName = trim($row['brand_name']);
                $imagesType = trim($row['images_type']);

                $rules = [
                    'brand_name' => ['required', new ValidBrand()],
                    'model_name' => ['required', new ValidBrand($brandName)],
                    'car_images' => ['required', new ValidateArrayImage()],
                    'car_images_alt' => 'nullable',
                    'car_images_mobile' => ['required', new ValidateArrayImage()],
                    'car_images_mobile_alt' => 'nullable',
                    'images_type' => 'required',
                ];
                $errorMessages = [
                    'brand_name.required'=> 'Brand Name is required',
                    'brand_name.exists'=> 'Brand Name does not exist or disabled',

                    'model_name.required'=>'Model Name is required',

                    'car_images.required' => 'Car Images are required.',
                    // 'car_images_alt.required' => 'Car Images alt tag required',
                    'car_images_mobile.required' => 'Car Imges for Mobile are required.',
                    // 'car_images_mobile_alt.required' => 'Car Images for Mobile alt tag required',
                    'images_type.required' => 'Images Type is required.'
                ];

                // to check that same entry exist in database or not
                $carGraphicImages = CarGraphic::join('cop_gt_ms','cop_gt_ms.gt_id','=','cop_graphics.gt_id')->join('cop_models','cop_models.model_id','=','cop_graphics.model_id')->where('cop_models.model_name','like', trim($row['model_name']))->where('cop_gt_ms.gt_name','=',$imagesType)->first();
                if(!empty($carGraphicImages)){
                    $this->validationErrors[] = [
                        'row' => $index + 2,
                        'field' => ucwords(str_replace('_', ' ', 'model_name')),
                        'message' => "$imagesType entry already exist in car graphics for specified Model",
                    ];
                }

                // to check that entered car_type is exist/enable or not
                $carGraphicStatus = CarGraphicType::where('gt_name','=',$imagesType)->where('status','=','1')->first();
                if(empty($carGraphicStatus)){
                    $this->validationErrors[] = [
                        'row' => $index + 2,
                        'field' => ucwords(str_replace('_', ' ', 'For All Fields')),
                        'message' => "$imagesType has been disbaled or not found in Car Graphic Type (Kindy enable or enter Images as Car Graphic Type)",
                    ];
                }

                // count images and its alt tag
                if($row['car_images_alt'] != null || $row['car_images_alt'] != "") {
                    $car_images_count = count(explode(',',$row['car_images']));
                    $car_images_alt_count = count(explode(',',$row['car_images_alt']));
    
                    if ($car_images_count !== $car_images_alt_count){
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'car_images_alt')),
                            'message' => "Entered images are '".$car_images_count."' but Entered images Alt tags are '".$car_images_alt_count."', the count should be same",
                        ];
                    }
                }

                // count mobile images and its alt tag
                if($row['car_images_mobile_alt'] != null || $row['car_images_mobile_alt'] != ""){
                    $car_images_mob_count = count(explode(',',$row['car_images_mobile']));
                    $car_images_mob_alt_count = count(explode(',',$row['car_images_mobile_alt']));
    
                    if ($car_images_mob_count !== $car_images_mob_alt_count){
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'car_images_mobile_alt')),
                            'message' => "Entered mobile images are '".$car_images_mob_count."' but Entered mobile images Alt tags are '".$car_images_mob_alt_count."', the count should be same",
                        ];
                    }
                }

                // check that any black alt tag inputed for desktop or not
                if($row['car_images_alt'] != null || $row['car_images_alt'] != "") {
                    $desktop_img_array = explode(',',$row['car_images_alt']);
                    $trimmedArrayDesk = array_map('trim', $desktop_img_array);
                    $filteredArrayDesk = array_filter($trimmedArrayDesk, function($value) {
                        return $value === '';
                    });
                    if (!empty($filteredArrayDesk)){
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'car_images_alt')),
                            'message' => "Blank alt tags are not allowed",
                        ];
                    }
                }

                // check that any black alt tag inputed for mobile or not
                if($row['car_images_mobile_alt'] != null || $row['car_images_mobile_alt'] != ""){
                    $mobile_img_array = explode(',',$row['car_images_mobile_alt']);
                    $trimmedArrayMob = array_map('trim', $mobile_img_array);
                    $filteredArrayMob = array_filter($trimmedArrayMob, function($value) {
                        return $value === '';
                    });
                    if (!empty($filteredArrayMob)){
                        $this->validationErrors[] = [
                            'row' => $index + 2,
                            'field' => ucwords(str_replace('_', ' ', 'car_images_mobile_alt')),
                            'message' => "Blank alt tags are not allowed",
                        ];
                    }
                }

                $validator = Validator::make($row->toArray(), $rules, $errorMessages);

                if ($validator->fails()) {
                    $errorMessages = $validator->errors()->toArray();
                    foreach ($errorMessages as $field => $messages) {
                        $this->validationErrors[] = [
                            'row' => $index + 2, // Adjust the row number to start from 1-based index
                            'field' => ucwords(str_replace('_', ' ', $field)),
                            'message' => implode(', ', $messages),
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('import_error', 'Something went wrong');
        }

        if (empty($this->validationErrors)) {
            $count = 0;
            
            foreach ($rows as $index => $row) {
                try {
                    $imagesType = trim($row['images_type']);
                    $brand = Brand::where('brand_name', 'like',trim($row['brand_name']))->first();
                    $model = Model::where('model_name','like', trim($row['model_name']))->where('brand_id',$brand->brand_id)->first();
                    $carGraphicType = CarGraphicType::where('gt_name', $imagesType)->first();

                    DB::beginTransaction();
                    $car_graphic_images = CarGraphic::create(
                        [
                            'brand_id' => $brand->brand_id,
                            'model_id' => $model->model_id,
                            'gt_id' => $carGraphicType->gt_id,
                            'created_by'=>auth()->id()
                        ]
                    );

                    if($imagesType == "Images"){$imageFolder = 'images';}
                    elseif($imagesType == "Interior"){$imageFolder = 'interior';}
                    elseif($imagesType == "Exterior"){$imageFolder = 'exterior';}

                    // for dektop (normal photos)
                    $all_images = explode(',',trim($row['car_images']));
                    $all_images_alt = preg_replace('/\s*,\s*/', ',', $row['car_images_alt']);
                    $new_images = [];
                    for($i=0; $i<count($all_images); $i++)
                    {
                        $time = date('dmYHis');
                        $imageWebpImageName = $model->model_id . '_' . $time . '_' . $i . '.webp';

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());
                        $urlImage = @file_get_contents($all_images[$i]);
                        $image = $manager->read($urlImage);

                            // store in digital_ocean_spaces
                            $DoPath = 'car_graphics/' . $model->model_id . '/' . $imageFolder .'/' . $imageWebpImageName;
                            Storage::disk('digitalocean')->put($DoPath, $image->toWebp(), 'public');

                        $image->resize(1400,570); // For Thumb Image

                            // store in digital_ocean_spaces for Thumb
                            $DoPathThumb = 'car_graphics/' . $model->model_id . '/' . $imageFolder .'/thumb/' . $imageWebpImageName;
                            Storage::disk('digitalocean')->put($DoPathThumb, $image->toWebp(), 'public');

                        $new_images[] = $imageWebpImageName;
                    }
                    $car_graphics_images_for_db = implode(',', $new_images);
                    $car_graphic_images->update([
                        'graphic_file' => $car_graphics_images_for_db,
                        'graphic_file_alt' => $all_images_alt
                    ]);


                    // for mobile
                    $all_images_mob = explode(',',trim($row['car_images_mobile']));
                    $all_images_mob_alt = preg_replace('/\s*,\s*/', ',', $row['car_images_mobile_alt']);
                    $new_images_mob = [];
                    for($i=0; $i<count($all_images_mob); $i++)
                    {
                        $time_mob = date('dmYHis');
                        $imageWebpImageName_mob = $model->model_id . '_' . $time_mob . '_' . $i . '.webp';

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());
                        $urlImage_Mob = @file_get_contents($all_images_mob[$i]);
                        $image_Mob = $manager->read($urlImage_Mob);

                            // store in digital_ocean_spaces
                            $DoPathMob = 'car_graphics/' . $model->model_id . '/' . $imageFolder .'/mobile/' . $imageWebpImageName_mob;
                            Storage::disk('digitalocean')->put($DoPathMob, $image_Mob->toWebp(), 'public');

                        $new_images_mob[] = $imageWebpImageName_mob;
                    }
                    $car_graphics_images_mob_for_db = implode(',', $new_images_mob);
                    $car_graphic_images->update([
                        'graphic_file_mob' => $car_graphics_images_mob_for_db,
                        'graphic_file_mob_alt' => $all_images_mob_alt
                    ]);


                    DB::commit();
                    $count++;
                    session()->flash('import_success', $count.' data has been imported successfully.');

                } catch (Exception $e) {
                    DB::rollBack();
                    Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                    session()->flash('import_error', 'Something went wrong.');
                }
            }
        }
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}

