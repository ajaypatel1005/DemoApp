<?php

namespace App\Exports;

use App\Models\Model;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Collection;
use Illuminate\Validation\ValidationException;

class FeatureValues implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        try {
            // Validate the input parameters
            $validatedData = request()->validate([
                'brand_id' => 'required',
                'model_id' => 'required',
                'sc_id' => 'required',
            ]);

            // Proceed with the query assuming validation passes
            $brand_id = request()->input('brand_id');
            $model_id = request()->input('model_id');
            $variant_id = request()->input('variant_id');
            $spec_cat_id = request()->input('sc_id');

            $model_type=Model::select('model_type')->where('model_id',$model_id)->first();
            // Your SQL query
            $sql = "SET @sql = NULL;
                SELECT CONCAT(
                        'SELECT cop_brands_ms.brand_name,cop_models.model_name,cop_variants.variant_name, ',
                        GROUP_CONCAT(DISTINCT
                            CONCAT(
                                'MAX(CASE WHEN cop_features_ms.features_name = ''',
                                features_name,
                                ''' THEN cop_fv.feature_value ELSE NULL END) AS `',
                                features_name,
                                '`'
                            ) ORDER BY cop_spec_ms.spec_id, cop_features_ms.feature_id
                        )
                    ) INTO @sql
                    FROM cop_features_ms
                    JOIN cop_fv ON cop_fv.feature_id = cop_features_ms.feature_id
                    JOIN cop_variants ON cop_variants.variant_id = cop_fv.variant_id
                    JOIN cop_models ON cop_variants.model_id = cop_models.model_id
                    JOIN cop_brands_ms ON cop_brands_ms.brand_id = cop_models.brand_id
                    JOIN cop_spec_ms ON cop_fv.spec_id = cop_spec_ms.spec_id
                    WHERE cop_spec_ms.sc_id=$spec_cat_id and fuel_type in ($model_type->model_type,2);";

            // Execute the first part of the query
            DB::unprepared($sql);

            // Build the second part of the SQL query
            if (!empty($variant_id)) {

                $sql = "SET @sql = CONCAT(@sql, ' FROM cop_features_ms
            JOIN cop_fv ON cop_fv.feature_id = cop_features_ms.feature_id
            JOIN cop_variants ON cop_variants.variant_id = cop_fv.variant_id
            JOIN cop_models ON cop_variants.model_id = cop_models.model_id
            JOIN cop_brands_ms ON cop_brands_ms.brand_id = cop_models.brand_id
            JOIN cop_spec_ms ON cop_fv.spec_id = cop_spec_ms.spec_id
            WHERE cop_fv.brand_id=$brand_id and cop_fv.model_id = $model_id and cop_variants.variant_id=$variant_id and cop_spec_ms.sc_id=$spec_cat_id
            GROUP BY cop_brands_ms.brand_name,cop_models.model_name,cop_variants.variant_name');";
            } else {

                $sql = "SET @sql = CONCAT(@sql, ' FROM cop_features_ms
            JOIN cop_fv ON cop_fv.feature_id = cop_features_ms.feature_id
            JOIN cop_variants ON cop_variants.variant_id = cop_fv.variant_id
            JOIN cop_models ON cop_variants.model_id = cop_models.model_id
            JOIN cop_brands_ms ON cop_brands_ms.brand_id = cop_models.brand_id
            JOIN cop_spec_ms ON cop_fv.spec_id = cop_spec_ms.spec_id
            WHERE cop_fv.brand_id=$brand_id and cop_fv.model_id = $model_id and cop_spec_ms.sc_id=$spec_cat_id
            GROUP BY cop_brands_ms.brand_name,cop_models.model_name,cop_variants.variant_name');";
            }


            // Execute the second part of the query
            DB::unprepared($sql);

            // Prepare, execute, and deallocate the statement
            DB::unprepared("PREPARE stmt FROM @sql;");
            $results = DB::select("EXECUTE stmt;");
            DB::unprepared("DEALLOCATE PREPARE stmt;");

            // Transform the results into a collection
            return collect($results);
            session()->flash('import_success', 'Export Successfully.');
        } catch (ValidationException $e) {

            throw $e;
        }
    }
    /**
     * @return array
     */
    public function headings(): array
    {
        // Get the first row of data to extract keys as headings
        $headings = $this->collection()->first();
        $headings = array_keys((array) $headings);
        if(!empty($headings)){
        if(!empty($headings[0]) &&  $headings[0]=='brand_name'){
            $headings[0] = 'Brand Name';
        }
        if(!empty($headings[1]) &&  $headings[1]=='model_name'){
            $headings[1] = 'Model Name';
        }
        if(!empty($headings[2]) &&  $headings[2]=='variant_name'){
            $headings[2] = 'Variant Name';
        }
    }
        return $headings;
    }
}
