<?php

namespace App\Exports;

use App\Models\CarGraphic;
use Maatwebsite\Excel\Concerns\FromView;
use Illuminate\Contracts\View\View;


class CarGraphicExport implements FromView
{
    public function view(): View
    {

        $car_graphics_view = CarGraphic::select(
            'cop_graphics.graphic_id',
            'cop_graphics.brand_id',
            'cop_graphics.model_id',
            'cop_graphics.graphic_file',
            'cop_graphics.status',
            'cop_brands_ms.brand_id',
            'cop_brands_ms.brand_name',
            'cop_models.model_id',
            'cop_models.model_name',
            'cop_gt_ms.gt_name'
        )
        ->join('cop_models','cop_graphics.model_id','=','cop_models.model_id')
        ->join('cop_brands_ms','cop_graphics.brand_id','=','cop_brands_ms.brand_id')
        ->join('cop_gt_ms','cop_graphics.gt_id','=','cop_gt_ms.gt_id')
        ->where([['cop_gt_ms.status', '=', 1],['cop_brands_ms.status', '=', 1],['cop_models.status', '=', 1]]);

        if (!empty($search)) {
            $car_graphics_view->where(function ($query) use ($search) {
                $query->orWhere('cop_brands_ms.brand_name', 'LIKE', '%' . $search . '%')
                      ->orWhere('cop_models.model_name', 'LIKE', '%' . $search . '%')
                      ->orWhere('cop_gt_ms.gt_name', 'LIKE', '%' . $search . '%');
            });
        }

        $car_graphics_view = $car_graphics_view->orderBy('cop_models.model_id')->get();
        $imagePath = config('constant.IMAGE_PATH');
        return view('exports.car_graphics_images',compact('car_graphics_view','imagePath'));
    }
}
