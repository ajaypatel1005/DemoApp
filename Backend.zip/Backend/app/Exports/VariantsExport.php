<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromView;

class VariantsExport implements FromView
{
    protected $type;

    public function __construct($type = 'all')
    {
        $this->type = $type;
    }

    public function view(): View
    {

        // Build base query
        $query = DB::table('cop_variants')
            ->select(
                'cop_brands_ms.brand_name',
                'cop_models.model_name',
                'cop_variants.variant_name',
                'cop_brands_ms.slug as brand_slug',
                'cop_models.slug as model_slug',
                'cop_variants.slug as variant_slug'
            )
            ->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
            ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
            ->where('cop_brands_ms.status', 1)
            ->where('cop_models.status', 1);

        // Conditional filtering based on type
        if ($this->type === 'live') {
            $query->where('cop_variants.status', 1);
        } elseif ($this->type === 'discontinued') {
            $query->where('cop_variants.status', 0);
        } // 'all' type skips status filter

        // Ordering
        $variants = $query
            ->orderBy('cop_brands_ms.brand_name')
            ->orderBy('cop_models.model_name')
            ->orderBy('cop_variants.variant_name')
            ->get();

        // $variants = DB::table('cop_variants')
        //     ->select('cop_brands_ms.brand_name', 'cop_models.model_name', 'cop_variants.variant_name','cop_brands_ms.slug as brand_slug','cop_models.slug as model_slug','cop_variants.slug as variant_slug')
        //     ->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
        //     ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
        //     ->where('cop_brands_ms.status',1)
        //     ->where('cop_models.status',1)
        //     ->where('cop_variants.status',1)
        //     ->orderBy('cop_brands_ms.brand_name')
        //     ->orderBy('cop_models.model_name')
        //     ->orderBy('cop_variants.variant_name')
        //     ->get();
        return view('exports.variant_view', [
            'variants' => $variants
        ]);
    }
}
