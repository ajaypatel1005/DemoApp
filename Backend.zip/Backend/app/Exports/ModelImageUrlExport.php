<?php

namespace App\Exports;

use App\Models\Model;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromView;

class ModelImageUrlExport implements FromView
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function view(): View
    {

        $model_view = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
            ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
            ->select(
                'cop_models.model_id',
                'cop_brands_ms.brand_id',
                'cop_models.launch_date',
                'cop_models.model_year',
                'cop_models.model_image',
                'cop_models.model_name',
                'cop_brands_ms.brand_name',
                DB::raw("CASE WHEN cop_models.model_type=0 THEN 'Non EV' WHEN cop_models.model_type=1 THEN 'EV' ELSE NULL END as model_type")
            )->where('cop_brands_ms.status', '=', 1)->where('cop_models.status', '=', '1'); // check brand is active

        $model_view = $model_view->get();
        $imagePath = config('constant.IMAGE_PATH');

        return view('exports.url', [
            'model_view' => $model_view,
            'imagePath' => $imagePath
        ]);
    }
}
