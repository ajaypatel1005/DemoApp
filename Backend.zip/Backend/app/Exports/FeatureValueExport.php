<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
class FeatureValueExport implements FromView
{
    public function view(): View
    { 

        $specification = request()->input('name');
        $type = request()->input('value');
        $query = DB::table('cop_features_ms')
            ->select('features_name')
            ->join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            ->join('cop_sc_ms', 'cop_sc_ms.sc_id', '=', 'cop_spec_ms.sc_id')
            ->where('cop_sc_ms.sc_name', '=', $specification)
            ->where('cop_features_ms.fuel_type', '!=', $type)

        ->orderBy('cop_spec_ms.spec_id')
        ->orderBy('cop_features_ms.feature_id') 
        ->get();

        return view('exports.feature_value', [
            'feature_values' => $query
        ]);
    }

}
