<?php

namespace App\Exports;

use App\Models\BookTestDrive;
use Carbon\Carbon;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class BookTestDriveExport implements FromCollection, WithHeadings, WithMapping
{
    protected $startDate;
    protected $endDate;

    public function __construct($startDate, $endDate)
    {
        $this->startDate = $startDate;
        $this->endDate = $endDate;
    }

    public function collection()
    {
        $query = BookTestDrive::query()
            ->join('cop_customers', 'cop_book_test_drives.customer_id', '=', 'cop_customers.customer_id')
            ->join('cop_brands_ms', 'cop_book_test_drives.brand_id', '=', 'cop_brands_ms.brand_id')
            ->join('cop_models', 'cop_book_test_drives.model_id', '=', 'cop_models.model_id')
            ->leftjoin('cop_dealer', 'cop_book_test_drives.dealer_id', '=', 'cop_dealer.id')
            ->select(
                'cop_book_test_drives.location',
                'cop_book_test_drives.address',
                'cop_book_test_drives.email',
                'cop_book_test_drives.name',
                'cop_brands_ms.brand_name',
                'cop_models.model_name',
                'cop_dealer.dealer_name',
                'cop_dealer.address as dealer_address',
                'cop_book_test_drives.fuel_types',
                'cop_book_test_drives.transmission',
                'cop_book_test_drives.estimated_purchase_date',
                'cop_book_test_drives.status',
                'cop_book_test_drives.created_at',
                'cop_book_test_drives.booking_id',
                'cop_customers.contact_no'
            );

        if ($this->startDate) {
            $query->whereDate('cop_book_test_drives.created_at', '>=', Carbon::parse($this->startDate));
        }

        if ($this->endDate) {
            $query->whereDate('cop_book_test_drives.created_at', '<=', Carbon::parse($this->endDate));
        }
        return $query->get();
    }

    public function headings(): array
    {
        return [
            'Sr. No',
            'Booking ID',
            'Name',
            'Email',
            'Contact Number',
            'Brand Name',
            'Model Name',
            'Customer Address',
            'Dealer Name',
            'Dealer Address',
            'Location',
            'Fuel Types',
            'Transmission',
            'Estimated Purchase Date',
            'Status',
            'Created Date',
        ];
    }

    public function map($item): array
    {
        static $index = 1;
        return [
            $index++, // Sr. No (index starts from 0, so add 1)
            $item->booking_id,
            $item->name,
            $item->email,
            encryptor('d', $item->contact_no), // Decrypt contact number
            $item->brand_name,
            $item->model_name,
            $item->address,
            $item->dealer_name,
            $item->dealer_address,
            $item->location,
            $item->fuel_types,
            $item->transmission,
            $item->estimated_purchase_date,
            $item->status === 1 ? 'Booked' : ($item->status === 2 ? 'Completed' : 'Cancelled'),
            $item->created_at,
        ];
    }
}
