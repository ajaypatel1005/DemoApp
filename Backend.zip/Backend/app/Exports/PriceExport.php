<?php
namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\DB;

class PriceExport implements FromCollection, WithHeadings
{
    protected $brandId;

    public function __construct($brandId)
    {
        $this->brandId = $brandId;
    }

    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        $query = DB::table('cop_pe_ms')
            ->select('cop_brands_ms.brand_name', 'cop_models.model_name', 'cop_variants.variant_name', 'state_name', 'city_name', 'ex_showroom_price')
            ->join('cop_variants', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
            ->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
            ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
            ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
            ->join('cop_state_ms', 'cop_state_ms.state_id', '=', 'cop_pe_ms.state_id')
            ->where('cop_pe_ms.status', 1)
            ->where('cop_variants.status', 1)
            ->where('cop_models.status', 1)
            ->where('cop_brands_ms.status', 1)
            ->orderBy('cop_brands_ms.brand_name')
            ->orderBy('cop_models.model_name')
            ->orderBy('cop_variants.variant_name')
            ->orderBy('ex_showroom_price', 'ASC');

        if ($this->brandId) {
            $query->where('cop_brands_ms.brand_name','LIKE', $this->brandId);
        }

        return $query->get();
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'Brand Name',
            'Model Name',
            'Variant Name',
            'State',
            'City',
            'Price',
        ];
    }
}
