<?php

namespace App\Exceptions;
use Exception;
use Illuminate\Http\Exceptions\PostTooLargeException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;

use Throwable;

class Handler extends ExceptionHandler
{
    protected function rateLimitExceeded($request, $exception)
    {
        return response()->json([
            'error' => 'Too Many Attempts. Please try again later.',
        ], 429);
    }


    public function render($request, Throwable $exception)
{
    try {

        if ($exception instanceof MethodNotAllowedHttpException) {
            return response()->json(['error' => 'Method Not Allowed'], 405);
        }
        if ($exception instanceof \Illuminate\Contracts\Encryption\DecryptException) {
            return response()->view('errors.404', [], 404);
        }

        if ($exception instanceof PostTooLargeException) {
            ob_get_contents();
            ob_end_clean();
            return response()->view('errors.429', [], 429);
        }

        return parent::render($request, $exception);

    } catch (Exception $e) {
        // return redirect()->view('errors.429', [], 429);
        return response()->json([
            'error' => 'Too Many Attempts. Please try again later.',
        ], 429);

    }

}








    /**
     * The list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     */
    public function register(): void
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }
}
