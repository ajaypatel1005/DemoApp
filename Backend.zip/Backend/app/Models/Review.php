<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Model as BrandModel;

class Review extends Model
{
    protected $table = 'cop_reviews';
    protected $primaryKey = 'id';
    protected $guarded = [];
    use HasFactory;

    public function brands()
    {
        return $this->belongsTo(Brand::class, 'brand_id');
    }

    public function models()
    {
        return $this->belongsTo(BrandModel::class, 'model_id');
    }
}
