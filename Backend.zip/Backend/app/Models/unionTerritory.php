<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\ClientInfoTraits;

class unionTerritory extends Model
{
    protected $table = 'cop_ut_ms';
    protected $primaryKey = 'ut_id';
    use HasFactory;
    use ClientInfoTraits;
    
    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];
        return "User {$eventNameMap[$eventName]} Union Territory record";
    }
   
    // Log additional custom properties
    public function logActivity(string $eventName)
    {
        $oldValues=null;
        $newValues=null;
        if($eventName=="updated")
        {
            $oldValues = $this->getOriginal();
            $newValues = $this->getAttributes();
        }
        if($eventName=="deleted")
        {
            $oldValues = $this->getOriginal();
        }
        if($eventName=="created")
        {
            $newValues = $this->getAttributes();
        }

        activity('union_territory')
            ->event($eventName)
            ->performedOn($this)
            ->withProperties([
                'old_values' => $oldValues,
                'new_values' => $newValues,
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log($this->getDescriptionForEvent($eventName));
    }

    // Log custom attributes
    protected static function boot()
    {
        parent::boot();
        static::created(function ($model) {
            $model->logActivity('created');
        });
        static::updated(function ($model) {
            $model->logActivity('updated');
        });
        static::deleted(function ($model) {
            $model->logActivity('deleted');
        });
    }
    public function scopeActive($query)
    {
        return $query->where('status', '1');
    }
}
