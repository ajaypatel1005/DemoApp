<?php

namespace App\Models;

use App\Models\SEO\Page;
use App\Models\SEO\Seo;
use App\Models\Model as CarModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\ClientInfoTraits;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Model as EloquentModel;

class Variant extends EloquentModel
{

    use HasFactory;
    use ClientInfoTraits;
    protected $table = 'cop_variants';
    protected $primaryKey = 'variant_id';
    protected $guarded = [];
    protected static $logAttributes = ['brand_id', 'model_id', 'variant_name', 'variant_type','variant_image', 'seating_capacity', 'status'];

    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];
        return "User {$eventNameMap[$eventName]} Variant record";
    }

    // Log additional custom properties
    public function logActivity(string $eventName)
    {
        $oldValues = null;
        $newValues = null;
        if ($eventName == "updated") {
            $oldValues = $this->getOriginal();
            $newValues = $this->getAttributes();
        }
        if ($eventName == "deleted") {
            $oldValues = $this->getOriginal();
        }
        if ($eventName == "created") {
            $newValues = $this->getAttributes();
        }

        activity('variant')
            ->event($eventName)
            ->performedOn($this)
            ->withProperties([
                'old_values' => $oldValues,
                'new_values' => $newValues,
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log($this->getDescriptionForEvent($eventName));
    }

    // Log custom attributes
    protected static function boot()
    {
        parent::boot();
        static::created(function ($model) {
            $model->logActivity('created');
            static::seoCreateContent($model, 'created');
        });
        static::updated(function ($model) {
            $model->logActivity('updated');
            static::seoCreateContent($model, 'updated');
        });
        static::deleted(function ($model) {
            $model->logActivity('deleted');
        });
    }

    protected static function seoCreateContent($modelData, $eventType)
    {

        $brand_data = Brand::where('brand_id', $modelData->brand_id)->first();
        $model_data = CarModel::where('model_id', $modelData->model_id)->first();
        $tagContentMapping = [
            // Title
            1 => $brand_data->brand_name . " " . $model_data->model_name . " " . $modelData->variant_name . " Price - Images, Specs & Reviews",

            // Desription
            2 => $brand_data->brand_name . " " . $model_data->model_name . " " . $modelData->variant_name .  " online at best prices. Explore specifications, features, mileage, colours, images, FAQs, news, reviews, and videos. ✓Book a Test Drive ✓Car Insurance ✓EMI Calculator",

            // Og Title
            9 =>  $brand_data->brand_name . " " . $model_data->model_name . " " . $modelData->variant_name . " Price - Images, Specs & Reviews",

            //Og Description
            10 =>  $brand_data->brand_name . " " . $model_data->model_name . " " . $modelData->variant_name . " online at best prices. Explore specifications, features, mileage, colours, images, FAQs, news, reviews, and videos. ✓Book a Test Drive ✓Car Insurance ✓EMI Calculator"

        ];

        $page_name = Page::where('page_name', 'like', '%Car Module%')->first();

        foreach ($tagContentMapping as $metaTagId => $contentFunction) {
            if ($eventType === 'updated') {
                $variantsSeo = Seo::with('page')
                    ->where('brand_id', $modelData->brand_id)
                    ->where('model_id', $modelData->model_id)
                    ->where('variant_id', $modelData->variant_id)
                    ->where('meta_tag_id', $metaTagId)
                    ->whereHas('page', function ($query) {
                        $query->where('page_name', 'like', '%Car Module%');
                    })
                    ->first();

                if ($variantsSeo) {
                    $variantsSeo->tag_content = $contentFunction;
                    $variantsSeo->save();
                } else {
                    Log::error("SEO record not found for brand_id: {$modelData->brand_id}, model_id: {$modelData->model_id}, meta_tag_id: {$metaTagId}");
                }
            }

            if ($eventType === 'created') {
                Seo::create([
                    'brand_id' => $modelData->brand_id,
                    'model_id' => $modelData->model_id,
                    'variant_id' => $modelData->variant_id,
                    'page_id' => $page_name->page_id,
                    'meta_tag_id' => $metaTagId,
                    'tag_content' => $contentFunction,
                    'status' => '1',
                    'seo_type' => '3',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }
    }


    public function price_entry()
    {
        return $this->hasMany(PriceEntry::class, 'variant_id');
    }
    public function scopeActive($query)
    {
        return $query->where('status', '1');
    }
    public function model()
    {
        return $this->belongsTo(CarModel::class, 'model_id');
    }
}
