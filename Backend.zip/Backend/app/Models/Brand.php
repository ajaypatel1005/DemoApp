<?php

namespace App\Models;

use App\Models\SEO\Seo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

use App\Traits\ClientInfoTraits;
use Illuminate\Database\Eloquent\Model as EloquentModel;
use Illuminate\Support\Facades\Log;

class Brand extends EloquentModel
{
    use HasFactory;
    use ClientInfoTraits;
    protected $table = 'cop_brands_ms';
    protected $primaryKey = 'brand_id';
    protected $fillable = [
        'brand_name',
        'brand_logo',
        'brand_banner',
        'brand_description',
        'slug',
        'status',
        'created_by',
        'updated_by'
    ];

    protected static $logAttributes = ['brand_name', 'brand_logo', 'brand_banner', 'brand_description', 'status'];

    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];
        return "User {$eventNameMap[$eventName]} Brand record";
    }

    // Log additional custom properties
    public function logActivity(string $eventName)
    {
        $oldValues = null;
        $newValues = null;
        if ($eventName == "updated") {
            $oldValues = $this->getOriginal();
            $newValues = $this->getAttributes();
        }
        if ($eventName == "deleted") {
            $oldValues = $this->getOriginal();
        }
        if ($eventName == "created") {
            $newValues = $this->getAttributes();
        }

        activity('brand')
            ->event($eventName)
            ->performedOn($this)
            ->withProperties([
                'old_values' => $oldValues,
                'new_values' => $newValues,
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log($this->getDescriptionForEvent($eventName));
    }

    // Log custom attributes
    protected static function boot()
    {
        parent::boot();
        static::created(function ($model) {
            $model->logActivity('created');
            static::seoCreateContent($model, 'created');
        });
        static::updated(function ($model) {
            $model->logActivity('updated');
            static::seoCreateContent($model, 'updated');
        });
        static::deleted(function ($model) {
            $model->logActivity('deleted');
        });
    }

    protected static function seoCreateContent($modelData, $eventType)
    {
        $year = '2024';
        $tagContentMapping = [
            // Title
            1 => function ($brand_name, $year) {
                return  $brand_name . ' Cars Price ' . $year . ' - Car Models, Specs & Features';
            },

            // Desription
            2 => function ($brand_name, $year) {
                return  'Check the latest ' . $year . ' ' . $brand_name . ' Prices in India. Your best guide to cars, Explore New ' . $brand_name . ' Car Models with Full Specs, images, review, dealers and Features at CarOnPhone.';
            },

            // Og Title
            9 => function ($brand_name, $year) {
                return  $brand_name . ' Cars Price ' . $year . ' - Car Models, Specs & Features';
            },
            //Og Description
            10 => function ($brand_name, $year) {
                return 'Check the latest ' . $year . ' ' .  $brand_name . ' Prices in India. Your best guide to cars, Explore New ' .  $brand_name . ' Car Models with Full Specs, images, review, dealers and Features at CarOnPhone.';
            },
        ];

        $brand_name = $modelData->brand_name;
        foreach ($tagContentMapping as $metaTagId => $contentFunction) {


            if ($eventType == 'updated') {
                $brandsSeo = Seo::where('brand_id', $modelData->brand_id)
                    ->where('meta_tag_id', $metaTagId)
                    ->where('page_id', 5)
                    ->first();
                    if ($brandsSeo) {
                        $brandsSeo->tag_content = $contentFunction($brand_name, $year);
                        $brandsSeo->update();
                    } else {
                        // Handle case where $brandsSeo is null (optional)
                        // You can choose to log this or handle it differently based on your application logic.
                        // For example:
                        Log::warning("SEO record not found for brand ID {$modelData->brand_id}, meta tag ID {$metaTagId}, page ID 5.");
                    }
            }

            if ($eventType == 'created') {
                Seo::create([
                    'brand_id' => $modelData->brand_id,
                    'page_id' => 5,
                    'meta_tag_id' => $metaTagId,
                    'tag_content' => $contentFunction($brand_name, $year),
                    'status' => '1',
                    'seo_type' => '1',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

            }
        }
    }

    public function models()
    {
        return $this->hasMany(Model::class, 'brand_id');
    }

    public function variants()
    {
        return $this->hasMany(Variant::class, 'brand_id');
    }
    public function banners()
    {
        return $this->hasMany(Banner::class, 'brand_id');
    }
    public function car_graphics()
    {
        return $this->hasMany(CarGraphic::class, 'brand_id');
    }
    public function car_listing_data()
    {
        return $this->hasMany(CarListingData::class, 'brand_id');
    }

    public function price_entry()
    {
        return $this->hasMany(PriceEntry::class, 'brand_id');
    }
    public function manager()
    {
        return $this->hasMany(Manager::class, 'brand_id');
    }
    // public function feature_value()
    // {
    //     return $this->hasMany(FeatureVa::class, 'fv_id');
    // }
    public function banner()
    {
        return $this->belongsTo(Banner::class, 'brand_id');
    }

    public function scopeActive($query)
    {
        return $query->where('status', '1');
    }

    // Begin::for SEO Tag table
    public function seo()
    {
        return $this->hasMany(Seo::class, 'seo_id');
    }
    // End::for SEO Tag table


}
