<?php

namespace App\Models;

use App\Models\SEO\Page;
use App\Models\SEO\Seo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model as M;
use App\Traits\ClientInfoTraits;
use Illuminate\Database\Eloquent\Model as EloquentModel;
use Illuminate\Support\Facades\Log;

class Model extends EloquentModel
{
    protected $table = 'cop_models';
    protected $primaryKey = 'model_id';
    use HasFactory;
    use ClientInfoTraits;
    protected $guarded = [];


    protected static $logAttributes = ['cs_id', 'launch_date', 'ct_id', 'brand_id', 'model_name', 'model_image', 'model_description', 'min_price', 'max_price', 'model_year', 'model_type', 'status'];

    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];
        return "User {$eventNameMap[$eventName]} Model record";
    }

    // Log additional custom properties
    public function logActivity(string $eventName)
    {
        $oldValues = null;
        $newValues = null;
        if ($eventName == "updated") {
            $oldValues = $this->getOriginal();
            $newValues = $this->getAttributes();
        }
        if ($eventName == "deleted") {
            $oldValues = $this->getOriginal();
        }
        if ($eventName == "created") {
            $newValues = $this->getAttributes();
        }

        activity('model')
            ->event($eventName)
            ->performedOn($this)
            ->withProperties([
                'old_values' => $oldValues,
                'new_values' => $newValues,
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log($this->getDescriptionForEvent($eventName));
    }

    // Log custom attributes
    protected static function boot()
    {
        parent::boot();
        static::created(function ($model) {
            $model->logActivity('created');
            static::seoCreateContent($model, 'created');
        });
        static::updated(function ($model) {
            $model->logActivity('updated');
            static::seoCreateContent($model, 'updated');
        });
        static::deleted(function ($model) {
            $model->logActivity('deleted');
        });
    }


    protected static function seoCreateContent($modelData, $eventType)
    {
        $brandData = Brand::where('brand_id', $modelData->brand_id)->first();
        $tagContentMapping = [

            // Title
            1 => $brandData->brand_name . " " . $modelData->model_name . " Models Price - Images, Specs & Reviews",

            // Description
            2 =>  $brandData->brand_name . " " . $modelData->model_name . " - buy wide range of " . $brandData->brand_name . " " . $modelData->model_name . " Models online at best prices. Check specifications, features, mileage, colours, images, FAQs, news, reviews, and videos. ✓Book a Test Drive ✓Car Insurance ✓EMI Calculator",

            // Og Title
            9 => $brandData->brand_name . " " . $modelData->model_name . " Models Price - Images, Specs & Reviews",

            // Og Description
            10 => $brandData->brand_name . " " . $modelData->model_name . " - buy wide range of " . $brandData->brand_name . " " . $modelData->model_name . " Models online at best prices. Check specifications, features, mileage, colours, images, FAQs, news, reviews, and videos. ✓Book a Test Drive ✓Car Insurance ✓EMI Calculator"
        ];


        foreach ($tagContentMapping as $metaTagId => $contentFunction) {
            if ($eventType == 'updated') {
                $modelsSeo = Seo::with('page')
                    ->where('brand_id', $modelData->brand_id)
                    ->where('model_id', $modelData->model_id)
                    ->where('meta_tag_id', $metaTagId)
                    ->whereHas('page', function ($query) {
                        $query->where('page_name', 'like', '%Car Module%');
                    })
                    ->first();

                if ($modelsSeo) {
                    $modelsSeo->tag_content = $contentFunction;
                    $modelsSeo->save();
                } else {
                    Log::error("SEO record not found for brand_id: {$modelData->brand_id}, model_id: {$modelData->model_id}, meta_tag_id: {$metaTagId}");
                }
            }

           $page_name = Page::where('page_name', 'like', '%Car Module%')->first();
            if ($eventType == 'created') {
                Seo::create([
                    'brand_id' => $modelData->brand_id,
                    'model_id' => $modelData->model_id,
                    'page_id' => $page_name->page_id,
                    'meta_tag_id' => $metaTagId,
                    'tag_content' => $contentFunction,
                    'status' => '1',
                    'seo_type' => '2',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }
    }


    public function variants()
    {
        return $this->hasMany(Variant::class, 'model_id');
    }

    public function banners()
    {
        return $this->hasMany(Banner::class, 'model_id');
    }

    public function car_graphics()
    {
        return $this->hasMany(CarGraphic::class, 'model_id');
    }

    public function car_listing_data()
    {
        return $this->hasMany(CarListingData::class, 'model_id');
    }


    public function price_entry()
    {
        return $this->hasMany(PriceEntry::class, 'model_id');
    }

    public function manager()
    {
        return $this->hasMany(Manager::class, 'model_id');
    }

    // public function banner()
    // {
    //     return $this->belongsTo(Banner::class,'model_id');
    // }


    public function model_info()
    {
        return $this->hasOne(ModelSpecDisplay::class, 'model_id');
    }
    public function banner()
    {
        return $this->hasMany(Banner::class, 'model_id');
    }
    public function scopeActive($query)
    {
        return $query->where('status', '1');
    }
    public function car_stage()
    {
        return $this->belongsTo(CarStage::class, 'cs_id');
    }

    public function ratings()
    {
        return $this->hasMany(Rating::class, 'model_id');
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class, 'brand_id');
    }
}
