<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SystemSetting extends Model
{
    use HasFactory;
    protected $table = 'cop_setting';
    protected $primaryKey = 'id';
    protected $fillable = [
        'key',
        'value',
        'is_expired',
        'status',
        'created_at',
        'updated_at',
    ];

    const TOLL_GURU_KEY = 'toll_guru_key';
    const RAPID_FUEL_PRICE = 'rapid_fuel_price';
    const KEY = [
        self::TOLL_GURU_KEY => 'Toll Guru API Key',
        self::RAPID_FUEL_PRICE => 'Rapid API Key',
    ];
}
