<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FaqCustomer extends Model
{
    use HasFactory;
    protected $table = 'cop_faq_customers';
    protected $primaryKey = 'id';
    protected $guarded = [];
}
