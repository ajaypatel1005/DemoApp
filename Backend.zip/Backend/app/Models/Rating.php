<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Rating extends Model
{

    // Inside the Rating model
    public function cop_rating_types()
    {
        return $this->hasOne(RatingType::class, 'rating_type_id', 'rating_type_id');
        // Adjust 'id' to the actual primary key of CopRatingType and 'rating_type_id' to the foreign key in the Rating table
    }




    use HasFactory;

    protected $table = 'cop_ratings';
    protected $primaryKey = 'rating_id';
    protected $guarded = [];

    public function model_data()
    {
        return $this->belongsTo(Model::class, 'model_id');
    }
}