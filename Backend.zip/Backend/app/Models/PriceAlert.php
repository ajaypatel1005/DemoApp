<?php

namespace App\Models;

use App\Models\Model as CarModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PriceAlert extends Model
{
    use HasFactory;
    protected $table = 'cop_price_alert';
    protected $primaryKey = 'id';

    protected $fillable = [
        'brand_id',
        'model_id',
        'created_by',
        'updated_by',
        'status'
    ];

    public function model()
    {
        return $this->belongsTo(CarModel::class, 'model_id');
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class, 'brand_id');
    }
    public function customer()
    {
        return $this->belongsTo(Customer::class, 'created_by','customer_id');
    }
}

