<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LogView extends Model
{
    protected $table = 'cop_logs_ms';
    protected $primaryKey = 'log_id';
    protected $fillable = ['log_name','model_name'];
    use HasFactory;
}
