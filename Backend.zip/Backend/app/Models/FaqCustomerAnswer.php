<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FaqCustomerAnswer extends Model
{
    use HasFactory;
    protected $table = 'cop_faq_customer_answers';
    protected $primaryKey = 'id';
    protected $guarded = [];
}
