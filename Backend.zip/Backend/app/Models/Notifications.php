<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notifications extends Model
{
    use HasFactory;

    protected $table = 'cop_notifications';
    protected $primaryKey = 'id';

    protected $fillable = [
        'brand_id',
        'model_id',
        'amount_diff',
        'created_by',
        'city_id',
        'notification_type'
    ];
}
