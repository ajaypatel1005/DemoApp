<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WarningLight extends Model
{
    use HasFactory;

    protected $table='cop_cwl_ms';
    protected $primaryKey ='wl_id';
    protected $guarded = [];
}
