<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\ClientInfoTraits;
class State extends Model
{
    use HasFactory;
    
    protected $table = 'cop_state_ms';
    protected $primaryKey = 'state_id';
    protected $fillable = ['state_name','status'];

    use HasFactory;
    use ClientInfoTraits;

    protected $guarded = [];

    public function s_station()
    {
        return $this->hasMany(ServiceStation::class, 'state_id');
    }

    public function f_station()
    {
        return $this->hasMany(FuelStation::class, 'state_id');
    }

    public function ev_station()
    {
        return $this->hasMany(EvStation::class, 'state_id');
    }

    public function price_entry()
    {
        return $this->hasMany(PriceEntry::class, 'state_id');
    }
    public function city()
    {
        return $this->hasMany(City::class, 'state_id');
    }

    protected static $logAttributes = ['state_name','status'];

    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];
        return "User {$eventNameMap[$eventName]} State record";
    }
   
    // Log additional custom properties
    public function logActivity(string $eventName)
    {
        $oldValues=null;
        $newValues=null;
        if($eventName=="updated")
        {
            $oldValues = $this->getOriginal();
            $newValues = $this->getAttributes();
        }
        if($eventName=="deleted")
        {
            $oldValues = $this->getOriginal();
        }
        if($eventName=="created")
        {
            $newValues = $this->getAttributes();
        }

        activity('state')
            ->event($eventName)
            ->performedOn($this)
            ->withProperties([
                'old_values' => $oldValues,
                'new_values' => $newValues,
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log($this->getDescriptionForEvent($eventName));
    }

    // Log custom attributes
    protected static function boot()
    {
        parent::boot();
        static::created(function ($model) {
            $model->logActivity('created');
        });
        static::updated(function ($model) {
            $model->logActivity('updated');
        });
        static::deleted(function ($model) {
            $model->logActivity('deleted');
        });
    }

    public function scopeActive($query)
    {
        return $query->where('status', '1');
    }
}
