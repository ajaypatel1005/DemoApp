<?php

namespace App\Models\CRM;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CallLog extends Model
{
    use HasFactory;

    protected $table = 'cop_lead_call_log';
    protected $primaryKey = 'lcl_id';
    protected $guarded = [];

    public function call_outcome()
    {
        return $this->belongsTo(CallOutcome::class, 'lco_id');
    }
    public function lead_id()
    {
        return $this->belongsTo(Lead::class, 'lead_id');
    }
    public function created_user()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
