<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadNotification extends Model
{
    use HasFactory;

    protected $table = 'cop_lead_reminder';
    protected $primaryKey = 'lr_id';

    public function lead()
    {
        return $this->belongsTo(Lead::class,'lead_id');
    }
}
