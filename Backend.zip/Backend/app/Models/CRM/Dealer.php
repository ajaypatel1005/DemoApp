<?php

namespace App\Models\CRM;

use App\Models\User;
use App\Models\Brand;
use App\Models\City;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dealer extends Model
{
    use HasFactory;

    protected $table = 'cop_dealers_ms';
    protected $primaryKey = 'dealer_id';
    public $guarded = [];


    public function lead()
    {
        return $this->hasMany(Lead::class, 'lead_id');
    }

    public function user()
    {
        return $this->hasMany(User::class, 'user_id');
    }

    public function city()
    {
        return $this->belongsTo(City::class,'city_id');
    }

    public function groupUser()
    {
        return $this->belongsTo(User::class,'parent_id');
    }
}
