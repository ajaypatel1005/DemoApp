<?php

namespace App\Models\CRM;

use App\Models\User;
use App\Models\City;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class SpocPerson extends Model
{
    use HasFactory;

    protected $table = 'cop_spoc_salesman_ms';
    protected $primaryKey = 'spoc_id';
    public $guarded = [];

    public static function getDealerSpocPerson($dealer_id)
    {
        $checkDealerSpoc = self::where('parent_id', $dealer_id)
            ->where('spoc_type', config('constant.SPOC_TYPE.DEALER_SPOC_PERSON'))
            ->select('user_id')
            ->first();
        if ($checkDealerSpoc) {
            return $checkDealerSpoc->user_id;
        } else {
            return null;
        }
    }

    public static function getSpocSalesMan($spoc_id)
    {
        $parentID=null;
        if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER')))
            {
                $parentID=Auth::user()->id;
            }
            else
            {
                $getParent = self::where('user_id', $spoc_id)->first();
                $parentID= $getParent->parent_id;
            }
        $checkSpocSalesman = self::where('parent_id', $parentID)
            ->whereNot('user_id',$spoc_id)
            ->where('spoc_type', config('constant.SPOC_TYPE.DEALER_SALESMAN'))
            ->get();
        if ($checkSpocSalesman) {
            return $checkSpocSalesman;
        } else {
            return null;
        }
    }

    public function lead()
    {
        return $this->hasMany(Lead::class, 'lead_id');
    }

    public function user()
    {
        return $this->hasMany(User::class, 'user_id');
    }
    public function city()
    {
        return $this->belongsTo(City::class,'city_id');
    }

    public function scopeSpocParent($query,$id)
    {
        return $query->where('parent_id', $id);
    }

    public function leads()
    {
        return $this->hasMany(Lead::class,'dealer_spoc_id');
    }

    public function spocLeads()
    {
        return $this->hasMany(Lead::class, 'dealer_spoc_id', 'user_id');
    }

}
