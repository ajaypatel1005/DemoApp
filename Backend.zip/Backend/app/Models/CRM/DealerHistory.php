<?php

namespace App\Models\CRM;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DealerHistory extends Model
{


    use HasFactory;

    protected $table = 'cop_lead_dealer_history';
    protected $primaryKey = 'dlh_id';
    public $guarded = [];


    public function lead()
    {
        return $this->belongsTo(Lead::class, 'lead_id');
    }

    public function followup_status()
    {
        return $this->belongsTo(LeadStatus::class, 'followup_status_id');
    }

    public function dealer_status()
    {
        return $this->belongsTo(LeadStatus::class, 'dealer_status_id');
    }

    public function create_by()
    {
        return $this->belongsTo(User::class, 'created_by');
    }





}
