<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadPipelineStage extends Model
{
    use HasFactory;
    protected $table = 'cop_lead_pipeline_stage_ms';
    protected $primaryKey = 'lps_id';
    protected $guarded = [];

    public function pipeline()
    {
        return $this->belongsTo(LeadPipeline::class, 'lp_id');
    }

    public function lead()
    {
        return $this->hasMany(Lead::class);
    }
}
