<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CallOutcome extends Model
{
    use HasFactory;

    protected $table = 'cop_lead_call_outcome_ms';
    protected $primaryKey = 'lco_id';
    protected $guarded = [];
}
