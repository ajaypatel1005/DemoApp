<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadCount extends Model
{
    use HasFactory;

    protected $table = 'cop_lead_unique_count';
    public $guarded = [];


    public static function generateUniqCode($leadType)
    {
        if (!empty($leadType) && in_array($leadType, ['lead_code', 'assign_code',
        'test_drive_code','booking_code','purchase_code','dealer_code','spoc_code',
        'manager_code','telecaller_code'])) {
            $leadCount = LeadCount::first();
            if ($leadType == 'lead_code') {
                $prefix = 'L';
                $count = $leadCount->lead_count + 1;
                $leadCount->increment('lead_count');
            } elseif ($leadType == 'assign_code') {
                $prefix = 'A';
                $count = $leadCount->assign_count + 1;
                $leadCount->increment('assign_count');
            }
            elseif ($leadType == 'test_drive_code') {
                $prefix = 'TD';
                $count = $leadCount->test_drive_count + 1;
                $leadCount->increment('test_drive_count');
            }
            elseif ($leadType == 'booking_code') {
                $prefix = 'B';
                $count = $leadCount->booking_count + 1;
                $leadCount->increment('booking_count');
            }
            elseif ($leadType == 'purchase_code') {
                $prefix = 'P';
                $count = $leadCount->purchase_count + 1;
                $leadCount->increment('purchase_count');
            }
            elseif ($leadType == 'dealer_code') {
                $prefix = 'D';
                $count = $leadCount->dealer_count + 1;
                $leadCount->increment('dealer_count');
            }
            elseif ($leadType == 'spoc_code') {
                $prefix = 'SP';
                $count = $leadCount->spoc_count + 1;
                $leadCount->increment('spoc_count');
            }
            elseif ($leadType == 'manager_code') {
                $prefix = 'M';
                $count = $leadCount->manager_count + 1;
                $leadCount->increment('manager_count');
            }
            elseif ($leadType == 'telecaller_code') {
                $prefix = 'T';
                $count = $leadCount->telecaller_count + 1;
                $leadCount->increment('telecaller_count');
            }
            return 'COP'. date('my').$prefix.$count;
        }
        return null;
    }
}
