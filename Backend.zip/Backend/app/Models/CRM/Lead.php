<?php

namespace App\Models\CRM;

use App\Models\Brand;
use App\Models\Model as ModelsModel;
use App\Models\User;
use App\Models\Variant;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Lead extends Model
{
    use HasFactory;

    protected $table = 'cop_leads';
    protected $primaryKey = 'lead_id';

    // protected $fillable = ['lead_id', 'dealer_id'];
    protected $guarded = [];

    public function activity()
    {
        return $this->hasMany(LeadActivity::class, 'lead_id');
    }
    public function lead_pipeline()
    {
        return $this->belongsTo(LeadPipeline::class, 'lp_id');
    }
    public function lead_status()
    {
        return $this->belongsTo(LeadStatus::class, 'ls_status_id');
    }
    public function lead_source()
    {
        return $this->belongsTo(LeadSource::class, 'ls_id');
    }
    public function lead_type()
    {
        return $this->belongsTo(LeadType::class, 'lt_id');
    }

    public function lead_pipeline_stage()
    {
        return $this->belongsTo(LeadPipelineStage::class, 'lps_id');
    }

    public function documents()
    {
        return $this->belongsTo(LeadDocument::class, 'lead_doc_id');
    }

    public function lead_history()
    {
        return $this->hasMany(LeadHistory::class, 'lead_id');
    }

    public function car_brand()
    {
        return $this->belongsTo(Brand::class, 'brand_id');
    }
    public function car_models()
    {
        return $this->belongsTo(ModelsModel::class, 'model_id');
    }
    public function car_variant()
    {
        return $this->belongsTo(Variant::class, 'variant_id');
    }
    public function lead_manager()
    {
        return $this->belongsTo(User::class, 'manager_user_id');
    }

    public function user_dealer()
    {
        return $this->belongsTo(User::class, 'dealer_id');
    }

    public function user_copspoc()
    {
        return $this->belongsTo(User::class, 'spoc_id');
    }

    public function user_dealerspoc()
    {
        return $this->belongsTo(User::class, 'dealer_spoc_id');
    }

    public function user_dealersalesman()
    {
        return $this->belongsTo(User::class, 'dealer_salesman_id');
    }


    public function dealer_status()
    {
        return $this->belongsTo(LeadStatus::class, 'dealer_status_id');
    }

    public function lead_dealer_history()
    {
        return $this->hasMany(DealerHistory::class, 'lead_id');
    }

    public function dealer_follow_status()
    {
        return $this->hasMany(DealerHistory::class, 'followup_status_id');
    }
    public static function generateUniqCode($leadType)
    {
        if (!empty($leadType) && in_array($leadType, ['lead_code', 'assign_code',
        'test_drive_code','booking_code','purchase_code','dealer_count','spoc_count',
        'manager_count','telecaller_count'])) {
            $leadCount = LeadCount::first();
            if ($leadType == 'lead_code') {
                $prefix = 'L';
                $count = $leadCount->lead_count + 1;
                $leadCount->increment('lead_count');
            } elseif ($leadType == 'assign_code') {
                $prefix = 'A';
                $count = $leadCount->assign_count + 1;
                $leadCount->increment('assign_count');
            } elseif ($leadType == 'test_drive_code') {
                $prefix = 'TD';
                $count = $leadCount->test_drive_count + 1;
                $leadCount->increment('test_drive_count');
            } elseif ($leadType == 'booking_code') {
                $prefix = 'B';
                $count = $leadCount->booking_count + 1;
                $leadCount->increment('booking_count');
            } elseif ($leadType == 'purchase_code') {
                $prefix = 'P';
                $count = $leadCount->purchase_count + 1;
                $leadCount->increment('purchase_count');
            }
            elseif ($leadType == 'dealer_count') {
                $prefix = 'D';
                $count = $leadCount->dealer_count + 1;
                $leadCount->increment('dealer_count');
            }
            return 'COP'. date('my').$prefix.$count;
        }
        return null;
    }
}
