<?php

namespace App\Models\CRM;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ActivityType extends Model
{
    use HasFactory;
    protected $table = 'cop_activity_type';
    protected $primaryKey = 'at_id';
    protected $guarded = [];

    public function activity()
    {
        return $this->hasMany(LeadActivity::class,'at_id');
    }
}
