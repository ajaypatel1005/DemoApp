<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FaqCustomerLikes extends Model
{
    use HasFactory;
    protected $table = 'cop_faq_customer_likes';
    protected $primaryKey = 'id';
    protected $guarded = [];
}
