<?php

namespace App\Models\SEO;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MetaTag extends Model
{

    protected $table = 'cop_seo_meta_tags_ms';
    protected $primaryKey = 'meta_tag_id';

    use HasFactory;
}
