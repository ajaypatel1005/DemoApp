<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModelSafety extends Model
{
    use HasFactory;
    protected $table = 'cop_model_safety';
    protected $primaryKey = 'id';
    protected $guarded = [];

    protected $fillable = [
        'brand_id',
        'model_id',
        'heading',
        'description',
        'image',
        'status',
        'created_by'

    ];
}
