<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Conversation extends Model
{
    use HasFactory;
    protected $table = 'ticket_conversation';
    protected $guarded = [];

    /**
     * Define Relationship
     */
    public function agent(){
        return $this->belongsTo(User::class, 'agent_id' ,'id');
    }

    public function files(){
        return $this->hasMany(TicketFileManager::class, 'conversation_id' ,'id');
    }
}
