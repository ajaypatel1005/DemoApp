<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\Brand;
use App\Models\Model as BrandModel;
use App\Models\Customer;

class Wishlist extends Model
{
    use HasFactory;

    protected $table='cop_wl';
    protected $primaryKey ='wl_id';
    protected $guarded = [];

    public function brands()
    {
        return $this->belongsTo(Brand::class, 'brand_id');
    }

    public function models()
    {
        return $this->belongsTo(BrandModel::class, 'model_id');
    }

    public function customers()
    {
        return $this->belongsTo(Customer::class, 'customer_id');
    }
}
