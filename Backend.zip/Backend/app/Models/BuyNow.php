<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\ClientInfoTraits;
use App\Models\Model as ModelsModel;


class BuyNow extends Model
{
    use HasFactory;
    use ClientInfoTraits;

    protected $table = 'cop_buy_now';
    protected $primaryKey = 'buynow_id';
    protected $guarded = [];

    public function  car_model()
    {
        return $this->belongsTo(ModelsModel::class, 'model_id', 'model_id');
    }

    public function  variant()
    {
        return $this->belongsTo(Variant::class, 'variant_id', 'variant_id');
    }

}
