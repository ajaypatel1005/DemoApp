<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;

use App\Models\CRM\Dealer;
use App\Models\CRM\DealerHistory;
use App\Models\CRM\SpocPerson;
use App\Traits\ClientInfoTraits;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;
use Symfony\Component\HttpFoundation\Request;
use Illuminate\Support\Facades\Session;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles, LogsActivity, ClientInfoTraits;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];


    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];


    protected static $logAttributes = ['name', 'email', 'remember_token'];
    protected static $ignoreChangedAttributes = ['password', 'updated_at', 'remember_token'];

    public function getDescriptionForEvent(string $eventName): string
    {
        $eventNameMap = [
            'created' => 'created a new',
            'updated' => 'updated the',
            'deleted' => 'deleted the',
        ];

        return "User {$eventNameMap[$eventName]} Users record";
    }

    // Customize the activity log options
    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'email'])
            ->logExcept(['password', 'remember_token'])
            ->setDescriptionForEvent(fn (string $eventName) => $this->getDescriptionForEvent($eventName))
            ->useLogName('user_log')
            ->logFillable() // Log only fillable attributes
            ->logUnguarded(); // Log all attributes regardless of fillable or guarded
    }

    public function logLogin(string $guard): void
    {
        activity('user_log')
            ->event('login')
            ->performedOn($this)
            ->withProperties([
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log("User logged in (Guard: {$guard})");
    }

    public function logLogout(string $guard): void
    {
        activity('user_log')
            ->event('logout')
            ->performedOn($this)
            ->withProperties([
                'ip_address' => $this->getClientIpAddress(),
                'session_id' => $this->getClientSessionId(),
            ])
            ->log("User logged out (Guard: {$guard})");
    }


    public function dealer()
    {
        return $this->hasOne(Dealer::class, 'user_id');
    }

    public function spocs_data()
    {
        return $this->hasOne(SpocPerson::class, 'user_id');
    }

    public function current_user()
    {
        return $this->hasOne(DealerHistory::class, 'created_by');
    }

    public static function boot()
    {

        parent::boot();
        static::updating(function ($user) {
            // Check if the password attribute is being changed
            if ($user->isDirty('password')) {
                activity('user_log')
                    ->event('password_change')
                    ->performedOn($user)
                    ->withProperties([
                        'ip_address' => $user->getClientIpAddress(),
                        'session_id' => $user->getClientSessionId(),
                    ])
                    ->log("User changed their password");
            }
        });
    }
}
