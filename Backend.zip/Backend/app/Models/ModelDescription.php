<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModelDescription extends Model
{
    use HasFactory;
    protected $table = 'cop_model_desc';
    protected $primaryKey = 'id';
    protected $guarded = [];

    // protected $fillable = [
    //     'brand_id',
    //     'model_id',
    //     'variant_id',
    //     'description',
    //     'thing_like',
    //     'thing_improve',
    //     'status',
    //     'created_by'
     
    // ];
}
