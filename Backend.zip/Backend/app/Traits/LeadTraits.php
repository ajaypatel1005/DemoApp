<?php
namespace App\Traits;
use App\Models\CRM\Lead;
use App\Models\Manager; // Import the Manager model
use App\Models\User;
use Illuminate\Support\Facades\Session;

trait LeadTraits {
    public function setLeadManager($leadID) {
        $lead = Lead::where('lead_id', $leadID)->first();

        if (!$lead) {
            return response()->json(['message' => 'Lead not found.']);
        }

        // Note::if manager assign brand wise then also enable this condition
        // if (!$lead->brand_id) {
        //     return response()->json(['message' => 'Lead has no brand ID assigned.']);
        // }

        if ($lead->manager_user_id) {
            return response()->json(['message' => 'Lead already has a manager assigned.']);
        }

        // Fetch managers based on the brand_id condition
        $rmUserIds = User::role(config('constant.CRM_ROLE.RELATIONSHIP_MANAGER'))->pluck('id');

        // Begin:: Assign manager with brand

        // $managers = Manager::where('brand_id', $lead->brand_id)
        // ->whereIn('user_id', $rmUserIds)
        // ->where('status', 1)
        // ->pluck('user_id');

        // Begin:: Assign manager without brand

        $managers = Manager::whereIn('user_id', $rmUserIds)
                    ->where('status', 1)
                    ->pluck('user_id');
        // End:: Assign manager without brand

        // $managers = Manager::where('brand_id', $lead->brand_id)->pluck('user_id');

        if ($managers->isEmpty()) {
            return response()->json(['message' => 'No managers found for this brand.']);
        }

        // Check lead status for assign manager lead count
        $allStatuses = [config('constant.LEAD_STATUS.NEW'),
            config('constant.LEAD_STATUS.ASSIGNED'),
            config('constant.LEAD_STATUS.IN_PROGRESS')];

        // Calculate count of leads for each manager
        $managerCounts = [];
        foreach ($managers as $manager) {
            $count = Lead::
            where('manager_user_id', $manager)
            // where('brand_id', $lead->brand_id)
            ->whereIn('ls_status_id', $allStatuses)
            ->count();
            $managerCounts[$manager] = $count;
        }
        // dd($managerCounts);

        // Find the manager with the minimum count
        $minManager = array_keys($managerCounts, min($managerCounts))[0];
        $minCount = $managerCounts[$minManager];

        // Assign the lead to the manager with the minimum count
        $lead->manager_user_id = $minManager;
        $lead->save();

        return response()->json([
            'message' => 'Successfully assign lead'
        ]);
    }
}
