<?php

namespace App\Traits;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

trait LocationTrait
{
    public function getCurrentLocation(Request $request)
    {
        $clientIP = $request->ip;
        $apiURL = 'https://api.findip.net/' . $clientIP . '/?token=10b46528d1634ec8b00cc22ca39004a3';

        try {
            $response = Http::get($apiURL);
            $ipDetails = $response->json();
            
            $location = null;
            
            if (!empty($ipDetails) && isset($ipDetails['city']['names']['en'])) {
                $cityName = $ipDetails['city']['names']['en'];

                // Remove extra text in city name if present
                $extraText = strpos($cityName, '(');
                if ($extraText !== false && $extraText > 0) {
                    $cityName = substr($cityName, 0, $extraText);
                }

                $location = $cityName;
            }

            return $location;
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to fetch location details'], 500);
        }
    }
    public function getUserIP()
    {
        // Get real visitor IP behind CloudFlare network
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
            $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
            $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];

        if (filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }

        return $ip;
    }
}


