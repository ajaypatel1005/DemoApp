<?php
namespace App\Traits;

trait UniqueValidationTrait
{
    private function checkUniqueness($row, $field, &$uniqueValues, $errorMessage, $index)
    {
        $validationErrors = [];

        if (isset($row[$field])) {
            $value = $row[$field];
            if (in_array($value, $uniqueValues)) {
                $this->validationErrors[] = [
                    'row' => $index + 2,
                    'field' => $field,
                    'message' => $errorMessage,
                ];
            } else {
                $uniqueValues[] = $value;
            }
        }
        return $validationErrors;
    }

    public function getValidationErrors()
    {
        return $this->validationErrors;
    }
}


?>