<?php

namespace App\Http\Resources\SEO;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BrandResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray($request): array
    {
        return
            [
                'brand_id' => $this->brand_id,
                'brand_name' => $this->brand_name,
                'brand_logo' => $this->brand_logo,
                'brand_banner' => $this->brand_banner,
                'brand_description' => $this->brand_description,
                'slug' => $this->slug,
            ];
    }
}
