<?php

namespace App\Http\Resources\SEO;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SeoResource extends JsonResource
{
    public $sr_no = 0;
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return
        [
            'sr_no' => $this->sr_no++,
            'seo_id' => $this->seo_id,
            'brand_id' => $this->brand_id,
            'model_id' => $this->model_id,
            'variant_id' => $this->variant_id,
            'page_id' => $this->page_id,
            'meta_tag_id' => $this->meta_tag_id,
            'tag_content' => $this->tag_content,
            'seo_type' => $this->seo_type,
            'status' => $this->status,
            'brands' => $this->brands ? new BrandResource($this->brands) : null,
            'models_data' => $this->models_data ? new ModelResource($this->models_data) : null,
            'variants' => $this->variants ? new VariantResource($this->variants) : null,
            'page' => $this->page ? new BrandResource($this->page) : null,

        ];
    }
}
