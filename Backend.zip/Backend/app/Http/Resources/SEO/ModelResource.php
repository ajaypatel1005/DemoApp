<?php

namespace App\Http\Resources\SEO;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ModelResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray($request): array
    {
        return
            [
                'model_id' => $this->model_id,
                'model_name' => $this->model_name,
                'model_image' => $this->model_image,
                'model_description' => $this->model_description,
                'min_price' => $this->min_price,
                'max_price' => $this->max_price,
                'model_year' => $this->model_year,
                'slug' => $this->slug,
            ];
    }
}
