<?php

namespace App\Http\Resources\SEO;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MetaTagResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray($request): array
    {
        return
        [
            'meta_tag_id' => $this->meta_tag_id,
            'meta_tag_name' => $this->meta_tag_name
        ];
    }
}
