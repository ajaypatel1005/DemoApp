<?php

namespace App\Http\Resources\SEO;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class VariantResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray($request): array
    {
        return
            [
                'variant_id' => $this->variant_id,
                'variant_name' => $this->variant_name,
                'variant_image' => $this->variant_image,
                'seating_capacity' => $this->seating_capacity,
                'slug' => $this->slug,
            ];
    }
}
