<?php

namespace App\Http\Resources\SEO;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PageResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray($request): array
    {
        return
        [
            'page_id' => $this->page_id,
            'page_name' => $this->page_name,
            'page_current_url' => $this->page_current_url,
            'page_slug' => $this->page_slug
        ];
    }
}
