<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;

class CorsMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle($request, Closure $next)
    {
        // try {
        //     $allowedBaseUrl = 'http://192.168.2.119:8080';

        //     $requestBaseUrl = $request->getScheme() . '://' . $request->getHttpHost();

        //     // dd($requestBaseUrl);

        //     if ($requestBaseUrl !== $allowedBaseUrl) {
        //         return response()->json(['error' => 'Unauthorized'], 403);
        //     }
        //     $response = $next($request);
        //     $response->headers->set('Access-Control-Allow-Origin', $allowedBaseUrl);
        //     $response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        //     $response->headers->set('Access-Control-Allow-Headers', 'Origin, Content-Type, X-Auth-Token, Authorization');

        //     return $response;
        // } catch (Exception $e) {
        //     return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        // }
    }
}
