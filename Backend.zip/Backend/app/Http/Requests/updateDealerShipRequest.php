<?php

namespace App\Http\Requests;

use App\Rules\GoogleMapsURL;
use Illuminate\Foundation\Http\FormRequest;

class updateDealerShipRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'company_name' => 'required',
            'dealer_name' => 'required',
            'state_id' => 'required',
            'city_id' => 'required',
            'brand_id' => 'required',
            'address' => 'required',
            'map_location' => ['nullable', 'string', new GoogleMapsURL]
        ];
    }
    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'state_id.required' => 'Please select a state',
            'city_id.required' => 'Please select a city',
            'brand_id.required' => 'Please select a brand',
            'map_location.GoogleMapsURL' => 'The map url must be a valid Google Maps URL'
        ];
    }
}
