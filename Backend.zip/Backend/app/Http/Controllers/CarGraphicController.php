<?php

namespace App\Http\Controllers;

use App\Models\CarGraphicType;
use App\Models\Brand;
use App\Models\Model;
use Illuminate\Validation\Rule;
use Exception;
use App\Models\CarGraphic;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class CarGraphicController extends Controller
{
    //  fetch model-name from branch
    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');

        if ($selectedBrandId) {
            $models = Model::where('brand_id', $selectedBrandId)
                ->active()
                ->get(['model_name', 'model_id']);
        } else {
            $models = [];
        }

        $brands = Brand::active()->get();

        return response()->json(['models' => $models, 'brands' => $brands]);
    }

    //  Show the form for creating a new resource.
    public function create()
    {
        if (!hasAnyPermission(['create_car_graphic'])) {
            abort(403, "you don't have permission to access");
        }
        $model_name = Model::active()->get();
        $brand_name = Brand::active()->get();
        $gt_id = CarGraphicType::active()->get();

        return view('car_graphics.create', ['gt_id' => $gt_id, 'model_name' => $model_name, 'brand_name' => $brand_name]);
    }

    //  Store a newly created resource in storage.
    public function store(Request $request)
    {
        $request->validate([
            'brand_id' => 'required',
            'model_id' => 'required',
            // 'car_graphics_video' => 'mimes:mp4,mkv,avi,mov',
            'car_graphics_images.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_interior.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_exterior.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_images_360.*' => 'mimes:png,jpg,jpeg,webp',
            // 'car_graphics_video_mob' => 'mimes:mp4,mkv,avi,mov',
            'car_graphics_images_mob.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_interior_mob.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_exterior_mob.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_images_360_mob.*' => 'mimes:png,jpg,jpeg,webp',
        ], [
            'brand_id.required' => 'Brand name field is required.',
            'model_id.required' => 'Model name field is required.',
            // 'car_graphics_video.mimes' => 'Car graphic video file must be mp4,mkv,avi,mov.',
            'car_graphics_images.*.mimes' => 'Car graphic images file must be png,jpg,jpeg,webp',
            'car_graphics_interior.*.mimes' => 'Car graphic interior (images) file must be png,jpg,jpeg,webp',
            'car_graphics_exterior.*.mimes' => 'Car graphic exteriror (images) file must be png,jpg,jpeg,webp',
            'car_graphics_images_360.*.mimes' => 'Car graphic 360 images file must be png,jpg,jpeg,webp',
            // 'car_graphics_video_mob.mimes' => 'Car graphic video file must be mp4,mkv,avi,mov.',
            'car_graphics_images_mob.*.mimes' => 'Car graphic images file must be png,jpg,jpeg,webp',
            'car_graphics_interior_mob.*.mimes' => 'Car graphic interior (images) file must be png,jpg,jpeg,webp',
            'car_graphics_exterior_mob.*.mimes' => 'Car graphic exteriror (images) file must be png,jpg,jpeg,webp',
            'car_graphics_images_360_mob.*.mimes' => 'Car graphic 360 images file must be png,jpg,jpeg,webp',
        ]);

        if ($request->gt_id) {
            $model_id = $request->model_id;
            $request->validate([
                'gt_id' => [
                    'required',
                    Rule::unique('cop_graphics')->where(function ($query) use ($model_id) {
                        return $query->where('model_id', $model_id);
                    }),
                ],
            ], [
                'gt_id.required' => 'Car graphic type name field is required.',
                'gt_id.unique' => 'Car graphic type for this model has already been taken.',
            ]);
        }
        DB::beginTransaction();
        try {
            $car_graphic_store = new CarGraphic();

            if (!empty($car_graphic_store)) {

                $car_graphic_store->brand_id = $request->brand_id;
                $car_graphic_store->model_id = $request->model_id;
                $car_graphic_store->gt_id = $request->gt_id;
                $car_graphic_store->status = $request->has('status') ? 1 : 0;
                $car_graphic_store->created_by = auth()->id();

                // to store images / interior / exterior / images_360
                if ($request->hasFile('car_graphics_images') || $request->hasFile('car_graphics_interior') || $request->hasFile('car_graphics_exterior') || $request->hasFile('car_graphics_images_360')) {
                    $images = [];
                    $images_mob = [];

                    if ($request->hasFile('car_graphics_images')) {
                        $imageFolder = 'images';
                        $images = $request->file('car_graphics_images');
                        $images_mob = $request->file('car_graphics_images_mob');
                    }
                    if ($request->hasFile('car_graphics_interior')) {
                        $imageFolder = 'interior';
                        $images = $request->file('car_graphics_interior');
                        $images_mob = $request->file('car_graphics_interior_mob');
                    }
                    if ($request->hasFile('car_graphics_exterior')) {
                        $imageFolder = 'exterior';
                        $images = $request->file('car_graphics_exterior');
                        $images_mob = $request->file('car_graphics_exterior_mob');
                    }
                    if ($request->hasFile('car_graphics_images_360')) {
                        $imageFolder = 'images_360';
                        $images = $request->file('car_graphics_images_360');
                        $images_mob = $request->file('car_graphics_images_360_mob');
                    }

                    // Sort the images by its original name (because we have also sort the images by its original name on images preview script)
                    $images = collect($images)->sortBy(function ($file) {
                        return $file->getClientOriginalName();
                    })->values()->all();

                    // for desktop
                    $i = 1;
                    $all_images = [];
                    $all_images_alt = [];
                    $altTagsForDesktop = $request->altTagForDesktop; // Get the alt tags array
                    foreach ($images as $index => $item) {
                        $time = date('dmYHis');
                        $imageWebpImageName = $car_graphic_store->model_id . '_' . $time . '_' . $i . '.webp';

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());
                        $image = $manager->read($item);

                        // store in digital_ocean_spaces
                        $DoPath = 'car_graphics' . '/' . $car_graphic_store->model_id . '/' . $imageFolder . '/' . $imageWebpImageName;
                        Storage::disk('digitalocean')->put($DoPath, $image->toWebp(), 'public');

                        $image->resize(1400, 570); // For Thumb Image

                        // store in digital_ocean_spaces for Thumb
                        $DoPathThumb = 'car_graphics' . '/' . $car_graphic_store->model_id . '/' . $imageFolder . '/' . 'thumb/' . $imageWebpImageName;
                        Storage::disk('digitalocean')->put($DoPathThumb, $image->toWebp(), 'public');

                        $all_images[] = $imageWebpImageName;
                        $all_images_alt[] = $altTagsForDesktop[$index];
                        $i++;
                    }

                    // Sort the images by its original name (because we have also sort the images by its original name on images preview script)
                    $images_mob = collect($images_mob)->sortBy(function ($file) {
                        return $file->getClientOriginalName();
                    })->values()->all();

                    // for mobile
                    $a = 1;
                    $all_images_mob = [];
                    $all_images_mob_alt = [];
                    $altTagsForMobile = $request->altTagForMobile; // Get the alt tags array
                    foreach ($images_mob as $index => $item) {
                        $time = date('dmYHis');
                        $imageWebpImageNameMob = $car_graphic_store->model_id . '_' . $time . '_' . $a . '.webp';

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());
                        $image_mob = $manager->read($item);

                        // store in digital_ocean_spaces
                        $DoPathMob = 'car_graphics' . '/' . $car_graphic_store->model_id . '/' . $imageFolder . '/' . 'mobile/' . $imageWebpImageNameMob;
                        Storage::disk('digitalocean')->put($DoPathMob, $image_mob->toWebp(), 'public');

                        $all_images_mob[] = $imageWebpImageNameMob;
                        $all_images_mob_alt[] = $altTagsForMobile[$index];
                        $a++;
                    }

                    $image_name_for_db = implode(',', $all_images);
                    $image_name_for_db_mob = implode(',', $all_images_mob);
                    $car_graphic_store->graphic_file = $image_name_for_db;
                    $car_graphic_store->graphic_file_mob = $image_name_for_db_mob;

                    $car_graphic_store->graphic_file_alt = implode(',', $all_images_alt);
                    $car_graphic_store->graphic_file_mob_alt = implode(',', $all_images_mob_alt);
                }

                // to store video
                if ($request->hasFile('car_graphics_video')) {

                    $videoFile = $request->file('car_graphics_video');

                    $time = date('dmYHis');
                    $imageVideoName = $car_graphic_store->model_id . '_' . $time . '_video.mp4';

                    // Store in DigitalOcean Spaces
                    $DoPath = 'car_graphics/' . $car_graphic_store->model_id . '/video/' . $imageVideoName;
                    Storage::disk('digitalocean')->put($DoPath, file_get_contents($videoFile), 'public');

                    $car_graphic_store->graphic_file = $imageVideoName;
                }

                $car_graphic_store->save();
                DB::commit();
                session()->flash('success', 'Car Graphic Added Successfully.');
                return redirect()->route('car_graphic.view');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_graphic.view');
    }

    //  Display the specified resource.
    public function view()
    {
        if (!hasAnyPermission(['view_car_graphic'])) {
            abort(403, "you don't have permission to access");
        }
        $car_graphic_view = CarGraphic::leftJoin('cop_gt_ms', 'cop_gt_ms.gt_id', '=', 'cop_graphics.gt_id')
            ->leftJoin('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_graphics.brand_id')
            ->leftJoin('cop_models', 'cop_models.model_id', '=', 'cop_graphics.model_id')
            ->select('cop_brands_ms.brand_name', 'cop_models.model_name', 'cop_models.model_id', 'cop_gt_ms.gt_name', 'cop_graphics.graphic_file', 'cop_graphics.graphic_id', 'cop_graphics.status')
            ->where([['cop_brands_ms.status', '=', 1], ['cop_models.status', '=', 1]])
            ->get();

        return view('car_graphics.view', ['car_graphic_view' => $car_graphic_view]);
    }

    //  Show the form for editing the specified resource.
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_car_graphic'])) {
            abort(403, "you don't have permission to access");
        }
        $brand_name = Brand::active()->get();
        $model_name = Model::active()->get();
        $gt_id = CarGraphicType::active()->get();
        $car_graphic_edit = CarGraphic::join('cop_gt_ms', 'cop_gt_ms.gt_id', '=', 'cop_graphics.gt_id')->where('graphic_id', decrypt($id))->first();
        $cop_graphic = CarGraphic::where('graphic_id', decrypt($id))->first();

        return view('car_graphics.edit', ['car_graphic_edit' => $car_graphic_edit, 'gt_id' => $gt_id, 'model_name' => $model_name, 'brand_name' => $brand_name, 'cop_graphic_status' => $cop_graphic]);
    }

    //  Update the specified resource in storage.
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_car_graphic'])) {
            abort(403, "you don't have permission to access");
        }

        $request->validate([
            'brand_id' => 'required',
            'model_id' => 'required',
            // 'car_graphics_video' => 'mimes:mp4,mkv,avi,mov',
            'car_graphics_images.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_interior.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_exterior.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_images_360.*' => 'mimes:png,jpg,jpeg,webp',
            // 'car_graphics_video_mob' => 'mimes:mp4,mkv,avi,mov',
            'car_graphics_images_mob.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_interior_mob.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_exterior_mob.*' => 'mimes:png,jpg,jpeg,webp',
            'car_graphics_images_360_mob.*' => 'mimes:png,jpg,jpeg,webp',
        ], [
            'brand_id.required' => 'Brand name field is required.',
            'model_id.required' => 'Model name field is required.',
            // 'car_graphics_video.mimes' => 'Car graphic video file must be mp4,mkv,avi,mov.',
            'car_graphics_images.*.mimes' => 'Car graphic images file must be png,jpg,jpeg,webp',
            'car_graphics_interior.*.mimes' => 'Car graphic interior (images) file must be png,jpg,jpeg,webp',
            'car_graphics_exterior.*.mimes' => 'Car graphic exteriror (images) file must be png,jpg,jpeg,webp',
            'car_graphics_images_360.*.mimes' => 'Car graphic 360 images file must be png,jpg,jpeg,webp',
            // 'car_graphics_video_mob.mimes' => 'Car graphic video file must be mp4,mkv,avi,mov.',
            'car_graphics_images_mob.*.mimes' => 'Car graphic images file must be png,jpg,jpeg,webp',
            'car_graphics_interior_mob.*.mimes' => 'Car graphic interior (images) file must be png,jpg,jpeg,webp',
            'car_graphics_exterior_mob.*.mimes' => 'Car graphic exteriror (images) file must be png,jpg,jpeg,webp',
            'car_graphics_images_360_mob.*.mimes' => 'Car graphic 360 images file must be png,jpg,jpeg,webp',
        ]);

        if ($request->gt_id) {
            $model_id = $request->model_id;
            $request->validate([
                'gt_id' => [
                    'required',
                    Rule::unique('cop_graphics')->where(function ($query) use ($model_id) {
                        return $query->where('model_id', $model_id);
                    })->ignore(decrypt($id), 'graphic_id'),
                ],
            ], [
                'gt_id.required' => 'Car graphic type name field is required.',
                'gt_id.unique' => 'Car graphic type for this model has already been taken.',
            ]);
        }
        DB::beginTransaction();
        try {
            $altTagForDesktop = implode(',', $request->altTagForDesktop);
            $altTagForMobile = implode(',', $request->altTagForMobile);
            $car_graphic_update = CarGraphic::where('graphic_id', decrypt($id))->first();
            $old_model_id = $car_graphic_update->model_id;
            if (!empty($car_graphic_update)) {
                $car_graphic_update->brand_id = $request->brand_id;
                $car_graphic_update->model_id = $request->model_id;
                $car_graphic_update->graphic_file_alt = preg_replace('/\s*,\s*/', ',', $altTagForDesktop);
                $car_graphic_update->graphic_file_mob_alt = preg_replace('/\s*,\s*/', ',', $altTagForMobile);
                $car_graphic_update->gt_id = $request->gt_id;
                $car_graphic_update->status = $request->has('status') ? 1 : 0;

                // to update images / interior / exterior
                if ($request->hasFile('car_graphics_images') || $request->hasFile('car_graphics_interior') || $request->hasFile('car_graphics_exterior') || $request->hasFile('car_graphics_images_360') || $request->hasFile('car_graphics_images_mob') || $request->hasFile('car_graphics_interior_mob') || $request->hasFile('car_graphics_exterior_mob') || $request->hasFile('car_graphics_images_360_mob')) {
                    $images = [];
                    $images_mob = [];

                    if ($request->hasFile('car_graphics_images')) {
                        $image_folder = 'images';
                        $images = $request->file('car_graphics_images');
                    }
                    if ($request->hasFile('car_graphics_images_mob')) {
                        $image_folder = 'images';
                        $images_mob = $request->file('car_graphics_images_mob');
                    }
                    if ($request->hasFile('car_graphics_interior')) {
                        $image_folder = 'interior';
                        $images = $request->file('car_graphics_interior');
                    }
                    if ($request->hasFile('car_graphics_interior_mob')) {
                        $image_folder = 'interior';
                        $images_mob = $request->file('car_graphics_interior_mob');
                    }
                    if ($request->hasFile('car_graphics_exterior')) {
                        $image_folder = 'exterior';
                        $images = $request->file('car_graphics_exterior');
                    }
                    if ($request->hasFile('car_graphics_exterior_mob')) {
                        $image_folder = 'exterior';
                        $images_mob = $request->file('car_graphics_exterior_mob');
                    }
                    if ($request->hasFile('car_graphics_images_360')) {
                        $image_folder = 'images_360';
                        $images = $request->file('car_graphics_images_360');
                    }
                    if ($request->hasFile('car_graphics_images_360_mob')) {
                        $image_folder = 'images_360';
                        $images_mob = $request->file('car_graphics_images_360_mob');
                    }

                    // for desktop
                    $i = 1;
                    $all_images = [];
                    foreach ($images as $item) {
                        $time = date('dmYHis');
                        $imageWebpImageName = $car_graphic_update->model_id . '_' . $time . '_' . $i . '.webp';

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());
                        $image = $manager->read($item);

                        // store in digital_ocean_spaces
                        $DoPath = 'car_graphics' . '/' . $car_graphic_update->model_id . '/' . $image_folder . '/' . $imageWebpImageName;
                        Storage::disk('digitalocean')->put($DoPath, $image->toWebp(), 'public');

                        $image->resize(1400, 570); // For Thumb Image

                        // store in digital_ocean_spaces
                        $DoPathThumb = 'car_graphics' . '/' . $car_graphic_update->model_id . '/' . $image_folder . '/' . 'thumb/' . $imageWebpImageName;
                        Storage::disk('digitalocean')->put($DoPathThumb, $image->toWebp(), 'public');

                        $all_images[] = $imageWebpImageName;
                        $i++;
                    }

                    // for mobile
                    $a = 1;
                    $all_images_mob = [];
                    foreach ($images_mob as $item) {
                        $time = date('dmYHis');
                        $imageWebpImageNameMob = $car_graphic_update->model_id . '_' . $time . '_' . $a . '.webp';

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());
                        $image_mob = $manager->read($item);

                        // store in digital_ocean_spaces
                        $DoPathMob = 'car_graphics' . '/' . $car_graphic_update->model_id . '/' . $image_folder . '/' . 'mobile/' . $imageWebpImageNameMob;
                        Storage::disk('digitalocean')->put($DoPathMob, $image_mob->toWebp(), 'public');

                        $all_images_mob[] = $imageWebpImageNameMob;
                        $a++;
                    }

                    if ($request->hasFile('car_graphics_images')) {
                        if ($request->old_car_graphic_images == '') {
                            $image_name_for_db = implode(',', $all_images);
                            $car_graphic_update->graphic_file = $image_name_for_db;
                        } else {
                            $image_name_for_db = implode(',', $all_images);
                            $old_car_graphic_images = $request->old_car_graphic_images;

                            $car_graphic_update->graphic_file = $old_car_graphic_images . ',' . $image_name_for_db;
                        }
                    }
                    if ($request->hasFile('car_graphics_images_mob')) {
                        if ($request->old_car_graphic_images_mob == '') {
                            $image_name_for_db_mob = implode(',', $all_images_mob);
                            $car_graphic_update->graphic_file_mob = $image_name_for_db_mob;
                        } else {
                            $image_name_for_db_mob = implode(',', $all_images_mob);
                            $old_car_graphic_images_mob = $request->old_car_graphic_images_mob;

                            $car_graphic_update->graphic_file_mob = $old_car_graphic_images_mob . ',' . $image_name_for_db_mob;
                        }
                    }
                    if ($request->hasFile('car_graphics_interior')) {
                        if ($request->old_car_graphic_interior == '') {
                            $image_name_for_db = implode(',', $all_images);
                            $car_graphic_update->graphic_file = $image_name_for_db;
                        } else {
                            $image_name_for_db = implode(',', $all_images);
                            $old_car_graphic_interior = $request->old_car_graphic_interior;

                            $car_graphic_update->graphic_file = $old_car_graphic_interior . ',' . $image_name_for_db;
                        }
                    }
                    if ($request->hasFile('car_graphics_interior_mob')) {
                        if ($request->old_car_graphic_interior_mob == '') {
                            $image_name_for_db_mob = implode(',', $all_images_mob);
                            $car_graphic_update->graphic_file_mob = $image_name_for_db_mob;
                        } else {
                            $image_name_for_db_mob = implode(',', $all_images_mob);
                            $old_car_graphic_interior_mob = $request->old_car_graphic_interior_mob;
                            // dd($old_car_graphic_interior_mob . ',' . $image_name_for_db_mob);
                            $car_graphic_update->graphic_file_mob = $old_car_graphic_interior_mob . ',' . $image_name_for_db_mob;
                        }
                    }
                    if ($request->hasFile('car_graphics_exterior')) {
                        if ($request->old_car_graphic_exterior == '') {
                            $image_name_for_db = implode(',', $all_images);
                            $car_graphic_update->graphic_file = $image_name_for_db;
                        } else {
                            $image_name_for_db = implode(',', $all_images);
                            $old_car_graphic_exterior = $request->old_car_graphic_exterior;

                            $car_graphic_update->graphic_file = $old_car_graphic_exterior . ',' . $image_name_for_db;
                        }
                    }
                    if ($request->hasFile('car_graphics_exterior_mob')) {
                        if ($request->old_car_graphic_exterior_mob == '') {
                            $image_name_for_db_mob = implode(',', $all_images_mob);
                            $car_graphic_update->graphic_file_mob = $image_name_for_db_mob;
                        } else {
                            $image_name_for_db_mob = implode(',', $all_images_mob);
                            $old_car_graphic_exterior_mob = $request->old_car_graphic_exterior_mob;

                            $car_graphic_update->graphic_file_mob = $old_car_graphic_exterior_mob . ',' . $image_name_for_db_mob;
                        }
                    }
                    if ($request->hasFile('car_graphics_images_360')) {
                        if ($request->old_car_graphic_images_360 == '') {
                            $image_name_for_db = implode(',', $all_images);
                            $car_graphic_update->graphic_file = $image_name_for_db;
                        } else {
                            $image_name_for_db = implode(',', $all_images);
                            $old_car_graphic_images_360 = $request->old_car_graphic_images_360;

                            $car_graphic_update->graphic_file = $old_car_graphic_images_360 . ',' . $image_name_for_db;
                        }
                    }
                    if ($request->hasFile('car_graphics_images_360_mob')) {
                        if ($request->old_car_graphic_images_360_mob == '') {
                            $image_name_for_db_mob = implode(',', $all_images_mob);
                            $car_graphic_update->graphic_file_mob = $image_name_for_db_mob;
                        } else {
                            $image_name_for_db_mob = implode(',', $all_images_mob);
                            $old_car_graphic_images_360_mob = $request->old_car_graphic_images_360_mob;

                            $car_graphic_update->graphic_file_mob = $old_car_graphic_images_360_mob . ',' . $image_name_for_db_mob;
                        }
                    }
                }

                // if brand / model changed then move all images of this car-graphic-type to new model_id folder
                if ($old_model_id != $request->model_id) {
                    $get_gt_name = CarGraphicType::select('gt_name')->where('gt_id', $car_graphic_update->gt_id)->first();
                    $image_folder = str_replace(' ', '_', strtolower($get_gt_name->gt_name));
                    
                    $mobileImagePathFrom = 'car_graphics' . '/' . $old_model_id . '/' . $image_folder . '/' . 'mobile/';
                    $mobileImagePathTo = 'car_graphics' . '/' . $request->model_id . '/' . $image_folder . '/' . 'mobile/';
                    
                    $mainImagePathFrom = 'car_graphics' . '/' . $old_model_id . '/' . $image_folder . '/';
                    $mainImagePathTo = 'car_graphics' . '/' . $request->model_id . '/' . $image_folder . '/';

                    if (Storage::disk('digitalocean')->exists($mobileImagePathFrom)) {
                        // Get all files
                        $files = Storage::disk('digitalocean')->allFiles($mobileImagePathFrom);

                        // foreach files
                        foreach ($files as $file) {
                            // Construct the new file path with the same file name in the new directory
                            $newMobileFilePath = str_replace($mobileImagePathFrom, $mobileImagePathTo, $file);

                            Storage::disk('digitalocean')->move($file, $newMobileFilePath);
                        }

                        // Only delete the directory if all files have been successfully moved
                        if (empty(Storage::disk('digitalocean')->allFiles($mobileImagePathFrom))) {
                            Storage::disk('digitalocean')->deleteDirectory($mobileImagePathFrom);
                        }
                    }

                    if (Storage::disk('digitalocean')->exists($mainImagePathFrom)) {
                        // Get all files
                        $files = Storage::disk('digitalocean')->allFiles($mainImagePathFrom);

                        // foreach files
                        foreach ($files as $file) {
                            // Construct the new file path with the same file name in the new directory
                            $newMainFilePath = str_replace($mainImagePathFrom, $mainImagePathTo, $file);

                            Storage::disk('digitalocean')->move($file, $newMainFilePath);
                        }

                        // Only delete the directory if all files have been successfully moved
                        if (empty(Storage::disk('digitalocean')->allFiles($mainImagePathFrom))) {
                            Storage::disk('digitalocean')->deleteDirectory($mainImagePathFrom);
                        }
                    }
                }

                // to update video
                if ($request->hasFile('car_graphics_video')) {
                    $videoFile = $request->file('car_graphics_video');

                    $oldVideoName = $car_graphic_update->graphic_file;

                    // delete first from digital_ocean_spaces
                    if ($oldVideoName) {
                        $DoPath = 'car_graphics/' . $car_graphic_update->model_id . '/' . 'video/' . $oldVideoName;
                        Storage::disk('digitalocean')->delete($DoPath, 'public');
                    }

                    $time = date('dmYHis');
                    $newVideoName = $car_graphic_update->model_id . '_' . $time . '_video.mp4';

                    // store again the new video in digital_ocean_spaces
                    $DoPath = 'car_graphics/' . $car_graphic_update->model_id . '/' . 'video/' . $newVideoName;
                    Storage::disk('digitalocean')->put($DoPath, file_get_contents($videoFile), 'public');

                    $car_graphic_update->graphic_file = $newVideoName;
                }

                $car_graphic_update->save();
                DB::commit();
                session()->flash('success', 'Car Graphic Type Updated Successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_graphic.view');
    }

    //  Remove the specified resource from storage.
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_car_graphic'])) {
            abort(403, "you don't have permission to access");
        }
        DB::beginTransaction();
        try {
            $car_graphic_destroy = CarGraphic::where('graphic_id', decrypt($id))->first();
            $gt_id = $car_graphic_destroy->gt_id;
            $car_graphic_type = CarGraphicType::where('gt_id', $gt_id)->value('gt_name');

            $oldFile = $car_graphic_destroy->graphic_file;

            if ($car_graphic_type == "Video") {
                if ($oldFile) {
                    // delete from digital_ocean_spaces
                    $DoPath = 'car_graphics/' . $car_graphic_destroy->model_id . '/' . 'video/';
                    Storage::disk('digitalocean')->deleteDirectory($DoPath, 'public');
                }
            } elseif ($car_graphic_type == "Images" || $car_graphic_type == "Interior" || $car_graphic_type == "Exterior" || $car_graphic_type == "Images 360") {
                if ($oldFile) {

                    if ($car_graphic_type == "Images") {
                        $imageFolder = 'images';
                    } elseif ($car_graphic_type == "Interior") {
                        $imageFolder = 'interior';
                    } elseif ($car_graphic_type == "Exterior") {
                        $imageFolder = 'exterior';
                    } elseif ($car_graphic_type == "Images 360") {
                        $imageFolder = 'images_360';
                    }

                    // delete full directory from digital_ocean_spaces
                    $bucketFolder = 'car_graphics/' . $car_graphic_destroy->model_id . '/' . $imageFolder;
                    Storage::disk('digitalocean')->deleteDirectory($bucketFolder);
                }
            }

            if (!empty($car_graphic_destroy)) {
                $car_graphic_destroy->delete();
                DB::commit();
                session()->flash('success', 'Car Graphic Deleted Successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('car_graphic.view');
    }

    //  Status change function.
    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_graphics')
            ->where('graphic_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status Updated Successfully']);
    }

    //  Delete Single-Image from Car Graphics Images using AJAX
    public function DelectSingleImage(Request $request)
    {
        $graphic_id = $request->graphic_id;
        $image_delete = $request->image_to_be_delete;
        $car_graphics = CarGraphic::where('graphic_id', $graphic_id)->first();
        $graphic_name = $request->graphic_name;

        $arr_all_images = explode(",", $car_graphics->graphic_file);
        $arr_all_images_alt = explode(",", $car_graphics->graphic_file_alt);

        // find the index/key of the image and alt tag to delete
        $image_index = array_search($image_delete, $arr_all_images);
        $alt_tag_index = array_search($request->alt_tag_to_be_delete, $arr_all_images_alt);

        if ($image_index !== false && $alt_tag_index !== false) {
            // remove the image and the corresponding alt tag at the same index
            array_splice($arr_all_images, $image_index, 1);
            array_splice($arr_all_images_alt, $alt_tag_index, 1);

            // delete single image from DigitalOcean Spaces
            $DoDeleteImage = 'car_graphics/' . $car_graphics->model_id . '/' . $graphic_name . '/' . $image_delete;
            Storage::disk('digitalocean')->delete($DoDeleteImage);

            // delete single thumbnail image from DigitalOcean Spaces
            $DoDeleteImageThumb = 'car_graphics/' . $car_graphics->model_id . '/' . $graphic_name . '/thumb/' . $image_delete;
            Storage::disk('digitalocean')->delete($DoDeleteImageThumb);

            $new_car_graphic_image = implode(',', $arr_all_images);
            $new_car_graphic_image_alt = implode(',', $arr_all_images_alt);

            CarGraphic::where('graphic_id', $graphic_id)->update([
                'graphic_file' => $new_car_graphic_image,
                'graphic_file_alt' => $new_car_graphic_image_alt
            ]);
        }

        $arr = CarGraphic::where('graphic_id', $graphic_id)->get();
        echo view('car_graphics.ajax_view_images', ['new_data' => $arr, 'graphic_name' => $graphic_name]);
    }

    //  Delete Single-Image from Car Graphics Images using AJAX (For Mobile)
    public function DelectSingleImageMob(Request $request)
    {
        $graphic_id = $request->graphic_id;
        $image_delete = $request->image_to_be_delete;
        $car_graphics = CarGraphic::where('graphic_id', $graphic_id)->first();
        $graphic_name = $request->graphic_name;

        $arr_all_images_mob = explode(",", $car_graphics->graphic_file_mob);
        $arr_all_images_mob_alt = explode(",", $car_graphics->graphic_file_mob_alt);

        // find the index of the image and alt tag to delete
        $image_index_mob = array_search($image_delete, $arr_all_images_mob);
        $alt_tag_index_mob = array_search($request->alt_tag_to_be_delete, $arr_all_images_mob_alt);

        if ($image_index_mob !== false && $alt_tag_index_mob !== false) {
            // remove the image and the corresponding alt tag at the same index
            array_splice($arr_all_images_mob, $image_index_mob, 1);
            array_splice($arr_all_images_mob_alt, $alt_tag_index_mob, 1);

            // delete single image from DigitalOcean Spaces for Mobile
            $DoDeleteImageMob = 'car_graphics/' . $car_graphics->model_id . '/' . $graphic_name . '/mobile/' . $image_delete;
            Storage::disk('digitalocean')->delete($DoDeleteImageMob);

            $new_car_graphic_image_mob = implode(',', $arr_all_images_mob);
            $new_car_graphic_image_mob_alt = implode(',', $arr_all_images_mob_alt);

            CarGraphic::where('graphic_id', $graphic_id)->update([
                'graphic_file_mob' => $new_car_graphic_image_mob,
                'graphic_file_mob_alt' => $new_car_graphic_image_mob_alt
            ]);
        }

        $arr = CarGraphic::where('graphic_id', $graphic_id)->get();
        echo view('car_graphics.ajax_view_images_mob', ['new_data' => $arr, 'graphic_name' => $graphic_name]);
    }

    // server side data table to reduce load
    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            $limit = ($request->has('length') ? $request->input('length') : 10);
            $page = ($request->has('start') ? $request->input('start') : 0);
            $search = ($request->has('search') ? $request->input('search')['value'] : '');

            $car_graphics_view = CarGraphic::select(
                'cop_graphics.graphic_id',
                'cop_graphics.brand_id',
                'cop_graphics.model_id',
                'cop_graphics.graphic_file',
                'cop_graphics.status',
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_gt_ms.gt_name'
            )
                ->join('cop_models', 'cop_graphics.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_graphics.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_gt_ms', 'cop_graphics.gt_id', '=', 'cop_gt_ms.gt_id')
                ->where([['cop_gt_ms.status', '=', 1], ['cop_brands_ms.status', '=', 1], ['cop_models.status', '=', 1]]);

            if (!empty($search)) {
                $car_graphics_view->where(function ($query) use ($search) {
                    $query->orWhere('cop_brands_ms.brand_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('cop_models.model_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('cop_gt_ms.gt_name', 'LIKE', '%' . $search . '%');
                });
            }

            $cntFilter = clone $car_graphics_view;
            $car_graphics_view->offset($page)->limit($limit);
            $car_graphics_view = $car_graphics_view->get();

            $stateTotal = DB::select("SELECT COUNT(*) AS count FROM cop_graphics INNER JOIN cop_brands_ms ON cop_brands_ms.brand_id = cop_graphics.brand_id INNER JOIN cop_models ON cop_models.model_id = cop_graphics.model_id INNER JOIN cop_gt_ms ON cop_gt_ms.gt_id = cop_graphics.gt_id WHERE cop_brands_ms.status = 1 AND cop_models.status = 1 AND cop_gt_ms.status = 1")[0]->count;
            $data = [];
            $i = $page;
            foreach ($car_graphics_view as $member) {
                $i++;
                $status = $disable = "";
                if ($member->status == 1) {
                    $status = 'checked';
                }
                $disable = (!auth()->user()->can('edit_car_graphic')) ? 'disabled' : '';

                $model_status = '<div class="form-check form-switch form-check-custom form-check-success form-check-solid">
                    <input class="form-check-input" name="status" type="checkbox" value="' . $member->graphic_id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>';

                $action = "";
                if (auth()->user()->can('edit_car_graphic')) {
                    $editRoute = route('car_graphic.edit', encrypt($member->graphic_id));
                    $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                            <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                }

                if (auth()->user()->can('delete_car_graphic')) {
                    $action .= '<a href="javascript:void(0);"
                        data-href="' . route('car_graphic.destroy', encrypt($member->graphic_id)) . '"
                        class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                }
                $data[] = array("sr_no" => $i, "brand_name" => $member->brand_name, "model_name" => $member->model_name, "graphic_type" => $member->gt_name, "status" => $model_status, "action" => $action);
            }
            return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $stateTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
        }
    }
}
