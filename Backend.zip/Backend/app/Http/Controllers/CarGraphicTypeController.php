<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Log;
use App\Models\CarGraphicType;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CarGraphicTypeController extends Controller
{

//  Show the form for creating a new resource.
    public function create()
    {
        if (!hasAnyPermission(['create_car_graphic_type', 'view_car_graphic_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $car_graphic_type_view = CarGraphicType::get();
        return view('car_graphic_type.create', ['car_graphic_type_view' => $car_graphic_type_view]);
    }

//    Store a newly created resource in storage.
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_car_graphic_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'gt_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:5|max:20|unique:cop_gt_ms,gt_name',
        ],[
            'gt_name.required' => 'Car graphic type name field is required.',
            'gt_name.regex' => 'Car graphic type name field format is invalid (Special characters not allowed).',
            'gt_name.min' => 'Car graphic type name field must be at least 5 characters.',
            'gt_name.max' => 'Car graphic type name field must not be greater than 20 characters.',
            'gt_name.unique' => 'Car graphic type name has already been taken.',
        ]);
        DB::beginTransaction();
        try{
            $car_graphic_type_store = new CarGraphicType();
            if (!empty($car_graphic_type_store)) {
                $car_graphic_type_store->gt_name = $request->gt_name;
                $car_graphic_type_store->status = $request->has('status') ? 1 : 0;
                $car_graphic_type_store->save();
                DB::commit();
                session()->flash('success', 'Car Graphic Type Added Successfully.');
            }
        } catch(Exception $e){
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_graphic_type.create');
    }

//    Show the form for editing the specified resource.
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_car_graphic_type', 'view_car_graphic_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $car_graphic_type_edit = CarGraphicType::where('gt_id', decrypt($id))->first();
        $car_graphic_type_view = CarGraphicType::get();
        return view('car_graphic_type.edit', ['car_graphic_type_edit' => $car_graphic_type_edit,'car_graphic_type_view' => $car_graphic_type_view]);
    }

//    Update the specified resource in storage.
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_car_graphic_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'gt_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:5|max:20|unique:cop_gt_ms,gt_name,'.decrypt($id).',gt_id',
        ],[
            'gt_name.required' => 'The car graphic type name field is required.',
            'gt_name.regex' => 'The car graphic type name field format is invalid (Special characters not allowed).',
            'gt_name.min' => 'The car graphic type name field must be at least 5 characters.',
            'gt_name.max' => 'The car graphic type name field must not be greater than 20 characters.',
            'gt_name.unique' => 'The car graphic type name has already been taken.',
        ]);
        DB::beginTransaction();
        try{
            $car_graphic_type_update = CarGraphicType::where('gt_id', decrypt($id))->first();
            if ($car_graphic_type_update) {
                $car_graphic_type_update->gt_name = $request->gt_name;
                $car_graphic_type_update->status = $request->has('status') ? 1 : 0;
                $car_graphic_type_update->save();
                DB::commit();
                session()->flash('success', 'Car Graphic Type Updated Successfully.');
            }
        } catch(Exception $e){
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_graphic_type.create');
    }

//    Remove the specified resource from storage.
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_car_graphic_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try{
            $car_graphic_type_destroy = CarGraphicType::where('gt_id', decrypt($id))->first();
            if (!empty($car_graphic_type_destroy)) {
                if ($car_graphic_type_destroy->car_graphic->isNotEmpty()) {
                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('car_graphic_type.create');
                }
                $car_graphic_type_destroy->delete();
                DB::commit();
                session()->flash('success', 'Car Graphic Type Deleted Successfully.');
            }
        } catch(Exception $e){
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_graphic_type.create');
    }

//    Status change function.
    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_gt_ms')
            ->where('gt_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
}
