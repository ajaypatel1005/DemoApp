<?php

namespace App\Http\Controllers;


use App\Models\WarningLight;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Exception;
use Illuminate\Support\Facades\Storage;

class WarningLightController extends Controller
{

    public function create()
    {
        if (!hasAnyPermission(['create_car_warning_light'])) {
            abort(403, "you don't have permission to access");
        }
        return view('warning_light.create');
    }


    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_car_warning_light'])) {
            abort(403, "you don't have permission to access");
        }

        $request->validate(
            [
                'wl_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:100|unique:cop_cwl_ms,wl_name',
                'wl_heading' => 'required|regex:/^[\\/A-Za-z\s]+$/|min:2|max:100|unique:cop_cwl_ms,wl_heading',
                'subheadings' => 'required',
                'wl_dp' => 'required',
                'wl_icon' => 'required|image|mimes:svg|unique:cop_cwl_ms,wl_icon|max:2048',
                'wl_video' => 'nullable'
            ],
            [
                'wl_name.required' => 'Warning Light Name Required',
                'wl_dp.required' => 'Icon Display Position is Required',
                'wl_name.min' => 'Minimum 2 Characters Are Required',
                'wl_name.max' => 'Maximum 100 Characters are allowed',
                'wl_name.unique' => 'Warning Light Name Already Exists',
                'wl_name.regex' => 'Warning Light Name is invalid',
                'subheadings.required' => 'Warning Light Subheading and Info Required',
                'wl_heading.required' => 'Warning Light Heading Required',
                'wl_heading.min' => 'Minimum 2 Characters Are Required',
                'wl_heading.max' => 'Maximum 100 Characters are allowed',
                'wl_heading.unique' => 'Warning Light Heading Already Exists',
                'wl_heading.regex' => 'Warning Light Heading is invalid',
                'wl_icon.required' => 'Warning Light IconRequired',
                'wl_icon.image' => 'This must be an Image',
                'wl_icon.mimes' => 'Warning Light Icon must be svg',
                'wl_icon.max' => 'Image should not be greater than 2 MB'
            ]
        );
        //     dd($request->all());
        DB::beginTransaction();
        try {

            $subheadings = $request->input('subheadings');
            $arrSubHead = array();
            $arrInfo = array();
            $countArray = 0;
            foreach ($subheadings as $subhead) {
                $arrSubHead[] = $subhead['value'];
                $arrInfo[$countArray] = $subhead['info'];
                $countArray++;
            }

            $warning_light_store = new WarningLight();
            if ($warning_light_store) {
                $warning_light_store->wl_name = $request->wl_name;
                $warning_light_store->wl_heading = $request->wl_heading;
                $warning_light_store->wl_subheading = json_encode($arrSubHead);
                $warning_light_store->wl_info = json_encode($arrInfo);
                $warning_light_store->wl_display_position = $request->wl_dp;
                $warning_light_store->created_By = auth()->id();
                $warning_light_store->wl_status = $request->has('status') ? 1 : 0;
                $warning_light_store->save();
            }

            $wl_id = $warning_light_store->wl_id;
            $wl_icon_Uploaded_File = $request->file('wl_icon');
            $iconName = $wl_id . '.' . $wl_icon_Uploaded_File->getClientOriginalExtension();

            $logoPathImg = 'warning_light/' . $wl_id . '/' . $iconName;
            $content = file_get_contents($wl_icon_Uploaded_File);
            Storage::disk('digitalocean')->put($logoPathImg, $content, 'public');

            $wl_video_Uploaded_File = $request->file('wl_video');
            $videoName = $wl_id . '.' . $wl_video_Uploaded_File->getClientOriginalExtension();
            $logoPathVideo = 'warning_light/' . $wl_id . '/' . $videoName;
            Storage::disk('digitalocean')->put($logoPathVideo, file_get_contents($wl_video_Uploaded_File));

            $warning_light_store->wl_icon = $iconName;
            $warning_light_store->wl_video = $videoName;

            $warning_light_store->updated_By = auth()->id();
            $warning_light_store->update();
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.' . $e);
        }

        return redirect()->route('warning_light.view');
    }

    public function view()
    {
        if (!hasAnyPermission(['view_car_warning_light'])) {
            abort(403, "you don't have permission to access");
        }
        $warning_light_view = WarningLight::all();
        return view('warning_light.view', compact('warning_light_view'));
    }

    public function edit($id)
    {
        if (!hasAnyPermission(['edit_car_warning_light'])) {
            abort(403, "you don't have permission to access");
        }

        $warning_light_edit = WarningLight::WHERE('wl_id', decrypt($id))->first();
        $subheading = json_decode($warning_light_edit->wl_subheading);
        $info = json_decode($warning_light_edit->wl_info);
        $mergedArray = array();

        foreach ($subheading as $key => $value) {
            $mergedArray[] = array(
                'value' => $value,
                'info' => $info[$key]
            );
        }
        //dd($subheading,$info);
        //       dd($mergedArray);
        return view('warning_light.edit', compact('warning_light_edit', 'mergedArray', 'info'));
    }


    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_car_warning_light'])) {
            abort(403, "you don't have permission to access");
        }
        $request->validate(
            [
                'wl_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:100|unique:cop_cwl_ms,wl_name,' . decrypt($id) . ',wl_id',
                'wl_dp' => 'required',
                'wl_heading' => 'required|regex:/^[\\/A-Za-z\s]+$/|min:2|max:100|unique:cop_cwl_ms,wl_heading,' . decrypt($id) . ',wl_id',
                'subheadings' => 'required',
                'wl_video' => 'nullable',
            ],
            [
                'wl_name.required' => 'Warning Light Name Required',
                'wl_name.min' => 'Minimum 2 Characters Are Required',
                'wl_dp.required' => 'Icon Display Position is Required',
                'wl_name.max' => 'Maximum 100 Characters are allowed',
                'wl_name.unique' => 'Warning Light Name Already Exists',
                'wl_name.regex' => 'Warning Light Name is invalid',
                'subheadings.required' => 'Warning Light Subheading and Info Required',
                'wl_heading.required' => 'Warning Light Heading Required',
                'wl_heading.min' => 'Minimum 2 Characters Are Required',
                'wl_heading.max' => 'Maximum 100 Characters are allowed',
                'wl_heading.unique' => 'Warning Light Heading Already Exists',
                'wl_heading.regex' => 'Warning Light Heading is invalid',
            ]
        );
        //       dd($request->all());
        DB::beginTransaction();
        try {

            $subheadings = $request->input('subheadings');
            $arrSubHead = array();
            $arrInfo = array();
            $countArray = 0;
            foreach ($subheadings as $subhead) {
                $arrSubHead[] = $subhead['value'];
                $arrInfo[$countArray] = $subhead['info'];
                $countArray++;
            }

            $warning_light_update = WarningLight::where('wl_id', decrypt($id))->first();
            if ($warning_light_update) {

                if (isset($request->wl_icon)) {
                    $request->validate(
                        [
                            'wl_icon' => 'required|image|mimes:svg|unique:cop_cwl_ms,wl_icon|max:2048,' . decrypt($id) . ',wl_id'
                        ],
                        [
                            'wl_icon.required' => 'Warning Light IconRequired',
                            'wl_icon.image' => 'This must be an Image',
                            'wl_icon.mimes' => 'Warning Light Icon must be svg',
                            'wl_icon.max' => 'Image should not be greater than 2 MB'
                        ]
                    );

                    $wl_id = $warning_light_update->wl_id;
                    $wl_icon_Uploaded_File = $request->file('wl_icon');
                    $iconName = $wl_id . '.' . $wl_icon_Uploaded_File->getClientOriginalExtension();

                    $logoPathImg = 'warning_light/' . $wl_id . '/' . $iconName;
                    $content = file_get_contents($wl_icon_Uploaded_File);
                    Storage::disk('digitalocean')->put($logoPathImg, $content, 'public');

                    $warning_light_update->wl_icon = $iconName;
                }

                if ($request->hasFile('wl_video')) {
                    $wl_id = $warning_light_update->wl_id;
                    $wl_video_Uploaded_File = $request->file('wl_video');
                    $videoName = $wl_id . '.' . $wl_video_Uploaded_File->getClientOriginalExtension();

                    $logoPathVideo = 'warning_light/' . $wl_id . '/' . $videoName;
                    Storage::disk('digitalocean')->put($logoPathVideo, file_get_contents($wl_video_Uploaded_File));
                    // Update wl_video field
                    $warning_light_update->wl_video = $videoName;
                }

                $warning_light_update->wl_name = $request->wl_name;
                $warning_light_update->wl_heading = $request->wl_heading;
                $warning_light_update->wl_display_position = $request->wl_dp;
                $warning_light_update->wl_subheading = json_encode($arrSubHead);
                $warning_light_update->wl_info = json_encode($arrInfo);
                $warning_light_update->wl_status = $request->has('status') ? 1 : 0;
                $warning_light_update->created_By = auth()->id();
                $warning_light_update->updated_By = auth()->id();
                $warning_light_update->update();
                DB::commit();
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.' . $e);
        }

        return redirect()->route('warning_light.view');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_car_warning_light'])) {
            abort(403, "you don't have permission to access");
        }
        DB::beginTransaction();
        try {
            $warning_light_destroy = WarningLight::WHERE('wl_id', decrypt($id))->first();
            if ($warning_light_destroy) {

                // Delete icon file
                $iconFilePath = 'warning_light/' . $warning_light_destroy->wl_id . '/' . $warning_light_destroy->wl_icon;
                if (Storage::disk('digitalocean')->exists($iconFilePath)) {
                    Storage::disk('digitalocean')->delete($iconFilePath);
                }

                // Delete video file
                $videoFilePath = 'warning_light/' . $warning_light_destroy->wl_id . '/' . $warning_light_destroy->wl_video;
                if (Storage::disk('digitalocean')->exists($videoFilePath)) {
                    Storage::disk('digitalocean')->delete($videoFilePath);
                }

                $warning_light_destroy->delete();

                DB::commit();
                session()->flash('success', 'Warning Light Deleted successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('warning_light.view');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');

        DB::table('cop_cwl_ms')
            ->where('wl_id', $id)
            ->update(['wl_status' => DB::raw('IF(wl_status = 1, 0, 1)')]);

        return response()->json(['message', 'Status Updated Successfully']);
    }
}
