<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Brand;
use App\Models\Color;
use App\Models\Model;
use App\Models\Variant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\ImageManager;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Drivers\Gd\Driver;

class VariantController extends Controller
{

    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');

        if ($selectedBrandId) {

            $models = Model::where('brand_id', $selectedBrandId)
                ->active()
                ->get();
        } else {
            $models = [];
        }

        return response()->json(['models' => $models]);
    }

    public function create()
    {
        if (!hasAnyPermission(['create_variant'])) {
            abort(403, "you don't have permission to access");
        }
        $brands = Brand::active()->get();
        $models = Model::active()->get();
        return view('variant.create', compact('models', 'brands'));
    }

    public function store(Request $request)
    {

        if (!hasAnyPermission(['create_variant'])) {
            abort(403, "you don't have permission to access");
        }
        $request->validate([
            'brand_id' => 'required',
            'model_id' => 'required',


            'variant_name' => 'required|min:2',
            'variant_image' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
            'variant_image_mob' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
            // 'variant_name' => 'required|regex:/^[()A-Za-z0-9\s]+$/|min:2|max:30',
            // 'variant_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'variant_type' => ['nullable', Rule::unique('cop_variants')->where(function ($q) use ($request) {
                return $q->where('variant_type', $request->variant_type)
                    ->where('model_id', $request->model_id);
            }),],
            'seating_capacity' => 'required|numeric',
            'start_variant_color_code' => 'required',
            'end_variant_color_code' => 'required',
            'variant_color_name' => 'required',
            'variant_color_image.*' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048'
        ], [
            'brand_id.required' => 'Select Brand Field is required.',
            'model_id.required' => 'Select Model Field is required.',
            'variant_name.required' => 'Variant Name is required.',
            // 'variant_name.unique' => 'This Variant Name already exists.',
            // 'variant_name.regex' => 'The Variant Name must contain only letters, numbers, and spaces.',
            'variant_name.min' => 'The Variant Name must be at least :min characters.',
            // 'variant_name.max' => 'The Variant Name must not exceed :max characters.',

            'variant_image.required' => 'Variant Image is required.',
            'variant_image.image' => 'Variant Image must be an image file.',
            'variant_image.mimes' => 'Variant Image must be a PNG, JPG, JPEG, or WebP file.',
            'variant_image.max' => 'Variant image should not be greater than 2 MB.',
            'variant_image_mob.required' => 'Variant Image is required.',
            'variant_image_mob.image' => 'Variant Image must be an image file.',
            'variant_image_mob.mimes' => 'Variant Image must be a PNG, JPG, JPEG, or WebP file.',
            'variant_image_mob.max' => 'Variant image should not be greater than 2 MB.',
            'seating_capacity.required' => 'Seating Capacity Field is required.',
            'seating_capacity.numeric' => 'Seating capacity must be numeric.',
            'start_variant_color_code.required' => 'Start color code is required.',
            'end_variant_color_code.required' => 'End color code is required.',
            'variant_color_name.required' => 'Variant color name is required.',
            'variant_color_image.*.required' => 'Variant color image is required.',
            'variant_color_image.*.image' => 'Variant color image must be an image file.',
            'variant_color_image.*.mimes' => 'Variant color image must be a PNG, JPG, JPEG, or WebP file.',
            'variant_color_image.*.max' => 'Variant color image should not be greater than 2 MB.',
            'variant_type' => 'Base Or Top Variant already exists'
        ]);

        DB::beginTransaction();
        try {
            $variant_store = new Variant;
            $all_variants = Variant::where('model_id', $request->model_id)->pluck('variant_type')->toArray();

            // Check if the requested variant_type is not already present among the existing variants
            if (!in_array($request->variant_type, $all_variants)) {
                // If not present, assign the variant_type from the request
                $variant_type = $request->variant_type;
            } else {
                // If present, assign null to the variant_type
                $variant_type = null;
            }
            if ($variant_store) {
                $brand_id = DB::table('cop_models')
                    ->where('model_id', $request->model_id)
                    ->value('brand_id');


                // dd($brand_id);
                // code for variant data store
                $variant_store->brand_id = $brand_id;
                $variant_store->model_id = $request->model_id;
                $variant_store->variant_name = $request->variant_name;
                $variant_store->variant_type = $variant_type;
                $variant_store->seating_capacity = $request->seating_capacity;
                $variant_store->created_by = auth()->id();
                $variant_store->updated_by = auth()->id();
                $variant_store->status = $request->has('status') ? 1 : 0;
                $variant_store->slug = DB::raw("LOWER(
                                                        REGEXP_REPLACE(
                                                            REGEXP_REPLACE(
                                                                LOWER(REPLACE(REPLACE(variant_name, ' ', '-'), '+', 'plus')), 
                                                                '[^a-zA-Z0-9-]+', 
                                                                ''
                                                            ),
                                                            '-+', 
                                                            '-'
                                                        )
                                                    )");
                $variant_store->save();

                // code for variant image store
                $variant_update = Variant::find($variant_store->variant_id);
                if ($variant_update) {
                    $variant_id = $variant_update->variant_id;
                    $uploadedImage = $request->file('variant_image');
                    $webpImageName = $variant_id . '.webp';

                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());
                    // main image
                    // read image from file system
                    $image = $manager->read($uploadedImage);
                    $variantImagePath = 'brands/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id . '/' . $webpImageName;
                    Storage::disk('digitalocean')->put($variantImagePath, $image->toWebp(), 'public');


                    // Thumbnail image

                    $image->resize(216, 102);
                    $variantThumbPath = 'brands/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id . '/thumb/' . $webpImageName;
                    Storage::disk('digitalocean')->put($variantThumbPath, $image->toWebp(), 'public');
                    // Begin::Mobile image
                    $uploadedImageMob = $request->file('variant_image_mob');
                    $webpImageNameMob = $variant_id . '_mob.webp';
                    $imageMob = $manager->read($uploadedImageMob);

                    $mobilePath = 'brands/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id . '/' . $webpImageNameMob;
                    Storage::disk('digitalocean')->put($mobilePath, $imageMob->toWebp(), 'public');
                    // End::Mobile image

                    $variant_update->variant_image = $webpImageName;
                    $variant_update->variant_image_mob = $webpImageNameMob;
                    $variant_update->update();


                    //code for varinat color and there image store
                    $startColorCodes = $request->input('start_variant_color_code');
                    $endColorCodes = $request->input('end_variant_color_code');
                    $colorNames = $request->input('variant_color_name');
                    $uploadedImages = $request->file('variant_color_image');
                    $uploadedImagesMob = $request->file('variant_color_image_mob');
                    $totalColors = count($startColorCodes);

                    for ($key = 0; $key < $totalColors; $key++) {
                        $color_store = new Color;
                        $color_store->brand_id = $request->brand_id;
                        $color_store->model_id = $request->model_id;
                        $color_store->variant_id = $variant_update->variant_id;
                        $color_store->color_code = $startColorCodes[$key];

                        // Check if end color is provided or not
                        if (isset($endColorCodes[$key])) {
                            $color_store->dual_color_code = $endColorCodes[$key];
                        } else {
                            $color_store->dual_color_code = null;
                        }

                        $color_store->color_name = $colorNames[$key];
                        $uploadedImage = $uploadedImages[$key];



                        // Move the uploaded image to the designated folder
                        $webpImageName = $color_store->variant_id . '_' . (time() + $key) . '.webp';
                        // $uploadedImage->move(public_path('brands') . '/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id, $webpImageName);

                        // create image manager with desired driver
                        $manager = new ImageManager(new Driver());
                        // main image
                        // read image from file system
                        $image = $manager->read($uploadedImage);

                        $colorImagePath = 'brands/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id . '/' . $webpImageName;
                        Storage::disk('digitalocean')->put($colorImagePath, $image->toWebp(), 'public');
                        // Thumbnail image

                        $image->resize(676, 348);
                        $colorImageThumbPath = 'brands/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id . '/thumb/' . $webpImageName;
                        Storage::disk('digitalocean')->put($colorImageThumbPath, $image->toWebp(), 'public');
                        // Begin::Mobile Color Image
                        $uploadedImageMob = $uploadedImagesMob[$key];
                        $webpImageNameMob = $color_store->variant_id . '_' . (time() + $key) . '_mob.webp';
                        $imageMob = $manager->read($uploadedImageMob);
                        $mobileColorImagePath = 'brands/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id . '/' . $webpImageNameMob;
                        Storage::disk('digitalocean')->put($mobileColorImagePath, $imageMob->toWebp(), 'public');

                        // End::Mobile Color Image

                        // Store the image name
                        $color_store->variant_color_image = $webpImageName;
                        $color_store->variant_color_image_mob = $webpImageNameMob;

                        $color_store->created_by = auth()->id();
                        $color_store->updated_by = auth()->id();
                        $color_store->save();
                    }
                    DB::commit();
                    session()->flash('success', 'Variant Added Successfully.');
                } else {
                    session()->flash('error', 'Model Not Found.');
                }
            } else {
                DB::rollBack();
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            // dd($e->getMessage());
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('variant.view');
    }

    public function view(Request $request)
    {
        if (!hasAnyPermission(['view_variant'])) {
            abort(403, "you don't have permission to access");
        }
        return view('variant.view');
    }

    public function edit($id)
    {
        if (!hasAnyPermission(['edit_variant'])) {
            abort(403, "you don't have permission to access");
        }
        $variant_edit = Variant::where('variant_id', decrypt($id))->first();
        $brands = Brand::active()->get();
        $models = Model::where('brand_id', $variant_edit->brand_id)
            ->active()
            ->get();
        $colors = Color::where('variant_id', $variant_edit->variant_id)->get();

        return view('variant.edit', compact('variant_edit', 'brands', 'models', 'colors'));
    }


    public function update(Request $request, $id)
    {
        // dd($request->all());

        if (!hasAnyPermission(['edit_variant'])) {
            abort(403, "you don't have permission to access");
        }


        $request->validate([
            'brand_id' => 'required|numeric',
            'model_id' => 'required|numeric',
            'variant_name' => 'required|min:2',
            'variant_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'variant_image_mob' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'variant_type' => ['nullable', Rule::unique('cop_variants')->ignore(decrypt($id), 'variant_id')->where(function ($q) use ($request) {
                return  $q->where('variant_type', $request->variant_type)
                    ->where('model_id', $request->model_id);
            })],
            'seating_capacity' => 'required|numeric',
            'start_variant_color_code.required' => 'Start color code is required.',
            'end_variant_color_code.required' => 'End color code is required.',
            'variant_color_name.required' => 'Variant color name is required.',
            'variant_color_image.*.required' => 'Variant color image is required.',
            'variant_color_image.*.image' => 'Variant color image must be an image file.',
            'variant_color_image.*.mimes' => 'Variant color image must be a PNG, JPG, JPEG, or WebP file.',
            'variant_color_image_mob.*.required' => 'Variant color image is required.',
            'variant_color_image_mob.*.image' => 'Variant color image must be an image file.',
            'variant_color_image_mob.*.mimes' => 'Variant color image must be a PNG, JPG, JPEG, or WebP file.',
            // 'variant_color_image.*.max' => 'Variant color image should not be greater than 2 MB.'
        ], [
            'brand_id.required' => 'Brand name is required.',
            'brand_id.numeric' => 'Brand ID must be numeric.',
            'model_id.required' => 'Model Model is required.',
            'model_id.numeric' => 'Model ID must be numeric.',
            'variant_name.required' => 'Variant Name is required.',
            // 'variant_name.unique' => 'This Variant Name already exists.',
            // 'variant_name.regex' => 'The Variant Name must contain only letters, numbers, and spaces.',
            'variant_name.min' => 'The Variant Name must be at least :min characters.',
            // 'variant_name.max' => 'The Variant Name must not exceed :max characters.',
            'variant_image.image' => 'Variant image must be an image file.',
            'variant_image.mimes' => 'Variant image must be a PNG, JPG, JPEG, or WebP file.',
            'variant_image.max' => 'Variant image should not be greater than 2 MB.',
            'seating_capacity.required' => 'Seating capacity is required.',
            'seating_capacity.numeric' => 'Seating capacity must be numeric.',
            'start_variant_color_code.required' => 'Start color code is required.',
            'end_variant_color_code.required' => 'End color code is required.',
            'variant_color_name.required' => 'Variant color name is required.',
            'variant_color_image.*.required' => 'Variant color image is required.',
            'variant_color_image.*.image' => 'Variant color image must be an image file.',
            'variant_color_image.*.mimes' => 'Variant color image must be a PNG, JPG, JPEG, or WebP file.',
            'variant_color_image_mob.*.required' => 'Variant color image is required.',
            'variant_color_image_mob.*.image' => 'Variant color image must be an image file.',
            'variant_color_image_mob.*.mimes' => 'Variant color image must be a PNG, JPG, JPEG, or WebP file.',
            // 'variant_color_image.*.max' => 'Variant color image should not be greater than 2 MB.'
            'variant_type' => 'Base or Top Variant of Model already exists'
        ]);
        DB::beginTransaction();
        try {
            $variant_update = Variant::where('variant_id', decrypt($id))->first();

            $all_variants = Variant::where('model_id', $request->model_id)
                ->where('variant_id', '!=', $variant_update->variant_id)
                ->pluck('variant_type')
                ->toArray();
            // Check if the requested variant_type is not already present among the existing variants
            if (!in_array($request->variant_type, $all_variants)) {
                // If not present, assign the variant_type from the request
                $variant_type = $request->variant_type;
            } else {
                // If present, assign null to the variant_type
                $variant_type = null;
            }

            if ($variant_update) {
                $imagePath = 'brands/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id;

                $color_name = $request->variant_color_name;

                foreach ($color_name as $key => $value) {
                    $uploadedImage = $request->file('variant_color_image')[$key] ?? null;
                    $uploadedImageMob = $request->file('variant_color_image_mob')[$key] ?? null;

                    // Color : Mobile Images
                    if ($uploadedImageMob) {
                        $webpImageNameMob = $variant_update->variant_id . '_' . (time() + $key) . '_mob.webp';

                        // Check if there's an existing image for this variant
                        $existingColor = Color::where([
                            'variant_id' => $variant_update->variant_id,
                            'color_name' => $request->variant_color_name[$key]
                        ])->first();

                        if ($existingColor && $existingColor->variant_color_image_mob) {
                            $existingImagePathMob = $imagePath . '/' . $existingColor->variant_color_image_mob;

                            Storage::disk('digitalocean')->deleteDirectory($existingImagePathMob);
                        }

                        $manager = new ImageManager(new Driver());

                        $imageMobColor = $manager->read($uploadedImageMob);
                        if (!is_dir($imagePath)) {
                            mkdir($imagePath, 0777, true);
                        }
                        $mobileImgPath = $imagePath . '/' . $webpImageNameMob;
                        Storage::disk('digitalocean')->put($mobileImgPath, $imageMobColor->toWebp(), 'public');

                        Color::updateOrCreate(
                            ['variant_id' => $variant_update->variant_id, 'color_name' => $request->variant_color_name[$key]],
                            [
                                'brand_id' => $request->brand_id,
                                'model_id' => $request->model_id,
                                'color_code' => $request->start_variant_color_code[$key],
                                'dual_color_code' => $request->end_variant_color_code[$key] ?? null,
                                'color_name' => $request->variant_color_name[$key],
                                'variant_color_image_mob' => $webpImageNameMob,
                                'created_by' => auth()->id(),
                            ]
                        );
                    } else {
                        Color::updateOrCreate(
                            ['variant_id' => $variant_update->variant_id, 'color_name' => $request->variant_color_name[$key]],
                            [
                                'brand_id' => $request->brand_id,
                                'model_id' => $request->model_id,
                                'color_code' => $request->start_variant_color_code[$key],
                                'dual_color_code' => $request->end_variant_color_code[$key] ?? null,
                                'color_name' => $request->variant_color_name[$key],
                                'created_by' => auth()->id(),
                            ]
                        );
                    }

                    // Color : Destop Images (Actual & Thub images)
                    if ($uploadedImage) {
                        $webpImageName = $variant_update->variant_id . '_' . (time() + $key) . '.webp';

                        // Check if there's an existing image for this variant
                        $existingColor = Color::where([
                            'variant_id' => $variant_update->variant_id,
                            'color_name' => $request->variant_color_name[$key]
                        ])->first();

                        // If an image exists, remove the previous one
                        if ($existingColor && $existingColor->variant_color_image) {
                            $existingImagePath = $imagePath . '/' . $existingColor->variant_color_image;
                            $existingThumbImagePath = $imagePath . '/thumb/' . $existingColor->variant_color_image;

                            Storage::disk('digitalocean')->deleteDirectory($existingImagePath);

                            Storage::disk('digitalocean')->deleteDirectory($existingThumbImagePath);
                        }

                        $manager = new ImageManager(new Driver());

                        // Actual image
                        $image = $manager->read($uploadedImage);
                        $mainImagePath = $imagePath . '/' . $webpImageName;
                        Storage::disk('digitalocean')->put($mainImagePath, $image->toWebp(), 'public');


                        // Thumbnail image
                        $image->resize(676, 348);
                        $thumbPath = $imagePath . '/thumb/' . $webpImageName;
                        Storage::disk('digitalocean')->put($thumbPath, $image->toWebp(), 'public');

                        // Update or create the Color record
                        Color::updateOrCreate(
                            ['variant_id' => $variant_update->variant_id, 'color_name' => $request->variant_color_name[$key]],
                            [
                                'brand_id' => $request->brand_id,
                                'model_id' => $request->model_id,
                                'color_code' => $request->start_variant_color_code[$key],
                                'dual_color_code' => $request->end_variant_color_code[$key] ?? null,
                                'color_name' => $request->variant_color_name[$key],
                                'variant_color_image' => $webpImageName,
                                'created_by' => auth()->id(),
                            ]
                        );
                    } else {
                        Color::updateOrCreate(
                            ['variant_id' => $variant_update->variant_id, 'color_name' => $request->variant_color_name[$key]],
                            [
                                'brand_id' => $request->brand_id,
                                'model_id' => $request->model_id,
                                'color_code' => $request->start_variant_color_code[$key],
                                'dual_color_code' => $request->end_variant_color_code[$key] ?? null,
                                'color_name' => $request->variant_color_name[$key],
                                'created_by' => auth()->id(),
                            ]
                        );
                    }
                }

                // For variant desktop iamge (Actual & Thub image)
                $uploadedVariantImage = $request->file('variant_image');
                if (!empty($uploadedVariantImage)) {
                    $imagePath = 'brands/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id;
                    $webpImageName = $variant_update->variant_id . '.webp';

                    $previousImagePath = $imagePath . '/' . $variant_update->variant_image;
                    Storage::disk('digitalocean')->deleteDirectory($previousImagePath);

                    $manager = new ImageManager(new Driver());

                    // Actual image
                    $image = $manager->read($uploadedVariantImage);
                    $mainPath = $imagePath . '/' . $webpImageName;
                    Storage::disk('digitalocean')->put($mainPath, $image->toWebp(), 'public');

                    // Thumbnail image
                    $image->resize(216, 102);
                    $mainThumbPath = $imagePath . '/thumb/' . $webpImageName;
                    Storage::disk('digitalocean')->put($mainThumbPath, $image->toWebp(), 'public');

                    $variant_update->variant_image = $webpImageName;
                }

                // For variant mobile iamge
                $uploadedVariantImageMob = $request->file('variant_image_mob');
                if (!empty($uploadedVariantImageMob)) {
                    $imagePathMob = 'brands/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id;
                    $webpImageNameMob = $variant_update->variant_id . '_mob.webp';

                    $previousImagePathMob = $imagePathMob . '/' . $variant_update->variant_image_mob;
                    Storage::disk('digitalocean')->deleteDirectory($previousImagePathMob);

                    $manager = new ImageManager(new Driver());
                    $imageMob = $manager->read($uploadedVariantImageMob);
                    $imagePath = $imagePathMob . '/' . $webpImageNameMob;
                    Storage::disk('digitalocean')->put($imagePath, $imageMob->toWebp(), 'public');

                    $variant_update->variant_image_mob = $webpImageNameMob;
                }

                // if brand / model changed then move all images of this variants to new model_id folder
                if ($variant_update->model_id != $request->model_id) {
                    // Old path
                    $imagePathFrom = 'brands/' . $variant_update->brand_id . '/' . $variant_update->model_id . '/' . $variant_update->variant_id . '/';

                    // New path
                    $imagePathTo = 'brands/' . $request->brand_id . '/' . $request->model_id . '/' . $variant_update->variant_id . '/';
                    
                    if (Storage::disk('digitalocean')->exists($imagePathFrom)) {
                        // Get all files
                        $files = Storage::disk('digitalocean')->allFiles($imagePathFrom);

                        // foreach files
                        foreach ($files as $file) {
                            // Construct the new file path with the same file name in the new directory
                            $newFilePath = str_replace($imagePathFrom, $imagePathTo, $file);

                            Storage::disk('digitalocean')->move($file, $newFilePath);
                        }

                        // Delete the old directory after moving all files
                        Storage::disk('digitalocean')->deleteDirectory($imagePathFrom);
                    }
                }

                $brand_id = DB::table('cop_models')
                    ->where('model_id', $request->model_id)
                    ->value('brand_id');

                $variant_update->brand_id = $brand_id;
                $variant_update->model_id = $request->model_id;
                $variant_update->variant_name = $request->variant_name;
                $variant_update->seating_capacity = $request->seating_capacity;
                $variant_update->variant_type = $request->variant_type;
                $variant_update->status = $request->has('status') ? 1 : 0;
                $variant_update->slug = DB::raw("LOWER(
                                                        REGEXP_REPLACE(
                                                            REGEXP_REPLACE(
                                                                LOWER(REPLACE(REPLACE(variant_name, ' ', '-'), '+', 'plus')), 
                                                                '[^a-zA-Z0-9-]+', 
                                                                ''
                                                            ),
                                                            '-+', 
                                                            '-'
                                                        )
                                                    )");
                // LOWER(REGEXP_REPLACE(LOWER(REPLACE(REPLACE(variant_name, ' ', '-'), '+', 'plus')), '[^a-zA-Z0-9-]+', ''))
                $variant_update->update();

                DB::commit();
                session()->flash('success', 'Variant Updated Successfully.');
            } else {
                session()->flash('error', 'Variant Not Found.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wong.');
        }
        return redirect()->route('variant.view');
    }


    public function deleteColor(Request $request)
    {
        $colorId = $request->input('color_id');
        $color = Color::find($colorId);
        $variantId = $color->variant_id;
        $variant = Variant::find($variantId);
        $brandId = $variant->brand_id;
        $modelId = $variant->model_id;
        if ($color) {
            if ($color->variant_color_image) {
                $img = 'brands' . '/' . $brandId . '/' . $modelId . '/' . $variantId . '/' . $color->variant_color_image;
                Storage::disk('digitalocean')->delete($img);
            }
            if ($color->variant_color_image_mob) {
                $img = 'brands' . '/' . $brandId . '/' . $modelId . '/' . $variantId . '/' . $color->variant_color_image_mob;
                Storage::disk('digitalocean')->delete($img);
            }
            $color->delete();
            return response()->json(['message' => 'Color Deleted Successfully'], 200);
        }

        return response()->json(['message' => 'Color Not Found'], 404);
    }


    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_variant'])) {
            abort(403, "you don't have permission to access");
        }
        DB::beginTransaction();
        try {
            $variant_destroy = Variant::where('variant_id', decrypt($id))->first();

            if ($variant_destroy) {

                if ($variant_destroy->price_entry->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('variant.view');
                }

                $uploadedImageDirectory = 'brands/' . $variant_destroy->brand_id . '/' . $variant_destroy->model_id . '/' . $variant_destroy->variant_id;


                Storage::disk('digitalocean')->deleteDirectory($uploadedImageDirectory);

                $variant_destroy->delete();
                DB::commit();
                session()->flash('success', 'Variant Deleted Successfully.');
            } else {
                session()->flash('error', 'Variant Not Found.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }

        return redirect()->route('variant.view');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_variants')
            ->where('variant_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            $limit = ($request->has('length') ? $request->input('length') : 10);
            $page = ($request->has('start') ? $request->input('start') : 0);
            $search = ($request->has('search') ? $request->input('search')['value'] : '');

            $variant_view = DB::table('cop_variants')
                ->join('cop_models', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_variants.brand_id', '=', 'cop_brands_ms.brand_id')
                ->select('cop_variants.*', 'cop_brands_ms.brand_name', 'cop_models.model_name')
                ->where([['cop_brands_ms.status', '=', 1], ['cop_models.status', '=', 1]]);

            if (!empty($search)) {
                $variant_view->where(function ($query) use ($search) {
                    $query->orWhere('cop_brands_ms.brand_name', 'LIKE', '%' . $search . '%');
                    $query->orWhere('cop_models.model_name', 'LIKE', '%' . $search . '%');
                    $query->orWhere('cop_variants.variant_name', 'LIKE', '%' . $search . '%');
                });
            }
            $cntFilter = clone $variant_view;
            $variant_view->offset($page)->limit($limit);
            $variant_view = $variant_view->get();

            $VariantTotal = DB::select("SELECT COUNT(*) AS count FROM cop_variants")[0]->count;
            $data = [];
            $i = $page;
            foreach ($variant_view as $member) {
                $i++;
                $status = $disable = "";
                if ($member->status == 1) {
                    $status = 'checked';
                }
                $disable = (!auth()->user()->can('edit_variant')) ? 'disabled' : '';
                $action = "";
                if (auth()->user()->can('edit_variant')) {
                    $editRoute = route('variant.edit', encrypt($member->variant_id));
                    $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                        <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                }
                if (auth()->user()->can('delete_variant')) {
                    $action .= '<a href="javascript:void(0);"
                    data-href="' . route('variant.destroy', encrypt($member->variant_id)) . '"
                    class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                }
                $data[] = array("sr_no" => $i, "brand_name" => $member->brand_name, "model_name" => $member->model_name, "variant_name" => $member->variant_name,"seating_capacity" => $member->seating_capacity,"variant_type" => $member->variant_type, "status" => '<div
                class="form-check form-switch form-check-custom form-check-success form-check-solid">
                <input class="form-check-input" name="status" type="checkbox" value="' . $member->variant_id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>', "action" => $action);
            }
            return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $VariantTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
        }
    }
}
