<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Feature;
use App\Models\FeatureValue;
use App\Models\Model;
use App\Models\Specification;
use App\Models\Variant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Exception;
use Illuminate\Support\Facades\Log;

class FeatureValueController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    public function fetchModels(Request $request)
    {


        $selectedBrandId = $request->input('brand_id');
        if ($selectedBrandId) {
            $models = Model::where('brand_id', $selectedBrandId)->active()->get();
        } else {
            $models = [];
        }
        return response()->json(['models' => $models]);
    }

    public function fetchVariants(Request $request)
    {
        $selectedModelId = $request->input('model_id');

        if ($selectedModelId) {
            $variants = Variant::where('model_id', $selectedModelId)->active()->get();
        } else {
            $variants = [];
        }

        return response()->json(['variants' => $variants]);
    }

    public function fetchFeatures(Request $request)
    {
        if ($request->has('spec_id') && $request->has('variant_id')) {
            $spec_id = $request->input('spec_id');
            $variant_id = $request->input('variant_id');
            $result = DB::table('cop_features_ms')
                ->where('spec_id', $spec_id)
                ->get();
            return response()->json($result);
        } else {
            return response()->json([]);
        }
    }


    public function create()
    {
        if (!hasAnyPermission(['create_feature_value'])) {
            abort(403, "you don't have permission to access");
        }
        $brands = Brand::active()->get();
        $models = Model::active()->get();
        $variants = Variant::active()->get();
        $specifications = Specification::active()->get();
        return view('feature_value.create', compact('brands', 'models', 'variants', 'specifications'));
    }
    public function fetchspec(Request $request)
    {
        $specId = $request->input('Spec_Id');

        $variantId = $request->input('Variant_Id');
        $modelId = $request->input('Model_Id');
        $modelType = Model::where('model_id', $modelId)->value('model_type');
        if ($modelType == 0) {
            $type = 1;
        } elseif ($modelType == 1) {
            $type = 0;
        }
        $results = DB::select("select cop_spec_ms.spec_id,cop_spec_ms.spec_name from cop_spec_ms where cop_spec_ms.spec_id=" . $specId);

        $results1 = DB::select("SELECT
        cop_features_ms.feature_id,
        cop_features_ms.fo_id,
        cop_features_ms.features_name,
        CASE
            WHEN cop_fv.feature_value IS NOT NULL THEN cop_fv.feature_value
            ELSE NULL
        END AS feature_value,cop_fv.key_highlight
        FROM
            cop_features_ms
        LEFT JOIN
            cop_fv
        ON
        cop_features_ms.feature_id = cop_fv.feature_id
        AND cop_fv.variant_id = " . $variantId . "
        WHERE cop_features_ms.fuel_type!=" . $type . " AND
         cop_features_ms.spec_id = " . $specId);
        echo view('feature_value.dynamic-table', ['results' => $results, 'results1' => $results1]);
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_feature_value'])) {
            abort(403, "you don't have permission to access");
        }
        // Validation rules
        // $rules = [
        //     'Feature_Id.*' => 'required',
        //     'Feature_Value.*' => 'required',
        //     // Add more validation rules for other fields if needed
        // ];

        // // Custom error messages for validation rules
        // $messages = [
        //     'Feature_Id.*.required' => 'Feature Id is required.',
        //     'Feature_Value.*.required' => 'Feature Value is required.',
        //     // Add custom messages for other rules if needed
        // ];

        // // Perform validation
        // $validator = validator($request->all(), $rules, $messages);


        DB::beginTransaction();
        try {
            $feature_ids = array_keys($request->input('Feature_Id'));
            $feature_value = $request->input('Feature_Value');
            $key_highlight = $request->input('highlight');



            foreach ($feature_ids as $key => $feature_id) {
                if(!empty($feature_value[$key])||$feature_value==""){

                if (strtolower($feature_value[$key]) == 'yes') {

                    $feature_value[$key] = 'Yes';
                } elseif (strtolower($feature_value[$key]) == 'no') {

                    $feature_value[$key] = 'No';
                } else {

                    $feature_value[$key];
                }
                FeatureValue::updateOrCreate(
                    [
                        'variant_id' => $request->variant_id,
                        'feature_id' => $feature_id
                    ], // Condition to find the product
                    [
                        'brand_id' => $request->brand_id,
                        'model_id' => $request->model_id,
                        'spec_id' => $request->spec_id,
                        'key_highlight' => !empty($key_highlight[$feature_id]) ? true : false,
                        'feature_value' => (strlen($feature_value[$key]) > 0) ? $feature_value[$key] : '',
                        'created_by' => auth()->id()

                    ]
                );
            }else{
                FeatureValue::where('feature_id',$feature_id)->where('variant_id',$request->variant_id)->delete();
            }

            }
            DB::commit();
        } catch (Exception $e) {
            DB::commit();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        // }


        return redirect()->route('feature_value.create')->with('success', 'Feature Values added successfully.');
    }
}
