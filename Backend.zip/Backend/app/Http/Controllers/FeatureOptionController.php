<?php

namespace App\Http\Controllers;
use Exception;
use App\Models\FeatureOption;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class FeatureOptionController extends Controller
{
    public function create()
    {
        if (!hasAnyPermission(['create_feature_option', 'view_feature_option'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $feature_option_view = FeatureOption::all();
        return view('feature_option.create', compact('feature_option_view'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_feature_option'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'fo_value' => 'required|regex:/^[A-Za-z\s\/]+$/|min:2|max:20|unique:cop_fo_ms,fo_value',
            ],
            [
                'fo_value.required' => 'Feature Option Value is required',
                'fo_value.regex' => 'Feature option should only be characters',
                'fo_value.unique' => 'Feature Option Value Already Taken',
                'fo_value.min' => 'Feature Option must be at least :min characters.',
                'fo_value.max' => 'Feature Option must not exceed :max characters.',
            ]
        );

        DB::beginTransaction();
        try{
            $feature_option_store = new FeatureOption();
            if ($feature_option_store) {
                $feature_option_store->fo_value = $request->fo_value;
                $feature_option_store->save();
                DB::commit();
                session()->flash('success', 'Feature Option Created Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('feature_option.create');
    }

    public function edit($id)
    {
        if (!hasAnyPermission(['edit_feature_option', 'view_feature_option'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $feature_option_view = FeatureOption::all();
        $feature_option_edit = FeatureOption::where('fo_id', decrypt($id))->first();
        return view('feature_option.edit', compact('feature_option_view', 'feature_option_edit'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_feature_option'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'fo_value' => 'required|regex:/^[A-Za-z\s\/]+$/|min:2|max:10|unique:cop_fo_ms,fo_value,' . decrypt($id) . ',fo_id'
            ],
            [
                'fo_value.required' => 'Feature Option Value is required',
                'fo_value.regex' => 'Feature option should only be characters',
                'fo_value.unique' => 'Feature Option Value Already Taken',
                'fo_value.min' => 'The Feature Option must be at least :min characters.',
                'fo_value.max' => 'The Feature Option must not exceed :max characters.',
            ]
        );
        DB::beginTransaction();
        try{
            $feature_option_update = FeatureOption::where('fo_id', decrypt($id))->first();

            if ($feature_option_update) {
                $feature_option_update->fo_value = $request->fo_value;
                $feature_option_update->update();
                DB::commit();
                session()->flash('success', 'Feature Option Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('feature_option.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_feature_option'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        try{
            $feature_option_destroy = FeatureOption::where('fo_id', decrypt($id))->first();
            if ($feature_option_destroy) {
                if ($feature_option_destroy->feature->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('feature_option.create');
                }
                $feature_option_destroy->delete();
                session()->flash('success', 'Feature Option Deleted Successfully');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return  redirect()->route('feature_option.create');
    }
}
