<?php

namespace App\Http\Controllers;

use App\Models\Icon;
use Illuminate\Http\Request;
use Exception;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class IconController extends Controller
{


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        $icon_view = Icon::all();
        if (!hasAnyPermission(['create_icon', 'view_icon'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        return view('icon.create', compact('icon_view'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_icon'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'icon_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:20|unique:cop_icon_ms,icon_name',
                'icon_image' => 'required|image|mimes:svg|unique:cop_icon_ms,icon_image|max:2048'
            ],
            [
                'icon_name.required' => 'Icon Name required',
                'icon_name.min' => 'Minimum 2 Characters are required',
                'icon_name.max' => 'Maximum 20 Characters are allowed',
                'icon_name.unique' => 'Icon Name Already Exists',
                'icon_name.regex' => 'Icon Name is invalid',
                'icon_image.required' => 'Icon Image required',
                'icon_image.image' => 'This must be an Image',
                'icon_image.mimes' => 'Icon Image must be svg',
                'icon_image.max' => 'Image should not be greater than 2 MB'
            ]
        );
        DB::beginTransaction();
        try {
            $icon_store = new Icon();

            if (!empty($icon_store)) {
                $icon_store->icon_name = $request->icon_name;
                $icon_store->status = $request->has('status') ? 1 : 0;
                $icon_store->save();

                $icon_id = $icon_store->icon_id;
                $icon_image_Uploaded_File = $request->file('icon_image');
                $imageImageName = $icon_id . '.' . $icon_image_Uploaded_File->getClientOriginalExtension();

                $logoPathImg = 'icon/' . $icon_id . '/' . $imageImageName;
                $content = file_get_contents($icon_image_Uploaded_File);
                Storage::disk('digitalocean')->put($logoPathImg, $content, 'public');

                $icon_store->icon_image = $imageImageName;
                $icon_store->update();
                DB::commit();
                session()->flash('success', 'Icon Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            // dd($e->getMessage());
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('icon.create');
    }

    public function edit($id)
    {
        if (!hasAnyPermission(['edit_icon', 'view_icon'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $icon_edit = Icon::where('icon_id', decrypt($id))->first();
        $icon_view = Icon::all();
        return view('icon.edit', compact('icon_edit', 'icon_view'));
    }

    public function update($id, Request $request)
    {

        if (!hasAnyPermission(['edit_icon'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'icon_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:20|unique:cop_icon_ms,icon_name,' . decrypt($id) . ',icon_id',
            ],
            [
                'icon_name.required' => 'Icon Name required',
                'icon_name.regex' => 'Icon Name is invalid',
                'icon_name.min' => 'Minimum 2 Characters Are required',
                'icon_name.max' => 'Maximum 20 Characters are allowed',
                'icon_name.unique' => 'Icon Name Already Exists',
            ]
        );
        DB::beginTransaction();
        try {
            $icon_update = Icon::where('icon_id', decrypt($id))->first();
            if ($icon_update) {
                if (isset($request->icon_image)) {

                    $request->validate(
                        [
                            'icon_image' => 'image|mimes:svg|unique:cop_icon_ms,icon_image,' . decrypt($id) . ',icon_id|max:2048'
                        ],
                        [
                            'icon_image.image' => 'This must be an Image',
                            'icon_image.mimes' => 'Icon Image must be svg',
                            'icon_image.max' => 'Image should not be greater than 2 MB'
                        ]
                    );

                    $icon_id = $icon_update->icon_id;
                    $icon_image_Uploaded_File = $request->file('icon_image');
                    $imageImageName = $icon_id . '.' . $icon_image_Uploaded_File->getClientOriginalExtension();

                    $logoPathImg = 'icon/' . $icon_id . '/' . $imageImageName;
                    $content = file_get_contents($icon_image_Uploaded_File);
                    Storage::disk('digitalocean')->put($logoPathImg, $content, 'public');

                    $icon_update->icon_image = $imageImageName;
                }
                $icon_update->icon_name = $request->icon_name;
                $icon_update->status = $request->has('status') ? 1 : 0;
                $icon_update->update();
                DB::commit();
                session()->flash('success', 'Icon Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }


        return redirect()->route('icon.create');
    }

    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_icon'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $icon_destroy = Icon::WHERE('icon_id', decrypt($id))->first();
        DB::beginTransaction();
        try {
            if (!empty($icon_destroy)) {

                $iconfolderPath = 'icon/' . $icon_destroy->icon_id;
                if (Storage::disk('digitalocean')->exists($iconfolderPath)) {
                    Storage::disk('digitalocean')->deleteDirectory($iconfolderPath);
                }

                $icon_destroy->delete();
                DB::commit();
                session()->flash('success', 'Icon Deleted successfully.');
            } else {
                session()->flash('error', 'Something went wrong.');
            }
        } catch (Exception $e) {
            DB::commit();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }

        return redirect()->route('icon.create');
    }
    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');

        DB::table('cop_icon_ms')
            ->where('icon_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);

        return response()->json(['message', 'Status Updated Successfully']);
    }
}
