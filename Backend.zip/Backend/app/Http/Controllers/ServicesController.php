<?php

namespace App\Http\Controllers;

use App\Models\Services;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ServicesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $services = Services::all();
        return view('services.view', compact('services'));
    }

    public function list(Request $request)
    {
        $draw = $request->input('draw');
        $start = $request->input('start');
        $length = $request->input('length');
        $search = $request->input('search.value');
        $orderColumn = $request->input('order.0.column');
        $orderDirection = $request->input('order.0.dir');

        $query = Services::select([
            'cop_services_lead.sl_id',
            'cop_services_lead.brand_id',
            'cop_services_lead.model_id',
            'cop_services_lead.full_name',
            'cop_services_lead.email',
            'cop_services_lead.contact_no',
            'cop_services_lead.city_id',
            'cop_services_lead.created_at',
            'cop_models.model_name',
            'cop_brands_ms.brand_name',
            'cop_city_ms.city_name',
        ])
        ->leftJoin('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_services_lead.brand_id')
        ->leftJoin('cop_models', 'cop_models.model_id', '=', 'cop_services_lead.model_id')
        ->leftJoin('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_services_lead.city_id');

        if ($request->has('category')) {
            $category = $request->input('category');
            $query->where('category', $category);
        }

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('cop_services_lead.full_name', 'like', '%' . $search . '%')
                    ->orWhere('cop_services_lead.email', 'like', '%' . $search . '%')
                    ->orWhere('cop_services_lead.contact_no', 'like', '%' . $search . '%')
                    ->orWhere('cop_city_ms.city_name', 'like', '%' . $search . '%')
                    ->orWhere('cop_models.model_name', 'like', '%' . $search . '%')
                    ->orWhere('cop_brands_ms.brand_name', 'like', '%' . $search . '%');
            });
        }

        if ($orderColumn !== null) {
            $columns = [
                'sl_no',
                'created_at',
                'brand_name',
                'model_name',
                'full_name',
                'email',
                'contact_no',
                'city_name'
            ];
            $column = $columns[$orderColumn] ?? 'created_at';
            $query->orderBy($column, $orderDirection);
        }

        $recordsTotal = Services::count();
        $recordsFiltered = $query->count();
        $services = $query->skip($start)->take($length)->get();

        $services->transform(function ($item, $key) {
            return [
                'sl_no' => $key + 1,
                'created_at' => Carbon::parse($item->created_at)->format('d-m-Y'),
                'brand_id' => $item->brand_id,
                'model_id' => $item->model_id,
                'full_name' => $item->full_name,
                'email' => $item->email,
                'contact_no' => $item->contact_no,
                'city_name' => $item->city_name,
                'brand_name' => $item->brand_name,
                'model_name' => $item->model_name,
            ];
        });

        return response()->json([
            'draw' => $draw,
            'recordsTotal' => $recordsTotal,
            'recordsFiltered' => $recordsFiltered,
            'servicesResult' => $services
        ]);
    }

    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
