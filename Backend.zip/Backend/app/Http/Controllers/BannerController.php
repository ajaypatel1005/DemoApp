<?php

namespace App\Http\Controllers;

use App\Models\Banner;
use App\Models\BannerCategory;
use App\Models\Brand;
use App\Models\Model;
use App\Models\Variant;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use App\Rules\UniqueModelWithStatusOff;

class BannerController extends Controller
{

    public function fetchModels(Request $request)
    {
        try {
            $selectedBrandId = $request->input('brand_id');
            $selectedText = $request->input('selectedText');
            $models = [];

            $brands = Brand::active()->get(); // Fetch all brands
            if (!empty($selectedBrandId) && ($selectedText == 'Head Banner' || $selectedText == 'Upcoming Banner')) {
                // Fetch all models for the selected brand
                $models = Model::where('brand_id', $selectedBrandId)
                    ->active()
                    ->get();
            } else {
                // Fetch models for the selected brand, filter by model_type and status
                $models = Model::where('brand_id', $selectedBrandId)
                    ->where('model_type', 1)
                    ->active()
                    ->get();
            }

            // Return the models and brands in the response
            return response()->json(['models' => $models, 'brands' => $brands]);
        } catch (\Exception $e) {
            // Log the error or handle it as needed
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
            return response()->json(['error' => 'An error occurred while fetching models.']);
        }
    }

    public function fetchVariants(Request $request)
    {
        try {
            $selectedModelId = $request->input('model_id');

            if ($selectedModelId) {
                $variants = Variant::where('model_id', $selectedModelId)->active()->get();
            } else {
                $variants = [];
            }
            return response()->json(['variants' => $variants]);
        } catch (\Exception $e) {
            // Log the error or handle it as needed
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
            return response()->json(['error' => 'An error occurred while fetching variants.']);
        }
    }


    public function create()
    {
        if (!hasAnyPermission(['create_banner'])) {
            abort(403, "you don't have permission to access");
        }
        $banner_category = BannerCategory::all();
        // $brands = Brand::all();
        // $models = Model::all();
        $brands = Brand::active()->get();
        $models = Model::active()->get();
        $variants = Variant::active()->get();

        return view('banner.create', compact('banner_category', 'brands', 'models', 'variants'));
    }

    public function store(Request $request)
    {
        $bcId = $request->input('bc_id');
        $bc = BannerCategory::find($bcId);
        $bcName = $bc ? $bc->bc_name : null;
        $bannerId = $request->route('banner.store');
        $brand = ($bcName == config('constant.BANNER_CATEGORY.EV_BANNER') || $bcName == config('constant.BANNER_CATEGORY.HEAD_BANNER') || $bcName == config('constant.BANNER_CATEGORY.UPCOMING_BANNER')) && !$request->input('btn_link') ? 'required' : 'nullable';
        $description = 'nullable|min:2|max:1000';
        $btnLink = ($bcName == config('constant.BANNER_CATEGORY.EV_BANNER') || $bcName == config('constant.BANNER_CATEGORY.HEAD_BANNER') || $bcName == config('constant.BANNER_CATEGORY.UPCOMING_BANNER'))
            ? ($request->input('brand_id') ? 'nullable' : 'required')
            : 'required';
        $priorityRule = ($bcName == config('constant.BANNER_CATEGORY.EV_BANNER') || $bcName == config('constant.BANNER_CATEGORY.HEAD_BANNER') || $bcName == config('constant.BANNER_CATEGORY.UPCOMING_BANNER'))
            ? ['required', 'integer', Rule::unique('cop_banners')->where(function ($query) use ($bcId) {
                return $query->where('bc_id', $bcId);
            })]
            : 'nullable';
        $applyValidation = ($bcName == config('constant.BANNER_CATEGORY.EV_BANNER'));

        $request->validate(
            [
                'bc_id' => 'required|numeric',
                'banner_heading' => [
                    'required',
                    'min:2',
                    'max:50',
                    'unique:cop_banners,banner_heading',
                    'regex:/^[A-Za-z0-9\s!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]+$/',
                ],
                'banner_description' => $description,
                // 'banner_image' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
                'banner_image' => 'required|image|mimes:png,jpg,jpeg,webp',

                'btn_text' => $btnLink,
                'btn_link' => $btnLink,
                'brand_id' => $brand,
                'model_id' => [
                    ($applyValidation ? 'required' : 'nullable'),
                    'integer',
                    new UniqueModelWithStatusOff($bannerId),
                ],
                'variant_id' => 'nullable',
                'priority' => $priorityRule,
            ],
            [
                'bc_id.required' => 'Banner Category is required',
                'banner_heading' => 'Banner Heading is required',
                'banner_heading.regex' => 'Banner Heading name allow only alphanumeric character',
                'banner_heading.min' => 'The Banner Heading must be at least :min characters.',
                'banner_heading.max' => 'The Banner Heading must not exceed :max characters.',
                'banner_heading.unique' => 'Banner Heading name already exist',

                'banner_description.required' => 'The Banner Description is required.',
                'banner_description.min' => 'The Banner Description must be at least :min characters.',
                'banner_description.max' => 'The Banner Description must not exceed :max characters.',
                'banner_description.unique' => 'Banner Description has already been taken.',

                // 'banner_image.max' => 'Banner Image should not be greater than 2 MB',
                'banner_image.required' => 'Banner Image is required.',
                'banner_image.mimes' => 'Banner Image must be png,jpg,jpeg,webp',


                'btn_text' => 'Button Text is required',
                'btn_text.regex' => 'Button Text name contain only letters and spaces.',
                'btn_text.min' => 'The Button Text must be at least :min characters.',
                'btn_text.max' => 'The Button Text must not exceed :max characters.',

                'btn_link.required' => 'Button link is required',
                'btn_link.url' => 'Invalid URL format for the button link',

                'brand_id.required' => 'Brand Field is required',
                'model_id.required' => 'Model Field is required',
                'variant_id.required' => 'Variant Field is required',
                'model_id.unique' => 'This Model already exist',

                'priority.required' => 'The priority field is required.',
                'priority.integer' => 'The priority field must be an integer.',
                'priority.unique' => 'The priority value must be unique.'
            ]
        );


        DB::beginTransaction();
        try {
            $banner_store = Banner::create([
                'bc_id' => $request->bc_id,
                'brand_id' => $request->brand_id,
                'model_id' => $request->model_id,
                'variant_id' => $request->variant_id,
                'banner_heading' => $request->banner_heading,
                'image_alt' => $request->image_alt,
                'image_title' => $request->image_title,
                'banner_description' => $request->banner_description,
                'btn_text' => $request->btn_text,
                'btn_link' => $request->btn_link,
                'priority' => $request->priority,
                'created_by' => auth()->id(),
                'status' => $request->has('status') ? 1 : 0,
            ]);
            $banner_update = Banner::find($banner_store->banner_id);
            if (!empty($banner_update)) {
                $banner_id = $banner_update->banner_id;
                if($request->hasFile('banner_image')){
                    $uploadedImage = $request->file('banner_image');
                    $webpImageName = $banner_id . '.webp';
                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());
                    // read image from file system
                    // main image
                    $image = $manager->read($uploadedImage);
                    $path = 'Banner/' . $banner_id . '/' . $webpImageName;
                    Storage::disk('digitalocean')->put($path, $image->toWebp(), 'public');
                    // Thumbnail image
                    $image->resize(1920, 724);
                    $thumbnailPath = 'Banner/' . $banner_id . '/thumb/' . $webpImageName;
                    Storage::disk('digitalocean')->put($thumbnailPath, $image->toWebp(), 'public');
                    $banner_update->banner_image = $webpImageName;
                }
                if($request->hasFile('banner_image_mob')){
                    // Begin::Image Insert for Mobile
                    $uploadedImageMob = $request->file('banner_image_mob');
                    $webpImageNameMob = $banner_id . '_mob.webp';
                    $imageMob = $manager->read($uploadedImageMob);
                    $mobilePath = 'Banner/' . $banner_id . '/' . $webpImageNameMob;
                    Storage::disk('digitalocean')->put($mobilePath, $imageMob->toWebp(), 'public');
                    // Update the brand_logo in the Brand record
                    $banner_update->banner_image_mob = $webpImageNameMob;
                    // End::Image Insert for Mobile
                }
                $banner_update->update();
                DB::commit();
                session()->flash('success', 'Banner Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('banner.view');
    }

    public function view()
    {
        $banner_view = Banner::select('cop_banners.*', 'cop_bc_ms.bc_name as bc_name', 'cop_brands_ms.brand_name as brand_name', 'cop_models.model_name as model_name', 'cop_variants.variant_name as variant_name')
            ->leftJoin('cop_bc_ms', 'cop_banners.bc_id', '=', 'cop_bc_ms.bc_id')
            ->leftJoin('cop_brands_ms', 'cop_banners.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_models', 'cop_banners.model_id', '=', 'cop_models.model_id')
            ->leftJoin('cop_variants', 'cop_banners.variant_id', '=', 'cop_variants.variant_id')
            ->get();
        return view('banner.view', ['banner_view' => $banner_view]);
    }

    public function edit($id)
    {
        if (!hasAnyPermission(['edit_banner'])) {
            abort(403, "you don't have permission to access");
        }
        $banner_edit = Banner::where('banner_id', decrypt($id))->first();
        $banner_category = BannerCategory::all();
        $brands = Brand::active()->get();
        $models = collect();
        if (
            $banner_category->where('bc_id', $banner_edit->bc_id)->first() &&
            ($banner_category->where('bc_id', $banner_edit->bc_id)->first()->bc_name == 'Head Banner' ||
                $banner_category->where('bc_id', $banner_edit->bc_id)->first()->bc_name == 'Upcoming Banner')
        ) {
            $models = Model::where('brand_id', $banner_edit->brand_id)
                ->active()
                ->get();
        } elseif ($banner_category->where('bc_id', $banner_edit->bc_id)->first()->bc_name == 'EV Banner') {
            $models = Model::where('brand_id', $banner_edit->brand_id)
                ->where('model_type', '1')
                ->active()
                ->get();
        }

        // $variants = Variant::all();
        $variants = Variant::where('model_id', $banner_edit->model_id)
            ->active()
            ->get();
        return view('banner.edit', compact('banner_edit', 'banner_category', 'brands', 'models', 'variants'));
    }


    public function update(Request $request, $id)
    {

        $bcId = $request->input('bc_id');
        $bc = BannerCategory::find($bcId);
        $bcName = $bc ? $bc->bc_name : null;
        $bannerId = $request->route('banner.store');

        $brand = ($bcName == config('constant.BANNER_CATEGORY.EV_BANNER') || $bcName == config('constant.BANNER_CATEGORY.HEAD_BANNER') || $bcName == config('constant.BANNER_CATEGORY.UPCOMING_BANNER')) && !$request->input('btn_link') ? 'required' : 'nullable';
        $description = 'nullable|min:2|max:1000';
        $btnLink = ($bcName == config('constant.BANNER_CATEGORY.EV_BANNER') || $bcName == config('constant.BANNER_CATEGORY.HEAD_BANNER') || $bcName == config('constant.BANNER_CATEGORY.UPCOMING_BANNER'))
            ? ($request->input('brand_id') ? 'nullable' : 'required')
            : 'required';
        $priorityRule = ($bcName == config('constant.BANNER_CATEGORY.EV_BANNER') || $bcName == config('constant.BANNER_CATEGORY.HEAD_BANNER') || $bcName == config('constant.BANNER_CATEGORY.UPCOMING_BANNER'))
            ? ['required', 'integer', Rule::unique('cop_banners')->where(function ($query) use ($bcId) {
                return $query->where('bc_id', $bcId);
            })->ignore(decrypt($id), 'banner_id')]
            : 'nullable';
        $applyValidation = ($bcName == config('constant.BANNER_CATEGORY.EV_BANNER'));

        $request->validate(
            [
                'bc_id' => 'required|numeric',
                'banner_heading' => [
                    'required',
                    'min:2',
                    'max:50',
                    Rule::unique('cop_banners')->ignore(decrypt($id), 'banner_id'),
                    'regex:/^[A-Za-z0-9\s!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]+$/',
                ],
                'banner_description' => $description,
                'banner_image' => [
                    $bcId ? 'nullable' : 'required',
                    'image',
                    'mimes:png,jpg,jpeg,webp',
                    // 'max:2048',
                    
                ],
                'btn_text' => $btnLink,
                'btn_link' => $btnLink,
                'brand_id' => $brand,
                'model_id' => [
                    ($applyValidation ? 'required' : 'nullable'),
                    'integer',
                    new UniqueModelWithStatusOff($bannerId),
                ],
                'variant_id' => 'nullable',
                'priority' => $priorityRule,
            ],
            [
                'bc_id.required' => 'Banner Category is required',
                'banner_heading' => 'Banner Heading is required',
                'banner_heading.regex' => 'Banner Heading name allow only alphanumeric character',
                'banner_heading.min' => 'The Banner Heading must be at least :min characters.',
                'banner_heading.max' => 'The Banner Heading must not exceed :max characters.',
                'banner_heading.unique' => 'Banner Heading name already exist',

                'banner_description.required' => 'The Banner Description is required.',
                'banner_description.min' => 'The Banner Description must be at least :min characters.',
                'banner_description.max' => 'The Banner Description must not exceed :max characters.',
                'banner_description.unique' => 'Banner Description has already been taken.',

                'banner_image.max' => 'Banner Image should not be greater than 2 MB',
                'banner_image.required' => 'Banner Image is required.',
                'banner_image.mimes' => 'Banner Image must be png,jpg,jpeg,webp',


                'btn_text' => 'Button Text is required',
                'btn_text.regex' => 'Button Text name contain only letters and spaces.',
                'btn_text.min' => 'The Button Text must be at least :min characters.',
                'btn_text.max' => 'The Button Text must not exceed :max characters.',

                'btn_link.required' => 'Button link is required',
                'btn_link.url' => 'Invalid URL format for the button link',

                'brand_id.required' => 'Brand Field is required',
                'model_id.required' => 'Model Field is required',
                'variant_id.required' => 'Variant Field is required',
                'model_id.unique' => 'This Model already exist',

                'priority.required' => 'The priority field is required.',
                'priority.integer' => 'The priority field must be an integer.',
                'priority.unique' => 'The priority value must be unique.'
            ]
        );

        DB::beginTransaction();
        try {
            $banner_update = Banner::where('banner_id', decrypt($id))->first();
            $imagePath = 'Banner/' . $banner_update->banner_id . '/' . $banner_update->banner_image;
            $imagePathMob = 'Banner/' . $banner_update->banner_id . '/' . $banner_update->banner_image_mob;
            $imageThumbPath = 'Banner/' . $banner_update->banner_id . '/thumb/' . $banner_update->banner_image;
            if (!empty($banner_update)) {

                // Begin::Update banner_image_mob if mobile banner image select
                if (isset($request->banner_image_mob)) {
                    Storage::disk('digitalocean')->deleteDirectory($imagePathMob);
                    $banner_id = $banner_update->banner_id;
                    $uploadedImageMob = $request->file('banner_image_mob');
                    $webpImageNameMob = $banner_id . '_mob.webp';
                    $manager = new ImageManager(new Driver());
                    $imageMob = $manager->read($uploadedImageMob);
                    // save image on s3
                    $bannerPath = 'Banner/' . $banner_id . '/' . $webpImageNameMob;
                    Storage::disk('digitalocean')->put($bannerPath, $imageMob->toWebp(), 'public');


                    $banner_update->banner_image_mob = $webpImageNameMob;
                    $banner_update->update();
                }
                // End::Update banner_image_mob if mobile banner image select


                if (isset($request->banner_image)) {
                    Storage::disk('digitalocean')->deleteDirectory($imagePath);
                    Storage::disk('digitalocean')->deleteDirectory($imageThumbPath);
                    $banner_id = $banner_update->banner_id;
                    $uploadedImage = $request->file('banner_image');
                    $webpImageName = $banner_id . '.webp';
                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());
                    $image = $manager->read($uploadedImage);
                    // save image on s3
                    $bannerPath = 'Banner/' . $banner_id . '/' . $webpImageName;
                    Storage::disk('digitalocean')->put($bannerPath, $image->toWebp(), 'public');
                    // Thumbnail image
                    $image->resize(1920, 724);
                    $bannerThumbPath = 'Banner/' . $banner_id . '/thumb/' . $webpImageName;
                    Storage::disk('digitalocean')->put($bannerThumbPath, $image->toWebp(), 'public');
                    // Update the brand_logo in the Brand record
                    $banner_update->banner_image = $webpImageName;
                    $banner_update->update();
                }

                if (in_array($request->bc_id, ['3', '4'])) {
                    $banner_update->brand_id = null;
                    $banner_update->model_id = null;
                    $banner_update->variant_id = null;
                } else {
                    // Update brand_id, model_id, and variant_id with new values
                    $banner_update->brand_id = $request->brand_id;
                    $banner_update->model_id = $request->model_id;
                    $banner_update->variant_id = $request->variant_id;
                }

                // Update the banner_name with the new value
                $banner_update->bc_id = $request->bc_id;
                // $banner_update->brand_id = $request->brand_id;
                // $banner_update->model_id = $request->model_id;
                // $banner_update->variant_id = $request->variant_id;
                $banner_update->banner_heading = $request->banner_heading;
                $banner_update->image_alt = $request->image_alt;
                $banner_update->image_title = $request->image_title;
                $banner_update->banner_description = $request->banner_description;
                $banner_update->btn_text = $request->btn_text;
                $banner_update->btn_link = $request->btn_link;
                $banner_update->priority = $request->priority;
                $banner_update->updated_by = auth()->id();
                $banner_update->status = $request->has('status') ? 1 : 0;
                $banner_update->update();
                DB::commit();
                session()->flash('success', 'Banner Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('banner.view');
    }

    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_banner'])) {
            abort(403, "you don't have permission to access");
        }
        DB::beginTransaction();
        try {
            $banner_destroy = Banner::where('banner_id', decrypt($id))->first();
            $imagePath = 'Banner/' . $banner_destroy->banner_id;
            if (!empty($banner_destroy)) {
                Storage::disk('digitalocean')->deleteDirectory($imagePath);
                $banner_destroy->delete();
                DB::commit();
                session()->flash('success', 'Banner Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong!');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('banner.view');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_banners')
            ->where('banner_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status Updated Successfully']);
    }

    public function encryptor(Request $request)
    {
        $action = $request->input('action');
        $string = $request->input('str');
        return encryptor($action, $string);
        // $secret_key = 'iWPPtLfcVTZtb1rJlGY2eL958g9dfhQpt797BU8LMfS2WvEkwI';
        // $secret_iv = 'm4iSFgKgxwVMWuTyOjUUTCGjJSJKJShH';

        // $output = false;
        // $encrypt_method = 'AES-256-CBC';
        // // hash
        // $key = hash('sha256', $secret_key);
        // // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        // $iv = substr(hash('sha256', $secret_iv), 0, 16);

        // //do the encyption given text/string/number
        // if ($action == 'e') {
        //     $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        //     $output = base64_encode($output);
        // } elseif ($action == 'd') {
        //     //decrypt the given text/string/number
        //     $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        // }

        // return $output;
    }
}
