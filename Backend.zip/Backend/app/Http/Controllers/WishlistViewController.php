<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;
use App\Models\User;
use App\Models\Wishlist;
use DateTime;
use Illuminate\Support\Facades\DB;

class WishlistViewController extends Controller
{
    public function index()
    {

        if (!hasAnyPermission(['view_wishlist'])) {
            abort(403, "you don't have permission to access");
        }

        return view('wishlist.view');
    }

    public function fetchRecord(Request $request)
    {
        if($request->ajax()) {
            $limit = ($request->has('length') ? $request->input('length') : 10);
            $page = ($request->has('start') ? $request->input('start') : 0);
            $search = ($request->has('search') ? $request->input('search')['value'] : '');

            // $city_view = Wishlist::select(
            //     'cop_wl.model_id',
            //     'cop_wl.customer_id',
            //     'cop_wl.created_at'
            // )
            // ->with(['brands','models','customers'])
            // ->get();

            // dd($city_view);
            $wishlist = Wishlist::select(
                'cop_wl.model_id',
                'cop_wl.customer_id',
                'cop_wl.created_at',
                'cop_wl.created_date',
                'cop_brands_ms.brand_name',
                'cop_models.model_name',
                'cop_customers.first_name',
                'cop_customers.last_name',
                'cop_customers.contact_no',
                'cop_city_ms.city_name',
            )
            ->join('cop_models','cop_models.model_id','=','cop_wl.model_id')
            ->join('cop_brands_ms','cop_brands_ms.brand_id','=','cop_models.brand_id')
            ->leftJoin('cop_customers','cop_customers.customer_id','=','cop_wl.customer_id')
            ->leftJoin('cop_city_ms','cop_city_ms.city_id','=','cop_customers.selected_city_id');

            if (!empty($search)) {
                $wishlist->where(function ($query) use ($search) {
                    $query->orWhere('cop_brands_ms.brand_name', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_models.model_name', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_customers.first_name', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_customers.last_name', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_customers.contact_no', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_wl.created_date', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_city_ms.city_name', 'LIKE', '%' . $search . '%');
                });
            }

            $cntFilter = clone $wishlist;
            $wishlist->offset($page)->limit($limit);
            $wishlist = $wishlist->orderBy('created_date', 'desc')->get();

            $wishlistTotal = DB::select("SELECT COUNT(*) AS count FROM cop_wl
            INNER JOIN cop_models ON cop_models.model_id = cop_wl.model_id
            INNER JOIN cop_brands_ms ON cop_brands_ms.brand_id = cop_models.brand_id
            LEFT JOIN cop_customers ON cop_customers.customer_id = cop_wl.customer_id
            LEFT JOIN cop_city_ms ON cop_city_ms.city_id = cop_customers.selected_city_id
            ")[0]->count;

            $data = [];
            $i = $page;
            foreach ($wishlist as $item) {
                $i++;

                // remove static 91 from starting of the mobile number
                if (substr($item->contact_no, 0, 2) === '91') {
                    $contact_no = substr($item->contact_no, 2);
                } else {
                    $contact_no = $item->contact_no;
                }

                // change date formate
                $date = new DateTime($item->created_date);
                $formattedDate = $date->format('Y-m-d g:i A');

                $data[] = array("sr_no" => $i,
                "brand_name" => $item->brand_name ? $item->brand_name : "-",
                "model_name" => $item->model_name ? $item->model_name : "-",
                "user_name" => ($item->first_name ? encryptor('d',$item->first_name) : "").' '.($item->last_name ? encryptor('d',$item->last_name) : ""),
                "user_contact" => $contact_no ? encryptor('d',$contact_no) : "-",
                "user_selected_city" => $item->city_name ? $item->city_name : "-",
                "add_date" => $formattedDate ? $formattedDate : "-");
            }
            return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $wishlistTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));

        }
    }
}
