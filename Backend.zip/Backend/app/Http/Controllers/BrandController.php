<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\ImageManager;
use Illuminate\Support\Str;

use Intervention\Image\Drivers\Gd\Driver;

class BrandController extends Controller
{
    public function create()
    {
        if (!hasAnyPermission(['create_brand', 'view_brand'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $brands_view = Brand::all();
        return view('brands.create', compact('brands_view'));
    }

    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_brand'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'brand_name' => 'required|min:2|max:30|unique:cop_brands_ms,brand_name',
                'brand_logo' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
                'brand_banner' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
                'brand_description' => 'required|min:2|max:1000|unique:cop_brands_ms,brand_description',

            ],
            [
                'brand_name.required' => 'Brand Name Required',
                'brand_logo.required' => 'Brand Logo Required',
                // 'brand_name.regex' => 'Brand Name is Invalid',
                'brand_logo.image' => 'This must be an Image',
                'brand_logo.mimes' => 'Brand Logo must be png,jpg,jpeg,webp',
                'brand_logo.max' => 'Brand Logo should not be greater than 2 MB',
                'brand_banner.required' => 'Brand Banner Required',
                'brand_banner.image' => 'This must be an Image',
                'brand_banner.mimes' => 'Brand Banner must be png,jpg,jpeg,webp',
                'brand_banner.max' => 'Brand Banner should not be greater than 2 MB',
                'brand_description.required' => 'The Brand Description is required.',
                'brand_description.min' => 'The Brand Description must be at least :min characters.',
                'brand_description.max' => 'The Brand Description must not exceed :max characters.',
                'brand_description.unique' => 'Brand Description has already been taken.',
                'brand_name.max' => 'Brand name field must not be greater than 25 characters',
                'brand_name.min' => 'Brand name field must be at least 2 characters',
            ]
        );
        DB::beginTransaction();
        try {
            $brands_store = new Brand();
            if ($brands_store) {
                $brands_store->brand_name = $request->brand_name;        //name

                $brands_store->slug = \Illuminate\Support\Str::slug($request->brand_name, '-');


                $brands_store->brand_description = $request->brand_description;
                $brands_store->created_by = auth()->id();     //description
                $brands_store->status = $request->has('status') ? 1 : 0;
                $brands_store->save();
                //Brand Logo
                $brand_id = $brands_store->brand_id;
                $brand_logo_Uploaded_File = $request->file('brand_logo');
                $manager = new ImageManager(new Driver());
                $logoPath = 'brands/' . $brand_id . '/';
                if (!empty($brand_logo_Uploaded_File)) {
                    $logoWebpImageName = $brand_id . '.webp';
                    // read image from file system
                    $image = $manager->read($brand_logo_Uploaded_File);

                    //logo store in bucket
                    Storage::disk('digitalocean')->put($logoPath . $logoWebpImageName, $image->toWebp(), 'public');

                    // Thumbnail image
                    $image->resize(300, 200);
                    $brands_store->brand_logo = $logoWebpImageName;

                    Storage::disk('digitalocean')->put($logoPath . 'thumb/' . $logoWebpImageName, $image->toWebp(), 'public');
                    $brands_store->update();
                }

                //Brand Banner
                $bannerUploadedFile = $request->file('brand_banner');
                if (!empty($bannerUploadedFile)) {
                    $bannerWebpImageName = $brand_id . '_banner.webp';
                    $image = $manager->read($bannerUploadedFile);
                    Storage::disk('digitalocean')->put($logoPath . $bannerWebpImageName, $image->toWebp(), 'public');

                    // Thumbnail image
                    $image->resize(1920, 580);
                    $brands_store->brand_banner = $bannerWebpImageName;
                    $brands_store->update();
                    Storage::disk('digitalocean')->put($logoPath . 'thumb/' . $bannerWebpImageName, $image->toWebp(), 'public');
                }
                DB::commit();
                session()->flash('success', 'Brand Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('brands.create');
    }




    public function edit($id)
    {
        if (!hasAnyPermission(['edit_brand', 'view_brand'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $brands_edit = Brand::where('brand_id', decrypt($id))->first();
        $brands_view = Brand::all();
        return view('brands.edit', compact('brands_edit', 'brands_view'));
    }

    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_brand'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'brand_name' => 'required|min:2|max:30|unique:cop_brands_ms,brand_name,' . decrypt($id) . ',brand_id',
                'brand_description' => 'required|min:2|max:1000|unique:cop_brands_ms,brand_description,' . decrypt($id) . ',brand_id',
                'brand_logo' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
                'brand_banner' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            ],
            [
                'brand_name.required' => 'Brand Name Required',
                // 'brand_name.regex'=>'Brand Name is Invalid',
                'brand_description.required' => 'The Brand Description is required.',
                'brand_description.min' => 'The Brand Description must be at least :min characters.',
                'brand_description.max' => 'The Brand Description must not exceed :max characters.',
                'brand_description.unique' => 'Brand Description has already been taken.',
                'brand_logo.required' => 'Brand Logo Required',
                'brand_logo.image' => 'This must be an Image',
                'brand_logo.mimes' => 'Brand Logo must be png,jpg,jpeg,webp',
                'brand_logo.max' => 'Brand Logo should not be greater than 2 MB',
                'brand_banner.required' => 'Brand Banner Required',
                'brand_banner.image' => 'This must be an Image',
                'brand_banner.mimes' => 'Brand Banner must be png,jpg,jpeg,webp',
                'brand_banner.max' => 'Brand Banner should not be greater than 2 MB',
                'brand_name.max' => 'Brand name field must not be greater than 25 characters',
                'brand_name.min' => 'Brand name field must be at least 2 characters',
            ]
        );
        DB::beginTransaction();
        try {
            $brands_update = Brand::WHERE('brand_id', decrypt($id))->first();
            $brand_id = $brands_update->brand_id;
            if (!empty($brands_update)) {
                //Brand Logo
                $logoPath = 'brands/' . $brand_id . '/';
                $manager = new ImageManager(new Driver());
                if (isset($request->brand_logo)) {

                    $brand_logo_Uploaded_File = $request->file('brand_logo');
                    $logoWebpImageName = $brand_id . '.webp';

                    // read image from file system
                    $image = $manager->read($brand_logo_Uploaded_File);
                    Storage::disk('digitalocean')->put($logoPath . $logoWebpImageName, $image->toWebp(), 'public');
                    // Thumbnail image
                    $image->resize(300, 200);
                    Storage::disk('digitalocean')->put($logoPath . 'thumb/' . $logoWebpImageName, $image->toWebp(), 'public');
                    $brands_update->brand_logo = $logoWebpImageName;
                }
                //Brand Banner
                if (isset($request->brand_banner)) {
                    $bannerUploadedFile = $request->file('brand_banner');
                    $bannerWebpImageName = $brand_id . '_banner.webp';
                    // read image from file system
                    $image = $manager->read($bannerUploadedFile);
                    Storage::disk('digitalocean')->put($logoPath . $bannerWebpImageName, $image->toWebp(), 'public');
                    // Thumbnail image
                    $image->resize(1920, 580);
                    Storage::disk('digitalocean')->put($logoPath . 'thumb/' . $bannerWebpImageName, $image->toWebp(), 'public');
                    $brands_update->brand_banner = $bannerWebpImageName;
                }

                $brands_update->brand_name = $request->brand_name;        //name
                $brands_update->slug = \Illuminate\Support\Str::slug(strtolower($request->brand_name), '-');

                $brands_update->brand_description = $request->brand_description;     //description
                $brands_update->status = $request->has('status') ? 1 : 0;
                $brands_update->updated_by = auth()->id();
                $brands_update->update();
                DB::commit();
                session()->flash('success', 'Brand Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('brands.create');
    }

    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_brand'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $brands_delete = Brand::WHERE('brand_id', decrypt($id))->first();
        DB::beginTransaction();
        try {
            if ($brands_delete) {

                if ($brands_delete->models->isNotEmpty() || $brands_delete->variants->isNotEmpty() || $brands_delete->banners->isNotEmpty() || $brands_delete->car_graphics->isNotEmpty() || $brands_delete->car_listing_data->isNotEmpty() ||  $brands_delete->price_entry->isNotEmpty() || $brands_delete->manager->isNotEmpty()) {
                    session()->flash('error', 'This field value cannot be deleted because other records are using it.');
                    return redirect()->route('brands.create');
                }
                $bucketPath = 'brands/' . $brands_delete->brand_id;
                Storage::disk('digitalocean')->deleteDirectory($bucketPath);
                $brands_delete->delete();
                DB::commit();
                session()->flash('success', 'Brand Deleted successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('brands.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');

        DB::table('cop_brands_ms')
            ->where('brand_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);

        return response()->json(['message', 'Status Updated Successfully']);
    }

    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            try {
                $limit = ($request->has('length') ? $request->input('length') : 10);
                $page = ($request->has('start') ? $request->input('start') : 0);
                $search = ($request->has('search') ? $request->input('search')['value'] : '');

                $brand_view = Brand::select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_brands_ms.status'
                );
                if (!empty($search)) {
                    $brand_view->where('cop_brands_ms.brand_name', 'LIKE', '%' . $search . '%');
                }

                $cntFilter = clone $brand_view;
                $brand_view->offset($page)->limit($limit);
                $brand_view = $brand_view->get();

                $brandTotal = DB::select("SELECT COUNT(*) AS count FROM cop_brands_ms")[0]->count;
                $data = [];
                $i = $page;
                foreach ($brand_view as $member) {
                    $i++;
                    $status = $disable = "";
                    if ($member->status == 1) {
                        $status = 'checked';
                    }
                    $disable = (!auth()->user()->can('edit_brand')) ? 'disabled' : '';

                    $model_status = '<div
                    class="form-check form-switch form-check-custom form-check-success form-check-solid">
                    <input class="form-check-input status" name="status" type="checkbox" value="' . $member->brand_id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>';
                    $action = "";
                    if (auth()->user()->can('edit_brand')) {
                        $editRoute = route('brands.edit', encrypt($member->brand_id));
                        $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                            <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                    }
                    if (auth()->user()->can('delete_brand')) {
                        $action .= '<a href="javascript:void(0);"
                        data-href="' . route('brands.destroy', encrypt($member->brand_id)) . '"
                        class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                    }
                    $data[] = array("sr_no" => $i, "brand_name" => $member->brand_name, "status" => $model_status, "action" => $action);
                }
                return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $brandTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            }
        }
    }
}
