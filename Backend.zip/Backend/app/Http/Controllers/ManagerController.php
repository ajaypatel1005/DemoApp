<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Language;
use Exception;
use App\Models\Manager;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Hash;


class ManagerController extends Controller
{

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_managers', 'view_managers'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $manager_view = Manager::with('users.roles')->select('cop_manager_ms.*', 'cop_brands_ms.brand_name as brand_name')
            ->leftJoin('cop_brands_ms', 'cop_manager_ms.brand_id', '=', 'cop_brands_ms.brand_id')
//            ->leftJoin('cop_ml_ms', 'cop_manager_ms.lang_id', '=', 'cop_ml_ms.lang_id')
            ->get();
        $brands = Brand::active()->get();
        $langs = DB::select('select lang_id,lang_name from cop_ml_ms where status = 1');
        $roles = Role::whereIn('name', [config('constant.CRM_ROLE.RELATIONSHIP_MANAGER'), config('constant.CRM_ROLE.TELECALLER')])->pluck('name');
        return view('manager.create', compact('brands', 'langs', 'manager_view',  'roles'));
    }

    /**
     * Store a newly created resource in storage.
     */

    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_managers'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'brand_id' => 'required|numeric',
            'roles' => 'required',
            'lang_id' => 'required|array',
            'first_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:30',
            'last_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:30',
            'm_image' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048|unique:cop_manager_ms,m_image',
            'm_email' => 'required|email|unique:cop_manager_ms,m_email|unique:users,email',
            'm_contact_no' => 'required|min:10|max:10|regex:/^[0-9]+$/|unique:cop_manager_ms,m_contact_no',
            'm_shift' => 'required',
        ], [
            'brand_id.required' => 'Select Brand is required',
            'roles.required' => 'Select Role is required',
            'lang_id.required' => 'Select Language is required',
            'first_name.required' => 'First Name is required',
            'first_name.regex' => 'First Name is invalid',
            'last_name.required' => 'Last Name is required',
            'last_name.regex' => 'Last Name is invalid',
            'm_image.required' => 'Manager Image is required',
            'm_image.max'=>'Image cannot be greater than 2 MB',
            'm_image.mimes' => 'Manager Image must be a PNG, JPG, JPEG, or WebP file.',
            'm_email.required' => 'Email is required',
            'm_email.email' => 'Please enter a valid email address',
            'm_email.unique' => 'This Email has already been taken.',

            'm_contact_no.required' => 'Contact is required',
            'm_contact_no.unique' => 'Contact No. has already been taken.',
            'm_contact_no.min' => 'The Contact Number must be at least :min characters.',
            'm_contact_no.max' => 'The Contact Number must not exceed :max characters.',

            'm_shift.required' => 'Shift is required',

        ]);
        DB::beginTransaction();
        try {
            $manager_store = new Manager();
            $manager_store->brand_id = $request->brand_id;
            $manager_store->lang_id = implode(',',$request->lang_id);
            $manager_store->first_name = $request->first_name;
            $manager_store->last_name = $request->last_name;
            $manager_store->m_email = $request->m_email;
            $manager_store->m_contact_no = $request->m_contact_no;
            $manager_store->m_shift = $request->m_shift;
            $manager_store->status = $request->has('status') ? 1 : 0;
            $manager_store->save();


            $manager_update = Manager::find($manager_store->manager_id);

            if ($manager_update) {

                $user = User::create([
                    'name' => $request->first_name . " " . $request->last_name,
                    'email' => $request->m_email,
                    'password' => Hash::make($request->m_contact_no),
                ]);
                $user->assignRole($request->roles);

                $manager_id = $manager_update->manager_id;
                $uploadedImage = $request->file('m_image');
                $webpImageName = $manager_id . '.webp';

                $uploadedImage->move(public_path('Manager') . '/' . $manager_id, $webpImageName);

                // Update the m_image in the Manager record
                $manager_update->m_image = $webpImageName;
                $manager_update->user_id = $user->id;
                $manager_update->update();

                session()->flash('success', 'Manager Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.'.$e);
        }

        return redirect()->route('manager.create');
    }

    /**
     * Display the specified resource.
     */
    //        public function view()
    //    {
    //        $manager_view = Manager::select('cop_manager_ms.*', 'cop_brands_ms.brand_name as brand_name', 'cop_ml_ms.lang_name as lang_name')
    //            ->leftJoin('cop_brands_ms', 'cop_manager_ms.brand_id', '=', 'cop_brands_ms.brand_id')
    //            ->leftJoin('cop_ml_ms', 'cop_manager_ms.lang_id', '=', 'cop_ml_ms.lang_id')
    //            ->get();
    //
    //        return view('manager.view', ['manager_view' => $manager_view]);
    //    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_managers', 'view_managers'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $manager_view = Manager::select('cop_manager_ms.*', 'cop_brands_ms.brand_name as brand_name')
        ->leftJoin('cop_brands_ms', 'cop_manager_ms.brand_id', '=', 'cop_brands_ms.brand_id')
        //            ->leftJoin('cop_ml_ms', 'cop_manager_ms.lang_id', '=', 'cop_ml_ms.lang_id')
        ->get();

        $manager_edit = Manager::where('manager_id', decrypt($id))->first();
        $manager_edit->lang_id = explode(',',$manager_edit->lang_id);
        $brands = Brand::active()->get();
        $langs = DB::select('select * from cop_ml_ms where status = 1');
        $user = User::findOrFail($manager_edit->user_id);
        $roles = Role::whereIn('name', ['Relationship Manager', 'Telecaller'])->pluck('name');
        $userRoles = $user->roles->pluck('name')->all();
        return view('manager.edit', compact('manager_edit', 'brands', 'langs', 'manager_view', 'roles', 'userRoles'));
    }

    /**
     * Update the specified resource in storage.
     */

    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_managers'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'brand_id' => 'required|numeric',
            'lang_id' => 'required|array',
            'first_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:30',
            'last_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:30',
            'm_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048|unique:cop_manager_ms,m_image,' . decrypt($id) . ',manager_id',
            'm_email' => 'required|email|unique:cop_manager_ms,m_email,' . decrypt($id) . ',manager_id',

            'm_contact_no' => 'required|min:10|max:10|regex:/^[0-9]+$/|unique:cop_manager_ms,m_contact_no,' . decrypt($id) . ',manager_id',
            'm_shift' => 'required',
        ], [
            'brand_id.required' => 'Select Brand is required',
            'lang_id.required' => 'Select Language is required',
            'first_name.required' => 'First Name is required',
            'first_name.regex' => 'First Name is invalid',
            'last_name.required' => 'Last Name is required',
            'last_name.regex' => 'Last Name is invalid',
            'm_image.nullable' => 'Manager Image is required',
            'm_image.max'=>'Image cannot be greater than 2 MB',
            'm_image.mimes' => 'Manager Image must be a PNG, JPG, JPEG, or WebP file.',
            'm_email.email' => 'Please enter a valid email address.',
            'm_email.required' => 'Email is required',
            'm_email.unique' => 'This Email has already been taken.',
            'm_email' => 'Email must be a valid format.',

            'm_contact_no.unique' => 'Contact No. must be unique',
            'm_contact_no.required' => 'Contact is required',
            'm_contact_no.min' => 'The Contact Number must be at least :min characters.',
            'm_contact_no.max' => 'The Contact Number must not exceed :max characters.',
            'm_shift.required' => 'Shift is required',
        ]);


        DB::beginTransaction();

        try {
            $manager_update = Manager::where('manager_id', decrypt($id))->first();


            $imagePath = 'Manager/' . $manager_update->manager_id . '/' . $manager_update->manager_id;


            if ($manager_update) {
                if (isset($request->m_image)) {
                    File::deleteDirectory($imagePath);

                    $manager_id = $manager_update->manager_id;
                    $uploadedImage = $request->file('m_image');
                    $webpImageName = $manager_id . '.webp';
                    $uploadedImage->move(public_path('Manager') . '/' . $manager_id, $webpImageName);
                    // Run the cwebp command to convert the image to WebP

                    // Update the brand_logo in the Brand record
                    $manager_update->m_image = $webpImageName;
                }

                // Update other fields
                $manager_update->brand_id = $request->brand_id;
                $manager_update->lang_id = implode(',',$request->lang_id); // Make sure lang_id is available in the request
                $manager_update->first_name = $request->first_name;
                $manager_update->last_name = $request->last_name;
                $manager_update->m_email = $request->m_email;
                $manager_update->m_contact_no = $request->m_contact_no;
                $manager_update->m_shift = $request->m_shift;
                $manager_update->status = $request->has('status') ? 1 : 0;


                $manager_update->update();

                if($manager_update)
                {
                $user = User::findOrFail($manager_update->user_id);
                $user->name = $request->first_name." ".$request->last_name;
                $user->email = $request->m_email;
                $user->save();
                $user->syncRoles($request->roles);
              }

                session()->flash('success', 'Manager Updated Successfully.');
            } else {
                session()->flash('error', 'Record Not Found.');
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('manager.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_managers'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $manager_destroy = Manager::where('manager_id', decrypt($id))->first();
            $imagePath = 'Manager/' . $manager_destroy->manager_id;



            if (!empty($manager_destroy)) {
                if (File::isDirectory($imagePath)) {

                    File::deleteDirectory($imagePath);
                    $manager_destroy->delete();

                    $user = User::findOrFail($manager_destroy->user_id);
                    $user->delete();
                }

                session()->flash('success', 'Manager Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong!');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('manager.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_manager_ms')
            ->where('manager_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
}
