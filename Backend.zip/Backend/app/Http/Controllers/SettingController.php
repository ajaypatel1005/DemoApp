<?php

namespace App\Http\Controllers;

use App\Models\SystemSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Exception;


class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $keys = SystemSetting::KEY;
        return view('setting.create', compact('keys'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_system_setting'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'key' => 'required',
                'value' => 'required|unique:cop_setting,value'
            ],
            [
                'key.required' => 'Key type is required',
                'value.required' => 'Value is required',
            ]
        );

        DB::beginTransaction();
        try {
            SystemSetting::create([
                'key' => $request->key,
                'value' => $request->value
            ]);
            DB::commit();
            session()->flash('success', 'Setting Added Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('setting.create');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_system_setting', 'view_system_setting'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $setting_edit = SystemSetting::where('id', decrypt($id))->first();
        $keys = SystemSetting::KEY;
        return view('setting.edit', compact('setting_edit', 'keys'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update($id, Request $request)
    {
        if (!hasAnyPermission(['edit_system_setting'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'key' => 'required',
                'value' => 'required|unique:cop_setting,value,' . decrypt($id),
            ],
            [
                'key.required' => 'Key type is required',
                'value.required' => 'Value is required',
            ]
        );

        DB::beginTransaction();
        try {
            $setting_update = SystemSetting::where('id', decrypt($id))->first();

            if (!empty($setting_update)) {
                $setting_update->key = $request->key;
                $setting_update->value = $request->value;
                $setting_update->update();
                DB::commit();
                session()->flash('success', 'Setting Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('setting.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_system_setting'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $setting_destroy = SystemSetting::WHERE('id', decrypt($id))->first();
        DB::beginTransaction();
        try {
            if (!empty($setting_destroy)) {
                $setting_destroy->delete();
                DB::commit();
                session()->flash('success', 'Setting Deleted successfully.');
            } else {
                DB::rollBack();
                session()->flash('error', 'Something went wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }

        return redirect()->route('setting.create');
    }

    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            try {
                $limit = ($request->has('length') ? $request->input('length') : 10);
                $page = ($request->has('start') ? $request->input('start') : 0);
                $search = ($request->has('search') ? $request->input('search')['value'] : '');

                $setting_view = SystemSetting::select('cop_setting.id', 'cop_setting.key', 'cop_setting.value', 'cop_setting.is_expired', 'created_at');

                if (!empty($search)) {
                    $setting_view->where(function ($query) use ($search) {
                        $query->orWhere('cop_setting.key', 'LIKE', '%' . $search . '%');
                    });
                }

                $cntFilter = clone $setting_view;
                $setting_view->offset($page)->limit($limit);
                $setting_view = $setting_view->get();

                $settingTotal = DB::select("SELECT COUNT(*) AS count FROM cop_setting")[0]->count;
                $data = [];
                $i = $page;
                $key = SystemSetting::KEY;
                foreach ($setting_view as $member) {
                    $i++;

                    $is_expired = '';
                    if ($member->is_expired == 0) {
                        $is_expired = 'checked';
                        $key_is_expired = '<i class="fas fa-check-circle fs-2" style="color:#72BC59;"></i>';
                    } else if ($member->is_expired == 1) {
                        $key_is_expired = '<i class="fas fa-minus-circle fs-2" style="color:#E1472E;"></i>';
                    }

                    $action = "";
                    if (auth()->user()->can('edit_system_setting')) {
                        $editRoute = route('setting.edit', encrypt($member->id));
                        $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                                <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                    }
                    if (auth()->user()->can('delete_system_setting')) {
                        $action .= '<a href="javascript:void(0);"
                            data-href="' . route('setting.destroy', encrypt($member->id)) . '"
                            class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                    }
                    $created_at = !empty($member->created_at) ?  date('d-m-Y', strtotime($member->created_at)) : '';
                    $data[] = array("sr_no" => $i, "key" => $key[$member->key], "value" => $member->value,"is_expired" => $key_is_expired, "created_at" => $created_at, "action" => $action);
                }
                return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $settingTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            }
        }
    }
}
