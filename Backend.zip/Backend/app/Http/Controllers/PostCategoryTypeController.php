<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use App\Models\PostCategoryType;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class PostCategoryTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_post_category_type', 'view_post_category_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $post_cat_type_view = PostCategoryType::all();
        return view('post_cat_type.create', compact('post_cat_type_view'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_post_category_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'post_cat_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:25|unique:cop_pct_ms,post_cat_name',
            'post_cat_type' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:25|unique:cop_pct_ms,post_cat_type',

        ], [
            'post_cat_name.required' => 'Post Category Name is required',
            'post_cat_name.regex' => 'Post Category Name contain only letters and spaces.',
            'post_cat_name.min' => 'The Post Category Name must be at least :min characters.',
            'post_cat_name.max' => 'The Post Category Name must not exceed :max characters.',
            'post_cat_name.unique' => 'post Category Name already exist',

            'post_cat_type.required' => 'Post Category Type is required',
            'post_cat_type.regex' => 'Post Category Type contain only letters and spaces.',
            'post_cat_type.min' => 'The Post Category Type must be at least :min characters.',
            'post_cat_type.max' => 'The Post Category Type must not exceed :max characters.',
            'post_cat_type.unique' => 'post Category Type already exist',
        ]);
        DB::beginTransaction();
        try {
            $slug = \Illuminate\Support\Str::slug(strtolower($request->post_cat_name), '-') ;
            PostCategoryType::create([
                'post_cat_name' => $request->post_cat_name,
                'post_cat_type' => $request->post_cat_type,
                'slug' => $slug,
                'status' => $request->has('status') ? 1 : 0,
                'style' => $request->has('style') ? 1 : 0
            ]);
            DB::commit();
            session()->flash('success', 'Post Category Type Added Sccessfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', "File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
        }
        return redirect()->route('post_cat_type.create');
    }

    /**
     * Display the specified resource.
     */
    public function view()
    {
        if (!hasAnyPermission(['create_post_category_type', 'view_post_category_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $post_cat_type_view = PostCategoryType::get();
        return view('post_cat_type.create', ['post_cat_type_view' => $post_cat_type_view]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_post_category_type', 'view_post_category_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $post_cat_type_edit = PostCategoryType::where('post_cat_id', decrypt($id))->first();
        $post_cat_type_view = PostCategoryType::all();
        return view('post_cat_type.edit', ['post_cat_type_edit' => $post_cat_type_edit], ['post_cat_type_view' => $post_cat_type_view]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request,  $id)
    {
        if (!hasAnyPermission(['edit_post_category_type', 'view_post_category_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'post_cat_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:25|unique:cop_pct_ms,post_cat_name,' . decrypt($id) . ',post_cat_id',
            'post_cat_type' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:25|unique:cop_pct_ms,post_cat_type,' . decrypt($id) . ',post_cat_id',

        ], [
            'post_cat_name.required' => 'Post Category Name is required',
            'post_cat_name.regex' => 'Post Category Name allow only alphanumeric character',
            'post_cat_name.min' => 'The Post Category Name must be at least :min characters.',
            'post_cat_name.max' => 'The Post Category Name must not exceed :max characters.',
            'post_cat_name.unique' => 'Post Category Name already exist',

            'post_cat_type.required' => 'Post Category Type is required',
            'post_cat_type.regex' => 'Post Category Type allow only alphanumeric character',
            'post_cat_type.min' => 'The Post Category Type must be at least :min characters.',
            'post_cat_type.max' => 'The Post Category Type must not exceed :max characters.',
            'post_cat_type.unique' => 'Post Category Type already exist',
        ]);
        DB::beginTransaction();
        try {
            $slug = \Illuminate\Support\Str::slug(strtolower($request->post_cat_name), '-') ;
            $post_cat_type_update = PostCategoryType::where('post_cat_id', decrypt($id))->first();
            // dd($post_cat_type_update);
            if (!empty($post_cat_type_update)) {
                $post_cat_type_update->post_cat_name = $request->post_cat_name;
                $post_cat_type_update->post_cat_type = $request->post_cat_type;
                $post_cat_type_update->slug = $slug;
                $post_cat_type_update->status = $request->has('status') ? 1 : 0;
                $post_cat_type_update->style = $request->has('style') ? 1 : 0;
                $post_cat_type_update->save();
                DB::commit();
                session()->flash('success', 'Post Category Type Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('post_cat_type.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_post_category_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $post_cat_type_destroy = PostCategoryType::where('post_cat_id', decrypt($id))->first();
            if (!empty($post_cat_type_destroy)) {
                if ($post_cat_type_destroy->post_cat_data->isNotEmpty()) {
                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('post_cat_type.create');
                }
                $post_cat_type_destroy->delete();
                DB::commit();
                session()->flash('success', 'Post Category Type Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('post_cat_type.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_pct_ms')
            ->where('post_cat_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

    public function toggleStyle(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_pct_ms')
            ->where('post_cat_id', $id)
            ->update(['style' => DB::raw('IF(style = 1, 0, 1)')]);
        return response()->json(['message' => 'Style updated successfully']);
    }
}
