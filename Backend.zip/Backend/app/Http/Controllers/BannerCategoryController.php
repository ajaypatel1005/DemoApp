<?php

namespace App\Http\Controllers;

use App\Events\NewNotificationEvent;
use App\Events\ReplyTicketNotificationEvent;
use App\Models\BannerCategory;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
class BannerCategoryController extends Controller
{

    public function create()
    {
        $notificationData = [
            'message' => "New Lead Assigned to you ",
            'title' => "New Lead Assigned",
            'url' => route('banner_cat.create'),
        ];
        event(new ReplyTicketNotificationEvent('cop-channel-user-' . 1794 , $notificationData));
        if (!hasAnyPermission(['create_banner_category', 'view_banner_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $banner_cat_view = BannerCategory::all();
        return view('banner_category.create', compact('banner_cat_view'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_banner_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'bc_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:25|unique:cop_bc_ms,bc_name',
        ], [
            'bc_name.required' => 'Banner Category name is required',
            'bc_name.regex' => 'Banner Category name contain only letters and spaces.',
            'bc_name.min' => 'The Banner Category must be at least :min characters.',
            'bc_name.max' => 'The Banner Category must not exceed :max characters.',
            'bc_name.unique' => 'Balance Category name already exist',
        ]);
        DB::beginTransaction();
        try {
            BannerCategory::create([
                'bc_name' => $request->bc_name
            ]);
            DB::commit();
            session()->flash('success', 'Banner Category Added Sccessfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('banner_cat.create');
    }

    /**
     * Display the specified resource.
     */
    public function view()
    {
        if (!hasAnyPermission(['create_banner_category', 'view_banner_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $banner_cat_view = BannerCategory::get();
        return view('banner_category.create', ['banner_cat_view' => $banner_cat_view]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_banner_category', 'view_banner_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $banner_cat_edit = BannerCategory::where('bc_id', decrypt($id))->first();
        $banner_cat_view = BannerCategory::all();
        return view('banner_category.edit', ['banner_cat_edit' => $banner_cat_edit], ['banner_cat_view' => $banner_cat_view]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_banner_category', 'view_banner_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'bc_name' => 'required|regex:/^[A-Za-z\s]+$/|min:5|max:25|unique:cop_bc_ms,bc_name,' . decrypt($id) . ',bc_id',
        ], [
            'bc_name.required' => 'Banner Category name is required',
            'bc_name.regex' => 'Banner Category name allow only alphanumeric character',
            'bc_name.min' => 'The Banner Category must be at least :min characters.',
            'bc_name.max' => 'The Banner Category must not exceed :max characters.',
            'bc_name.unique' => 'Balance Category name already exist',
        ]);
        DB::beginTransaction();
        try {
            $banner_cat_update = BannerCategory::where('bc_id', decrypt($id))->first();
            // dd($banner_cat_update);
            if (!empty($banner_cat_update)) {
                $banner_cat_update->bc_name = $request->bc_name;
                $banner_cat_update->save();
                DB::commit();
                session()->flash('success', 'Banner Category Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('banner_cat.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_banner_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $banner_cat_destroy = BannerCategory::where('bc_id', decrypt($id))->first();
            if (!empty($banner_cat_destroy)) {
                if ($banner_cat_destroy->banner->isNotEmpty()) {
                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('banner_cat.create');
                }
                $banner_cat_destroy->delete();
                DB::commit();
                session()->flash('success', 'Banner Category Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('banner_cat.create');
    }
}
