<?php

namespace App\Http\Controllers;

use App\Models\CarType;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class CarTypeController extends Controller
{
    public function create()
    {
        if (!hasAnyPermission(['create_car_type', 'view_car_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $car_type_view = CarType::all();
        return view('car_types.create', compact('car_type_view'));
    }
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_car_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'ct_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:20|unique:cop_ct_ms,ct_name',
                'ct_image' => 'required|image|mimes:svg|unique:cop_ct_ms,ct_image|max:2048'
            ],
            [
                'ct_name.required' => 'Car Type Name required',
                'ct_name.min' => 'Minimum 2 Characters are required',
                'ct_name.max' => 'Maximum 20 Characters are allowed',
                'ct_name.unique' => 'Car Type Name Already Exists',
                'ct_name.regex' => 'Car Type Name is invalid',
                'ct_image.required' => 'Car Type Image required',
                'ct_image.image' => 'This must be an Image',
                'ct_image.mimes' => 'Car Type Image must be svg',
                'ct_image.max' => 'Image should not be greater than 2 MB'
            ]
        );
        DB::beginTransaction();
        try {
            $car_type_store = new CarType();

            if (!empty($car_type_store)) {
                $car_type_store->ct_name = $request->ct_name;
                $car_type_store->save();

                $ct_id = $car_type_store->ct_id;
                $ct_image_Uploaded_File = $request->file('ct_image');
                $imageImageName = $ct_id . '.' . $ct_image_Uploaded_File->getClientOriginalExtension();
                $logoPath = 'car_types/' . $ct_id . '/' . $imageImageName;
                Storage::disk('digitalocean')->put($logoPath,  file_get_contents($ct_image_Uploaded_File), 'public');
                $car_type_store->ct_image = $imageImageName;
                $car_type_store->update();
                DB::commit();
                session()->flash('success', 'Car Type Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('car_types.create');
    }


    public function edit($id)
    {
        if (!hasAnyPermission(['edit_car_type', 'view_car_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $car_type_edit = CarType::where('ct_id', decrypt($id))->first();
        $car_type_view = CarType::all();
        return view('car_types.edit', compact('car_type_edit', 'car_type_view'));
    }

    public function update($id, Request $request)
    {
        if (!hasAnyPermission(['edit_car_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'ct_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:20|unique:cop_ct_ms,ct_name,' . decrypt($id) . ',ct_id',
            ],
            [
                'ct_name.required' => 'Car Type Name required',
                'ct_name.regex' => 'Car Type Name is invalid',
                'ct_name.min' => 'Minimum 2 Characters Are required',
                'ct_name.max' => 'Maximum 20 Characters are allowed',
                'ct_name.unique' => 'Car Type Name Already Exists',
            ]
        );
        DB::beginTransaction();
        try {
            $car_type_update = CarType::where('ct_id', decrypt($id))->first();
            $imagePath = 'car_types/' . $car_type_update->ct_id;
            if ($car_type_update) {
                if (isset($request->ct_image)) {
                    $request->validate(
                        [
                            'ct_image' => 'image|mimes:svg|unique:cop_ct_ms,ct_image,' . decrypt($id) . ',ct_id|max:2048'
                        ],
                        [
                            'ct_image.image' => 'This must be an Image',
                            'ct_image.mimes' => 'Car Type Image must be svg',
                            'ct_image.max' => 'Image should not be greater than 2 MB'
                        ]
                    );

                    $ct_id = $car_type_update->ct_id;
                    $ct_image_Uploaded_File = $request->file('ct_image');
                    $imageImageName = $ct_id . '.' . $ct_image_Uploaded_File->getClientOriginalExtension();
                    $logoPath = 'car_types/' . $ct_id . '/' . $imageImageName;
                    Storage::disk('digitalocean')->put($logoPath, file_get_contents($ct_image_Uploaded_File), 'public');
                    $car_type_update->ct_image = $imageImageName;
                }
                $car_type_update->ct_name = $request->ct_name;
                $car_type_update->update();
                DB::commit();
                session()->flash('success', 'Car Type Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }


        return redirect()->route('car_types.create');
    }

    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_car_type'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $car_type_destroy = CarType::WHERE('ct_id', decrypt($id))->first();
        DB::beginTransaction();
        try {
            if (!empty($car_type_destroy)) {
                if ($car_type_destroy->models->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('car_types.create');
                }
                //delete Image from bucket
                $bucketFolder='car_types/' . $car_type_destroy->ct_id;
                Storage::disk('digitalocean')->deleteDirectory($bucketFolder);

                $car_type_destroy->delete();
                DB::commit();
                session()->flash('success', 'Car Type Deleted successfully.');
            } else {
                DB::rollBack();
                session()->flash('error', 'Something went wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }

        return redirect()->route('car_types.create');
    }

    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            try {
                $limit = ($request->has('length') ? $request->input('length') : 10);
                $page = ($request->has('start') ? $request->input('start') : 0);
                $search = ($request->has('search') ? $request->input('search')['value'] : '');

                $car_type_view = CarType::select('cop_ct_ms.ct_id', 'cop_ct_ms.ct_name','cop_ct_ms.ct_image');

                if (!empty($search)) {
                    $car_type_view->where(function ($query) use ($search) {
                        $query->orWhere('cop_ct_ms.ct_name', 'LIKE', '%' . $search . '%');
                    });
                }

                $cntFilter = clone $car_type_view;
                $car_type_view->offset($page)->limit($limit);
                $car_type_view = $car_type_view->get();
                $imagePath=config('constant.IMAGE_PATH');
                $carTypeTotal = DB::select("SELECT COUNT(*) AS count FROM cop_ct_ms")[0]->count;
                $data = [];
                $i = $page;
                foreach ($car_type_view as $member) {
                    $i++;
                    $action = "";
                    if (auth()->user()->can('edit_car_type')) {
                        $editRoute = route('car_types.edit', encrypt($member->ct_id));
                        $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                                <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                    }
                    if (auth()->user()->can('delete_car_type')) {
                        $action .= '<a href="javascript:void(0);"
                            data-href="' . route('car_types.destroy', encrypt($member->ct_id)) . '"
                            class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                    }
                    $ct_image = '<img style="width:75px; height:75px;"
                    src="'. $imagePath.'/car_types/' . $member->ct_id . '/' . $member->ct_image.'"
                    alt="'.$member->ct_name.' image">';

                    $data[] = array("sr_no" => $i, "ct_name" => $member->ct_name,"ct_image"=>$ct_image, "action" => $action);
                }
                return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $carTypeTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            }
        }
    }
}
