<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Country;
use App\Models\Banner;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use Illuminate\Support\Facades\File;
class CountryController extends Controller
{
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_country'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'country_name' => 'required|regex:/^[()A-Za-z\s]+$/|unique:cop_country_ms,country_name|min:2|max:25'
            ],
            [
                'country_name.regex' => 'Country Name contain only letters and spaces.',
                'country_name.required' => 'Country Name is required',
                'country_name.unique' => 'Country Name has already been taken',
                'country_name.min' => 'The Country Name must be at least :min characters.',
                'country_name.max' => 'The Country Name must not exceed :max characters.',
            ],
        );

        $request->validate(['country_name' => 'required|unique:cop_country_ms,country_name|min:2|max:25'
        ]);
        DB::beginTransaction();
        try {
            Country::create([
                'country_name' => $request->country_name,
                'status' => !empty($request->status) ? 1 : 0
            ]);
            DB::commit();
            session()->flash('success', "Country Added Successfully");
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('countries.create');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_country','view_country'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $cop_country_ms = Country::all();
        return view('country.create', compact('cop_country_ms'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_country'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $countries_edit = Country::where('country_id', decrypt($id))->first();
        $countries = Country::get();
        $cop_country_ms = Country::all();
        return view('country.edit', compact('countries_edit', 'countries','cop_country_ms'));
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_country'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'country_name' => 'required|regex:/^[()A-Za-z\s]+$/|unique:cop_country_ms,country_name,' . decrypt($id) . ',country_id|min:2|max:25'
            ],
            [
                'country_name.regex' => 'Country Name contain only letters and spaces.',
                'country_name.required' => 'Country Name is required',
                'country_name.unique' => 'Country Name has already been taken',
                'country_name.min' => 'The Country Name must be at least :min characters.',
                'country_name.max' => 'The Country Name must not exceed :max characters.',
            ],
        );
        DB::beginTransaction();
        try {
            $countries_update = Country::where('country_id', decrypt($id))->first();
            if (!empty($countries_update)) {
                $countries_update->country_name = $request->country_name;
                $countries_update->status = $request->has('status') ? 1 : 0;
                $countries_update->save();
                DB::commit();
                session()->flash('success', 'Successfully updated');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('danger', 'Something Went Wrong');
        }
        return redirect()->route('countries.create');
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_country'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $countries_destroy = Country::where('country_id', decrypt($id))->first();
            if ($countries_destroy) {


                if ($countries_destroy->states->isNotEmpty() || $countries_destroy->price_entry->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('country.create');
                }
                $countries_destroy->delete();
                DB::commit();
                session()->flash('success', 'Country Deleted Successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('danger', 'Something Went Wrong');
        }
        return redirect()->route('countries.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_country_ms')
            ->where('country_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

    public function saveBanner() {
        $brands = DB::select('select banner_id,banner_image from cop_banners where status = 1 and bc_id=1');
         // create image manager with desired driver
         $manager = new ImageManager(new Driver());
        foreach($brands as $brandData){
            $banner_id = $brandData->banner_id;
            $webpImageName = $banner_id . '.webp';
            $uploadedImage = "https://uatadmin.caronphone.com/Banner/".$banner_id.'/'.$brandData->banner_image;
            // echo "<img src='".$uploadedImage."' width='400' height='100'>";
            // echo "<br>";

            $imagePath = 'Banner/' . $banner_id . '/' . $brandData->banner_image;
            // if (File::exists($imagePath)) {
            //     File::delete($imagePath);
            // }

            // read image from file system
            // main image

            $urlImage =@file_get_contents($uploadedImage);
            if($urlImage === false){
            }else{
                    $image = $manager->read($urlImage);
                if(!is_dir(public_path('Banner') . '/' . $banner_id)){
                    mkdir(public_path('Banner') . '/' . $banner_id, 0777, true);
                }
                $image->toWebp()->save(public_path('Banner') . '/' . $banner_id.'/'.$webpImageName);

                // Thumbnail image
                if(!is_dir(public_path('Banner') . '/' . $banner_id.'/thumb')){
                    mkdir(public_path('Banner') . '/' . $banner_id.'/thumb', 0777, true);
                }
                $image->resize(1920,724);
                $image->toWebp()->save(public_path('Banner') . '/' . $banner_id.'/thumb/'.$webpImageName);
            }
        }

    }

    public function savebrands() {
        $brands = DB::select('select brand_id,brand_logo from cop_brands_ms where status = 1');
        // create image manager with desired driver
         $manager = new ImageManager(new Driver());
        foreach($brands as $brandData){
            $brand_id = $brandData->brand_id;
            $webpImageName = $brand_id . '.webp';
            $uploadedImage = "https://uatadmin.caronphone.com/brands/".$brand_id.'/'.$brandData->brand_logo;
            // echo "<img src='".$uploadedImage."' width='400' height='100'>";
            // echo "<br>";

            $imagePath = 'brands/' . $brand_id . '/' . $brandData->brand_logo;
            // if (File::exists($imagePath)) {
            //     File::delete($imagePath);
            // }

            // read image from file system
            // main image

            $urlImage =@file_get_contents($uploadedImage);
            if($urlImage === false){
            }else{
                    $image = $manager->read($urlImage);
                if(!is_dir(public_path('brands') . '/' . $brand_id)){
                    mkdir(public_path('brands') . '/' . $brand_id, 0777, true);
                }
                $image->toWebp()->save(public_path('brands') . '/' . $brand_id.'/'.$webpImageName);

                // Thumbnail image
                if(!is_dir(public_path('brands') . '/' . $brand_id.'/thumb')){
                    mkdir(public_path('brands') . '/' . $brand_id.'/thumb', 0777, true);
                }
                $image->resize(300,200);
                $image->toWebp()->save(public_path('brands') . '/' . $brand_id.'/thumb/'.$webpImageName);
            }
        }

    }

    public function savebrandBanner() {
        $brands = DB::select('select brand_id,brand_banner from cop_brands_ms where status = 1');
        // create image manager with desired driver
         $manager = new ImageManager(new Driver());
        foreach($brands as $brandData){
            $brand_id = $brandData->brand_id;
            $webpImageName = $brandData->brand_banner;
            $uploadedImage = "https://uatadmin.caronphone.com/brands/".$brand_id.'/'.$brandData->brand_banner;
            // echo "<img src='".$uploadedImage."' width='400' height='100'>";
            // echo "<br>";

           // if (File::exists($imagePath)) {
            //     File::delete($imagePath);
            // }

            // read image from file system
            // main image

            $urlImage =@file_get_contents($uploadedImage);
            if($urlImage === false){
            }else{
                    $image = $manager->read($urlImage);
                if(!is_dir(public_path('brands') . '/' . $brand_id)){
                    mkdir(public_path('brands') . '/' . $brand_id, 0777, true);
                }
                $image->toWebp()->save(public_path('brands') . '/' . $brand_id.'/'.$webpImageName);

                // Thumbnail image
                if(!is_dir(public_path('brands') . '/' . $brand_id.'/thumb')){
                    mkdir(public_path('brands') . '/' . $brand_id.'/thumb', 0777, true);
                }
                $image->resize(300,200);
                $image->toWebp()->save(public_path('brands') . '/' . $brand_id.'/thumb/'.$webpImageName);
            }
        }

    }

    public function savemodels() {
        $brands = DB::select('select brand_id,model_id,model_image,model_name from cop_models where status = 1');
        // create image manager with desired driver
         $manager = new ImageManager(new Driver());
        foreach($brands as $brandData){
            $brand_id = $brandData->brand_id;
            $model_id = $brandData->model_id;
            $webpImageName = $model_id . '.webp';
            $uploadedImage = "https://uatadmin.caronphone.com/brands/".$brand_id.'/'.$model_id.'/'.$brandData->model_image;
            // echo "<img src='".$uploadedImage."' width='400' height='100' alt='".$brandData->model_name."'>";
            // echo "<br>";

            $imagePath = 'brands/' .$brand_id.'/'.$model_id.'/'. $brandData->model_image;
            // if (File::exists($imagePath)) {
            //     File::delete($imagePath);
            // }


            // read image from file system
            // main image

            $urlImage =@file_get_contents($uploadedImage);
            if($urlImage === false){
            }else{
                $image = $manager->read($urlImage);

                if(!is_dir(public_path('brands') . '/' .$brand_id.'/'.$model_id)){
                    mkdir(public_path('brands') . '/' .$brand_id.'/'.$model_id, 0777, true);
                }
                $image->toWebp()->save(public_path('brands') . '/' .$brand_id.'/'.$model_id.'/'.$webpImageName);

                // Thumbnail image
                if(!is_dir(public_path('brands') . '/' .$brand_id.'/'.$model_id.'/thumb')){
                    mkdir(public_path('brands') . '/' .$brand_id.'/'.$model_id.'/thumb', 0777, true);
                }
                $image->resize(630,420);
                $image->toWebp()->save(public_path('brands') . '/' .$brand_id.'/'.$model_id.'/thumb/'.$webpImageName);
            }
        }

    }

    public function savecargraphic() {
        $brands = DB::select('select brand_id,model_id,graphic_file from cop_graphics where status = 1');
        // create image manager with desired driver
         $manager = new ImageManager(new Driver());
         $files = [];
        foreach($brands as $brandData){
            $brand_id = $brandData->brand_id;
            $model_id = $brandData->model_id;
            $allImages = explode(",",$brandData->graphic_file);
            for($i=0;$i<count($allImages);$i++){
                // $webpImageName = $allImages[$i];
                $uploadedImage = "https://uatadmin.caronphone.com/".'car_graphics/'.$model_id.'/images/'.$allImages[$i];
                array_push($files,$uploadedImage);

            }

        }
        // echo "<pre>";
        // print_r($files);
        $chunkSize = 5; // Set the desired chunk size
        $chunks = array_chunk($files, $chunkSize);
        // print_r($chunks);
        // Create an image manager
        $manager = new ImageManager(new Driver());

        foreach ($chunks as $chunk) {
            foreach ($chunk as $file) {
                // Read image from file system
                $urlImage =@file_get_contents($file);
                if($urlImage === false){
                }else{
                    $image = $manager->read($urlImage);


                    // Process and save images as needed (similar to your existing code)
                    $pathExplode=explode('images/',$file);
                    // For example, you can save the main image
                    $imageName = $pathExplode[1];
                    $destinationPath = public_path('car_graphics/').explode('car_graphics/',$pathExplode[0])[1].'/images/';
                    if(!is_dir($destinationPath)){
                        mkdir($destinationPath, 0777, true);
                    }
                    if(!is_dir($destinationPath.'/thumb')){
                        mkdir($destinationPath.'/thumb', 0777, true);
                    }
                    $image->toWebp()->save($destinationPath . $imageName);

                    // Generate Thumbnail
                    $destinationPathThumbnail = public_path('car_graphics/').explode('car_graphics/',$pathExplode[0])[1].'/images/thumb/';
                    $thumbnailImage = $image->resize(1400,570);
                    $thumbnailImage->toWebp()->save($destinationPathThumbnail . $imageName);

                }
            }
        }
    }

    public function savevariant() {
        $brands = DB::select('select brand_id,model_id,variant_id,variant_image from cop_variants where status = 1');
        // create image manager with desired driver
         $manager = new ImageManager(new Driver());
         foreach($brands as $brandData){
            $brand_id = $brandData->brand_id;
            $model_id = $brandData->model_id;
            $webpImageName = $brandData->variant_image;
            $uploadedImage = "https://uatadmin.caronphone.com/brands/".$brand_id.'/'.$model_id.'/'.$brandData->variant_id.'/'.$brandData->variant_image;
            $imagePath = public_path('brands') . '/' . $brand_id . '/' . $model_id . '/' . $brandData->variant_id;
            // if (File::exists($imagePath)) {
            //     File::delete($imagePath);
            // }


            // read image from file system
            // main image

            $urlImage =@file_get_contents($uploadedImage);
            if($urlImage === false){
            }else{
                $image = $manager->read($urlImage);

                if(!is_dir($imagePath)){
                    mkdir($imagePath, 0777, true);
                }
                $image->toWebp()->save($imagePath.'/'.$webpImageName);

                // Thumbnail image
                if(!is_dir($imagePath.'/thumb')){
                    mkdir($imagePath.'/thumb', 0777, true);
                }
                $image->resize(216,102);
                $image->toWebp()->save($imagePath.'/thumb/'.$webpImageName);
            }
        }

        $colors = DB::select('select brand_id,model_id,variant_id,variant_color_image from cop_colors ');
        // create image manager with desired driver
         $manager = new ImageManager(new Driver());
         foreach($colors as $brandData){
            $brand_id = $brandData->brand_id;
            $model_id = $brandData->model_id;
            $webpImageName = $brandData->variant_color_image;
            $uploadedImage = "https://uatadmin.caronphone.com/brands/".$brand_id.'/'.$model_id.'/'.$brandData->variant_id.'/'.$brandData->variant_color_image;
            $imagePath = public_path('brands') . '/' . $brand_id . '/' . $model_id . '/' . $brandData->variant_id;
            // if (File::exists($imagePath)) {
            //     File::delete($imagePath);
            // }


            // read image from file system
            // main image
                $urlImage =@file_get_contents($uploadedImage);
                if($urlImage === false){
                }else{
                    $image = $manager->read($urlImage);

                    if(!is_dir($imagePath)){
                        mkdir($imagePath, 0777, true);
                    }
                    $image->toWebp()->save($imagePath.'/'.$webpImageName);

                    // Thumbnail image
                    if(!is_dir($imagePath.'/thumb')){
                        mkdir($imagePath.'/thumb', 0777, true);
                    }
                    $image->resize(676,348);
                    $image->toWebp()->save($imagePath.'/thumb/'.$webpImageName);
                }
        }
    }



}
