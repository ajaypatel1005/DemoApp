<?php

namespace App\Http\Controllers\imports;

use App\Http\Controllers\Controller;
use App\Imports\VariantColorImport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Maatwebsite\Excel\Facades\Excel;

class VariantColorImportController extends Controller
{
    public function create()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "you don't have permission to access");
        }
        return view('import.variant_colors');
    }
    public function store(Request $request)
    {
         // Validate the request
         $request->validate([
            'file' => 'required|mimes:xlsx,csv', // Adjust the allowed file types if needed
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');
            ini_set('max_execution_time', '10000');
            $import = new VariantColorImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.variant_colors', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }
}
