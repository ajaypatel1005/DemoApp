<?php

namespace App\Http\Controllers\imports;

use App\Http\Controllers\Controller;
use App\Imports\CarGraphicsImagesAltTagUpdateImport;
use Illuminate\Http\Request;
use App\Imports\CarGraphicsImagesImport;
use App\Imports\CarGraphicsVideoImport;
use Illuminate\Support\Facades\Redirect;

use Maatwebsite\Excel\Facades\Excel;
class CarGraphicsImportController extends Controller
{
    // Car Graphic Images
    public function images_create()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "you don't have permission to access");
        }
        return view('import.car_graphics_images');
    }
    public function images_store(Request $request)
    {
         $request->validate([
            'file' => 'required|mimes:xlsx,csv',
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new CarGraphicsImagesImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.car_graphics_images', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }


    // Car Graphic Video
    public function video_create()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "you don't have permission to access");
        }
        return view('import.car_graphics_video');
    }
    public function video_store(Request $request)
    {
         $request->validate([
            'file' => 'required|mimes:xlsx,csv',
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new CarGraphicsVideoImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.car_graphics_video', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }

    // Car Graphic Images Alt Tag Update
    public function images_alt_tag_create()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "you don't have permission to access");
        }
        return view('import.car_graphics_images_alt_tag');
    }
    public function images_alt_tag_store(Request $request)
    {
         $request->validate([
            'file' => 'required|mimes:xlsx,csv',
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new CarGraphicsImagesAltTagUpdateImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.car_graphics_images', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }
}
