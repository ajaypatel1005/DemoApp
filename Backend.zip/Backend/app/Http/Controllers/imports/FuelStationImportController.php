<?php

namespace App\Http\Controllers\imports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Imports\FuelStationImport;
use Illuminate\Support\Facades\Redirect;
use Maatwebsite\Excel\Facades\Excel;

class FuelStationImportController extends Controller
{
    // Fuel Station Import
    public function create()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "you don't have permission to access");
        }
        return view('import.fuel_station');
    }
    public function store(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,csv',
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new FuelStationImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.fuel_station', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }
}
