<?php

namespace App\Http\Controllers\imports;

use App\Http\Controllers\Controller;
use App\Imports\ReviewImport;
use App\Models\Brand;
use App\Models\CarStage;
use App\Models\Feature;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\Redirect;

class ReviewImportController extends Controller
{
    // Method to export Excel file with brand and model data

    // public function exportExcelWithAllModels()
    // {
    //     // Using a closure to handle the export logic
    //     return Excel::download(new class implements FromCollection, WithHeadings {

    //         // Fetch data: brands with their respective models
    //         public function collection()
    //         {
    //             $data = [];
    //             $brands = Feature::where('status', 1) ->get(); 
                
    //             foreach ($brands as $brand) {
    //                 // foreach ($brand->models as $model) {

    //                         $data[] = [
    //                             'feature' => $brand->features_name, 
    //                             // 'model' => $model->model_name,  
    //                         ];
    //                 // }
    //             }

    //             // Return the data as a collection
    //             return collect($data);
    //         }

    //         // Define headings for the Excel sheet
    //         public function headings(): array
    //         {
    //             return ['Feature Name']; // Define column headings
    //         }

    //     }, 'features.xlsx');
    // }
    public function exportExcelWithAllModels()
    {
        // Using a closure to handle the export logic
        return Excel::download(new class implements FromCollection, WithHeadings {

            // Fetch data: brands with their respective models
            public function collection()
            {
                $data = [];
                $brands = Brand::with(['models' => function ($query) {
                    $query->where('status', 1); 
                }])
                ->where('status', 1) 
                ->get();


                foreach ($brands as $brand) {
                    foreach ($brand->models as $model) {

                            $data[] = [
                                'brand' => $brand->brand_name, 
                                'model' => $model->model_name,  
                            ];
                    }
                }

                // Return the data as a collection
                return collect($data);
            }

            // Define headings for the Excel sheet
            public function headings(): array
            {
                return ['Brand Name', 'Model Name']; // Define column headings
            }

        }, 'brand_model_all_models.xlsx');
    }




    public function exportExcelWithUpcomingModel()
    {
        // Using a closure to handle the export logic
        return Excel::download(new class implements FromCollection, WithHeadings {

            // Fetch data: brands with their respective models, but only upcoming ones
            public function collection()
            {
                $data = [];

                // Fetch brands and eager load models with the associated car_stage from cop_cs_ms
                $brands = Brand::with(['models' => function ($query) {
                    $query->where('status', 1)  // Models that are active
                        ->whereHas('car_stage', function ($q) {
                            $q->where('cs_name', 'Upcoming');  // Only models with "upcoming" car stage
                        });
                }])
                    ->where('status', 1)  // Only active brands
                    ->get();

                // Iterate through the brands and models to create the data array
                foreach ($brands as $brand) {
                    foreach ($brand->models as $model) {
                        $data[] = [
                            'brand' => $brand->brand_name,
                            'model' => $model->model_name,
                        ];
                    }
                }

                // Return the data as a collection
                return collect($data);
            }

            // Define headings for the Excel sheet
            public function headings(): array
            {
                return ['Brand Name', 'Model Name']; // Define column headings
            }
        }, 'brand_model_upcoming_models.xlsx');
    }


    public function exportExcelWithLaunchedModel()
    {
        // Using a closure to handle the export logic
        return Excel::download(new class implements FromCollection, WithHeadings {

            // Fetch data: brands with their respective models, but only upcoming ones
            public function collection()
            {
                $data = [];

                // Fetch brands and eager load models with the associated car_stage from cop_cs_ms
                $brands = Brand::with(['models' => function ($query) {
                    $query->where('status', 1)  // Models that are active
                        ->whereHas('car_stage', function ($q) {
                            $q->where('cs_name', 'Launched');  // Only models with "launched" car stage
                        });
                }])
                    ->where('status', 1)  // Only active brands
                    ->get();

                // Iterate through the brands and models to create the data array
                foreach ($brands as $brand) {
                    foreach ($brand->models as $model) {
                        $data[] = [
                            'brand' => $brand->brand_name,
                            'model' => $model->model_name,
                        ];
                    }
                }

                // Return the data as a collection
                return collect($data);
            }

            // Define headings for the Excel sheet
            public function headings(): array
            {
                return ['Brand Name', 'Model Name']; // Define column headings
            }
        }, 'brand_model_launched_models.xlsx');
    }

    // Method to show the import form (e.g., for uploading files)
    public function create()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "You don't have permission to access this page.");
        }

        return view('import.review'); // Adjust this to the path of your import view
    }

    // Method to handle file import logic
    public function store(Request $request)
    {


        // Validate the uploaded file
        $request->validate([
            'file' => 'required|mimes:xlsx,csv', // Allowed file types for import
        ]);

        // Check if the request contains a file
        if ($request->hasFile('file')) {
            $file = $request->file('file');

            // Instantiate the import class for ReviewImport
            $import = new ReviewImport();

            // Import the data from the uploaded file
            $import->collection(Excel::toCollection($import, $file)->first());

            // Get any validation errors from the import class
            $validationErrors = $import->getValidationErrors();


            // Redirect back with validation errors (if any)
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }
}
