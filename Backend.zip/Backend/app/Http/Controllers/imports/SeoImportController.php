<?php

namespace App\Http\Controllers\imports;

use App\Http\Controllers\Controller;
use App\Imports\SeoImport;
use App\Imports\SeoImportCarModule;
use App\Models\SEO\Page;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Maatwebsite\Excel\Facades\Excel;

class SeoImportController extends Controller
{
    public function create()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "you don't have permission to access");
        }
        $pageLists=Page::where('status',1)->whereIn('page_name',config('constant.SEO_CAR_MODUL_SUB_PAGE'))->get();
        // dd($pageLists);
        return view('import.seo_import',compact('pageLists'));
    }
    public function store(Request $request)
    {
         // Validate the request
         $request->validate([
            'file' => 'required|mimes:xlsx,csv', // Adjust the allowed file types if needed
        ]);

        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $page_id = $request->page_id;
            // dd($page_id);
            if(!empty($page_id))
            {
                $import = new SeoImportCarModule($page_id);
                
            }
            else
            {
                $import = new SeoImport();
            }

            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.variants', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }
}
