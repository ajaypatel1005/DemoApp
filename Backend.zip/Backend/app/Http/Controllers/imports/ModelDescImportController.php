<?php

namespace App\Http\Controllers\imports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Imports\ModelDescImport;
use App\Imports\ModelSafetyImport;
use Illuminate\Support\Facades\Redirect;
use Maatwebsite\Excel\Facades\Excel;

class ModelDescImportController extends Controller
{
    // Ev Station Import
    public function create()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "you don't have permission to access");
        }
        return view('import.model_desc');
    }

    public function store(Request $request)
    {

        $request->validate([
            'file' => 'required|mimes:xlsx,csv',
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new ModelDescImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.ev_station', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }

    public function createFeature()
    {
        if (!hasAnyPermission(['imports'])) {
            abort(403, "you don't have permission to access");
        }
        return view('import.model_safety');
    }


    public function storeFeature(Request $request)
    {

        $request->validate([
            'file' => 'required|mimes:xlsx,csv',
        ]);


        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $import = new ModelSafetyImport();
            $import->collection(Excel::toCollection($import, $file)->first());

            $validationErrors = $import->getValidationErrors();

            // return view('import.ev_station', compact('validationErrors'));
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }
}
