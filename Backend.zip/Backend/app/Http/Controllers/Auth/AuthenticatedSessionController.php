<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $user = Auth::user();

        // Check user status and log the login activity if active
        if ($user && $user->status === 1) {
            $user->logLogin(Auth::getDefaultDriver());
            $request->session()->regenerate();

            return redirect()->intended(RouteServiceProvider::HOME);
        }

        // Logout and return error for inactive users
        Auth::logout();
        return back()->withErrors([
            'email' => __('Invalid credentials'),
        ]);

        // if (Auth::user()->hasRole(config('constant.CRM_ROLE.RELATIONSHIP_MANAGER')) || Auth::user()->hasRole(config('constant.CRM_ROLE.TELECALLER'))) {
        //     return redirect()->route('crm.dashboard');
        // }

        // if (Auth::user()->hasRole(config('constant.CRM_ROLE.COP_SPOC_PERSON'))) {
        //     return redirect()->route('cop_spoc.dashboard');
        // }

        // if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER_SPOC_PERSON'))) {
        //     return redirect()->route('dealer_spoc.dashboard');
        // }

        // if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER'))) {
        //     return redirect()->route('dealer.dashboard');
        // }

        // if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER_SALESMAN'))) {
        //     return redirect()->route('salesman.dashboard');
        // }

    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        // Retrieve the authenticated user
        $user = Auth::user();
        if ($user) {
            $user->logLogout(Auth::getDefaultDriver());
        }

        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
