<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Rules\PasswordStrength;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rules\Password;

class PasswordController extends Controller
{
    /**
     * Update the user's password.
     */
    public function update(Request $request): RedirectResponse
    {
        $user = Auth::user();

        $validated = $request->validateWithBag('updatePassword', [
            'current_password' => [
                'required',
                function ($attribute, $value, $fail) use ($user) {
                    if (!Hash::check($value, $user->password)) {
                        $fail(__('The current password is incorrect.'));
                    }
                },
            ],
            'password' => ['required', 'confirmed','min:16',new PasswordStrength],
            'password_confirmation' => ['required'],
        ], [
            'current_password.required' => __('The current password is required.'),
            'password.required' => __('The new password is required.'),
            'password.custom' => __('The password must be a combination of at least 1 uppercase letter, 1 lowercase letter, 1 special character, and 1 numeric value.'),
            'password.confirmed' => __('The new password and confirmation do not match.'),
            'password.min' => __('The password must be at least :min characters long.'),
            'password_confirmation.required' => __('The Confirm Password is required.'),
        ]);

        try
        {
        $request->user()->update([
            'password' => Hash::make($validated['password']),
        ]);
        return back()->with('success','Password Updated Successfully.');
    }
    catch(Exception $e)
    {
        return back()->with('error','Password Updated Successfully.');
        Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
    }
    }
}
