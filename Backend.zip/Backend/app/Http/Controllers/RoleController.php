<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (!hasAnyPermission(['view_roles'])) {
            abort(403, "You don't have permission to access");
        }
        return view('roles.index', [
            'roles' => Role::orderBy('id', 'DESC')->get()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_roles'])) {
            abort(403, "You don't have permission to access");
        }
        return view('roles.create', [
            'permissions' => Permission::get()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|min:1|max:30|unique:roles,name',
            'permissions' => 'required',
        ]);
        DB::beginTransaction();
        try {
            $role = Role::create(['name' => $request->name]);
            $query = Permission::query();
            if (!in_array('all', $request->permissions)) {
                $query->whereIn('id', $request->permissions);
            }
            $permissions = $query->get(['name'])->toArray();
            $role->syncPermissions($permissions);
            DB::commit();
            session()->flash('success', 'Role has been added successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }

        return redirect()->route('roles.index');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_roles'])) {
            abort(403, "You don't have permission to access");
        }
        $role = Role::findOrFail(decrypt($id));
        $rolePermissions = DB::table("role_has_permissions")->where("role_id", $role->id)
            ->pluck('permission_id')
            ->all();

        return view('roles.edit', [
            'role' => $role,
            'permissions' => Permission::get(),
            'rolePermissions' => $rolePermissions
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'name' => 'required|string|min:1|max:30|unique:roles,name,' . decrypt($id),
            'permissions' => 'required',
        ]);
        DB::beginTransaction();
        try {
            $role = Role::findOrFail(decrypt($id));
            $input = $request->only('name');
            $role->update($input);
            $query = Permission::query();
            if (!in_array('all', $request->permissions)) {
                $query->whereIn('id', $request->permissions);
            }
            $permissions = $query->get(['name'])->toArray();
            $role->syncPermissions($permissions);
            DB::commit();
            session()->flash('success', 'Role has been updated successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }

        return redirect()->route('roles.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_roles'])) {
            abort(403, "You don't have permission to access");
        }
        try {
            $role = Role::findOrFail(decrypt($id));
            $role->delete();
            session()->flash('success', 'Role has been deleted successfully.');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('roles.index');
    }
}
