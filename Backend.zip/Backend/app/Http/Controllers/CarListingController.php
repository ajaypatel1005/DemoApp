<?php

namespace App\Http\Controllers;

use App\Models\CarListing;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
class CarListingController extends Controller
{

    public function create()
    {
        if (!hasAnyPermission(['create_car_listing', 'view_car_listing'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $car_listing_view = CarListing::all();
        return view('car_listing.create', compact('car_listing_view'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_car_listing'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'cl_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:30|unique:cop_cl_ms,cl_name',
        ], [
            'cl_name.required' => 'The Car Listing name is required',
            'cl_name.regex' => 'The Car Listing name contain only letters and spaces.',
            'cl_name.min' => 'The Car Listing must be at least :min characters.',
            'cl_name.max' => 'The Car Listing must not exceed :max characters.',
            'cl_name.unique' => 'The Car Listing name already exist',
        ]);
        DB::beginTransaction();
        try {
            CarListing::create([
                'cl_name' => $request->cl_name
            ]);
            DB::commit();
            session()->flash('success', 'Car Listing Added Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_listing.create');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_car_listing', 'view_car_listing'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $car_listing_edit = CarListing::where('cl_id', decrypt($id))->first();
        $car_listing_view = CarListing::all();
        return view('car_listing.edit', ['car_listing_edit' => $car_listing_edit], ['car_listing_view' => $car_listing_view]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_car_listing', 'view_car_listing'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'cl_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:30|unique:cop_cl_ms,cl_name,' . decrypt($id) . ',cl_id',
        ], [
            'cl_name.required' => 'The name is required',
            'cl_name.regex' => 'The Car Listing name contain only letters and spaces.',
            'cl_name.min' => 'The Car Listing must be at least :min characters.',
            'cl_name.max' => 'The Car Listing must not exceed :max characters.',
            'cl_name.unique' => 'The already exist',
        ]);
        DB::beginTransaction();
        try {
            $car_listing_update = CarListing::where('cl_id', decrypt($id))->first();
            if (!empty($car_listing_update)) {
                $car_listing_update->cl_name = $request->cl_name;
                $car_listing_update->save();
                DB::commit();
                session()->flash('success', 'Car Listing Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('car_listing.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_car_listing'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $car_listing_destroy = CarListing::where('cl_id', decrypt($id))->first();
            if (!empty($car_listing_destroy)) {
                if ($car_listing_destroy->cldata->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('car_listing.create');
                }
                $car_listing_destroy->delete();
                DB::commit();
                session()->flash('success', 'Car Listing Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_listing.create');
    }
}
