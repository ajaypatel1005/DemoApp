<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Testimonial;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Intervention\Image\ImageManager;
use Illuminate\Support\Str;

use Intervention\Image\Drivers\Gd\Driver;

class TestimonialController extends Controller
{
    public function create()
    {
        if (!hasAnyPermission(['create_testimonial'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        return view('testimonial.create');
    }
    public function view()
    {
        if (!hasAnyPermission(['view_testimonial'])) {
            abort(403, "you don't have permission to access");
        }

        $testimonials_view = Testimonial::all();


        return view('testimonial.view', ['testimonials_view' => $testimonials_view]);
    }
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_testimonial'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'name' => 'required|min:2|max:25',
                'image' => 'image|mimes:png,jpg,jpeg,webp|max:2048',
                'review' => 'required',
                'designation' => 'min:2|max:25',


            ],
            [
                'name.required' => 'Name Required',
                'name.max' => 'Name field must not be greater than 25 characters',
                'name.min' => 'Name field must be at least 2 characters',
                'image.image' => 'This must be an Image',
                'image.mimes' => 'Brand Banner must be png,jpg,jpeg,webp',
                'image.max' => 'Brand Banner should not be greater than 2 MB',
                'review.required' => 'Review is required.',
                'designation.max' => 'Designation field must not be greater than 25 characters',
                'designation.min' => 'Designation field must be at least 2 characters',


            ]
        );
        DB::beginTransaction();
        try {
            $testimonial_store = new Testimonial();
            if ($testimonial_store) {
                $testimonial_store->name = $request->name;
                $testimonial_store->designation = $request->designation;
                $testimonial_store->review = $request->review;  //description
                $testimonial_store->rating = $request->rating;  //description

                $testimonial_store->status = $request->has('status') ? 1 : 0;
                $testimonial_store->save();
                //Brand Logo
                $id = $testimonial_store->id;

                //Brand Banner
                $image = $request->file('image');
                if (!empty($image)) {
                    $webpimage = $id . '.webp';
                    $image->move(public_path('testimonial'), $webpimage);
                    $testimonial_store->image = $webpimage;
                    $testimonial_store->update();
                }
                DB::commit();
                session()->flash('success', 'Testimonial Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('testimonial.view');
    }




    public function edit($id)
    {
        if (!hasAnyPermission(['edit_testimonial'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $testimonial_edit = Testimonial::where('id', decrypt($id))->first();
        return view('testimonial.edit', compact('testimonial_edit'));
    }

    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_testimonial'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'name' => 'required|min:2|max:25',
                'image' => 'image|mimes:png,jpg,jpeg,webp|max:2048',
                'review' => 'required',
                'designation' => 'min:2|max:25',


            ],
            [
                'name.required' => 'Name Required',
                'name.max' => 'Name field must not be greater than 25 characters',
                'name.min' => 'Name field must be at least 2 characters',
                'image.image' => 'This must be an Image',
                'image.mimes' => 'Brand Banner must be png,jpg,jpeg,webp',
                'image.max' => 'Brand Banner should not be greater than 2 MB',
                'review.required' => 'Review is required.',
                'designation.max' => 'Designation field must not be greater than 25 characters',
                'designation.min' => 'Designation field must be at least 2 characters',


            ]
        );
        DB::beginTransaction();
        try {
            $testimonial_update = Testimonial::WHERE('id', decrypt($id))->first();
            $testimonial_id = $testimonial_update->id;

            if (!empty($testimonial_update)) {
                $imagePath = public_path('testimonial') . '/' .  $testimonial_update->image;
                //Image
                if (isset($request->image)) {
                    // Update brand_logo
                    // File::deleteDirectory($imagePath);
                    if (File::exists($imagePath)) {
                        File::delete($imagePath);
                    }
                    $webpimage = $testimonial_id . '.webp';
                    $request->image->move(public_path('testimonial'), $webpimage);
                    $testimonial_update->image = $webpimage;
                    $testimonial_update->update();
                }

                $testimonial_update->name = $request->name;
                $testimonial_update->designation = $request->designation;
                $testimonial_update->rating = $request->rating;
                $testimonial_update->review = $request->review;
                $testimonial_update->status = $request->has('status') ? 1 : 0;
                $testimonial_update->update();
                DB::commit();
                session()->flash('success', 'Testimonial Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('testimonial.view');
    }

    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_testimonial'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $testimonial_delete = Brand::WHERE('brand_id', decrypt($id))->first();
        DB::beginTransaction();
        try {
            if ($testimonial_delete) {


                $filePath = public_path('testimonial') . '/' . $testimonial_delete->image;

                if (File::exists($filePath)) {
                    File::delete($filePath);
                }

                $testimonial_delete->delete();
                DB::commit();
                session()->flash('success', 'Testimonial Deleted successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('testimonial.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');

        DB::table('cop_testimonial')
            ->where('id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);

        return response()->json(['message', 'Status Updated Successfully']);
    }
    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            try {
                $limit = ($request->has('length') ? $request->input('length') : 10);
                $page = ($request->has('start') ? $request->input('start') : 0);
                $search = ($request->has('search') ? $request->input('search')['value'] : '');

                $testimonial_view = Testimonial::select(
                    'id',
                    'name',
                    'status'
                ); // check brand is active
                if (!empty($search)) {
                    $testimonial_view->where(function ($query) use ($search) {
                        $query->orWhere('name', 'LIKE', '%' . $search . '%');
                    });
                }

                $cntFilter = clone $testimonial_view;
                $testimonial_view->offset($page)->limit($limit);
                $testimonial_view = $testimonial_view->get();

                $ModelTotal = DB::select("SELECT COUNT(*) AS count FROM cop_models")[0]->count;
                $data = [];
                $i = $page;
                foreach ($testimonial_view as $member) {
                    $i++;
                    $status = $disable = "";
                    if ($member->status == 1) {
                        $status = 'checked';
                    }
                    $disable = (!auth()->user()->can('edit_testimonial')) ? 'disabled' : '';

                    $testimonial_status = '<div
                        class="form-check form-switch form-check-custom form-check-success form-check-solid">
                        <input class="form-check-input" name="status" type="checkbox" value="' . $member->id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>';
                    $action = "";
                    if (auth()->user()->can('edit_testimonial')) {
                        $editRoute = route('testimonial.edit', encrypt($member->id));
                        $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                                <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                    }
                    if (auth()->user()->can('delete_testimonial')) {
                        $action .= '<a href="javascript:void(0);"
                            data-href="' . route('testimonial.destroy', encrypt($member->id)) . '"
                            class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                    }
                    $data[] = array("sr_no" => $i, "name" => $member->name,  "status" => $testimonial_status, "action" => $action);
                }
                return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $ModelTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            }
        }
    }
}
