<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\State;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;

class StateApiController extends Controller
{
    public function index(Request $request)
    {

        $providedToken = $request->header('X-Custom-Token');

        $api_token = config('constant.API Token');

        if ($providedToken === $api_token) {
        try {

            $state = State::select(
                'cop_state_ms.*',
                'cop_country_ms.country_name as country_name'
            )
                ->leftJoin('cop_country_ms', 'cop_state_ms.country_id', '=', 'cop_country_ms.country_id')
                ->where('cop_state_ms.status', '!=', 0) // Filter out banners with status 0
                ->get();

            $stateData = $state->map(function ($item) {

                $data = [
                    'state_id' => $item->state_id,
                    'country_name' => $item->country_name,
                    'state_name' => $item->state_name,
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $stateData, "Successfuly Data Get");

        } catch (Exception $e) {
            // return ResponseHelper::errorResponse(['Something went wrong!!']);
            return ResponseHelper::errorResponse('success','Something went wrong!!');
        }
    } else {
        return response()->json(['error' => 'Unauthorized'], 401);
    }
    }
}
