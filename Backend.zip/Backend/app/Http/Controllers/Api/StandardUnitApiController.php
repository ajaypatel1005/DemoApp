<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\StandardUnit;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;

class StandardUnitApiController extends Controller
{
    public function index()
    {
        try {
            $standardUnit = StandardUnit::all();
            // dd($models);
            $formattedData = $standardUnit->map(function ($item) {

                $data = [
                    'su_id' => $item->su_id,
                    'su_name' => $item->su_name,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse(['Something went wrong!!']);
            return ResponseHelper::errorResponse('success','Something went wrong!!');
        }
    }
}
