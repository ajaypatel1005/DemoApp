<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Models\CarGraphicType;
use App\Http\Controllers\Helpers\ResponseHelper;

class CarGraphicTypeApiController extends Controller
{

    public function index()
    {
        try {
            $graphic_type = CarGraphicType::where('status', '=', 1)->get();
            // dd($models);
            if ($graphic_type->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }
            $formattedData = $graphic_type->map(function ($item) {

                $data = [
                    'graphic_type_id' => encrypt($item->gt_id),
                    'graphic_type_name' => $item->gt_name,
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
