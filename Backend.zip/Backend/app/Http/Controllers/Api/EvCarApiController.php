<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CarListingData;
use Illuminate\Support\Facades\Auth;
use App\Models\Wishlist;
use App\Models\Model;
use Illuminate\Support\Facades\DB;

class EvCarApiController extends Controller
{


    private function pricefilter($model_id)
    {
        $priceMinMax = Model::select(
            DB::raw('MIN(cop_pe_ms.ex_showroom_price) as min_ex_showroom_price'),
            DB::raw('MAX(cop_pe_ms.ex_showroom_price) as max_ex_showroom_price')
        )
            ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->where('cop_models.model_id', $model_id)
            ->where('cop_models.model_type', '0')
            ->first();

        return [
            'price_filter' => $priceMinMax['min_ex_showroom_price'],
            'min_ex_showroom_price' => $this->convertToLakhCrore($priceMinMax['min_ex_showroom_price']),
            'max_ex_showroom_price' => $this->convertToLakhCrore($priceMinMax['max_ex_showroom_price']),
        ];
    }


    public function formatModel($models, $power, $engine, $wishlist)
    {
        // dd($power, $engine);
        $formattedData = $models->map(function ($item) use ($power, $engine) {
            $powerDetails = $power->where('model_id', $item->model_id)->first();
            $engineDetails = $engine->where('model_id', $item->model_id)->first();
            if ($powerDetails === null) {
                dd("Power details are null for model name & ID: {$item->model_name} : {$item->model_id}");
            }

            if ($engineDetails === null) {
                dd("Engine details are null for model name & ID: {$item->model_name} : {$item->model_id}");
            }
            $data = [
                'model_id' => encrypt($item->model_id),
                'car_stage' => $item->cs_name,
                'model_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp") ?? NULL,
                'launch_date' => $item->launch_date,
                'brand_name' => $item->brand_name,
                'model_name' => $item->model_name,
                'price' => $this->pricefilter($item->model_id),
                // 'min_price' => $this->convertToLakhCrore($item->min_price),
                // 'max_price' => $this->convertToLakhCrore($item->max_price),
                'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                'rating_type_name' => $item->rating_type_name ?? NULL,
                'city_name' => $item->city_name ?? NULL,
                'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : NULL,
                'wishlist' => $item->wishlist,


                'power' => [
                    'feature_id' => $powerDetails->feature_id ?? null,
                    'features_image' =>  asset("Feature/{$powerDetails->feature_id}/{$powerDetails->feature_id}.svg") ?? NULL,
                    'feature_value' => $powerDetails->feature_value ?? NULL,
                    'su_name' => $powerDetails->su_name ?? NULL,
                ],
                'engine' => [
                    'feature_id' => $engineDetails->feature_id ?? null,
                    'features_image' => asset("Feature/{$engineDetails->feature_id}/{$engineDetails->feature_id}.svg") ?? NULL,
                    'feature_value' => $engineDetails->feature_value ?? NULL,
                    'su_name' => $engineDetails->su_name ?? NULL,
                ],
            ];

            return $data;
        });

        return $formattedData;
    }

    private function getFeatureDetails($featureName)
    {
        $data = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
            ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
            // ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
            ->leftJoin('cop_fv', 'cop_fv.model_id', '=', 'cop_models.model_id')
            ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
            ->select(
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_features_ms.feature_id',
                'cop_features_ms.features_image',
                'cop_fv.fv_id',
                'cop_fv.feature_value',
                'cop_su_ms.su_name'
            )->where('cop_features_ms.features_name', $featureName)
            // ->where('cop_models.model_type', '=', 1)
            ->distinct()

            ->get();

        // dd($data );

        if ($data->isEmpty()) {

            return ResponseHelper::errorResponse('success', 'No data available!!');
        }


        return $data;
    }

    public function index(Request $request)
    {

        if ($request->type == 'price_filter') {


            $minPrice = $request->input('minprice');
            $maxPrice = $request->input('maxprice');

            $cityName = $request->input('city_name');
            if ($cityName == "" || $cityName == null) {
                $formattedData = ['city_name required'];
                return ResponseHelper::responseMessage('success', $formattedData);
            }
            $models = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')
                ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')

                ->select(
                    'cop_models.*',
                    'cop_cs_ms.cs_name',
                    'cop_brands_ms.brand_name',
                    'cop_ct_ms.ct_name',
                    'cop_variants.*',
                    'cop_pe_ms.ex_showroom_price',
                    'cop_city_ms.city_id',
                    'cop_city_ms.city_name',
                    'cop_ratings.rating_id',
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name'

                )->where('cop_cs_ms.cs_name', '=', 'Launched')
                ->where(function ($query) use ($minPrice, $maxPrice) {
                    $query->where('cop_models.min_price', '>=', $minPrice)
                        ->where('cop_models.max_price', '<=', $maxPrice);
                })
                ->where('cop_models.model_type', '=', 1)
                ->where('cop_city_ms.city_name', $cityName)

                ->distinct()
                ->get();


            // if ($models->isEmpty()) {
            //     return ResponseHelper::responseMessage('error', 'Not Found');
            // }

            $power = $this->getFeatureDetails('Power (EV)');
            // dd($powerEV);
            $engine = $this->getFeatureDetails('Range');

            $responseArray = [];

            foreach ($models as $model) {
                $model->power = $power->where('model_id', $model->model_id)->first();
                $model->engine = $engine->where('model_id', $model->model_id)->first();

                $wishlistGet = Wishlist::where('model_id', $model->model_id)
                ->where('customer_id', Auth::guard('api')->id())
                ->exists();

            // Set the wishlist property directly on the model object
            $model->wishlist = $wishlistGet ? true : false;
                $responseArray[] = $model;
            }
            // dd($responseArray);
            $wishlist= [];
            $formattedData = $this->formatModel(collect($responseArray), $power, $engine, $wishlist);


            return ResponseHelper::responseMessage('success', $formattedData);
        } else if ($request->type == 'EV Cars') {

            $evCar = CarListingData::select(
                'cop_models.*',
                // 'cop_msd.*',
                'cop_cl_ms.cl_name as cl_name',
                'cop_brands_ms.brand_name as brand_name',
                'cop_ratings.rating_id',
                'cop_ratings.rating_value',
                'cop_rating_types.rating_type_name',
            )
                ->leftJoin('cop_cl_ms', 'cop_cl_data.cl_id', '=', 'cop_cl_ms.cl_id')
                ->leftJoin('cop_brands_ms', 'cop_cl_data.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_models', 'cop_cl_data.model_id', '=', 'cop_models.model_id')
                // ->leftJoin('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                ->where('cop_cl_data.status', '=', 1)
                ->where('cop_cl_ms.cl_name', '=', 'EV Cars')
                ->distinct("cop_models.model_id")
                ->get();


            if ($evCar->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }

            $power = $this->getFeatureDetails('Power (EV)');
            // dd($powerEV);
            $engine = $this->getFeatureDetails('Range');


            $responseArray = [];

            foreach ($evCar as $model) {
                $model->power = $power->where('model_id', $model->model_id)->first();
                $model->engine = $engine->where('model_id', $model->model_id)->first();

                $wishlistGet = Wishlist::where('model_id', $model->model_id)
                ->where('customer_id', Auth::guard('api')->id())
                ->exists();

            // Set the wishlist property directly on the model object
            $model->wishlist = $wishlistGet ? true : false;
                $responseArray[] = $model;
            }
            // dd($responseArray);
            $wishlist = [];
            $formattedData = $this->formatModel(collect($responseArray), $power, $engine, $wishlist);


            return ResponseHelper::responseMessage('success', $formattedData);





            // } else {
            //     return ResponseHelper::responseMessage('error', 'Not Match');

        } else if ($request->type == 'all_ev_cars') {
            $models = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')

                ->leftJoin('cop_ratings', function ($join) {
                    $join->on('cop_ratings.model_id', '=', 'cop_models.model_id')
                        ->where('cop_cs_ms.cs_name', '!=', 'Upcoming');
                })
                ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                ->select(
                    'cop_models.*',
                    'cop_cs_ms.cs_name',
                    'cop_brands_ms.brand_name',
                    'cop_ct_ms.ct_name',

                )->where('cop_cs_ms.cs_name', '=', 'Launched')
                ->where('cop_models.model_type', '=', 1)
                ->distinct()
                ->get();



            if ($models->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }

            $power = $this->getFeatureDetails('Power (EV)');
            // dd($powerEV);
            $engine = $this->getFeatureDetails('Range');

            $responseArray = [];

            foreach ($models as $model) {
                $model->power = $power->where('model_id', $model->model_id)->first();
                $model->engine = $engine->where('model_id', $model->model_id)->first();

                $wishlistGet = Wishlist::where('model_id', $model->model_id)
                    ->where('customer_id', Auth::guard('api')->id())
                    ->exists();

                // Set the wishlist property directly on the model object
                $model->wishlist = $wishlistGet ? true : false;
                $responseArray[] = $model;
            }
            $wishlist = [];
            // dd($responseArray);
            $formattedData = $this->formatModel(collect($responseArray), $power, $engine, $wishlist);


            return ResponseHelper::responseMessage('success', $formattedData);
        }
    }

    private function convertToLakhCrore($price)
    {
        if ($price >= 10000000) {
            return number_format($price / 10000000, 2) . ' Cr';
        } elseif ($price >= 100000) {
            return number_format($price / 100000, 2) . ' Lakh';
        } else {
            return $price;
        }
    }
}
