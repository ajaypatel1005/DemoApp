<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AllTax;
use Exception;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\Helpers\ResponseHelper;

class AllTaxApiController extends Controller
{
    public function index()
    {
        try {
            $all_tax_view = AllTax::gest();

            if ($all_tax_view->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }


            $formattedData = $all_tax_view->map(function ($item) {

                $data = [
                    'tax_id' => encrypt($item->tax_id),
                    'tax_name' => $item->tax_name,
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
