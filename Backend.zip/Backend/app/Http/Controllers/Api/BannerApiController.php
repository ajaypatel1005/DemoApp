<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Banner;
use Illuminate\Support\Facades\File;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

class BannerApiController extends Controller
{

    public function banner(Request $request)
    {
        $bcName = $request->type;

        try {
            // $data = Banner::with(['banner_category', 'brand'])
            //     ->join('cop_models', 'cop_banners.brand_id', '=', 'cop_models.brand_id')
            //     ->select('cop_banners.banner_id', 'cop_banners.bc_id', 'cop_banners.brand_id', 'cop_banners.banner_heading', 'cop_banners.banner_image', 'cop_banners.btn_text', 'cop_banners.btn_link', 'cop_banners.banner_description','cop_models.model_id','cop_models.model_name')
            //     ->whereHas('banner_category', function ($query) use ($bcName) {
            //         $query->where('bc_name', $bcName);
            //     })
            //     ->get();
            $data = Banner::select('cop_banners.*', 'cop_bc_ms.bc_name as bc_name', 'cop_brands_ms.brand_name as brand_name', 'cop_models.model_name as model_name', 'cop_variants.variant_name as variant_name')
                ->leftJoin('cop_bc_ms', 'cop_banners.bc_id', '=', 'cop_bc_ms.bc_id')
                ->leftJoin('cop_brands_ms', 'cop_banners.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_models', 'cop_banners.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_variants', 'cop_banners.variant_id', '=', 'cop_variants.variant_id')
                ->where('cop_bc_ms.bc_name', '=', $bcName)
                ->get();
            // dd($data);
            $formattedData = [];
            $base_url = config('constant.fronted_url');
            foreach ($data as $item) {
                $formattedData[] = [
                    'banner_id' => encrypt($item->banner_id),
                    'bc_id' => encrypt($item->bc_id),
                    'bc_name' => $item->banner_category->bc_name ?? NULL,
                    'brand_id' => encrypt($item->brand_id) ?? NULL,
                    'brand_name' => $item->brand->brand_name ?? NULL,
                    'model_id' => $item->model_id ?? NULL,
                    'model_name' => $item->model_name ?? NULL,
                    'banner_heading' => $item->banner_heading,
                    'banner_description' => $item->banner_description,
                    // 'banner_image' => $item->banner_image,
                    'banner_image' => asset("Banner/{$item->banner_id}/{$item->banner_id}.webp"),
                    'btn_text' => $item->btn_text,
                    // 'btn_link' => $base_url.$item->btn_link,
                    'btn_link' =>  $item->model_name ?? NULL,
                ];
            }
            if (count($data) > 0) {

                return ResponseHelper::responseMessage('success', $formattedData);
            } else {
                return ResponseHelper::errorResponse('success', 'Banner Not Found!!');
            }
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
