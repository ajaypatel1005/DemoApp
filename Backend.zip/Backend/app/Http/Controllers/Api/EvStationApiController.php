<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Models\EvStation;
use App\Http\Controllers\Helpers\ResponseHelper;
class EvStationApiController extends Controller
{
    public function index(Request $request)
    {

        try {
            $ev_station = EvStation::select('cop_evs_ms.*', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_city_ms', 'cop_evs_ms.city_id', '=', 'cop_city_ms.city_id')
            ->leftJoin('cop_state_ms', 'cop_evs_ms.state_id', '=', 'cop_state_ms.state_id')
            ->where('cop_evs_ms.status', '=', 1);

            if ($request->has('city_id')) {
                $ev_station->where('cop_evs_ms.city_id', $request->city_id);
            }
            $ev_station = $ev_station->get();

            if ($ev_station->isEmpty()) {

                return ResponseHelper::errorResponse('success','No data available!!');
            }

            $formattedData = $ev_station->map(function ($item) {

                $data = [
                    'ev_station_id' => encrypt($item->evs_id),
                    'state_id' => encrypt($item->state_id),
                    'state_name' => $item->state_name,
                    'city_id' => encrypt($item->city_id),
                    'city_name' => $item->city_name,
                    'ev_station_name' => $item->evs_name,
                    'ev_station_address' => $item->evs_address,
                    'ev_station_location' => $item->evs_location,
                    'ev_station_charging_slots' => $item->evs_charging_slots,
                    'ev_station_charging_port_type' => $item->evs_charging_port_type,
                    'ev_station_charging_voltage' => $item->evs_charging_voltage,
                    'ev_station_charging_rate' => $item->evs_charging_rate,
                    'ev_station_car_capacity' => $item->evs_car_capacity,
                    'ev_station_contact_number' => $item->evs_contact_number,
                       ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success','Something went wrong!!');
        }
    }


    public function ev_city(Request $request)
    {
           try{
        $ev_city = EvStation::join('cop_city_ms', 'cop_evs_ms.city_id', '=', 'cop_city_ms.city_id')
        ->leftjoin('cop_state_ms', 'cop_evs_ms.state_id', '=', 'cop_state_ms.state_id')
            ->select('cop_evs_ms.city_id', 'cop_city_ms.city_name as city_name', 'cop_evs_ms.state_id','cop_state_ms.state_name')
            ->DISTINCT()
            ->get();




        return ResponseHelper::responseMessage('success', $ev_city);
        } catch (Exception $e) {
        
            return ResponseHelper::errorResponse('success','Something went wrong!!');
        }
    }


}
