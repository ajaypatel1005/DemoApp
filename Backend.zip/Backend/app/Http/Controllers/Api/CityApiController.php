<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\City;

class CityApiController extends Controller
{
    public function index()
    {
        try {

            $state = City::select(
                'cop_city_ms.*',
                'cop_state_ms.state_name as state_name'
            )
                ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
                ->where('cop_city_ms.status', '!=', 0)
                ->where('cop_state_ms.status', '!=', 0)
                ->get();


            if ($state->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }

            $stateData = $state->map(function ($item) {

                $data = [
                    'city_id' => encrypt($item->city_id),
                    'state_name' => $item->state_name,
                    'city_name' => $item->city_name,
                    'city_image' => asset("city_image/{$item->city_id}/{$item->city_image}"),
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $stateData, "Successfuly Data Get");
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }

    //START:::City Tier API with City_Image 
    public function city_tier(Request $request)
    {
        try {
            $request->has('tier');
            $tier = $request->tier;

            $query = City::select(
                'cop_city_ms.*',
                'cop_state_ms.state_name as state_name'
            )
                ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
                ->where('cop_city_ms.status', '!=', 0)
                ->where('cop_state_ms.status', '!=', 0)
                ->where('tier', $tier);

            $state = $query->get();

            if ($state->isEmpty()) {
                return ResponseHelper::errorResponse('success', 'No data available!!');
            }
            $stateData = $state->map(function ($item) {

                $data = [
                    'city_id' => encrypt($item->city_id),
                    'state_name' => $item->state_name,
                    'city_name' => $item->city_name,
                    'city_image' => asset("city_image/{$item->city_id}/{$item->city_image}")
                ];
                return $data;
            });
            return ResponseHelper::responseMessage('success', $stateData, "Successfuly Data Get");
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
    //END:::City Tier API with City_Image 
}