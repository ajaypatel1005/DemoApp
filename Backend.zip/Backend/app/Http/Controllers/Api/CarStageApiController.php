<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CarStage;
use Illuminate\Support\Facades\Log;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;

class CarStageApiController extends Controller
{
    public function index()
    {
        try {
            $carStages = CarStage::select('cop_cs_ms.cs_name', 'cop_cs_ms.cs_id')->get();


            if ($carStages->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }
            $formattedData = $carStages->map(function ($item) {

                $data = [
                    'cs_id' => encrypt($item->cs_id),
                    'cs_name' => $item->cs_name,
                ];

                return $data;
            });
            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
