<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\PostCategoryType;
use Exception;
use Illuminate\Http\Request;

class PostApiController extends Controller
{
    public function index(Request $request)
    {
        try {

            $p_c_name = $request->search;
            $post_category = PostCategoryType::join('cop_post', 'cop_post.post_cat_id', '=', 'cop_pct_ms.post_cat_id')
                ->select('post_id', 'cop_pct_ms.post_cat_name','cop_pct_ms.style', 'title', 'content', 'post_image', 'author', 'author_image', 'post_date')
                ->where('cop_pct_ms.status', '!=', 0)
                ->where('cop_pct_ms.style', '>=', 0)
                ->where(function ($query) use ($p_c_name) {
                    if (!empty($p_c_name)) {
                        $query->where('cop_pct_ms.post_cat_name', 'like', '%' . $p_c_name . '%');
                    }
                })
                ->orderBy('cop_post.post_date', 'asc') // Order by post_date in descending order
                ->where('cop_post.status', '!=', 0)
                ->get();
                // dd($post_category->toSql());

            $postData = $post_category->map(function ($item) {
                $data = [
                    'post_id' => encrypt($item->post_id),
                    'post_cat_id' => encrypt($item->post_cat_id),
                    'post_cat_name' => $item->post_cat_name,
                    'style' => $item->style,
                    'title' => $item->title,
                    'content' => $item->content,
                    'post_image' => asset("Post/{$item->post_id}/Post_image/{$item->post_id}_post.webp"),
                    'author' => $item->author,
                    'author_image' => asset("Post/{$item->post_id}/Author_image/{$item->post_id}_author.webp"),
                    'post_date' => $item->post_date,

                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $postData);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse(['Something went wrong!!']);
            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
