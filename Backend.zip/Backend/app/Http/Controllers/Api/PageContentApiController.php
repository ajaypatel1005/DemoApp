<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\PageContent;
use Exception;
use Illuminate\Http\Request;

class PageContentApiController extends Controller
{
    public function index(Request $request)
    {
        try {
            $pc_name = $request->search;
            $page_content = PageContent::where(function ($query) use ($request) {
                $query->orWhere('cop_pc.pc_name', 'like', '%' . $request->search . '%');
            })
            ->where('cop_pc.pc_name','=' ,$pc_name)
            ->where('cop_pc.status', '!=', 0)
            ->get();
            // ->toSql();

        if ($page_content->isEmpty()) {
            // return ResponseHelper::responseMessage('error', 'Not Found');
            return ResponseHelper::errorResponse('success','No data available!!');
        }
            $page_contentData = $page_content->map(function ($item) {

                $data = [
                    'pc_id' => encrypt($item->pc_id),
                    'pc_name' => $item->pc_name,
                    'pc_title' => $item->pc_title,
                    'pc_sub_title' => $item->pc_sub_title,
                    'pc_description' => $item->pc_description,
                    'pc_m_title' => $item->pc_m_title,
                    'pc_m_sub_title' => $item->pc_m_sub_title,
                    'pc_m_description' => $item->pc_m_description,
                    'pc_b_text' => $item->pc_b_text,
                    'pc_b_link' => $item->pc_b_link,
                    'pc_b_type' => $item->pc_b_type,

                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $page_contentData);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse(['Something went wrong!!']);
            return ResponseHelper::errorResponse('success','Something went wrong!!');
        }
    }
}
