<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Model;
use App\Models\PriceEntry;
use App\Models\Variant;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

// use GuzzleHttp\Psr7\Request;

class BrandApiController extends Controller
{
    private function pricefilter($model_id)
    {
        $priceMinMax = Model::select(
            DB::raw('MIN(cop_pe_ms.ex_showroom_price) as min_ex_showroom_price'),
            DB::raw('MAX(cop_pe_ms.ex_showroom_price) as max_ex_showroom_price')
        )
            ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->where('cop_models.model_id', $model_id)
            ->where('cop_models.model_type', '0')
            ->first();

        return [
            'price_filter' => $priceMinMax['min_ex_showroom_price'],
            'min_ex_showroom_price' => $this->convertToLakhCrore($priceMinMax['min_ex_showroom_price']),
            'max_ex_showroom_price' => $this->convertToLakhCrore($priceMinMax['max_ex_showroom_price']),
        ];
    }


    public function brand()
    {
        try {
            $brands = Brand::select('cop_brands_ms.brand_name', 'cop_brands_ms.brand_id', 'cop_brands_ms.brand_description')
                ->where('status', '!=', 0)
                ->orderBy('priority', 'asc')
                ->get();

            if ($brands->isEmpty()) {


                return ResponseHelper::errorResponse('success', 'No data available');
            }


            $brandsData = $brands->map(function ($item) {
                $data = [
                    'brand_id' => encrypt($item->brand_id),
                    'brand_name' => $item->brand_name,
                    'brand_description' => $item->brand_description,
                    'brand_logo' => asset("brands/{$item->brand_id}/{$item->brand_id}.webp") ?? null,
                    'brand_banner' => asset("brands/{$item->brand_id}/{$item->brand_id}_banner.webp") ?? null,
                ];
                return  $data;
            });

            return ResponseHelper::responseMessage('success', $brandsData, "Successfuly Data Get");
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }

    //testing
    public function brandDetail(Request $request, $id)
    {
        // dd($id);
        $brand_name = $id;

        $brandDetails = Brand::join('cop_models', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
            ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
            ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
            ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
            ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')

            ->select(
                'cop_cs_ms.cs_name',
                'cop_ct_ms.ct_name',
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_brands_ms.brand_description',
                'cop_brands_ms.brand_banner',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_models.model_type',
                'cop_models.model_image',
                'cop_models.min_price',
                'cop_models.max_price',
                'cop_variants.variant_id',
                'cop_variants.variant_name',
                'cop_variants.seating_capacity',
                'cop_ratings.rating_value',
                'cop_rating_types.rating_type_name',
            )
            ->where('cop_brands_ms.brand_name', '=', $brand_name)
            ->where('cop_cs_ms.cs_name', '=', 'Launched')
            ->where('cop_variants.variant_id', '=', function ($query) {
                $query->select('variant_id')
                    ->from('cop_variants')
                    ->whereColumn('cop_variants.model_id', '=', 'cop_models.model_id')
                    ->where('cop_variants.status', '=', 1)
                    ->orderBy('variant_id')
                    ->limit(1);
            })
            ->where('cop_models.status', '=', 1)
            ->where('cop_brands_ms.status', '=', 1)
            ->where('cop_variants.status', '=', 1)
            ->distinct()
            ->get();

        if ($brandDetails->isEmpty()) {

            $brandDetail = Brand::select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_brands_ms.brand_description',
                'cop_brands_ms.brand_banner',
            )
                ->where('cop_brands_ms.brand_name', '=', $brand_name)

                ->where('cop_brands_ms.status', '=', 1)

                ->distinct()
                ->get();
            $brandsDatas = $brandDetail->map(function ($item) {
                $data = [
                    'brand_id' => encrypt($item->brand_id),
                    'brand_name' => $item->brand_name,
                    'brand_description' => $item->brand_description,
                    'brand_logo' => asset("brands/{$item->brand_id}/{$item->brand_id}.webp") ?? null,
                    'brand_banner' => asset("brands/{$item->brand_id}/{$item->brand_id}_banner.webp") ?? null,
                    'models' => [],
                ];
                return  $data;
            });

            return ResponseHelper::responseMessage('success', $brandsDatas);
        }

        $grouped_models = $brandDetails->groupBy('brand_id');

        $result = [];

        foreach ($grouped_models as $brand_id => $models) {
            $brand_name = Brand::where('brand_id', $brand_id)->value('brand_name');
            $brand_description = Brand::where('brand_id', $brand_id)->value('brand_description');
            $brand_banner = Brand::where('brand_id', $brand_id)->value('brand_banner');

            $brand_data = [
                'brand_id' => encrypt($brand_id),
                'brand_name' => $brand_name,
                'brand_description' => $brand_description,
                'brand_banner' => asset("brands/{$brand_id}/{$brand_id}_banner.webp") ?? null,

                'models' => [],
            ];

            foreach ($models as $model) {
                $model_data = [
                    'ct_name' => $model->ct_name,
                    'model_id' => encrypt($model->model_id),
                    'brand_name' => $brand_name,
                    'model_name' => $model->model_name,
                    'price' => $this->pricefilter($model->model_id),
                    // 'min_price' => $this->convertToLakhCrore($model->min_price),
                    // 'max_price' => $this->convertToLakhCrore($model->max_price),
                    'model_type' => $model->model_type == 0 ? 'Non EV' : 'EV',
                    'model_image' => asset("brands/{$model->brand_id}/{$model->model_id}/{$model->model_id}.webp") ?? null,
                    'rating_type_name' => $model->rating_type_name,
                    'rating_value' => isset($model->rating_value) ? number_format((float)$model->rating_value, 1, '.', '') : NULL,
                    'variants' => [],
                ];

                $variants =  $models->where('variant_id', $model->variant_id)->map(function ($variant) {
                    return [
                        'variant_id' => encrypt($variant->variant_id),
                        'variant_name' => $variant->variant_name,
                        'seating_capacity' => $variant->seating_capacity,
                        'features' => [],
                    ];
                })->values()->toArray();
                foreach ($variants as &$variant) {
                    $variantDetails = Variant::join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                        ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                        ->select(
                            'cop_fv.feature_value',
                            'cop_features_ms.features_name',
                            'cop_su_ms.su_name'
                        )
                        ->where('cop_variants.variant_id', decrypt($variant['variant_id']))
                        ->where(function ($query) {
                            $query->whereIn('cop_features_ms.features_name', ['Displacement', 'Battery Capacity']);
                        })
                        ->distinct()
                        ->where('cop_variants.status', '=', 1)
                        ->where('cop_features_ms.status', '=', 1)
                        ->where('cop_fv.status', '=', 1)
                        ->get();
                    $variant['features'] = $variantDetails->toArray();
                }
                $variants = is_array($variants) ? $variants : [$variants];
                $model_data['variants'] = $variants;
                $brand_data['models'][] = $model_data;
            }

            $result[] = $brand_data;
        }

        return ResponseHelper::responseMessage('success', $result);
    }

    // global serach
    public function globalSearch(Request $request)
    {
        try {
            $search_keyword = $request->input('search_keyword');


            if (empty($search_keyword)) {

                return ResponseHelper::responseMessage('success');
            }

            $all_models = Model::select('cop_brands_ms.brand_id', 'cop_brands_ms.brand_name', 'cop_models.model_name', 'cop_models.model_id')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->where(function ($query) use ($search_keyword) {
                    $query->where('cop_brands_ms.brand_name', 'like', '%' . $search_keyword . '%')
                        ->orWhere('cop_models.model_name', 'like', '%' . $search_keyword . '%');
                })
                ->where('cop_cs_ms.cs_name', '!=', 'Upcoming')
                ->where('cop_models.status', '=', 1)
                ->where('cop_brands_ms.status', '=', 1)
                ->get();

            if ($all_models->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }

            $result = [];

            foreach ($all_models as $model) {
                $brand_name = Brand::where('brand_id', $model->brand_id)->value('brand_name');

                $variants = Variant::where('model_id', $model->model_id)
                    ->where('cop_variants.status', '=', 1)
                    ->get();

                $variant_data = [];

                foreach ($variants as $variant) {
                    $priceEntry = PriceEntry::where('variant_id', $variant->variant_id)
                        ->where('cop_pe_ms.status', '=', 1)
                        ->first();
                    if ($priceEntry) {
                        $variant_data[] = [
                            'variant_id' => encrypt($variant->variant_id),
                            'variant_name' => $variant->variant_name,
                        ];
                    }
                }

                $model_data = [
                    'model_id' => encrypt($model->model_id),
                    'model_name' => $model->model_name,
                    'variants' => $variant_data,
                ];

                if (!isset($result[$brand_name])) {
                    $result[$brand_name] = [
                        'brand_id' => encrypt($model->brand_id),
                        'brand_name' => $brand_name,
                        'models' => [],
                    ];
                }

                $result[$brand_name]['models'][] = $model_data;
            }


            $result = array_values($result);

            return ResponseHelper::responseMessage('success', $result, "Successfully Data Get");
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
    
    // global serach

    private function convertToLakhCrore($price)
    {
        if ($price >= 10000000) {
            return number_format($price / 10000000, 2) . ' Cr';
        } elseif ($price >= 100000) {
            return number_format($price / 100000, 2) . ' Lakh';
        } else {
            return $price;
        }
    }
}
