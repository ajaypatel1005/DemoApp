<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Specification;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class SpecificationApiController extends Controller
{
    public function specification()
    {
        try {

            $specs = Specification::select(
                'cop_spec_ms.*',
                'cop_sc_ms.sc_name as sc_name'
            )
                ->leftJoin('cop_sc_ms', 'cop_spec_ms.sc_id', '=', 'cop_sc_ms.sc_id')
                ->where('cop_spec_ms.status', '!=', 0) // Filter out banners with status 0
                ->get();

            $specsData = $specs->map(function ($item) {
                $imagePath = public_path("Specification/{$item->spec_id}/{$item->spec_id}.webp");
                $specImage = File::exists($imagePath) ? asset("Specification/{$item->spec_id}/{$item->spec_id}.webp") : null;
                return [
                    'spec_id' => $item->spec_id,
                    'sc_name' => $item->sc_name,
                    'spec_name' => $item->spec_name,

                    'spec_image' => $specImage,
                ];

            });

            return ResponseHelper::responseMessage('success', $specsData, "Successfuly Data Get");
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse(['Something went wrong!!']);
            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
