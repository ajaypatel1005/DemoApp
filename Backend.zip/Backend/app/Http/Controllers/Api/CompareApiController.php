<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Brand;
use App\Models\Model;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Feature;
use App\Models\FeatureValue;
use App\Models\Specification;
use App\Models\SpecificationCategory;
use App\Models\Variant;
use Illuminate\Support\Facades\DB;

class CompareApiController extends Controller
{
    public function compareModel(Request $request)
    {
        $expectedOrder = ['model_id', 'variant_id'];

        $selectedParameters = [];

        try {
            $compareCar = FeatureValue::select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_variants.variant_id',
                'cop_variants.variant_name',
                'cop_variants.variant_image',
                'cop_pe_ms.*',
            )
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_fv.brand_id')
                ->join('cop_models', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_variants', 'cop_variants.variant_id', '=', 'cop_fv.variant_id')
                ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                ->distinct('cop_variants,variant_id')
                ->where('cop_variants.status', '!=', 0);

            foreach ($expectedOrder as $parameter) {
                if ($request->has($parameter)) {
                    $compareCar->where('cop_fv.' . $parameter, $request->$parameter);
                    $selectedParameters[] = $parameter;
                } else {
                    break;
                }
            }
            // dd($compareCar->toSql());
            if (in_array('variant_id', $selectedParameters) && in_array('model_id', $selectedParameters)) {
                $compareCar = $compareCar->get();
                if ($compareCar->isEmpty()) {
                    // return ResponseHelper::responseMessage('error', 'Not Found');
                    return ResponseHelper::errorResponse('success', 'No data available!!');
                }

                $formattedData = $compareCar->map(function ($item) {

                    $data = [
                        'brand_id' => $item->brand_id,
                        'brand_name' => $item->brand_name,

                        'model_id' => $item->model_id,
                        'model_name' => $item->model_name,

                        'variant_id' => $item->variant_id,
                        'variant_name' => $item->variant_name,
                        'variant_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_image}") ?? "",

                        'basic_details' => [
                            'on_road_price' => $this->convertToLakhCrore($item->ex_showroom_price),
                            'color_code' => [],
                            'dual_color_code' => [],
                        ],
                        'specification_catagory' => []
                    ];

                    $colors = DB::table('cop_variants')
                        ->join('cop_colors', 'cop_variants.variant_id', '=', 'cop_colors.variant_id')
                        ->select('cop_colors.color_code', 'cop_colors.dual_color_code') // Corrected select statement
                        ->where('cop_colors.variant_id', $item->variant_id)
                        ->get();

                    if (!empty($colors)) {
                        foreach ($colors as $color) {
                            $data['basic_details']['color_code'][] = $color->color_code;

                            $data['basic_details']['dual_color_code'][] = $color->dual_color_code;
                        }
                    }

                    $spec_cat = SpecificationCategory::all();

                    $key_spec_cat = 0;
                    foreach ($spec_cat as $specCatItem) {

                        $data['specification_catagory'][] = [
                            'specification_catagory_name' => $specCatItem->sc_name,
                        ];

                        $spec = Specification::join('cop_sc_ms', 'cop_sc_ms.sc_id', '=', 'cop_spec_ms.sc_id')
                            ->where('sc_name', $specCatItem->sc_name)->get();

                        $data['specification_catagory'][$key_spec_cat][$specCatItem->sc_name] = [];

                        $key_spec = 0;
                        foreach ($spec as $specItem) {
                            $data['specification_catagory'][$key_spec_cat][$specCatItem->sc_name][] = [
                                'specification_name' => $specItem->spec_name,
                                'spec_image' => asset("Specification/{$specItem->spec_id}/{$specItem->spec_image}") ?? "",
                            ];

                            $feature = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                                ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                                ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                                ->where('cop_spec_ms.spec_name', $specItem->spec_name)
                                ->where('cop_fv.variant_id', $item->variant_id)
                                // ->where(function($query) {
                                //     $query->where('cop_features_ms.fuel_type', 0) // Assuming 0 corresponds to the value for Battery Capacity
                                //           ->orWhere('cop_features_ms.fuel_type', 1)
                                //           ->orWhere('cop_features_ms.fuel_type', 2);
                                // })
                                ->get();

                            $data['specification_catagory'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name] = [];

                            foreach ($feature as $featureItem) {
                                $data['specification_catagory'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name][] = [
                                    'features_name' => $featureItem->features_name,
                                    'feature_value' => ($featureItem->feature_value !== null && $featureItem->feature_value !== '')
                                        ? $featureItem->feature_value . ($featureItem->su_name !== null ? ' ' . $featureItem->su_name : '')
                                        : 'N/A',
                                ];
                            }

                            $key_spec++;
                        }
                        $key_spec_cat++;
                    }

                    return $data;
                });
                return ResponseHelper::responseMessage('success', $formattedData);
            }

            // Check if 'model_id' is selected
            if (in_array('model_id', $selectedParameters)) {
                $selectedModelId = $request->input('model_id');

                // Fetch variants matching with the selected model
                $variants = Variant::select('variant_id', 'variant_name')
                    ->where('model_id', $selectedModelId)
                    ->get();

                $variantData = [];
                foreach ($variants as $variant) {
                    $variantData[] = [
                        'variant_id' => $variant->variant_id,
                        'variant_name' => $variant->variant_name,
                    ];
                }

                return response()->json(['variants' => $variantData]);
            } else {

                $data = [];
                $brands = Brand::select('brand_id', 'brand_name')
                    ->where('status', 1)
                    ->get();

                if (!empty($brands)) {
                    foreach ($brands as $brand) {
                        $brandData = [
                            'brand_id' => encrypt($brand->brand_id),
                            'brand_name' => $brand->brand_name,
                            'models' => [],
                        ];

                        $models = Model::select('model_id', 'model_name')
                            ->where('brand_id', $brand->brand_id)
                            ->where('status', 1)
                            ->get();


                        foreach ($models as $model) {
                            $modelData = [
                                'model_id' => $model->model_id,
                                'model_name' => $model->model_name,
                                'variants' => [],
                            ];

                            $variants = Variant::select('variant_id', 'variant_name')
                                ->where('model_id', $model->model_id)
                                ->where('status', '=', 1)
                                ->get();

                            foreach ($variants as $variant) {
                                $variantData = [
                                    'variant_id' => $variant->variant_id,
                                    'variant_name' => $variant->variant_name,
                                ];

                                $modelData['variants'][] = $variantData;
                            }

                            $brandData['models'][] = $modelData;
                        }

                        $data['brands'][] = $brandData;
                    }
                }

                return response()->json($data);
            }
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse(['Something went wrong!!']);
            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }

    public function compare_model(Request $request)
    {
        try {
            $brand_id = $request->brand_id;
            $brand = Model::find($brand_id);
            if (!$brand) {
                return ResponseHelper::errorResponse('error', 'Brand not found');
            }
            $models = Model::with('ratings', 'brand')
                ->where('brand_id', $brand_id)
                ->get();

            $formattedModels = $models->map(function ($model) {
                $brand_id = $model->brand->brand_id;
                $rating_value = $model->ratings->pluck('rating_value')->map(function ($value) {
                    return isset($value) ? number_format((float)$value, 1, '.', '') : null;
                })->first();
                return [
                    'brand_name' => $model->brand->brand_name,
                    'model_id' => $model->model_id,
                    'model_image' => asset("brands/{$brand_id}/{$model->model_id}/{$model->model_id}.webp"),
                    'model_name' => $model->model_name,
                    'min_price' => $model->min_price,
                    'max_price' => $model->max_price,
                    'rating_value' => $rating_value,
                ];
            });

            return ResponseHelper::responseMessage('success', $formattedModels, "Successfully retrieved data");
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('success', 'Something went wrong!!' . $e->getMessage());
        }
    }

    public function compareAnswer(Request $request)
    {
        try {

            $variantIds = explode(',', $request->input('variant_id'));

            if (count($variantIds) < 2) {
                return ResponseHelper::errorResponse('error', 'At least two variant_ids are required.');
            }
            // dd( $variantIds);
            $data = [];
            $spec_cat = [];

            foreach ($variantIds as $variantId) {


                $compareCar = FeatureValue::select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_variants.variant_id',
                    'cop_variants.variant_name',
                    'cop_variants.variant_image',
                    'cop_pe_ms.*',
                )
                    ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_fv.brand_id')
                    ->join('cop_models', 'cop_models.model_id', '=', 'cop_fv.model_id')
                    ->join('cop_variants', 'cop_variants.variant_id', '=', 'cop_fv.variant_id')
                    ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                    ->distinct('cop_variants.variant_id')
                    ->where('cop_variants.variant_id', $variantId)
                    ->where('cop_variants.status', '!=', 0)
                    // ->where('cop_models.model_type', '>=' , 0)
                    // $variantType = $compareCar->first()->model_type == 1 ? "EV" : "Non-EV";
                    ->get();

                if ($compareCar->isEmpty()) {
                    return ResponseHelper::errorResponse('success', 'No data available for variant_id ' . $variantId);
                }

                $formattedData = $compareCar->map(function ($item) {
                    $data = [
                        'brand_id' => encrypt($item->brand_id),
                        'brand_name' => $item->brand_name,
                        'model_id' => encrypt($item->model_id),
                        'model_name' => $item->model_name,
                        'variant_id' => encrypt($item->variant_id),
                        'variant_name' => $item->variant_name,
                        'variant_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_image}") ?? "",
                        'basic_details' => [
                            'on_road_price' => $this->convertToLakhCrore($item->ex_showroom_price),
                            'color_code' => [],
                            'dual_color_code' => [],
                        ],
                    ];
                    return $data;
                });
                $data[] = $formattedData;
            }

            foreach ($variantIds as $variantId) {
                $checkFuelType = Variant::select('cop_models.model_type')->join('cop_models', 'cop_models.model_id', '=', 'cop_variants.model_id')
                    ->where('cop_variants.variant_id', $variantId)
                    ->first();

                if (!empty($checkFuelType)) {
                    $variant_types[] = $checkFuelType->model_type == 1 ? "EV" : "Non-EV";
                }
            }

            if (!empty($variant_types)) {
                $unique_variant_types = array_unique($variant_types);

                if (count($unique_variant_types) == 1) {
                    $overall_variant_type = reset($unique_variant_types);
                    $all_variant_type = $overall_variant_type;
                } else {
                    $all_variant_type = 'Both';
                }
            }

            // $SpecData = $compareCar->map(function ($items) {
            $spec_cat = ['specification_catagory' => []];

            $spec_cat_data = SpecificationCategory::all();

            $key_spec_cat = 0;
            foreach ($spec_cat_data as $specCatItem) {

                $spec_cat['specification_catagory'][] = [
                    'specification_catagory_name' => $specCatItem->sc_name,
                ];

                $spec = Specification::join('cop_sc_ms', 'cop_sc_ms.sc_id', '=', 'cop_spec_ms.sc_id')
                    ->where('sc_name', $specCatItem->sc_name)->get();

                $spec_cat['specification_catagory'][$key_spec_cat][$specCatItem->sc_name] = [];

                $key_spec = 0;
                foreach ($spec as $specItem) {
                    $spec_cat['specification_catagory'][$key_spec_cat][$specCatItem->sc_name][] = [
                        'specification_name' => $specItem->spec_name,
                        'spec_image' => asset("Specification/{$specItem->spec_id}/{$specItem->spec_image}") ?? "",
                    ];

                    $featureQry = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', $specItem->spec_name);

                    if ($all_variant_type == 'EV') {
                        $feature = $featureQry->whereIn('cop_features_ms.fuel_type', [1, 2])
                            ->get();
                    } else if ($all_variant_type == 'Non-EV') {
                        $feature = $featureQry->whereIn('cop_features_ms.fuel_type', [0, 2])
                            ->get();
                    } else {
                        $feature = $featureQry->get();
                    }

                    $spec_cat['specification_catagory'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name] = [];

                    foreach ($feature as $featureItem) {

                        $spec_cat['specification_catagory'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name][] = [
                            'features_name' => $featureItem->features_name,
                            'feature_value' => []
                        ];

                        foreach ($variantIds as $variantId) {
                            $feature_value = FeatureValue::join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                                ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                                ->where('cop_features_ms.features_name', $featureItem->features_name)
                                ->where('cop_fv.variant_id', $variantId)
                                ->get();

                            if ($feature_value->isEmpty() | $feature_value == '' | $feature_value == null) {
                                $value = 'N/A';

                                $lastIndex = count($spec_cat['specification_catagory'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name]) - 1;

                                $spec_cat['specification_catagory'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name][$lastIndex]['feature_value'][] = $value;
                            }

                            foreach ($feature_value as $fv_item) {
                                $value = ($fv_item->feature_value !== null && $fv_item->feature_value !== '' && $fv_item->feature_value !== '-')
                                    ? $fv_item->feature_value . ($fv_item->su_name !== null ? ' ' . $fv_item->su_name : '')
                                    : 'N/A';

                                $lastIndex = count($spec_cat['specification_catagory'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name]) - 1;

                                $spec_cat['specification_catagory'][$key_spec_cat][$specCatItem->sc_name][$key_spec][$specItem->spec_name][$lastIndex]['feature_value'][] = $value;
                            }
                        }
                    }

                    $key_spec++;
                }
                $key_spec_cat++;
            }

            return $spec_cat;
            // });

            $data[] = $formattedData;
            $spec_cat[] = $spec_cat;

            $finalData = [$data, $spec_cat];

            return ResponseHelper::responseMessage('success', $finalData, "Successfully retrieved data");
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }

    private function convertToLakhCrore($price)
    {
        if ($price >= 10000000) {
            return number_format($price / 10000000, 2) . ' Cr';
        } elseif ($price >= 100000) {
            return number_format($price / 100000, 2) . ' Lakh';
        } else {
            return $price;
        }
    }
}