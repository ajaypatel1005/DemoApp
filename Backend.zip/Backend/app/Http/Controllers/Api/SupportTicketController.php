<?php

namespace App\Http\Controllers\Api;

use App\Events\NewNotificationEvent;
use App\Events\ReplyTicketNotificationEvent;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Conversation;
use App\Models\Ticket;
use App\Models\TicketFileManager;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class SupportTicketController extends Controller
{
    public function saveTicket(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required',
            'subject' => 'required',
            'category_id' => 'required',
            'description' => 'required',
            'book_test_drive_id' => 'required'
        ]);

        if ($validator->fails()) {
            return  response()->json([
                'status' => false,
                'code' => 422,
                'errors' => $validator->errors(),
                'msg' => '',
            ], 422);
        }
        try {
            $ticket = new Ticket();
            $ticket->test_drive_id = encryptor('d', $request->book_test_drive_id);
            $ticket->title = $request->subject;
            $ticket->ticket_no = Ticket::generateInvoiceNumber('test_drive');
            $ticket->description = $request->description;
            $ticket->category_id = encryptor('d', $request->category_id);
            $ticket->created_by_customer = encryptor('d', $request->customer_id);
            $ticket->priority = 2;
            $ticket->status = 0;
            $ticket->save();
            $uploadedFiles = [];
            if ($request->hasFile('files')) {
                foreach ($request->file('files') as $file) {
                    $filePath = $file->store('uploads/tickets', 'public');
                    $uploadedFiles[] = $filePath;
                }
            }
            foreach ($uploadedFiles as $filePath) {
                $ticketFile = new TicketFileManager();
                $ticketFile->ticket_id = $ticket->id;
                $ticketFile->path = $filePath;
                $ticketFile->name = $filePath;
                $ticketFile->save();
            }
            $conversation = Conversation::create([
                'ticket_id' => $ticket->id,
                'body' => 'Thank you for reaching out to us. We have received your ticket.Your ticket number is [Ticket Number]. Our team is currently reviewing the details, and we will work diligently to resolve this matter as quickly as possible. If you have any additional information or questions in the meantime, please feel free to reply!',
                'agent_id' => auth()->id(),
            ]);
            $conversation->save();
            $id=encryptor('e', $ticket->id);
            $notificationData = [
                'message' => "Click here to view your ticket details and track its progress.",
                'title' => "Ticket Created Successfully",
                'url' => "/myaccount/support/$id"
            ];
            createNotification($notificationData['title'], $notificationData['message'],encryptor('d', $request->customer_id) , $notificationData['url']);
            event(new ReplyTicketNotificationEvent('cop-channel-user-' . encryptor('d', $request->customer_id), $notificationData));
            return ResponseHelper::responseMessage('success', $ticket, 'Support ticket has been created successfully.');
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }

    public function saveReply(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required',
            'reply' => 'required_without:files',
            'ticket_id' => 'required'
        ]);

        if ($validator->fails()) {
            return  response()->json([
                'status' => false,
                'code' => 422,
                'errors' => $validator->errors(),
                'msg' => '',
            ], 422);
        }
        try {
            if ($request->hasFile('files') || !empty($request->reply)) {
            $conversation = new Conversation();
            $conversation->body = $request->reply??'';
            $conversation->ticket_id = $request->ticket_id;

            $conversation->customer_id = encryptor('d', $request->customer_id);
            $conversation->save();
            $uploadedFiles = [];
            if ($request->hasFile('files')) {
                foreach ($request->file('files') as $key => $file) {
                    // $filePath = $file->store('uploads/tickets', 'public');
                    // $uploadedFiles[] = $filePath;
                    $uploadedImage = $file;
                    $webpImageName = date('YmdHis') . $key . '.webp';

                    $manager = new ImageManager(new Driver());


                    $image = $manager->read($uploadedImage);
                    $image->toWebp()->save(public_path('storage') . '/uploads/tickets/' . $webpImageName);

                    // $filePath = $file->store('uploads/tickets', 'public');
                    $uploadedFiles[] = 'uploads/tickets/' . $webpImageName;
                }
            }
            foreach ($uploadedFiles as $filePath) {
                $ticketFile = new TicketFileManager();
                $ticketFile->conversation_id = $conversation->id;
                $ticketFile->path = $filePath;
                $ticketFile->name = $filePath;
                $ticketFile->save();
            }
            return ResponseHelper::responseMessage('success', $conversation, 'Replied');
        }
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
