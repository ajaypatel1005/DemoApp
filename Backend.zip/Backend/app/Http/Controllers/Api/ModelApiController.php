<?php

namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Model;
use App\Models\Variant;
use App\Models\CarStage;
use Exception;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Brand;
use App\Models\CarGraphic;
use App\Models\CarListingData;
use App\Models\CarType;
use App\Models\Color;
use App\Models\Feature;
use App\Models\PriceEntry;
use App\Models\SpecificationCategory;
use App\Models\Specification;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Models\Wishlist;


class ModelApiController extends Controller
{

    private function pricefilter($model_id)
    {
        // dd($model_id);
        $priceMinMax = Model::select(
            DB::raw('MIN(cop_pe_ms.ex_showroom_price) as min_ex_showroom_price'),
            DB::raw('MAX(cop_pe_ms.ex_showroom_price) as max_ex_showroom_price')
        )
            ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->where('cop_models.model_id', $model_id)
            // ->where('cop_models.model_type', '0')
            ->first();

        return [
            'price_filter' => $priceMinMax['min_ex_showroom_price'],
            'min_ex_showroom_price' => $this->convertToLakhCrore($priceMinMax['min_ex_showroom_price']),
            'max_ex_showroom_price' => $this->convertToLakhCrore($priceMinMax['max_ex_showroom_price']),
        ];
    }

    public function formatModel($models, $power, $engine, $wishlist)
    {
        // dd($power, $engine);
        $formattedData = $models->map(function ($item) use ($power, $engine) {
            $powerDetails = $power->where('model_id', $item->model_id)->first();
            $engineDetails = $engine->where('model_id', $item->model_id)->first();
            if ($powerDetails === null) {
                dd("Power details are null for model name & ID: {$item->model_name} : {$item->model_id}");
            }

            if ($engineDetails === null) {
                dd("Engine details are null for model name & ID: {$item->model_name} : {$item->model_id}");
            }
            $data = [
                'model_id' => encrypt($item->model_id),
                'car_stage' => $item->cs_name,
                'model_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp") ?? NULL,
                'launch_date' => $item->launch_date,
                'brand_name' => $item->brand_name,
                'brand_description' => $item->brand_description,
                'model_name' => $item->model_name,
                'price' => $this->pricefilter($item->model_id),
                // 'min_price' => $this->convertToLakhCrore($item->min_price),
                // 'max_price' => $this->convertToLakhCrore($item->max_price),
                'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                'rating_type_name' => $item->rating_type_name ?? NULL,
                'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : NULL,
                'wishlist' => $item->wishlist,

                'power' => [
                    'feature_id' => $powerDetails->feature_id ?? null,
                    'features_image' =>  asset("Feature/{$powerDetails->feature_id}/{$powerDetails->feature_id}.svg") ?? NULL,
                    'feature_value' => $powerDetails->feature_value ?? NULL,
                    'su_name' => $powerDetails->su_name ?? NULL,
                ],
                'engine' => [
                    'feature_id' => $engineDetails->feature_id ?? null,
                    'features_image' => asset("Feature/{$engineDetails->feature_id}/{$engineDetails->feature_id}.svg") ?? NULL,
                    'feature_value' => $engineDetails->feature_value ?? NULL,
                    'su_name' => $engineDetails->su_name ?? NULL,
                ],
            ];

            return $data;
        });

        return $formattedData;
    }

    private function getFeatureDetails($featureName)
    {
        $data = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
            ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
            // ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
            ->leftJoin('cop_fv', 'cop_fv.model_id', '=', 'cop_models.model_id')
            ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
            ->select(
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_features_ms.feature_id',
                'cop_features_ms.features_image',
                'cop_fv.fv_id',
                'cop_fv.feature_value',
                'cop_su_ms.su_name',
                'cop_models.status',
                'cop_brands_ms.status',
                'cop_fv.status',
            )->where('cop_features_ms.features_name', $featureName)
            ->where('cop_models.status', '=', 1)
            ->where('cop_brands_ms.status', '=', 1)
            ->where('cop_fv.status', '=', 1)
            ->where('cop_features_ms.status', '=', 1)
            ->distinct()

            ->get();
        // dd($data );

        if ($data->isEmpty()) {
            // return ResponseHelper::errorResponse(['No data available']);
            return ResponseHelper::errorResponse('success', 'No data available!!');
        }

        return $data;
    }

    public function trendingModel(Request $request)
    {
        try {

            if ($request->type == 'Upcoming Car') {

                $currentDate = now()->toDateString();
                $date90DaysLater = now()->addDays(90)->toDateString();
                // dd($date90DaysLater);
                // dd($currentDate);

                $models = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                    ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')

                    ->leftJoin('cop_ratings', function ($join) {
                        $join->on('cop_ratings.model_id', '=', 'cop_models.model_id')
                            ->where('cop_cs_ms.cs_name', '!=', 'Upcoming');
                    })
                    ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                    ->select(
                        'cop_models.*',
                        'cop_cs_ms.cs_name',
                        'cop_brands_ms.brand_name',
                        'cop_brands_ms.brand_description',
                        'cop_ct_ms.ct_name',
                        DB::raw('COALESCE(cop_ratings.rating_value, NULL) as rating_value'),
                        'cop_rating_types.rating_type_name'
                    )
                    ->where('cop_cs_ms.cs_name', '=', 'Upcoming')
                    ->where('cop_models.launch_date', '>', $date90DaysLater)
                    ->where('cop_brands_ms.status', '=', 1)
                    ->where('cop_models.status', '=', 1)
                    ->distinct()
                    ->get();

                // if ($models->isEmpty()) {
                //     return ResponseHelper::errorResponse(['No data available']);
                // }

                $power = $this->getFeatureDetails('Power');
                $engine = $this->getFeatureDetails('Displacement');

                $powerEV = $this->getFeatureDetails('Power (EV)');
                // dd($powerEV);
                $range = $this->getFeatureDetails('Range');

                $responseArray = [];

                foreach ($models as $model) {

                    $model->power = $powerEV->where('model_id', $model->model_id)->first();
                    $model->range = $range->where('model_id', $model->model_id)->first();

                    $model->power = $power->where('model_id', $model->model_id)->first();
                    $model->engine = $engine->where('model_id', $model->model_id)->first();

                    $wishlistGet = Wishlist::where('model_id', $model->model_id)
                        ->where('customer_id', Auth::guard('api')->id())
                        ->exists();

                    $model->wishlist = $wishlistGet ? true : false;


                    $responseArray[] = $model;
                }

                $wishlist = [];
                $formattedData = $this->bugdetformatModel(collect($responseArray), $power, $engine, $powerEV, $range, $wishlist);


                return ResponseHelper::responseMessage('success', $formattedData);
            } else if ($request->type == 'Popular Car') {

                $models = CarListingData::select(
                    'cop_models.*',
                    'cop_msd.*',
                    'cop_cl_ms.cl_name as cl_name',
                    'cop_brands_ms.brand_name as brand_name',
                    'cop_brands_ms.brand_description as brand_description',
                    'cop_ratings.rating_id',
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                )
                    ->leftJoin('cop_cl_ms', 'cop_cl_data.cl_id', '=', 'cop_cl_ms.cl_id')
                    ->leftJoin('cop_brands_ms', 'cop_cl_data.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_models', 'cop_cl_data.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                    ->where('cop_cl_data.status', '=', 1)
                    ->where('cop_brands_ms.status', '=', 1)
                    ->where('cop_models.status', '=', 1)
                    ->where('cop_cl_ms.cl_name', '=', 'Popular Cars')
                    ->distinct("cop_models.model_id")
                    ->get();

                $power = $this->getFeatureDetails('Power');
                $engine = $this->getFeatureDetails('Displacement');

                $responseArray = [];

                foreach ($models as $model) {
                    $model->power = $power->where('model_id', $model->model_id)->first();
                    $model->engine = $engine->where('model_id', $model->model_id)->first();


                    $wishlistGet = Wishlist::where('model_id', $model->model_id)
                        ->where('customer_id', Auth::guard('api')->id())
                        ->exists();

                    $model->wishlist = $wishlistGet ? true : false;



                    $responseArray[] = $model;
                }
                $wishlist = [];
                // dd($responseArray);
                $formattedData = $this->formatModel(collect($responseArray), $power, $engine, $wishlist);


                return ResponseHelper::responseMessage('success', $formattedData);
            } else if ($request->type == 'Ev Car') {

                $models = CarListingData::select(
                    'cop_models.*',
                    'cop_msd.*',
                    'cop_cl_ms.cl_name as cl_name',
                    'cop_brands_ms.brand_name as brand_name',
                    'cop_brands_ms.brand_description',
                    'cop_ratings.rating_id',
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                )
                    ->leftJoin('cop_cl_ms', 'cop_cl_data.cl_id', '=', 'cop_cl_ms.cl_id')
                    ->leftJoin('cop_brands_ms', 'cop_cl_data.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_models', 'cop_cl_data.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                    ->where('cop_cl_data.status', '=', 1)
                    ->where('cop_brands_ms.status', '=', 1)
                    ->where('cop_models.status', '=', 1)
                    ->where('cop_cl_ms.cl_name', '=', 'EV Cars')
                    ->distinct("cop_models.model_id")
                    ->get();

                // if ($models->isEmpty()) {
                //     return ResponseHelper::errorResponse(['No data available']);
                // }

                $power = $this->getFeatureDetails('Power (EV)');
                $engine = $this->getFeatureDetails('Range');

                $responseArray = [];

                foreach ($models as $model) {
                    $model->power = $power->where('model_id', $model->model_id)->first();
                    $model->engine = $engine->where('model_id', $model->model_id)->first();
                    $wishlistGet = Wishlist::where('model_id', $model->model_id)
                        ->where('customer_id', Auth::guard('api')->id())
                        ->exists();

                    // Set the wishlist property directly on the model object
                    $model->wishlist = $wishlistGet ? true : false;
                    $responseArray[] = $model;
                }
                $wishlist = [];

                $formattedData = $this->formatModel(collect($responseArray), $power, $engine, $wishlist);


                return ResponseHelper::responseMessage('success', $formattedData);
            } else {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }





    public function electric_Car(Request $request)
    {

        try {
            $evCar_models = Model::join('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_banners', 'cop_banners.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->select(
                    'cop_brands_ms.brand_name',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_type',
                    'cop_models.min_price',
                    'cop_models.max_price',
                    'cop_msd.model_engine',
                    'cop_msd.model_bhp',
                    'cop_msd.model_transmission',
                    'cop_msd.model_mileage',
                    'cop_msd.model_fuel',
                    'cop_banners.banner_id',
                    'cop_banners.banner_image'
                )
                ->where('cop_banners.status', '=', 1)
                ->where('cop_brands_ms.status', '=', 1)
                ->where('cop_models.model_type', '=', 1)
                ->whereNotNull('cop_banners.model_id')
                ->where(function ($query) use ($request) {
                    $query->where('cop_models.model_name', 'like', '%' . $request->search . '%')
                        ->orWhere('cop_brands_ms.brand_name', 'like', '%' . $request->search . '%');
                })
                ->distinct()
                ->get();


            $inputType = ['Battery Capacity', 'Power (EV)', 'Range', 'Charging Time (AC)'];

            $su_data = Feature::leftJoin('cop_su_ms', 'cop_features_ms.su_id', '=', 'cop_su_ms.su_id')
                ->whereIn('cop_features_ms.features_name', $inputType)
                ->select('cop_su_ms.su_id', 'cop_su_ms.su_name', 'cop_features_ms.features_image', 'cop_features_ms.feature_id', 'cop_features_ms.features_name')
                ->orderBy(DB::raw("CASE
                                            WHEN cop_features_ms.features_name = 'Battery Capacity' THEN 1
                                            WHEN cop_features_ms.features_name = 'Range' THEN 2
                                            WHEN cop_features_ms.features_name = 'Power (EV)' THEN 3
                                            WHEN cop_features_ms.features_name = 'Charging Time (AC)' THEN 4
                                                                                      ELSE 6
                                        END"))
                ->get();


            // if ($evCar_models->isEmpty()) {
            //     return ResponseHelper::errorResponse(['No data available']);
            // }


            $format_data = $su_data->map(function ($item) {

                $feature = [
                    'su_id' => $item->su_id ?? NULL,
                    'feature_id' => $item->feature_id,
                    'features_name' => $item->features_name,
                    'su_name' => $item->su_name ?? NULL,
                    'features_image' =>  asset("Feature/{$item->feature_id}/{$item->features_image}") ?? NULL,
                ];
                return $feature;
            });



            $formattedData = $evCar_models->map(function ($item) {

                $data = [
                    'banner_id' => encrypt($item->banner_id),
                    'model_id' => encrypt($item->model_id),
                    'brand_name' => $item->brand_name,
                    'model_name' => $item->model_name,
                    'price' => $this->pricefilter($item->model_id),
                    // 'min_price' => $this->convertToLakhCrore($item->min_price),
                    // 'max_price' => $this->convertToLakhCrore($item->max_price),
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                    'Battery_Capacity' => $item->model_engine, // battery capacity
                    'Power' => $item->model_bhp, // Power
                    'Type_of_Transmission' => $item->model_transmission, //
                    'Range' => $item->model_mileage, // Power
                    'Charging_Time' => $item->model_fuel, //
                    'banner_image' => asset("Banner/{$item->banner_id}/{$item->banner_id}.webp"),

                ];
                return $data;
            });

            $combinedData = [
                'feature' => $format_data,
                'Ev_Car' => $formattedData,
            ];
            return ResponseHelper::responseMessage('success', $combinedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }

    public function bugdetformatModel($models, $power, $engine, $powerEV, $range, $wishlist)
    {
        // dd($power);
        $formattedData = $models->map(function ($item) use ($power, $engine, $powerEV, $range) {
            $powerDetails = $power->where('model_id', $item->model_id)->first();
            $engineDetails = $engine->where('model_id', $item->model_id)->first();
            $powerEVDetails = $powerEV->where('model_id', $item->model_id)->first();
            $rangeDetails = $range->where('model_id', $item->model_id)->first();
            //  dd($engineDetails);
            if ($powerDetails === null) {
                // dd("Power details are null for model name & ID: {$item->model_name} : {$item->model_id}");
            }

            if ($engineDetails === null) {
                // dd("Engine details are null for model name & ID: {$item->model_name} : {$item->model_id}");
            }

            // dd($powerDetails->feature_id);
            $feature_id = ($item->model_type == 0) ? (($powerDetails === null) ? '-' : $powerDetails->feature_id) : (($powerEVDetails === null) ? '-' : $powerEVDetails->feature_id);

            $feature_value = ($item->model_type == 0) ? (($powerDetails === null) ? '-' : $powerDetails->feature_value) : (($powerEVDetails === null) ? '-' : $powerEVDetails->feature_value);

            $su_name = ($item->model_type == 0) ? (($powerDetails === null) ? '-' : $powerDetails->su_name) : (($powerEVDetails === null) ? '-' : $powerEVDetails->su_name);


            $feature_iden = ($item->model_type == 0) ? (($engineDetails === null) ? '-' : $engineDetails->feature_id) : (($rangeDetails === null) ? '-' : $rangeDetails->feature_id);

            $feature_valueen = ($item->model_type == 0) ? (($engineDetails === null) ? '-' : $engineDetails->feature_value) : (($rangeDetails === null) ? '-' : $rangeDetails->feature_value);

            $su_nameen = ($item->model_type == 0) ? (($engineDetails === null) ? '-' : $engineDetails->su_name) : (($rangeDetails === null) ? '-' : $rangeDetails->su_name);


            $data = [
                'model_id' => encrypt($item->model_id),
                'car_stage' => $item->cs_name,
                'model_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp") ?? NULL,
                'launch_date' => $item->launch_date,
                'brand_name' => $item->brand_name,
                'model_name' => $item->model_name,
                'price' => $this->pricefilter($item->model_id),
                // 'min_price' => $this->convertToLakhCrore($item->min_price),
                // 'max_price' => $this->convertToLakhCrore($item->max_price),
                'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                'rating_type_name' => $item->rating_type_name ?? NULL,
                'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : NULL,
                'wishlist' => $item->wishlist,
                'power' => [
                    'feature_id' => $feature_id,
                    'features_image' =>  asset("Feature/{$feature_id}/{$feature_id}.svg") ?? NULL,
                    'feature_value' => $feature_value,
                    'su_name' => $su_name,
                ],
                'engine' => [
                    'feature_id' => $feature_iden,
                    'features_image' => asset("Feature/{$feature_iden}/{$feature_iden}.svg") ?? NULL,
                    'feature_value' => $feature_valueen,
                    'su_name' => $su_nameen,
                ],
            ];
            // dd($data);
            return $data;
        });

        return $formattedData;
    }


    public function budgetBy(Request $request)
    {
        try {


            $cityName = $request->input('cityname');


            if ($cityName == "" || $cityName == null) {
                $formattedData = ['cityname required'];
                return ResponseHelper::responseMessage('success', $formattedData);
            }

            $minPrice = $request->input('minprice');
            $maxPrice = $request->input('maxprice');

            $models = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->leftjoin('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                ->leftJoin('cop_city_ms', 'cop_pe_ms.city_id', '=', 'cop_city_ms.city_id')
                ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                ->select([
                    'cop_cs_ms.cs_id',
                    DB::raw('GROUP_CONCAT(DISTINCT cop_cs_ms.cs_name) as cs_name'),
                    'cop_models.model_id',
                    DB::raw('GROUP_CONCAT(DISTINCT cop_models.model_name) as model_name'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_models.model_name) as model_name'),
                    DB::raw('MAX(cop_models.min_price) as min_price'),
                    DB::raw('MAX(cop_models.max_price) as max_price'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_msd.model_engine) as model_engine'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_msd.model_bhp) as model_bhp'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_msd.model_transmission) as model_transmission'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_msd.model_mileage) as model_mileage'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_msd.model_fuel) as model_fuel'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_brands_ms.brand_id) as brand_id'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_brands_ms.brand_name) as brand_name'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_ratings.rating_id) as rating_id'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_ratings.rating_value) as rating_value'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_rating_types.rating_type_name) as rating_type_name'),
                    DB::raw('MAX(cop_pe_ms.ex_showroom_price) as ex_showroom_price'),
                    DB::raw('GROUP_CONCAT(DISTINCT cop_city_ms.city_name) as city_name'),
                ])
                ->where('cop_brands_ms.status', '=', 1)
                ->where('cop_models.status', '=', 1)
                ->where('cop_variants.status', '=', 1)
                ->where('cop_pe_ms.status', '=', 1)
                ->where('cop_city_ms.status', '=', 1)
                ->where('cop_models.model_type', '=', 0)
                ->where('cop_city_ms.city_name', '=', $cityName)
                ->where('cop_cs_ms.cs_name', '=', 'Launched')
                ->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice])
                ->groupBy('cop_models.model_id', 'cop_cs_ms.cs_id')
                ->distinct()
                ->limit(10)
                ->get();


            // if ($models->isEmpty()) {
            //     return ResponseHelper::errorResponse(['No data available']);
            // }
            $power = $this->getFeatureDetails('Power');
            $engine = $this->getFeatureDetails('Displacement');

            $powerEV = $this->getFeatureDetails('Power (EV)');
            // dd($powerEV);
            $range = $this->getFeatureDetails('Range');

            $responseArray = [];

            foreach ($models as $model) {



                $model->power = $powerEV->where('model_id', $model->model_id)->first();
                $model->range = $range->where('model_id', $model->model_id)->first();

                $model->power = $power->where('model_id', $model->model_id)->first();
                $model->engine = $engine->where('model_id', $model->model_id)->first();
                $wishlistGet = Wishlist::where('model_id', $model->model_id)
                    ->where('customer_id', Auth::guard('api')->id())
                    ->exists();

                // Set the wishlist property directly on the model object
                $model->wishlist = $wishlistGet ? true : false;

                $responseArray[] = $model;
            }
            $wishlist = [];

            $formattedData = $this->bugdetformatModel(collect($responseArray), $power, $engine, $powerEV, $range, $wishlist);


            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }

    public function Model(Request $request)
    {
        try {
            $model = Model::Select('cop_models.model_id', 'cop_models.model_name')->get();


            $formattedData = $model->map(function ($item) {
                return [

                    'model_id' => encrypt($item->model_id),
                    'model_name' => $item->model_name,

                ];
            });
            return ResponseHelper::responseMessage('success', $formattedData, "Successfully Data Get");
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }


    public function carModule(Request $request, $id)
    {

        // try {

        // dd($id);
        $modelname = $id;
        $cityName = $request->input('cityname');
        $key_main = 0;

        if ($cityName == "" || $cityName == null) {
            $formattedData = 'cityname required';
            return ResponseHelper::errorResponse('success', $formattedData);
        }

        $carModule = Model::join('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
            ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')

            ->join('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
            ->join('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
            ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
            ->join('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_pe_ms.city_id')

            ->select(
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_brands_ms.brand_logo',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_models.model_type',
                'cop_models.min_price',
                'cop_models.max_price',
                'cop_models.model_description',
                'cop_msd.model_engine',
                'cop_msd.model_bhp',
                'cop_msd.model_transmission',
                'cop_msd.model_mileage',
                'cop_msd.model_fuel',
                'cop_ratings.rating_id',
                'cop_ratings.rating_value',
                'cop_rating_types.rating_type_name',
                'cop_variants.*',
                'cop_pe_ms.ex_showroom_price',
                'cop_city_ms.city_id',
                'cop_city_ms.city_name',

            )
            ->where('cop_models.status', '=', 1)
            ->where('cop_variants.status', '=', 1)
            ->where('cop_models.model_name', '=', $modelname)
            ->where('cop_city_ms.city_name', $cityName)
            ->distinct('cop_models.model_id')
            ->get();


        if ($carModule->isEmpty()) {

            return ResponseHelper::responseMessage('success', $carModule);
        }


        foreach ($carModule as $item) {
            $modelname = $item->model_name;
            $variantId = $item->variant_id;
            $carGraphicTypeId = $item->gt_id;



            if (!isset($formattedData[$modelname])) {




                $formattedData[$modelname] = [
                    'brand_id' => encrypt($item->brand_id),
                    'model_id' => encrypt($item->model_id),
                    'brand_name' => $item->brand_name,
                    'model_name' => $item->model_name,
                    'brand_logo' => asset("brands/{$item->brand_id}/{$item->brand_id}.webp") ?? NULL,
                    'model_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp") ?? NULL,
                    'min_price' => $this->convertToLakhCrore($item->min_price),
                    'max_price' => $this->convertToLakhCrore($item->max_price),
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                    'model_engine' => $item->model_engine,
                    'model_bhp' => $item->model_bhp,
                    'model_description' => $item->model_description,
                    'model_transmission' => $item->model_transmission,
                    'model_mileage' => $item->model_mileage,
                    'model_fuel' => $item->model_fuel,
                    'rating_id' => $item->rating_id,
                    'rating_value' => $item->rating_value,
                    'rating_type_name' => $item->rating_type_name,
                    'variants' => [],
                    'car_graphic_type' => [],
                    'compare' => [],


                ];
            }


            //variants

            if ($item->model_type == 0) {
                $input_field = ['Displacement', 'Type of Transmission', 'Type of Fuel', 'Mileage', 'Power'];
            } else {
                $input_field = ['Battery Capacity', 'Type of Transmission', 'Range', 'Power (EV)', 'Charging Time (AC)'];
            }


            $feature_value = Variant::join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                ->select(
                    'cop_fv.feature_value',
                    'cop_features_ms.features_name',
                    'cop_su_ms.su_name'
                )
                ->where('cop_variants.variant_id', $item->variant_id)
                ->whereIn('cop_features_ms.features_name', $input_field)
                ->distinct()
                // ->toSql();
                // dd($feature_value);
                ->get();


            foreach ($feature_value as $features) {
                if ($features->features_name === 'Type of Transmission') {
                    $model_transmissions = $features->feature_value;
                }
                if ($features->features_name === 'Type of Fuel') {
                    $model_fuel = $features->feature_value;
                }
                if ($features->features_name === 'Displacement') {
                    $model_engine = $features->feature_value . ' ' . $features->su_name;
                }
                if ($features->features_name === 'Mileage') {
                    $model_mileage = $features->feature_value . ' ' . $features->su_name;
                }
                if ($features->features_name === 'Power') {
                    $model_power = $features->feature_value . ' ' . $features->su_name;
                }
                //ev car
                if ($features->features_name === 'Battery Capacity') {
                    $variant_battery = $features->feature_value . ' ' . $features->su_name;
                }

                if ($features->features_name === 'Range') {
                    $variant_range = $features->feature_value . ' ' . $features->su_name;
                }

                if ($features->features_name === 'Power (EV)') {
                    $variant_power_ev = $features->feature_value . ' ' . $features->su_name;
                }

                if ($features->features_name === 'Charging Time (AC)') {
                    $variant_charging = $features->feature_value . ' ' . $features->su_name;
                }
            }

            if (!isset($formattedData[$modelname]['variants'][$key_main])) {
                $featutres_key = 0;
                $formattedData[$modelname]['variants'][$key_main] = [
                    'variant_id' => encrypt($item->variant_id),
                    'variant_name' => $item->variant_name,
                    'variant_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_id}.webp") ?? NULL,
                    'ex_showroom_price' => $item->ex_showroom_price,
                    'location' => $cityName,
                    'seating_capacity' => $item->seating_capacity,
                    'type_of_transmission' => $model_transmissions ?? null,
                    'type_of_fuel' => $model_fuel ?? null,
                    'displacement' => $model_engine ?? null,
                    'mileage' => $model_mileage ?? null,
                    'power' => $model_power ?? null,
                    'battery' => $variant_battery ?? null,
                    'range' => $variant_range ?? null,
                    'power_ev' => $variant_power_ev ?? null,
                    'charging_time' => $variant_charging ?? null,
                    'colors' => [],
                    'specification_cat' => [],
                    'price_entry' => [],
                    'key_highlight' => [],
                ];
            }



            $model_transmissions = null;
            $model_fuel = null;
            $model_engine = null;
            $model_mileage = null;





            //end variants


            //compare start

            $Price = $item->min_price;

            $maxPrice = $Price + ($Price * 0.15);
            $minPrice = $Price - ($Price * 0.15);

            $compare = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                // ->leftJoin('cop_colors', 'cop_colors.model_id', '=', 'cop_models.model_id')


                ->select(
                    'cop_cs_ms.cs_id',
                    'cop_cs_ms.cs_name',
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_brands_ms.brand_logo',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_type',
                    'cop_models.min_price',
                    'cop_models.max_price',

                    DB::raw('(SELECT `variant_id` FROM `cop_variants` WHERE `cop_variants`.`model_id` = `cop_models`.`model_id` AND `cop_variants`.`status` = 1 LIMIT 1) AS variant_id')
                )
                ->where('cop_models.status', '=', 1)
                ->where('cop_models.min_price', '>', $minPrice)
                ->where('cop_models.min_price', '<', $maxPrice)
                ->where('cop_models.model_type', $item->model_type)
                ->where('cop_cs_ms.cs_name', "Launched")

                ->distinct()
                ->orderByRaw('CASE WHEN `cop_models`.`model_id` = ' . $item->model_id . '  THEN 0 ELSE 1 END')

                ->orderBy('cop_models.min_price', 'asc')
                ->groupBy('cop_models.model_id', 'cop_models.model_id', 'cop_cs_ms.cs_id', 'cop_cs_ms.cs_name')
                ->groupBy(
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_type',
                    'cop_models.min_price',
                    'cop_models.max_price',
                    'cop_cs_ms.cs_id',
                    'cop_cs_ms.cs_name',
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_brands_ms.brand_logo'
                )
                // dd($compare);
                ->get();

            // dd($compare);
            $formattedData[$modelname]['compare'] = [];

            $key_features = 0;
            foreach ($compare as $modelItem) {

                $formattedData[$modelname]['compare'][] = [

                    'cs_name' => encrypt($modelItem->cs_name),
                    'brand_name' => $modelItem->brand_name,
                    'model_id' => $modelItem->model_id,
                    'model_name' => $modelItem->model_name,
                    'model_type' => $modelItem->model_type == 0 ? 'Non EV' : 'EV',
                    'variant_id' => $modelItem->variant_id,
                    'model_image' => asset("brands/{$modelItem->brand_id}/{$modelItem->model_id}/{$modelItem->model_id}.webp") ?? NULL,
                    'ex_showroom' => $modelItem->min_price,
                    'features' => [],
                ];

                if ($modelItem->model_type == 0) {
                    $input_field = ['Displacement', 'Type of Transmission', 'Type of Fuel', 'Mileage', 'Power'];
                } else {
                    $input_field = ['Battery Capacity', 'Type of Transmission', 'Range', 'Power (EV)', 'Charging Time (AC)'];
                }


                $feature = Variant::join('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                    ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                    ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                    ->select(
                        'cop_fv.feature_value',
                        'cop_features_ms.features_name',
                        'cop_su_ms.su_name',
                        'cop_variants.variant_id',
                    )->where('cop_variants.variant_id', $modelItem->variant_id)
                    ->whereIn('cop_features_ms.features_name', $input_field)
                    ->distinct()

                    //   ->toSql();
                    //   dd($feature);
                    ->get();

                $formattedData[$modelname]['compare'][$key_features]['features'] = [];

                foreach ($feature as $feature_compare) {

                    if ($feature_compare->features_name === 'Type of Transmission') {
                        $variant_transmissions = $feature_compare->feature_value;
                    }
                    if ($feature_compare->features_name === 'Type of Fuel') {
                        $variant_fuel = $feature_compare->feature_value;
                    }
                    if ($feature_compare->features_name === 'Displacement') {
                        $variant_engine = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                    }
                    if ($feature_compare->features_name === 'Mileage') {
                        $variant_mileage = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                    }
                    if ($feature_compare->features_name === 'Power') {
                        $variant_power = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                    }
                    //ev car
                    if ($feature_compare->features_name === 'Battery Capacity') {
                        $variant_battery = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                    }

                    if ($feature_compare->features_name === 'Range') {
                        $variant_range = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                    }

                    if ($feature_compare->features_name === 'Power (EV)') {
                        $variant_power_ev = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                    }

                    if ($feature_compare->features_name === 'Charging Time (AC)') {
                        $variant_charging = $feature_compare->feature_value . ' ' . $feature_compare->su_name;
                    }
                }

                $formattedData[$modelname]['compare'][$key_features]['features'][] = [
                    // 'model_type' => $modelItem->model_type == 0 ? 'Non EV' : 'EV',
                    // 'variant_id' => $modelItem->variant_id,
                    // 'variant_name' => $feature_compare->variant_name,
                    'Transmission' => $variant_transmissions ?? null,
                    'Fuel' => $variant_fuel ?? null,
                    'Engine' => $variant_engine ?? null,
                    'Mileage' => $variant_mileage ?? null,
                    'Power' => $variant_power ?? null,
                    'Battery Capacity' => $variant_battery ?? null,
                    'Driving Range' => $variant_range ?? null,
                    'Power(Ev)' => $variant_power_ev ?? null,
                    'Charging Time(AC)' => $variant_charging ?? null,

                ];

                $key_features++;
            }




            $model_transmissions = null;
            $model_fuel = null;
            $model_engine = null;
            $model_mileage = null;
            // end compare model







            //key high lights

            if ($modelItem->model_type == 0) {
                $input_field = ['Displacement', 'Type of Transmission', 'Type of Fuel', 'Mileage', 'Power'];
            } else {
                $input_field = ['Battery Capacity', 'Type of Transmission', 'Range', 'Power (EV)', 'Charging Time (AC)'];
            }


            $feature = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')

                ->whereIn('cop_features_ms.features_name', $input_field)

                ->where('cop_fv.variant_id', '=', $item->variant_id)
                ->get();

            $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Specs'] = [];


            foreach ($feature as $key_spec) {

                $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Specs'][] = [

                    'features_name' => $key_spec->features_name,
                    'features_image' => asset("Feature/{$key_spec->feature_id}/{$key_spec->feature_id}.svg") ?? NULL,
                    'features_value' => $key_spec->feature_value,
                    'su_name' => $key_spec->su_name,


                ];
            }

            $inputType = ['Parking Sensors', 'No Of Airbags', 'Anti Lock Braking System', 'Hill Assist', 'Child Safety Locks'];

            $feature = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')


                ->whereIn('cop_features_ms.features_name', $inputType)
                ->where('cop_fv.variant_id', '=', $item->variant_id)
                ->get();


            $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Safety'] = [];


            foreach ($feature as $key_sefety) {

                $formattedData[$modelname]['variants'][$key_main]['key_highlight']['Key_Safety'][] = [

                    'features_name' => $key_sefety->features_name,
                    'features_image' => asset("Feature/{$key_sefety->feature_id}/{$key_sefety->feature_id}.svg") ?? NULL,
                    'features_value' => $key_sefety->feature_value,
                    'su_name' => $key_sefety->su_name,


                ];
            }



            // end key high lights


            //price entry

            $price_entry = PriceEntry::select(
                'cop_pe_ms.*',
                'cop_brands_ms.brand_name as brand_name',
                'cop_models.model_name as model_name',
                'cop_variants.variant_name as variant_name',
                'cop_city_ms.city_name as city_name',
                'cop_state_ms.state_name as state_name',
                'cop_country_ms.country_name as country_name',
                'cop_taxes_ms.tax_name as tax_name',
                // 'cop_ut.ut_name as ut_name',
            )

                ->leftJoin('cop_brands_ms', 'cop_pe_ms.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_models', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_variants', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')

                ->leftJoin('cop_city_ms', 'cop_pe_ms.city_id', '=', 'cop_city_ms.city_id')
                ->leftJoin('cop_state_ms', 'cop_pe_ms.state_id', '=', 'cop_state_ms.state_id')
                ->leftJoin('cop_country_ms', 'cop_pe_ms.country_id', '=', 'cop_country_ms.country_id')
                ->leftJoin('cop_taxes_ms', 'cop_pe_ms.tax_id', '=', 'cop_taxes_ms.tax_id')
                // ->leftJoin('cop_ut', 'cop_pe_ms.ut_id', '=', 'cop_ut.ut_id')
                ->where('cop_pe_ms.status', 1)
                ->where('cop_variants.variant_id', $item->variant_id)
                ->where('cop_city_ms.city_name', $cityName);


            $price_entry = $price_entry->get();

            $formattedData[$modelname]['variants'][$key_main]['price_entry'];

            foreach ($price_entry as $priceItem) {

                $taxNames = \App\Models\AllTax::whereIn('tax_id', json_decode($priceItem->tax_id, true))
                    ->select('tax_id', 'tax_name')
                    ->get();

                $taxCosts = json_decode($priceItem->tax_cost, true);

                $taxInfo = [];
                foreach ($taxNames as $taxName) {
                    $taxId = $taxName->tax_id;
                    $taxInfo[] = [
                        'tax_id' => $taxId,
                        'tax_name' => $taxName->tax_name,
                        'cost' => isset($taxCosts[$taxId]) ? (int)$taxCosts[$taxId] : null,

                    ];
                }


                $formattedData[$modelname]['variants'][$key_main]['price_entry'] = [



                    'price_entry_id' => $priceItem->pe_id,
                    'variant_id' => $priceItem->variant_id,
                    'variant_name' => $priceItem->variant_name,
                    'country_name' => $priceItem->country_name,
                    'state_name' => $priceItem->state_name,
                    'city_name' => $priceItem->city_name,
                    // 'ut_name' => $priceItem->ut_name,
                    'ex_showroom_price' => $priceItem->ex_showroom_price,
                    'tax_name' => $taxInfo,
                    'total_price' => $priceItem->total_price,
                ];
            }

            //price entry end

            $colorData = Color::select(
                'cop_colors.color_id',
                'cop_colors.color_name',
                'cop_colors.color_code',
                'cop_colors.dual_color_code',
                'cop_colors.variant_color_image',
                'cop_colors.variant_id',
            )
                ->where('cop_colors.variant_id', '=', $item->variant_id)
                ->distinct()
                ->get();

            $formattedData[$modelname]['variants'][$key_main]['colors'] = [];

            foreach ($colorData as $colorItem) {
                $formattedData[$modelname]['variants'][$key_main]['colors'][] = [
                    'color_id' => encrypt($colorItem->color_id),
                    'variant_id' => encrypt($colorItem->variant_id),
                    'color_name' => $colorItem->color_name,
                    'color_code' => $colorItem->color_code,
                    'dual_color_code' => $colorItem->dual_color_code ?? null,
                    'variant_color_image' => $colorItem->variant_color_image,
                    'variant_color_image_path' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$colorItem->variant_color_image}") ?? null,
                ];
            }

            $specificationCategory = SpecificationCategory::all();

            $formattedData[$modelname]['variants'][$key_main]['specification_cat'] = [];

            $key_spec_cat = 0;
            foreach ($specificationCategory as $specItem) {
                $formattedData[$modelname]['variants'][$key_main]['specification_cat'][] = [
                    'sc_id' => $specItem->sc_id,
                    'spec_cat_name' => $specItem->sc_name,
                ];

                $spec_cat = Specification::join('cop_sc_ms', 'cop_sc_ms.sc_id', '=', 'cop_spec_ms.sc_id')->where('cop_sc_ms.sc_name', $specItem->sc_name)->get();

                $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'] = [];

                $key_spec = 0;
                foreach ($spec_cat as $spec) {
                    $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'][] = [
                        'spec_id' => $spec->spec_id,
                        'spec_name' => $spec->spec_name,
                        // 'spec_image' => $spec->spec_image,
                        'spec_image' => asset("Specification/{$spec->spec_id}/{$spec->spec_id}.svg") ?? NULL,
                    ];

                    $feature = Feature::join('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->join('cop_models', 'cop_models.model_id', '=', 'cop_fv.model_id')
                        ->leftJoin('cop_su_ms', 'cop_su_ms.su_id', '=', 'cop_features_ms.su_id')
                        ->where('cop_features_ms.spec_id', '=', $spec->spec_id)
                        ->where('cop_fv.variant_id', '=', $item->variant_id)
                        ->where('cop_models.model_type', '=', $item->model_type)
                        ->get();


                    $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'][$key_spec]['features'] = [];

                    foreach ($feature as $featureItem) {

                        $formattedData[$modelname]['variants'][$key_main]['specification_cat'][$key_spec_cat]['spec'][$key_spec]['features'][] = [
                            'features_name' => $featureItem->features_name,
                            'feature_value' => $featureItem->feature_value,
                            'su_name' => $featureItem->su_name,

                        ];
                    }
                    $key_spec++;
                }
                $key_spec_cat++;
            }





            $graphicData = CarGraphic::select(
                'cop_graphics.model_id',
                'cop_graphics.graphic_file',
                'cop_gt_ms.gt_name',
                'cop_gt_ms.gt_id',
            )
                ->leftJoin('cop_gt_ms', 'cop_gt_ms.gt_id', '=', 'cop_graphics.gt_id')
                ->where('cop_graphics.model_id', '=', $item->model_id)
                ->distinct()
                ->get();

            $formattedData[$modelname]['car_graphic_type'] = [];
            $key_graphic = 0;
            foreach ($graphicData as $graphicItem) {
                $abc = [
                    'model_id' => encrypt($graphicItem->model_id),
                    'car_graphic_type_id' => encrypt($graphicItem->gt_id),
                    'car_graphic_type_name' => $graphicItem->gt_name
                ];


                if ($graphicItem->gt_name == "Images") {
                    $single_image = explode(',', $graphicItem->graphic_file);
                    $arr = [];
                    for ($i = 0; $i < count($single_image); $i++) {
                        $arr[] = asset("car_graphics/{$graphicItem->model_id}/images/{$single_image[$i]}");
                    }
                    $abc['car_graphic_images'] = $arr;
                }

                if ($graphicItem->gt_name == "Images 360") {
                    $single_image_360 = explode(',', $graphicItem->graphic_file);

                    $arr = [];
                    for ($i = 0; $i < count($single_image_360); $i++) {
                        $arr[] = asset("car_graphics/{$graphicItem->model_id}/360_images/{$single_image_360[$i]}");
                    }
                    $abc['car_graphic_images_360'] = $arr;
                }

                if ($graphicItem->gt_name == "Video") {
                    $abc['car_graphic_video'] = asset("car_graphics/{$graphicItem->model_id}/videos/{$graphicItem->graphic_file}");
                }
                $formattedData[$modelname]['car_graphic_type'][$key_graphic] = $abc;

                $key_graphic++;
            }


            $key_main++;
        }

        // if ($carModule->isEmpty()) {
        //     return ResponseHelper::errorResponse(['No data available']);
        // }

        $formattedData = array_values($formattedData);



        return ResponseHelper::responseMessage('success', $formattedData);
        // } catch (Exception $e) {
        //     // dd($e->getMessage());
        //     return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        // }
    }








    public function upComingCar(Request $request)
    {
        try {

            $min_Price = $request->minprice;
            $max_Price = $request->maxprice;

            $currentDate = now()->toDateString();

            //brand by

            $modelCounts = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                ->select('cop_models.brand_id', 'cop_brands_ms.brand_name', DB::raw('COUNT(*) as model_count'))
                ->where('cop_cs_ms.cs_name', '=', 'Upcoming')
                ->where('cop_models.launch_date', '>', $currentDate)
                ->groupBy('cop_models.brand_id', 'cop_brands_ms.brand_name');


            if ($request->has('minprice')) {
                $modelCounts->where('cop_models.min_price', '>=', $min_Price);
            }

            if ($request->has('maxprice')) {
                $modelCounts->where('cop_models.max_price', '<=', $max_Price);
            }

            // if ($request->has('brand_id') && !empty($request->input('brand_id'))) {
            //     $brandId = $request->input('brand_id');
            //     $modelCounts->where('cop_models.brand_id', '=', $brandId);
            // }
            $modelscount = $modelCounts->distinct()->get();
            if ($request->has('ct_name') && !empty($request->input('ct_name'))) {
                $ct_name = explode(',', $request->input('ct_name'));
                $modelCounts->whereIn('cop_ct_ms.ct_name', $ct_name);
            }

            if ($request->has('month')) {
                $monthsAhead = (int) $request->input('month');

                if ($monthsAhead > 0) {
                    $currentMonth = now();
                    $endDate = $currentMonth->copy()->addMonths($monthsAhead)->startOfMonth()->subDay(); // Adjusted this line

                    $modelCounts->whereDate('cop_models.launch_date', '>=', $currentMonth)
                        ->whereDate('cop_models.launch_date', '<=', $endDate);
                } else {

                    return response()->json(['error' => 'Invalid value for month parameter'], 400);
                }
            }


            $modelscount = $modelCounts->distinct()->get();
            /// end brand counts

            // start car type


            $cartypeCounts = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                ->select('cop_models.ct_id', 'cop_ct_ms.ct_name', 'cop_ct_ms.ct_image', 'cop_brands_ms.brand_id', DB::raw('COUNT(*) as model_count'))
                ->where('cop_cs_ms.cs_name', '=', 'Upcoming')
                ->groupBy('cop_models.ct_id', 'cop_ct_ms.ct_name', 'cop_brands_ms.brand_id', 'cop_ct_ms.ct_image');
            // ->get();

            if ($request->has('minprice') && !empty($min_Price)) {
                $cartypeCounts->where('cop_models.min_price', '>=', $min_Price);
            }

            if ($request->has('maxprice') && !empty($max_Price)) {
                $cartypeCounts->where('cop_models.max_price', '<=', $max_Price);
            }


            // if ($request->has('ct_id') && !empty($request->input('ct_id'))) {
            //     $ct_id = explode(',', $request->input('ct_id'));
            //     $cartypeCounts->whereIn('cop_ct_ms.ct_id', $ct_id);
            // }
            // $cartype_counts = $cartypeCounts->distinct()->get();

            if ($request->has('brand_name') && !empty($request->input('brand_name'))) {
                $brand_name = explode(',', $request->input('brand_name'));
                $cartypeCounts->whereIn('cop_brands_ms.brand_name', $brand_name);
            }


            if ($request->has('month')) {
                $monthsAhead = (int) $request->input('month');

                if ($monthsAhead > 0) {
                    $currentMonth = now();
                    $endDate = $currentMonth->copy()->addMonths($monthsAhead)->startOfMonth()->subDay(); // Adjusted this line

                    $cartypeCounts->whereDate('cop_models.launch_date', '>=', $currentMonth)
                        ->whereDate('cop_models.launch_date', '<=', $endDate);
                } else {

                    return response()->json(['error' => 'Invalid value for month parameter'], 400);
                }
            }

            $cartype_counts = $cartypeCounts->distinct()->get();

            $groupedData = $cartype_counts->groupBy('ct_name');


            $aggregatedModelCounts = [];


            foreach ($groupedData as $brandName => $models) {
                $aggregatedModelCounts[] = [
                    'ct_id' => $models[0]->ct_id,
                    // 'ct_image' => $models[0]->ct_image,
                    'ct_image' => asset("car_types/{$models[0]->ct_id}/{$models[0]->ct_id}.svg"),
                    'ct_name' => $brandName,
                    'model_count' => $models->sum('model_count'),
                ];
            }




            /// end car type


            // price


            $price_counts = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                ->selectRaw('
        CASE
            WHEN ( (cop_models.min_price >= 200000 AND cop_models.min_price < 1000000) And (`cop_models`.`max_price` BETWEEN 200000 AND 1000000)) THEN "200000 - 1000000"
            WHEN ( (cop_models.min_price >= 1000000 AND cop_models.min_price < 2500000) And (`cop_models`.`max_price` BETWEEN 1000000 AND 2500000)) THEN "1000000 - 2500000"
            WHEN ( (cop_models.min_price >= 2500000 AND cop_models.min_price < 5000000) AND (`cop_models`.`max_price` BETWEEN 2500000 AND 5000000) ) THEN "2500000 - 5000000"
            WHEN ( (cop_models.min_price >= 5000000 AND cop_models.min_price < 10000000) AND (`cop_models`.`max_price` BETWEEN 5000000 AND 10000000) ) THEN "5000000 - 10000000"
            WHEN ( (cop_models.min_price > 10000000) ) THEN "10000000+"
        END AS price_range,
        COUNT(*) AS model_count
    ')
                ->where('cop_cs_ms.cs_name', '=', 'Upcoming')

                ->groupBy('price_range')

                ->orderByRaw("FIELD(price_range, '200000 - 1000000', '1000000 - 2500000', '2500000 - 5000000', '5000000 - 10000000', '10000000+')");


            // if ($request->has('minprice') && !empty($min_Price)) {
            //     $price_counts->where('cop_models.min_price', '>=', $min_Price);
            // }

            // if ($request->has('maxprice') && !empty($max_Price)) {
            //     $price_counts->where('cop_models.max_price', '<=', $max_Price);
            // }
            if ($request->has('ct_name') && !empty($request->input('ct_name'))) {
                $ct_name = explode(',', $request->input('ct_name'));
                $price_counts->whereIn('cop_ct_ms.ct_name', $ct_name);
            }

            if ($request->has('brand_name') && !empty($request->input('brand_name'))) {
                $brand_name = explode(',', $request->input('brand_name'));
                $price_counts->whereIn('cop_brands_ms.brand_name', $brand_name);
            }

            if ($request->has('month')) {
                $monthsAhead = (int) $request->input('month');

                if ($monthsAhead > 0) {
                    $currentMonth = now();
                    $endDate = $currentMonth->copy()->addMonths($monthsAhead)->startOfMonth()->subDay(); // Adjusted this line

                    $price_counts->whereDate('cop_models.launch_date', '>=', $currentMonth)
                        ->whereDate('cop_models.launch_date', '<=', $endDate);
                } else {

                    return response()->json(['error' => 'Invalid value for month parameter'], 400);
                }
            }


            $price_count = $price_counts->get();



            $show_prices = []; // Initialize an array to store all price range data

            foreach ($price_count as $price) {
                switch ($price->price_range) {
                    case "200000 - 1000000":
                        $show_keyword = "2 - 10 lakh";
                        break;
                    case "1000000 - 2500000":
                        $show_keyword = "10 - 25 lakh";
                        break;
                    case "2500000 - 5000000":
                        $show_keyword = "25 - 50 lakh";
                        break;
                    case "5000000 - 10000000":
                        $show_keyword = "50 lakh  - 1 crore";
                        break;
                    case "10000000 - 990000000":
                        $show_keyword = "1 Cr+";
                        break;
                    default:
                        $show_keyword = "Unknown";
                }

                $show_prices[] = [
                    "price_range" => $price->price_range,
                    "model_count" => $price->model_count,
                    "show_keyword" => $show_keyword
                ];
            }


            // dd( $price_count);
            /// end price

            $currentDate = now()->toDateString();
            $upcomingModel = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                ->select(
                    'cop_brands_ms.brand_id',
                    'cop_models.model_id',
                    'cop_ct_ms.ct_id',
                    'cop_ct_ms.ct_name',
                    'cop_ct_ms.ct_image',
                    'cop_brands_ms.brand_name',
                    'cop_models.model_name',
                    'cop_models.launch_date',
                    'cop_cs_ms.cs_name',
                    'cop_models.model_image',
                    'cop_models.min_price',
                    'cop_models.max_price',
                    'cop_models.model_type',
                )
                ->where('cop_cs_ms.cs_name', '=', 'Upcoming')
                ->where('cop_models.launch_date', '>', $currentDate);

            if ($request->has('month')) {
                $monthsAhead = (int) $request->input('month');

                if ($monthsAhead > 0) {
                    $currentMonth = now();
                    $endDate = $currentMonth->copy()->addMonths($monthsAhead)->startOfMonth()->subDay();

                    $upcomingModel->whereDate('cop_models.launch_date', '>=', $currentMonth)
                        ->whereDate('cop_models.launch_date', '<=', $endDate);
                } else {

                    return response()->json(['error' => 'Invalid value for month parameter'], 400);
                }
            }

            if ($request->has('brand_name') && !empty($request->input('brand_name'))) {

                $brand_name = explode(',', $request->input('brand_name'));
                $upcomingModel->whereIn('cop_brands_ms.brand_name', $brand_name);
            }

            if ($request->has('ct_name') && !empty($request->input('ct_name'))) {
                $ct_name = explode(',', $request->input('ct_name'));
                $upcomingModel->whereIn('cop_ct_ms.ct_name', $ct_name);
            }

            if (!empty($min_Price) && !empty($max_Price)) {

                $upcomingModel->where('cop_models.min_price', '>=', $min_Price)
                    ->where('cop_models.max_price', '<=', $max_Price);
            }

            $models = $upcomingModel->distinct()->get();
            // if ($models->isEmpty()) {
            //     return ResponseHelper::errorResponse(['No data available']);
            // }



            $formattedData = $models->map(function ($item) {
                return [

                    'brand_id' => encrypt($item->brand_id),
                    'ct_id' => encrypt($item->ct_id),
                    'ct_name' => $item->ct_name,
                    'ct_image' => asset("car_types/{$item->ct_id}/{$item->ct_id}.svg"),
                    'brand_name' => $item->brand_name,
                    'model_name' => $item->model_name,
                    'launch_date' => date('d M, Y', strtotime($item->launch_date)),
                    'model_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp") ?? NULL,
                    'min_price' => $this->convertToLakhCrore($item->min_price),
                    'max_price' => $this->convertToLakhCrore($item->max_price),
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                ];
            });


            $combineData = [
                'brand' => $modelscount,
                'cartype' => $aggregatedModelCounts,
                'price_counts' => $show_prices,
            ];


            $responseData = [
                'countdata' => $combineData,
                'upcoming_model' => $formattedData,
            ];

            return ResponseHelper::responseMessage('success', $responseData, "Successfuly Data Get");
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }


    public function allModel()
    {
        try {
            $all_models = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', 'cop_models.brand_id')
                ->select('cop_brands_ms.brand_id', 'cop_brands_ms.status', 'model_name', 'model_id')
                ->where('cop_models.status', '=', 1)
                ->where('cop_brands_ms.status', '=', 1)
                ->where('cop_cs_ms.cs_name', '!=', 'Upcoming')
                ->get();

            if ($all_models->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }

            $result = [];

            foreach ($all_models as $model) {
                $brand_name = Brand::where('brand_id', $model->brand_id)->value('brand_name');

                $variants = Variant::where('model_id', $model->model_id)
                    ->where('cop_variants.status', '=', 1)->get();

                $variant_data = [];

                foreach ($variants as $variant) {
                    $priceEntry = PriceEntry::where('variant_id', $variant->variant_id)
                        ->where('cop_pe_ms.status', '=', 1)
                        ->first();
                    if ($priceEntry) {
                        $variant_data[] = [
                            'variant_id' => encrypt($variant->variant_id),
                            'variant_name' => $variant->variant_name,
                        ];
                    }
                }

                $model_data = [
                    'model_id' => encrypt($model->model_id),
                    'model_name' => $model->model_name,
                    'variants' => $variant_data,
                ];

                if (!isset($result[$brand_name])) {
                    $result[$brand_name] = [
                        'brand_id' => encrypt($model->brand_id),
                        'brand_name' => $brand_name,
                        'models' => [],
                    ];
                }

                $result[$brand_name]['models'][] = $model_data;
            }


            $result = array_values($result);

            return ResponseHelper::responseMessage('success', $result, "Successfully Data Get");
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }






    private function convertToLakhCrore($price)
    {
        if ($price >= 10000000) {
            return number_format($price / 10000000, 2) . ' Cr';
        } elseif ($price >= 100000) {
            return number_format($price / 100000, 2) . ' Lakh';
        } else {
            return $price;
        }
    }
}
