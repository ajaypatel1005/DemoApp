<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Country;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;

class CountryApiController extends Controller
{
    public function index()
    {
        try {
            // $country = Country::all();
            $country = Country::where('status', '=', 1)->get();


            if ($country->isEmpty()) {
                // return ResponseHelper::errorResponse(['No data available']);
                return ResponseHelper::errorResponse('success', 'No data available!!');
            }

            $countryData = $country->map(function ($item) {


                $data = [
                    'country_id ' => encrypt($item->country_id),
                    'country_name' => $item->country_name,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $countryData);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse(['Something went wrong!!']);
            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
