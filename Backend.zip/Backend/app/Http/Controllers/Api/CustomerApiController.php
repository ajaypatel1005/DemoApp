<?php

namespace App\Http\Controllers\Api;

use App\Models\Customer;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
// use Kreait\Firebase\Auth;
use Illuminate\Support\Facades\Validator;
use Tymon\JWTAuth\Facades\JWTAuth;
use Carbon\Carbon;
use App\Http\Controllers\Helpers\ResponseHelper;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Validation\ValidationException;

class CustomerApiController extends Controller
{

    public function registerCustomer(Request $request)
    {
        $customer = Customer::where('contact_no', $request->contact_no)
        ->first();

        if (!$customer) {
            
            $validator = Validator::make($request->all(), [
                // 'first_name' => 'required',
                // 'last_name' => 'required',
                // 'email' => 'required|email',
                'contact_no' => 'required|max:13|',
            ]);

            if ($validator->fails()) {
                return ResponseHelper::errorResponse($validator->errors()->all(), 'Please fill Contect Number required fields');
            }

            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                // 'last_name' => 'required',
                // 'email' => 'required|email',
                // 'contact_no' => 'required',
            ]);

            if ($validator->fails()) {
                return ResponseHelper::errorResponse($validator->errors()->all(), 'Please fill First Name required fields');
            }
            $validator = Validator::make($request->all(), [
                // 'first_name' => 'required',
                'last_name' => 'required',
                // 'email' => 'required|email',
                // 'contact_no' => 'required',
            ]);

            if ($validator->fails()) {
                return ResponseHelper::errorResponse($validator->errors()->all(), 'Please fill Last Name required fields');
            }
            $validator = Validator::make($request->all(), [
                // 'first_name' => 'required',
                // 'last_name' => 'required',
                'email' => 'required|email',
                // 'contact_no' => 'required',
            ]);

            if ($validator->fails()) {
                return ResponseHelper::errorResponse($validator->errors()->all(), 'Please fill Email required fields');
            }


            $customer = new Customer();
            $customer->first_name = $request->first_name;
            $customer->last_name = $request->last_name;
            $customer->email = $request->email;
            $customer->contact_no = $request->contact_no;
            $customer->save();
            $message = 'Customer registered successfully';
        } else {
            $validator = Validator::make($request->all(), [
                'contact_no' => 'required',
            ]);
            if ($validator->fails()) {
                return ResponseHelper::errorResponse($validator->errors()->all(), 'Please fill in all required fields');
            }
            $message = 'Customer login successfully';
        }
        $accessToken = $customer->createToken('authToken', ['*'], Carbon::now()->addDays(15))->accessToken;
        $formattedData = [
            'message' => $message,
            'token' => $accessToken,
            'login_status' => !$customer->wasRecentlyCreated,
            'contact_no' => $customer->contact_no,
            'first_name' => $customer->first_name,
            'last_name' => $customer->last_name,
            'address_1'=>$customer->address_1,
            'address_2'=>$customer->address_2,
            'email' => $customer->email,
        ];

        return ResponseHelper::responseMessage('success', $formattedData);
    }

    public function updateCustomer(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'contact_no' => 'required | string |regex:/^\+91[0-9]{10}$/',
                'first_name' => 'nullable|string',
                'last_name' => 'nullable|string',
                'email' => 'nullable|email',
                'address_1' => 'nullable|string',
                'address_2' => 'nullable|string',
                'profile_pic' => 'nullable|image|max:2048'
            ]);
            $customer_id = Auth::guard('api')->id();

            $customer = Customer::where('customer_id', $customer_id)->firstOrFail();

            if ($request->hasFile('profile_pic') && $customer->profile_pic) {
                $oldImagePath = public_path('Customer_Profile_Pic/' . $customer->profile_pic);
                if (File::exists($oldImagePath)) {
                    File::delete($oldImagePath);
                }
            }
            $customer->update($validatedData);

            if ($request->hasFile('profile_pic')) {
                $image = $request->file('profile_pic');
                $imageName = time() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('Customer_Profile_Pic'), $imageName);
                $customer->profile_pic = $imageName;
                $customer->save();
            }
            return ResponseHelper::responseMessage('success', 'Customer information updated successfully');
        } catch (ValidationException $e) {
            $errors = $e->validator->errors()->messages();
            return ResponseHelper::errorResponse('error', $errors);
        } catch (\Exception $e) {
            return ResponseHelper::errorResponse('error', 'Something went wrong!!');
        }
    }

    
}