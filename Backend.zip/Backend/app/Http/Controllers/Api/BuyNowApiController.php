<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BuyNow;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Helpers\ResponseHelper;

class BuyNowApiController extends Controller
{



    public function index(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'customer_id' => 'required',
            'model_id' => 'required',
            'variant_id' => 'required',
            'price_id' => 'required',
            'manager_id' => 'required',
            'city_id' => 'required',
        ]);

        if ($validator->fails()) {
            return ResponseHelper::errorResponse($validator->errors()->all(), 'Please fill in all required fields');
        }

        // dd($request->all());
        $addbuyNow = new BuyNow();
        $addbuyNow->customer_id = $request->customer_id;
        $addbuyNow->model_id = $request->model_id;
        $addbuyNow->variant_id = $request->variant_id;
        $addbuyNow->price_id = $request->price_id;
        $addbuyNow->manager_id = $request->manager_id;
        $addbuyNow->city_id = $request->city_id;

        $addbuyNow->save();
        return ResponseHelper::responseMessage('success', $addbuyNow, 'Car Buy Successfully !! ');
    }
}
