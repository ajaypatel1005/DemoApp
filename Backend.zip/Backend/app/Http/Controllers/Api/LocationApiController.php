<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AllTax;
use Exception;
use App\Traits\LocationTrait;
use App\Http\Controllers\Helpers\ResponseHelper;

class LocationApiController extends Controller
{
    use LocationTrait;
    public function index(Request $request)
    {
        $location = $this->getCurrentLocation($request);

 return response()->json(['location' => $location]);
  


    }
}
