<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Variant;
use Illuminate\Support\Facades\File;
use Exception;

class VariantApiController extends Controller
{
    public function variant()
    {
        try {
            $variants = Variant::select(
                'cop_variants.*',
                'cop_brands_ms.brand_name as brand_name',
                'cop_models.model_name as model_name',
                'cop_colors.color_name',
                'cop_colors.color_code',
                'cop_colors.dual_color_code',
                'cop_colors.variant_color_image'
            )
                ->leftJoin('cop_brands_ms', 'cop_variants.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_models', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_colors', 'cop_variants.variant_id', '=', 'cop_colors.variant_id')
                ->where('cop_variants.status', '!=', 0) // Filter out banners with status 0
                ->get();

            $variantsData = $variants->map(function ($item) {
                //                variant_image
                $imagePath = public_path("brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_id}.webp");
                $variantImage = File::exists($imagePath) ? asset("brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_id}.webp") : null;
                //                variant_color_image
                $imagePath = public_path("brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_color_image}");
                $variantCImage = File::exists($imagePath) ? asset("brands/{$item->brand_id}/{$item->model_id}/{$item->variant_id}/{$item->variant_color_image}") : null;

                return [
                    'variant_id' => $item->variant_id,
                    'brand_name' => $item->brand_name,
                    'model_name' => $item->model_name,
                    'variant_name' => $item->variant_name,
                    'variant_image' => $variantImage,
                    'seating_capacity' => $item->seating_capacity,
                    'color_name' => $item->color_name,
                    'color_code' => $item->color_code,
                    'dual_color_code' => $item->dual_color_code,
                    'variant_color_image' => $variantCImage,
                ];
            });

            return ResponseHelper::responseMessage('success', $variantsData, "Successfuly Data Get");
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse(['Something went wrong!!']);
            return ResponseHelper::errorResponse('success','Something went wrong!!');
        }
    }
}
