<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CarType;
use App\Models\FeatureValue;
use App\Models\Model;
use Illuminate\Support\Facades\DB;
use Exception;

class AdvancedSearchApiController extends Controller
{


    private function pricefilter($model_id)
    {
        $priceMinMax = Model::select(
            DB::raw('MIN(cop_pe_ms.ex_showroom_price) as min_ex_showroom_price'),
            DB::raw('MAX(cop_pe_ms.ex_showroom_price) as max_ex_showroom_price')
        )
            ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            ->where('cop_models.model_id', $model_id)
            ->where('cop_models.model_type', '0')
            ->first();

        return [
            'price_filter' => $priceMinMax['min_ex_showroom_price'],
            'min_ex_showroom_price' => $this->convertToLakhCrore($priceMinMax['min_ex_showroom_price']),
            'max_ex_showroom_price' => $this->convertToLakhCrore($priceMinMax['max_ex_showroom_price']),
        ];
    }


    public function index(Request $request)
    {

        $minPrice = $request->input('minprice');
        $maxPrice = $request->input('maxprice');
        $brandName = $request->filled('brand_name') ? explode(',', trim($request->input('brand_name'))) : [];
        $ct_name = $request->filled('ct_name') ? explode(',', trim($request->input('ct_name'))) : [];
        $fuelType = $request->filled('fuel_type') ? explode(',', trim($request->input('fuel_type'))) : ['Petrol', 'Diesel', 'Petrol-CNG', 'Hybrid'];
        $engineCapacity = $request->input('engine_type');
        $transmissionType = $request->filled('transmission_type') ? [$request->input('transmission_type')] : ['Automatic', 'Manual'];
        $driveTrain = $request->filled('drivetrain') ? explode(',', trim($request->input('drivetrain'))) : [];
        $safetyFeatures = $request->filled('safetyfeature') ? explode(',', trim($request->input('safetyfeature'))) : [];
        $interiorFeatures = $request->filled('interiorfeature') ? explode(',', trim($request->input('interiorfeature'))) : [];
        $exteriorFeatures = $request->filled('exteriorfeature') ? explode(',', trim($request->input('exteriorfeature'))) : [];

        try {
            //car model card data

            $fvModel = FeatureValue::join('cop_models', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_fv.brand_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')

                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftJoin('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
                ->select(
                    'cop_brands_ms.brand_id',
                    'cop_brands_ms.brand_name',
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_models.model_image',
                    'cop_models.min_price',
                    'cop_models.max_price',

                    DB::raw('MIN(cop_pe_ms.ex_showroom_price) AS min_ex_showroom_price'),
                    DB::raw('MAX(cop_pe_ms.ex_showroom_price) AS max_ex_showroom_price'),
                    'cop_ratings.rating_value',
                    'cop_rating_types.rating_type_name',
                );

            if (!empty($minPrice) && !empty($maxPrice)) {

                $fvModel->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $fvModel->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $fvModel->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $fvModel->whereIn('cop_fv.model_id', function ($fvModel) use ($fuelType) {
                    $fvModel->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $fvModel->whereIn('cop_fv.model_id', function ($fvModel) use ($transmissionType) {
                    $fvModel->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $fvModel->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->leftJoin('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            // dd($explodeEngineCapacity);
                            foreach ($explodeEngineCapacity as $range) {

                                $result = explode('-', $range);

                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                // dd(  $toEngine );
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [(int)$fromEngine, (int)$toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [(int)$fromEngine, (int)$toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }
            if (!empty($driveTrain)) {
                $fvModel->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }
            if (!empty($safetyFeatures)) {
                $fvModel->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }
            if (!empty($interiorFeatures)) {
                $fvModel->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }
            if (!empty($exteriorFeatures)) {
                $fvModel->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }
            $models = $fvModel->groupBy(
                'cop_fv.model_id',
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_models.model_id',
                'cop_models.model_name',
                'cop_models.model_image',
                'cop_models.min_price',
                'cop_models.max_price',
                'cop_ratings.rating_value',
                'cop_rating_types.rating_type_name',

            )->distinct()
                ->get();
            // dd($models->get()->count());
            $responseCardData = $models->map(function ($item) {
                return
                    $data['modelcard'] = [
                        'brand_id' => encrypt($item->brand_id),
                        'brand_name' => $item->brand_name,
                        'model_id' => encrypt($item->model_id),
                        'model_name' => $item->model_name,
                        'model_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->model_image}") ?? "",
                        // 'min_price' => $this->convertToLakhCrore($item->min_price),
                        // 'max_price' => $this->convertToLakhCrore($item->max_price),
                        'price' => $this->pricefilter($item->model_id),
                        'rating_type_name' => $item->rating_type_name ?? NULL,
                        'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : NULL,

                    ];
            });

            //by budget

            $price_count = Model::selectRaw('
            CASE
                WHEN (cop_pe_ms.ex_showroom_price >= 200000 AND cop_pe_ms.ex_showroom_price < 1000000) THEN "200000 - 1000000"
                WHEN (cop_pe_ms.ex_showroom_price >= 1000000 AND cop_pe_ms.ex_showroom_price < 2500000) THEN "1000000 - 2500000"
                WHEN (cop_pe_ms.ex_showroom_price >= 2500000 AND cop_pe_ms.ex_showroom_price < 5000000) THEN "2500000 - 5000000"
                WHEN (cop_pe_ms.ex_showroom_price >= 5000000 AND cop_pe_ms.ex_showroom_price < 10000000) THEN "5000000 - 10000000"
                ELSE "10000000 - 990000000"
            END AS price_range,
            COUNT(DISTINCT cop_fv.model_id) as model_count
        ')
                ->join('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->where('cop_models.model_type', '=', '0')
                ->groupBy('price_range')
                ->orderByRaw("FIELD(price_range, '200000 - 1000000', '1000000 - 2500000', '2500000 - 5000000', '5000000 - 10000000', '10000000 - 990000000')");


            if (!empty($brandName)) {
                $price_count->whereIn('cop_brands_ms.brand_name', $brandName);
            }

            // if (!empty($minPrice) && !empty($maxPrice)) {
            //     $price_count->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            // }


            if (!empty($ct_name)) {
                $price_count->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $price_count->whereIn('cop_fv.model_id', function ($by_brand) use ($fuelType) {
                    $by_brand->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $price_count->whereIn('cop_fv.model_id', function ($by_brand) use ($transmissionType) {
                    $by_brand->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $price_count->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }
            if (!empty($driveTrain)) {
                $price_count->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $price_count->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $price_count->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $price_count->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $count_price = $price_count->get();
            $show_prices = []; // Initialize an array to store all price range data

            foreach ($count_price as $price) {
                switch ($price->price_range) {
                    case "200000 - 1000000":
                        $show_keyword = "2 - 10 lakh";
                        break;
                    case "1000000 - 2500000":
                        $show_keyword = "10 - 25 lakh";
                        break;
                    case "2500000 - 5000000":
                        $show_keyword = "25 - 50 lakh";
                        break;
                    case "5000000 - 10000000":
                        $show_keyword = "50 lakh  - 1 crore";
                        break;
                    case "10000000 - 990000000":
                        $show_keyword = "1 Cr+";
                        break;
                    default:
                        $show_keyword = "Unknown";
                }

                $show_prices[] = [
                    "price_range" => $price->price_range,
                    "model_count" => $price->model_count,
                    "show_keyword" => $show_keyword
                ];
            }
            //end by budget

            //By Brand
            $brands = Brand::select('brand_id', 'brand_name')->get();

            $by_brand = Model::select('cop_models.brand_id', 'cop_brands_ms.brand_name', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->Join('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')

                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->where('cop_models.model_type', '=', '0');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $by_brand->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                // $by_brand->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $by_brand->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $by_brand->whereIn('cop_fv.model_id', function ($by_brand) use ($fuelType) {
                    $by_brand->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $by_brand->whereIn('cop_fv.model_id', function ($by_brand) use ($transmissionType) {
                    $by_brand->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $by_brand->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }
            if (!empty($driveTrain)) {
                $by_brand->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $by_brand->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $by_brand->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $by_brand->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }


            $by_brand = $by_brand->groupBy('cop_models.brand_id', 'cop_brands_ms.brand_name')
                ->havingRaw('model_count > 0')
                ->get();
            // dd($by_brand->toSql());
            if ($by_brand->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'Not Found!!');
            }

            $byBrand = $brands->map(function ($brand) use ($by_brand) {
                $brand_id = $brand->brand_id;
                $brand_name = $brand->brand_name;
                $count = 0;

                $modelCount = $by_brand->firstWhere('brand_id', $brand_id);
                if ($modelCount) {
                    $count = $modelCount->model_count;
                }

                return [
                    'brand_id' => $brand_id,
                    'brand_name' => $brand_name,
                    'model_count' => $count,
                ];
            })->filter(function ($brand_count) {
                return $brand_count['model_count'] > 0;
            })->values();


            //By Body Type
            $carType = CarType::select('ct_id', 'ct_name', 'ct_image')->get();

            $by_body_type = Model::select('cop_models.ct_id', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->where('cop_models.model_type', 0);

            if (!empty($minPrice) && !empty($maxPrice)) {
                $by_body_type->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $by_body_type->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                // $by_body_type->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($by_body_type) use ($fuelType) {
                    $by_body_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($by_body_type) use ($transmissionType) {
                    $by_body_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }
            if (!empty($driveTrain)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $by_body_type->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $by_body_type = $by_body_type->groupBy('cop_models.ct_id')
                ->havingRaw('model_count > 0')
                ->get();

            $byBodyType = $carType->map(function ($cartype) use ($by_body_type) {
                $ct_id = $cartype->ct_id;
                $ct_name = $cartype->ct_name;
                $ct_image = asset("car_types/{$cartype->ct_id}/{$cartype->ct_image}");

                $count = 0;

                $modelCount = $by_body_type->firstWhere('ct_id', $ct_id);
                if ($modelCount) {
                    $count = $modelCount->model_count;
                }
                // if($count>0){
                return [
                    'ct_id' => $ct_id,
                    'ct_name' => $ct_name,
                    'ct_image' => $ct_image,
                    'model_count' => $count,
                ];
            })->filter(function ($body_type_count) {
                return $body_type_count['model_count'] > 0;
            })->values();


            //Fuel Type

            $fuel = FeatureValue::select('feature_value')->whereIn('feature_value', ['Petrol', 'Diesel', 'Petrol-CNG', 'Hybrid'])->distinct()->get();

            $fuel_type = Model::select('cop_fv.feature_value', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_features_ms.features_name', '=', 'Type of Fuel');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $fuel_type->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $fuel_type->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $fuel_type->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            // if (!empty($fuelType)) {
            //     $fuel_type->whereIn('cop_fv.model_id', function ($fuel_type) use ($fuelType) {
            //         $fuel_type->select('model_id')
            //             ->from('cop_fv')
            //             ->whereIn('feature_value', $fuelType);
            //     });
            // }
            if (!empty($transmissionType)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($fuel_type) use ($transmissionType) {
                    $fuel_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }

            if (!empty($engineCapacity)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }

            if (!empty($driveTrain)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $fuel_type->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $fuel_type = $fuel_type->groupBy('cop_fv.feature_value')
                ->havingRaw('model_count > 0')
                ->get();
            // dd($fuel_type->toSql());

            $byfuelType = $fuel->map(function ($fuel) use ($fuel_type) {

                $feature_value = $fuel->feature_value;
                $count = 0;

                $modelCount = $fuel_type->firstWhere('feature_value', $feature_value);
                if ($modelCount) {
                    $count = $modelCount->model_count;
                }

                return [
                    'feature_value' => $feature_value,
                    'model_count' => $count,
                ];
            })->filter(function ($item) {
                return $item['model_count'] > 0;
            })->values();


            //Engine capacity(cc)
            $engineCc = Model::selectRaw("
                CASE
                    WHEN feature_value >= 0 AND feature_value < 1200 THEN '0 - 1200'
                    WHEN feature_value >= 1200 AND feature_value < 1500 THEN '1200 - 1500'
                    WHEN feature_value >= 1500 AND feature_value < 2000 THEN '1500 - 2000'
                    WHEN feature_value >= 2000 AND feature_value < 3000 THEN '2000 - 3000'
                    WHEN feature_value >= 3000 AND feature_value < 5000 THEN '3000 - 5000'
                    WHEN feature_value >= 5000 AND feature_value < 8000 THEN '5000 - 8000'
                END AS feature_value_range,
                COUNT(DISTINCT cop_fv.model_id) AS model_count
            ")
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_features_ms.features_name', '=', 'Displacement');


            if (!empty($minPrice) && !empty($maxPrice)) {
                $engineCc->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $engineCc->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $engineCc->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $engineCc->whereIn('cop_fv.model_id', function ($engineCc) use ($fuelType) {
                    $engineCc->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $engineCc->whereIn('cop_fv.model_id', function ($engineCc) use ($transmissionType) {
                    $engineCc->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            // if (!empty($engineCapacity)) {
            //     $engineCc->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
            //         $query->select('cop_fv.model_id')
            //             ->from('cop_features_ms')
            //             ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
            //             ->where('features_name', '=', 'Displacement')
            //             ->where(function ($query) use ($engineCapacity) {
            //                 $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
            //                 $cnt = 0;
            //                 foreach ($explodeEngineCapacity as $range) {
            //                     $result = explode('-', $range);
            //                     $fromEngine = $result[0];
            //                     $toEngine = $result[1];
            //                     if ($cnt == 0) {
            //                         $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
            //                     } else {
            //                         $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
            //                     }
            //                     $cnt++;
            //                 }
            //             });
            //     });
            // }

            if (!empty($driveTrain)) {
                $engineCc->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $engineCc->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $engineCc->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $engineCc->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $engine_capacity = $engineCc->groupBy('feature_value_range')
                ->having('model_count', '>', 0)
                ->get();


            //Transmission Type
            $transmission_type = Model::select('cop_fv.feature_value', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_features_ms.features_name', '=', 'Type of Transmission');


            if (!empty($minPrice) && !empty($maxPrice)) {
                $transmission_type->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $transmission_type->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $transmission_type->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($transmission_type) use ($fuelType) {
                    $transmission_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            // if (!empty($transmissionType)) {
            //     $transmission_type->whereIn('cop_fv.model_id', function ($transmission_type) use ($transmissionType) {
            //         $transmission_type->select('model_id')
            //             ->from('cop_fv')
            //             ->whereIn('feature_value', $transmissionType);
            //     });
            // }
            if (!empty($engineCapacity)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [(int)$fromEngine, (int)$toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [(int)$fromEngine, (int)$toEngine]);
                                }
                            }
                        });
                });
            }
            if (!empty($driveTrain)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }
            if (!empty($safetyFeatures)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $transmission_type->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $bytransmissionType = $transmission_type->groupBy('cop_fv.feature_value')
                ->havingRaw('model_count > 0')->get()->map(function ($data) {
                    $feature_value = $data->feature_value;
                    return [
                        'feature_value' => $feature_value,
                        'model_count' => $data->model_count,
                    ];
                });

            //Drivetrain Type
            // $feature_id = 26;
            $drivetrain_type = DB::table('cop_models')
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->select(
                    'cop_fv.feature_value',
                    DB::raw('COUNT(DISTINCT cop_fv.model_id) AS model_count')
                )
                ->where('cop_models.model_type', 0)
                ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                ->where('cop_fv.feature_value', '!=', '-');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $drivetrain_type->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $drivetrain_type->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $drivetrain_type->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($drivetrain_type) use ($fuelType) {
                    $drivetrain_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($drivetrain_type) use ($transmissionType) {
                    $drivetrain_type->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }

            // if (!empty($driveTrain)) {
            //     $drivetrain_type->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
            //         $query->select('cop_fv.model_id')
            //             ->from('cop_fv')
            //             ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
            //             ->where('cop_features_ms.features_name', '=', 'Drivetrain')
            //             ->whereIn('cop_fv.feature_value', $driveTrain);
            //     });
            // }

            if (!empty($safetyFeatures)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $drivetrain_type->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $bydrivetrainType = $drivetrain_type->groupBy('cop_fv.feature_value')
                ->havingRaw('model_count > 0')
                ->get()
                // dd($drivetrain_type->toSql())
                ->map(function ($data) {
                    $feature_value = $data->feature_value;
                    return [
                        'feature_value' => $feature_value,
                        'model_count' => $data->model_count,
                    ];
                });


            //Safety Features


            // $spec_id = 12;
            // $safety_features = DB::table('cop_models')
            //     ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
            //     ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            //     ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
            //     ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
            //     ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //     // ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_fv.spec_id')
            //     ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //     ->select(
            //         'cop_fv.feature_id as features_id',
            //         'cop_features_ms.features_name',
            //         DB::raw('COUNT(DISTINCT cop_fv.model_id) AS model_count')
            //     )
            //     ->where('cop_models.model_type', 0)
            //     ->where('cop_spec_ms.spec_name', '=', 'Safety')
            //     ->where('cop_fv.feature_value', '=', '1');

            $safety_features = Model::select('cop_features_ms.features_name', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_spec_ms.spec_name', '=', 'Safety')
                ->where('cop_fv.feature_value', '=', '1');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $safety_features->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $safety_features->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $safety_features->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $safety_features->whereIn('cop_fv.model_id', function ($safety_features) use ($fuelType) {
                    $safety_features->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $safety_features->whereIn('cop_fv.model_id', function ($safety_features) use ($transmissionType) {
                    $safety_features->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $safety_features->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }

            if (!empty($driveTrain)) {
                $safety_features->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            // if (!empty($safetyFeatures)) {
            //     $safety_features->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
            //         $query->select('cop_fv.model_id')
            //             ->from('cop_fv')
            //             ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //             ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //             ->where('cop_spec_ms.spec_name', '=', 'Safety')
            //             ->where('cop_fv.feature_value', '=', '1')
            //             ->whereIn('cop_features_ms.features_name', $safetyFeatures);
            //     });
            // }
            if (!empty($interiorFeatures)) {
                $safety_features->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            if (!empty($exteriorFeatures)) {
                $safety_features->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $bysafetyFeatures = $safety_features->groupBy('cop_features_ms.features_name')
                ->havingRaw('model_count > 0')
                ->get()
                // dd($safety_features->toSql())
                ->map(function ($data) {
                    return [
                        'features_name' => $data->features_name,
                        'model_count' => $data->model_count,
                    ];
                });

            //Interior


            // $spec_id = 10;
            // $f_interior = DB::table('cop_models')
            //     ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
            //     ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            //     ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
            //     ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
            //     ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //     ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //     ->select(
            //         'cop_fv.feature_id as features_id',
            //         'cop_features_ms.features_name',
            //         DB::raw('COUNT(DISTINCT cop_fv.model_id) AS model_count')
            //     )
            //     ->where('cop_models.model_type', 0)
            //     ->where('cop_spec_ms.spec_name', '=', 'Interior');
            //   ->where('cop_fv.feature_value', '!=', '-');
            $f_interior = Model::select('cop_features_ms.features_name', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_spec_ms.spec_name', '=', 'Interior')
                ->where('cop_fv.feature_value', '=', '1');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $f_interior->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $f_interior->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $f_interior->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $f_interior->whereIn('cop_fv.model_id', function ($f_interior) use ($fuelType) {
                    $f_interior->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $f_interior->whereIn('cop_fv.model_id', function ($f_interior) use ($transmissionType) {
                    $f_interior->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $f_interior->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }

            if (!empty($driveTrain)) {
                $f_interior->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $f_interior->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            // if (!empty($interiorFeatures)) {
            //     $f_interior->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
            //         $query->select('cop_fv.model_id')
            //             ->from('cop_fv')
            //             ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //             ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //             ->where('cop_spec_ms.spec_name', '=', 'Interior')
            //             ->where('cop_fv.feature_value', '=', '1')
            //             ->whereIn('cop_features_ms.features_name', $interiorFeatures);
            //     });
            // }

            if (!empty($exteriorFeatures)) {
                $f_interior->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
                });
            }

            $fInterior = $f_interior->groupBy('cop_features_ms.features_name')
                ->havingRaw('model_count > 0')
                ->get()
                // dd($f_interior->toSql())
                ->map(function ($data) {
                    //   $feature_value = $data->feature_value;
                    return [
                        // 'features_id' => $data->features_id,
                        'features_name' => $data->features_name,
                        'model_count' => $data->model_count,
                    ];
                });

            //Exterior


            // $spec_id = 11;
            // $f_exterior = DB::table('cop_models')
            //     ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
            //     ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
            //     ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
            //     ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
            //     ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //     ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //     ->select(
            //         'cop_fv.feature_id as features_id',
            //         'cop_features_ms.features_name',
            //         DB::raw('COUNT(DISTINCT cop_fv.model_id) AS model_count')
            //     )
            //     ->where('cop_models.model_type', 0)
            //     ->where('cop_spec_ms.spec_name', '=', 'Exterior');
            //   ->where('cop_fv.feature_value', '!=', '-');

            $f_exterior = Model::select('cop_features_ms.features_name', DB::raw('COUNT(DISTINCT cop_fv.model_id) as model_count'))
                ->leftJoin('cop_fv', 'cop_models.model_id', '=', 'cop_fv.model_id')
                ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_ct_ms', 'cop_ct_ms.ct_id', '=', 'cop_models.ct_id')
                ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                ->where('cop_models.model_type', 0)
                ->where('cop_spec_ms.spec_name', '=', 'Exterior')
                ->where('cop_fv.feature_value', '=', '1');

            if (!empty($minPrice) && !empty($maxPrice)) {
                $f_exterior->whereBetween('cop_pe_ms.ex_showroom_price', [$minPrice, $maxPrice]);
            }
            if (!empty($brandName)) {
                $f_exterior->whereIn('cop_brands_ms.brand_name', $brandName);
            }
            if (!empty($ct_name)) {
                $f_exterior->whereIn('cop_ct_ms.ct_name', $ct_name);
            }
            if (!empty($fuelType)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($f_exterior) use ($fuelType) {
                    $f_exterior->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $fuelType);
                });
            }
            if (!empty($transmissionType)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($f_exterior) use ($transmissionType) {
                    $f_exterior->select('model_id')
                        ->from('cop_fv')
                        ->whereIn('feature_value', $transmissionType);
                });
            }
            if (!empty($engineCapacity)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($query) use ($engineCapacity) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_features_ms')
                        ->join('cop_fv', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('features_name', '=', 'Displacement')
                        ->where(function ($query) use ($engineCapacity) {
                            $explodeEngineCapacity = explode(',', str_replace(" ", "", $engineCapacity));
                            $cnt = 0;
                            foreach ($explodeEngineCapacity as $range) {
                                $result = explode('-', $range);
                                $fromEngine = $result[0];
                                $toEngine = $result[1];
                                if ($cnt == 0) {
                                    $query->whereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                } else {
                                    $query->orWhereBetween('cop_fv.feature_value', [$fromEngine, $toEngine]);
                                }
                                $cnt++;
                            }
                        });
                });
            }

            if (!empty($driveTrain)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($query) use ($driveTrain) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->join('cop_features_ms', 'cop_fv.feature_id', '=', 'cop_features_ms.feature_id')
                        ->where('cop_features_ms.features_name', '=', 'Drivetrain')
                        ->whereIn('cop_fv.feature_value', $driveTrain);
                });
            }

            if (!empty($safetyFeatures)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($query) use ($safetyFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Safety')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $safetyFeatures);
                });
            }

            if (!empty($interiorFeatures)) {
                $f_exterior->whereIn('cop_fv.model_id', function ($query) use ($interiorFeatures) {
                    $query->select('cop_fv.model_id')
                        ->from('cop_fv')
                        ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                        ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
                        ->where('cop_spec_ms.spec_name', '=', 'Interior')
                        ->where('cop_fv.feature_value', '=', '1')
                        ->whereIn('cop_features_ms.features_name', $interiorFeatures);
                });
            }

            // if (!empty($exteriorFeatures)) {
            //     $f_exterior->whereIn('cop_fv.model_id', function ($query) use ($exteriorFeatures) {
            //         $query->select('cop_fv.model_id')
            //             ->from('cop_fv')
            //             ->leftjoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
            //             ->leftJoin('cop_spec_ms', 'cop_spec_ms.spec_id', '=', 'cop_features_ms.spec_id')
            //             ->where('cop_spec_ms.spec_name', '=', 'Exterior')
            //             ->where('cop_fv.feature_value', '=', '1')
            //             ->whereIn('cop_features_ms.features_name', $exteriorFeatures);
            //     });
            // }

            $fExterior = $f_exterior->groupBy('cop_features_ms.features_name')
                ->havingRaw('model_count > 0')
                ->get()
                // dd($f_exterior->toSql())
                ->map(function ($data) {
                    //   $feature_value = $data->feature_value;
                    return [
                        // 'features_id' => $data->features_id,
                        'features_name' => $data->features_name,
                        'model_count' => $data->model_count,
                    ];
                });

            $responseData = [
                'cardData' => $responseCardData,
                'filterData' => array(
                    'by_budget' => $show_prices,
                    'by_brand' => $byBrand,
                    'by_body_type' => $byBodyType,
                    'fuel_type' => $byfuelType,
                    'engine_capacity' => $engine_capacity,
                    'transmission_type' => $bytransmissionType,
                    'drivetrain_type' => $bydrivetrainType,
                    'safety_features' => $bysafetyFeatures,
                    'f_interior' => $fInterior,
                    'f_exterior' => $fExterior
                )
            ];


            return ResponseHelper::responseMessage('success', $responseData, "Successfully Data Get");
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('success', 'Something went wrong!!' . $e->getMessage());
        }
    }

    // show matching variants in advanced search

    public function matchVariants(Request $request)
    {


        $modelNAme =  $request->model_name;
        $featureName = 'Type of Fuel';
        try {
            $matchVariant = Model::Join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_variants', 'cop_variants.model_id', '=', 'cop_models.model_id')
                ->leftJoin('cop_fv', 'cop_fv.variant_id', '=', 'cop_variants.variant_id')
                ->leftJoin('cop_features_ms', 'cop_features_ms.feature_id', '=', 'cop_fv.feature_id')
                ->join('cop_pe_ms', 'cop_pe_ms.variant_id', '=', 'cop_variants.variant_id')
                ->select(
                    'cop_models.model_id',
                    'cop_models.model_name',
                    'cop_fv.feature_value',
                    'cop_variants.variant_id',
                    'cop_variants.variant_name',
                    'cop_models.status',
                    'cop_brands_ms.status',
                    'cop_pe_ms.ex_showroom_price',
                    'cop_fv.status',
                )->where('cop_features_ms.features_name', $featureName)
                ->where('cop_models.model_name', $modelNAme)
                ->where('cop_models.status', '=', 1)
                ->where('cop_brands_ms.status', '=', 1)
                ->where('cop_fv.status', '=', 1)
                ->where('cop_features_ms.status', '=', 1)
                ->where('cop_variants.status', '=', 1)
                ->distinct()
                ->get();

            // dd($matchVariant);

            $formatData = $matchVariant->map(function ($item) {
                $data = [
                    'model_id' => encrypt($item->model_id),
                    'model_name' => $item->model_name,
                    'variant_id' =>$item->variant_id,
                    'variant_name' =>$item->variant_name,
                    'feature_value' => $item->feature_value,
                    'ex_showroom_price' => $this->convertToLakhCrore($item->ex_showroom_price),

                ];
                return  $data;
            });
               return ResponseHelper::responseMessage('success', $formatData, "Successfully Data Get");
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('success', 'Something went wrong!!' . $e->getMessage());
        }
    }
    private function convertToLakhCrore($price)
    {
        if ($price >= 10000000) {
            return number_format($price / 10000000, 2) . ' Cr';
        } elseif ($price >= 100000) {
            return number_format($price / 100000, 2) . ' Lakh';
        } else {
            return $price;
        }
    }
}
