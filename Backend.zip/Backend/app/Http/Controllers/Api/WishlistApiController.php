<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Customer;
use App\Models\Model;
use App\Models\Wishlist;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class WishlistApiController extends Controller
{
    public function index(Request $request)
    {
        try {
            $customerId = Auth::guard('api')->id();
            // $customer = JWTAuth::parseToken()->authenticate();
            // return response()->json(['message' => 'Token is valid'], 200);

            $validator = Validator::make($request->all(), [

                'model_id' => 'required',
                'created_date' => 'required',

            ]);

            if ($validator->fails()) {
                return ResponseHelper::errorResponse($validator->errors()->all());
            }
            $customer_id = $customerId;
            $model_id = decrypt($request->model_id);
            $created_date = $request->created_date;

            $user = Customer::find($customerId);
            if (!$user) {
                return ResponseHelper::errorResponse('success', 'Customer not found!!');
            }
            //deletw wish list

            $existingWishlistItem = Wishlist::where('customer_id', $customer_id)
                ->where('model_id', $model_id)
                ->first();

            if ($existingWishlistItem) {

                $existingWishlistItem->delete();

                return ResponseHelper::responseMessage('success', $wishlist_status = False, 'Wishlist deleted successfully');
            }

            $wishlistAdd = new Wishlist();
            $wishlistAdd->customer_id = $customer_id;
            $wishlistAdd->model_id = $model_id;
            $wishlistAdd->created_date = $created_date;

            $wishlistAdd->save();


            return ResponseHelper::responseMessage('success', $wishlist_status = True, 'Wishlist Added successfully');
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }

    public function customerWishlist(Request $request)
    {
        try {
            $customer_id = Auth::guard('api')->id();
            $customerWishlist = Wishlist::select(
                'cop_wl.customer_id',
                'cop_models.model_id',
                'cop_models.model_name',
                
                'cop_models.model_image',
                'cop_models.model_type',
                'cop_ratings.rating_value',
                'cop_brands_ms.brand_id',
                'cop_brands_ms.brand_name',
                'cop_msd.model_bhp',
                'cop_msd.model_fuel',
                DB::raw('(SELECT CONCAT(MIN(CAST(cop_fv.feature_value AS INTEGER)), " ", cop_su_ms.su_name) FROM cop_fv INNER JOIN cop_features_ms ON cop_features_ms.feature_id = cop_fv.feature_id LEFT JOIN cop_su_ms ON cop_su_ms.su_id = cop_features_ms.su_id WHERE cop_features_ms.features_name = "Displacement" AND cop_fv.model_id = cop_wl.model_id GROUP BY cop_su_ms.su_name) AS min_displacement'),
                DB::raw('(SELECT CONCAT(cop_fv_mileage.feature_value, " ", cop_su_ms_mileage.su_name) FROM cop_fv AS cop_fv_mileage INNER JOIN cop_features_ms AS cop_features_ms_mileage ON cop_features_ms_mileage.feature_id = cop_fv_mileage.feature_id LEFT JOIN cop_su_ms AS cop_su_ms_mileage ON cop_su_ms_mileage.su_id = cop_features_ms_mileage.su_id WHERE cop_fv_mileage.model_id = cop_wl.model_id AND cop_features_ms_mileage.features_name = "Mileage" LIMIT 1) AS min_mileage'),
                DB::raw('(SELECT cop_fv_transmission.feature_value FROM cop_fv AS cop_fv_transmission INNER JOIN cop_features_ms AS cop_features_ms_transmission ON cop_features_ms_transmission.feature_id = cop_fv_transmission.feature_id WHERE cop_fv_transmission.model_id = cop_wl.model_id AND cop_features_ms_transmission.features_name = "Type of Transmission" LIMIT 1) AS transmission_type')

            )
                ->join('cop_models', 'cop_wl.model_id', '=', 'cop_models.model_id')
                ->join('cop_msd', 'cop_msd.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                ->join('cop_ratings', 'cop_ratings.model_id', '=', 'cop_models.model_id')
                ->where('cop_wl.customer_id', $customer_id)
                ->get();

            $customer_wishlist = $customerWishlist->map(function ($item) {
                // Get min and max prices for the model
                $priceMinMax = Model::select(
                    DB::raw('MIN(cop_pe_ms.ex_showroom_price) as min_ex_showroom_price'),
                    DB::raw('MAX(cop_pe_ms.ex_showroom_price) as max_ex_showroom_price')
                )
                    ->join('cop_pe_ms', 'cop_pe_ms.model_id', '=', 'cop_models.model_id')
                    ->where('cop_models.model_id', $item->model_id)
                    ->first();

                $data = [
                    'customer_id' => $item->customer_id,
                    'brand_id' => $item->brand_id,
                    'brand_name' => $item->brand_name,
                    'model_id' => $item->model_id,
                    'model_name' => $item->model_name,
                    'model_image' => asset("brands/{$item->brand_id}/{$item->model_id}/{$item->model_id}.webp") ?? NULL,
                    'min_price' => $this->convertToLakhCrore($priceMinMax['min_ex_showroom_price']),
                    'max_price' => $this->convertToLakhCrore($priceMinMax['max_ex_showroom_price']),
                    'model_type' => $item->model_type == 0 ? 'Non EV' : 'EV',
                    'model_bhp' => $item->model_bhp,
                    'model_fuel' => $item->model_fuel,
                    'variant_engine' => $item->min_displacement,
                    'variant_transmission' => $item->transmission_type,
                    'variant_mileage' => $item->min_mileage,
                    'rating_value' => isset($item->rating_value) ? number_format((float)$item->rating_value, 1, '.', '') : NULL
                ];
                return  $data;
            });

            return ResponseHelper::responseMessage('success', $customer_wishlist);
        } catch (Exception $e) {
            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }

    private function convertToLakhCrore($price)
    {
        if ($price >= 10000000) {
            return number_format($price / 10000000, 2) . ' Cr';
        } elseif ($price >= 100000) {
            return number_format($price / 100000, 2) . ' Lakh';
        } else {
            return $price;
        }
    }
}