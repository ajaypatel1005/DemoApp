<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\WarningLight;

class WarningLightApiController extends Controller
{
    public function index(Request $request)
    {
        try {

            $warning_light = WarningLight::where(function ($query) use ($request) {
                           })
           ->where('wl_status', '!=', 0)
            ->get();

        if ($warning_light->isEmpty()) {
            // return ResponseHelper::responseMessage('error', 'Not Found');
            return ResponseHelper::errorResponse('success','No data available!!');
        }
            $w_lData = $warning_light->map(function ($item) {

                $data = [
                        'wl_id' => encrypt($item->wl_id),
                        'wl_name' => $item->wl_name,
                        'wl_icon' => asset("warning_light/{$item->wl_id}/{$item->wl_icon}") ?? "",
                        'wl_heading'  => $item->wl_heading,
                        'wl_subheading'  => $item->wl_subheading,
                        'wl_info'  => $item->wl_info,
                        'wl_display_position'  => $item->wl_display_position,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $w_lData);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse(['Something went wrong!!']);
            return ResponseHelper::errorResponse('success','Something went wrong!!');
        }
    }
}
