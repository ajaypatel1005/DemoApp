<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\NewsLatter;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use Illuminate\Support\Facades\Validator;

class NewsLatterApicontroller extends Controller
{

    public function index(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'email' => 'Required|email',
        ], [
            'email.email' => 'The email must be a valid email address.',
        ]);
        if ($validator->fails()) {
            return ResponseHelper::errorResponse($validator->errors()->all(), 'Please Fill Valid all required fields', 'message');
        }
        $addnewsLatter = new NewsLatter();
        $addnewsLatter->email = $request->email;
        $addnewsLatter->status = $request->has('status') ? 1 : 0;
        $addnewsLatter->save();

        return ResponseHelper::responseMessage('success', $addnewsLatter, 'Car On Phone Suscribe !! ');
    }
}
