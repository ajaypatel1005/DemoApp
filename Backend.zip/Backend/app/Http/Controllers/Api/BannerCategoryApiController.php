<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Models\BannerCategory;
use App\Http\Controllers\Helpers\ResponseHelper;

class BannerCategoryApiController extends Controller
{
    public function index()
    {
        try {
            $banner_cat = BannerCategory::all();
            // dd($models);

            if ($banner_cat->isEmpty()) {


                return ResponseHelper::errorResponse('success', 'Banner Category Not Found!!');
            }
            $formattedData = $banner_cat->map(function ($item) {


                $data = [
                    'banner_cat_id' => encrypt($item->bc_id),
                    'banner_cat' => $item->bc_name,
                ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
