<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CarGraphic;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class CarGraphicApiController extends Controller
{
    public function index()
    {
        try {
            $cargrphic = CarGraphic::select(
                'cop_graphics.*',
                'cop_gt_ms.*',
                'cop_brands_ms.brand_name as brand_name',
                'cop_models.model_name as model_name'
            )
                ->leftJoin('cop_gt_ms', 'cop_graphics.gt_id', '=', 'cop_gt_ms.gt_id')
                ->leftJoin('cop_brands_ms', 'cop_graphics.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_models', 'cop_graphics.model_id', '=', 'cop_models.model_id')
                ->where('cop_graphics.status', '!=', 0)
                ->get();


            if ($cargrphic->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }
            // dd($cargrphic);
            $cargrphicData = $cargrphic->map(function ($item) {

                if ($item->gt_name == 'Images') {
                    $single_image = explode(',', $item->graphic_file);
                    $graphicFiles = [];

                    for ($i = 0; $i < count($single_image); $i++) {
                        $graphicFiles[] = asset("car_graphics/{$item->model_id}/images/{$single_image[$i]}");
                    }

                    return [
                        'graphic_id' => encrypt($item->graphic_id),
                        'brand_name' => $item->brand_name,
                        'model_name' => $item->model_name,
                        'gt_name' => $item->gt_name,
                        'graphic_file' => $graphicFiles,
                    ];
                } elseif ($item->gt_name == 'Video') {
                    return [
                        'graphic_id' => encrypt($item->graphic_id),
                        'brand_name' => $item->brand_name,
                        'model_name' => $item->model_name,
                        'gt_name' => $item->gt_name,
                        'graphic_file' => asset("car_graphics/{$item->model_id}/videos/{$item->graphic_file}"),
                    ];
                } elseif ($item->gt_name == 'Images 360') {
                    $single_image = explode(',', $item->graphic_file);
                    $graphicFiles = [];

                    for ($i = 0; $i < count($single_image); $i++) {
                        $graphicFiles[] = asset("car_graphics/{$item->model_id}/360_images/{$single_image[$i]}");
                    }

                    return [
                        'graphic_id' => encrypt($item->graphic_id),
                        'brand_name' => $item->brand_name,
                        'model_name' => $item->model_name,
                        'gt_name' => $item->gt_name,
                        'graphic_file' => $graphicFiles,
                    ];
                } else {
                    return [
                        'graphic_id' => encrypt($item->graphic_id),
                        'brand_name' => $item->brand_name,
                        'model_name' => $item->model_name,
                        'gt_name' => $item->gt_name,
                        'graphic_file' => null,
                    ];
                }
            });

            return ResponseHelper::responseMessage('success', $cargrphicData, "Successfully Data Get");
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
