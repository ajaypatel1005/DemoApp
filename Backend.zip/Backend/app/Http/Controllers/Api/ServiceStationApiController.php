<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\ServiceStation;
use Illuminate\Support\Facades\DB;

class ServiceStationApiController extends Controller
{
    public function index(Request $request)
    {
        try {
            $city_name = $request->city_name;
            $brand_id = $request->brand_id;

            $service_station =  ServiceStation::select('cop_s_stations_ms.*', 'cop_brands_ms.brand_name as brand_name', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
                ->leftJoin('cop_brands_ms', 'cop_s_stations_ms.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_city_ms', 'cop_s_stations_ms.city_id', '=', 'cop_city_ms.city_id')
                ->leftJoin('cop_state_ms', 'cop_s_stations_ms.state_id', '=', 'cop_state_ms.state_id')
                ->where('cop_s_stations_ms.status', 1)
                ->where('cop_city_ms.city_name', '=', $city_name)
                ->when($brand_id, function ($query) use ($brand_id) {
                    return $query->whereExists(function ($subQuery) use ($brand_id) {
                        $subQuery->select(DB::raw(1))
                            ->from('cop_s_stations_ms')
                            ->whereColumn('cop_s_stations_ms.brand_id', '=', 'cop_brands_ms.brand_id')
                            ->where('cop_s_stations_ms.brand_id', '=', $brand_id);
                    });
                })
                ->get();


            if ($service_station->isEmpty()) {
                // return ResponseHelper::errorResponse(['No data available']);
                return ResponseHelper::errorResponse('success','No data available!!');
            }
            $formattedData = $service_station->map(function ($item) {


                $data = [
                    's_station_id' => encrypt($item->s_station_id),
                    'brand_id'=>  $item->brand_id,
                    'brand_name'=>  $item->brand_name,
                    's_station_name' => $item->s_station_name,
                    's_station_address' => $item->s_station_address,
                    's_station_location' => $item->s_station_location,
                    'state_name' => $item->state_name,
                    'city_name' => $item->city_name,
                    's_station_contact_number' => $item->contact_no,
                   's_station_emil' => $item->email,


                       ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
            // return ResponseHelper::errorResponse(['Something went wrong!!']);
            return ResponseHelper::errorResponse('success','Something went wrong!!');
        }
    }

}
