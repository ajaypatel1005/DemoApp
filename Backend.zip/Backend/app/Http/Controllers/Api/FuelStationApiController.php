<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\FuelStation;
use Exception;
class FuelStationApiController extends Controller
{
    public function index(Request $request)
    {
        // $f_station_Id = $request->f_station_id;

        try {
            $fuel_station_view = FuelStation::select('cop_f_stations_ms.*', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_city_ms', 'cop_f_stations_ms.city_id', '=', 'cop_city_ms.city_id')
            ->leftJoin('cop_state_ms', 'cop_f_stations_ms.state_id', '=', 'cop_state_ms.state_id')
            ->where('cop_f_stations_ms.status', '=', 1);


            if ($request->has('city_id')) {
                $fuel_station_view->where('cop_f_stations_ms.city_id', $request->city_id);
            }
            $fuel_station_view = $fuel_station_view->get();

            if ($fuel_station_view->isEmpty()) {

                return ResponseHelper::errorResponse('success','No data available!!');
            }


            $formattedData = $fuel_station_view->map(function ($item) {

                $data = [
                    'f_station_id' => encrypt($item->f_station_id),
                    'f_station_name' => $item->f_station_name,
                    'f_station_address' => $item->f_station_address,
                    'f_station_location' => $item->f_station_location,
                    'state_id' => encrypt($item->state_id),
                    'state_name' => $item->state_name,
                    'city_id' => encrypt($item->city_id),
                    'city_name' => $item->city_name,
                    'contact_no' => $item->contact_no,
                        ];
                return $data;
            });

            return ResponseHelper::responseMessage('success', $formattedData);
        } catch (Exception $e) {
         
            return ResponseHelper::errorResponse('success','Something went wrong!!');
        }
    }
}
