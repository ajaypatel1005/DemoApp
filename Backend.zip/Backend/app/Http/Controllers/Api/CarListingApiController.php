<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CarListing;
use Exception;

class CarListingApiController extends Controller
{
    public function index()
    {
        try {
            $car_listing = CarListing::all();

            if ($car_listing->isEmpty()) {

                return ResponseHelper::errorResponse('success', 'No data available!!');
            }

            $clData = $car_listing->map(function ($item) {

                $data = [
                    'cl_id' => encrypt($item->cl_id),
                    'car_listing' => $item->cl_name,
                ];

                return $data;
            });

            return ResponseHelper::responseMessage('success', $clData);
        } catch (Exception $e) {

            return ResponseHelper::errorResponse('success', 'Something went wrong!!');
        }
    }
}
