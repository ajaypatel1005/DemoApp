<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\BookTestDrive;
use App\Models\Customer;
use Illuminate\Support\Facades\Validator;

class BookTestDriveApiController extends Controller
{

    public function addTestDrive(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required',
            'model_id' => 'required',
            'brand_id' => 'required',
            'fuel_types' => 'required',
            'additional_notes' => 'nullable',
            'btest_date' => 'required',
            'btest_time' => 'required',
        ]);

        if ($validator->fails()) {
            return ResponseHelper::errorResponse($validator->errors()->all(), 'Please fill in all required fields');
        }

        $test_drive = new BookTestDrive();
        $test_drive->customer_id = $request->customer_id;
        $test_drive->model_id = $request->model_id;
        $test_drive->brand_id = $request->brand_id;
        $test_drive->fuel_types = $request->fuel_types;
        $test_drive->additional_notes = $request->additional_notes;
        $test_drive->btest_date = $request->btest_date;
        $test_drive->btest_time = $request->btest_time;
        $test_drive->save();


        // $customer = Customer::where('customer_id', $request->customer_id)->first();
        // dd($customer);
        return ResponseHelper::responseMessage('success', $test_drive, 'Test Drive Book Successfully ');
    }
}
