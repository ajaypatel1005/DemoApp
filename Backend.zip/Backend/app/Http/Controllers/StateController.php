<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\State;
use App\Models\Country;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class StateController extends Controller
{
    //    Show the form for creating a new resource.
    public function create()
    {
        if (!hasAnyPermission(['create_state', 'view_state'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $cop_state_ms = State::select('cop_state_ms.*', 'cop_country_ms.country_name as country_name')
            ->leftJoin('cop_country_ms', 'cop_state_ms.country_id', '=', 'cop_country_ms.country_id')
            ->where('cop_country_ms.status', '=', 1)
            ->get();

        $countries = Country::active()->get();
        return view('state.create', compact('cop_state_ms', 'countries'));
    }

    //    Store a newly created resource in storage.
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_state'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'state_name' => 'required|regex:/^[()A-Za-z\s]+$/|unique:cop_state_ms,state_name|min:2',
            'country_id' => 'required',
            'cbu_rto' => 'required|numeric|max:100'
        ], [
            'state_name.regex' => 'State Name contain only letters and spaces.',
            'state_name.required' => 'State Name is required',
            'state_name.unique' => 'State Name has already been taken',
            'state_name.min' => 'The State Name must be at least :min characters.',
            'state_name.max' => 'The State Name must not exceed :max characters.',
            'country_id.required' => 'Select Country is required',
            'cbu_rto.required' => 'CBU Percentage is required.',
            'cbu_rto.numeric' => 'CBU Percentage must be a number.',
            'cbu_rto.max' => 'CBU Percentage must not exceed :max.'
        ]);
        DB::beginTransaction();
        
        try {
            $cop_state_ms_store = new State;
            if (!empty($cop_state_ms_store)) {
                $cop_state_ms_store->state_name = $request->state_name;
                $cop_state_ms_store->cbu_rto = $request->cbu_rto;
                $cop_state_ms_store->country_id = $request->country_id;
                $cop_state_ms_store->status = $request->has('status') ? 1 : 0;
                $cop_state_ms_store->is_ut = $request->has('is_ut') ? '1' : '0';
                DB::commit();
                $cop_state_ms_store->save();
                session()->flash('success', 'State Added Successfully');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('states.create');
    }

    //    Show the form for editing the specified resource.
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_state', 'view_state'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $cop_state_ms_edit = State::where('state_id', decrypt($id))->first();
        $cop_state_ms = State::get();
        $countries = Country::active()->get();
        $cop_country_ms_edit = Country::active()->get();
        $cop_state_ms = State::select('cop_state_ms.*', 'cop_country_ms.country_name as country_name')
            ->leftJoin('cop_country_ms', 'cop_state_ms.country_id', '=', 'cop_country_ms.country_id')
            ->where('cop_country_ms.status', '=', 1)
            ->get();
        return view('state.edit', compact('cop_country_ms_edit', 'cop_state_ms_edit', 'cop_state_ms', 'cop_state_ms'));
    }

    //    Update the specified resource in storage.
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_state'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'state_name' => 'required|regex:/^[()A-Za-z\s]+$/|unique:cop_state_ms,state_name,' . decrypt($id) . ',state_id|min:2',
                'country_id' => 'required',
                'cbu_rto' => 'required|numeric|max:100'
            ],
            [
                'state_name.regex' => 'State Name contain only letters and spaces.',
                'state_name.required' => 'State Name is required',
                'state_name.unique' => 'State Name has already been taken',
                'state_name.min' => 'The State Name must be at least :min characters.',
                'state_name.max' => 'The State Name must not exceed :max characters.',
                'country_id.required' => 'Country Name is required',
                'cbu_rto.required' => 'CBU Percentage is required.',
                'cbu_rto.numeric' => 'CBU Percentage must be a number.',
                'cbu_rto.max' => 'CBU Percentage must not exceed :max.',
            ]
        );
        DB::beginTransaction();
        try {
            $cop_state_ms_update = State::where('state_id', decrypt($id))->first();
            if (!empty($cop_state_ms_update)) {

                $cop_state_ms_update->state_name = $request->state_name;
                $cop_state_ms_update->cbu_rto = $request->cbu_rto;
                $cop_state_ms_update->country_id = $request->country_id;
                $cop_state_ms_update->status = $request->has('status') ? 1 : 0;
                $cop_state_ms_update->is_ut = $request->has('is_ut') ? '1' : '0';
                $cop_state_ms_update->save();
                DB::commit();
                session()->flash('success', 'State Name Updated Successfully');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('states.create');
    }

    //    Remove the specified resource from storage.
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_state'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $cop_state_ms_destroy = State::where('state_id', decrypt($id))->first();
            if ($cop_state_ms_destroy) {


                if ($cop_state_ms_destroy->s_station->isNotEmpty() || $cop_state_ms_destroy->f_station->isNotEmpty() || $cop_state_ms_destroy->ev_station->isNotEmpty() || $cop_state_ms_destroy->price_entry->isNotEmpty() || $cop_state_ms_destroy->city->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('states.create');
                }



                $cop_state_ms_destroy->delete();
                DB::commit();
                session()->flash('success', 'State Name Deleted Successfully.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('states.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_state_ms')
            ->where('state_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status Updated Successfully']);
    }

    public function fetchRecord(Request $request)
    {
        if($request->ajax()) {
            $limit = ($request->has('length') ? $request->input('length') : 10);
            $page = ($request->has('start') ? $request->input('start') : 0);
            $search = ($request->has('search') ? $request->input('search')['value'] : '');

            $state_view = State::select(
                'cop_state_ms.state_id',
                'cop_state_ms.state_name',
                'cop_state_ms.cbu_rto',
                'cop_state_ms.status',
                'cop_country_ms.country_name',
            )
            ->join('cop_country_ms','cop_country_ms.country_id','=','cop_state_ms.country_id')
            ->where([['cop_country_ms.status', '=', 1]]);

            if (!empty($search)) {
                $state_view->where(function ($query) use ($search) {
                    $query->orWhere('cop_state_ms.state_name', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_state_ms.cbu_rto', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_country_ms.country_name', 'LIKE', '%' . $search . '%');
                });
            }

            $cntFilter = clone $state_view;
            $state_view->offset($page)->limit($limit);
            $state_view = $state_view->get();

            $stateTotal = DB::select("SELECT COUNT(*) AS count FROM cop_state_ms INNER JOIN cop_country_ms ON cop_country_ms.country_id = cop_state_ms.country_id WHERE cop_country_ms.status = 1")[0]->count;
            $data = [];
            $i = $page;
            foreach ($state_view as $member) {
                $i++;
                $status = $disable = "";
                if ($member->status == 1) {
                    $status = 'checked';
                }
                $disable = (!auth()->user()->can('edit_state')) ? 'disabled' : '';

                $model_status = '<div class="form-check form-switch form-check-custom form-check-success form-check-solid">
                    <input class="form-check-input" name="status" type="checkbox" value="' . $member->state_id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>';

                $action = "";
                if (auth()->user()->can('edit_state')) {
                    $editRoute = route('states.edit', encrypt($member->state_id));
                    $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                            <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                }

                if (auth()->user()->can('delete_state')) {
                    $action .= '<a href="javascript:void(0);"
                        data-href="' . route('states.delete', encrypt($member->state_id)) . '"
                        class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                }
                $data[] = array("sr_no" => $i, "state_name" => $member->state_name, "country_name" => $member->country_name, "cbu_rto" => $member->cbu_rto, "status" => $model_status, "action" => $action);
            }
            return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $stateTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));

        }
    }
}
