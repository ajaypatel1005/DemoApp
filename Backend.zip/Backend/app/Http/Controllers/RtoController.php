<?php

namespace App\Http\Controllers;

use App\Models\Rto;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Exception;
use Illuminate\Validation\Rule;

class RtoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_rto'])) {
            abort(403, "you don't have permission to access");
        }
        $states = State::all();
        return view('rto.create', compact('states'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $request->validate([
            'state_id' => 'required',
            'rto_type' => 'required',
            'pre_condition' => 'nullable',
            'pre_amount' => 'nullable|numeric',
            'percentage' => 'required|numeric|between:0,100',
            'post_condition' => 'nullable|different:pre_condition',
            'post_amount' => [
                'nullable',
                'numeric',
                function ($attribute, $value, $fail) use ($request) {
                    if ($value !== null && $value <= $request->pre_amount) {
                        $fail('Post Amount must be greater than Pre Amount');
                    }
                },
            ],
        ], [
            'state_id.required' => 'State is required',
            'rto_type.required' => 'RTO Type is required',
            // 'pre_condition.required' => 'Pre Condition is required',
            // 'pre_amount.required' => 'Pre Amount is required',
            'pre_amount.numeric' => 'Pre Amount must be a number',
            'post_amount.numeric' => 'Post Amount must be a number',
            'percentage.required' => 'Percentage is required',
            'percentage.numeric' => 'Percentage must be a number',
            'percentage.between' => 'The percentage must be between :min and :max.',
            'post_condition.different' => 'Post Condition must be different from Pre Condition',
        ]);

        $rto_store = new Rto;
        try {
            $rto_store->state_id = $request->state_id;
            $rto_store->rto_type = $request->rto_type;
            $rto_store->pre_condition = $request->pre_condition;
            $rto_store->pre_amount = $request->pre_amount;
            $rto_store->post_condition = $request->post_condition;
            $rto_store->post_amount = $request->post_amount;
            $rto_store->percentage = $request->percentage;
            $rto_store->fuel_type = $request->fuel_type;
            $rto_store->cc = $request->has('cc') ? "1" : "0";
            $rto_store->save();
            DB::commit();
            session()->flash('success', 'Tax Added Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('rto.view');
    }

    /**
     * Display the specified resource.
     */
    public function view()
    {
        if (!hasAnyPermission(['view_rto'])) {
            abort(403, "you don't have permission to access");
        }

        $rto_data_view = DB::table('cop_rto_ms')
            ->join('cop_state_ms', 'cop_rto_ms.state_id', '=', 'cop_state_ms.state_id')
            ->select('cop_rto_ms.*', 'cop_state_ms.state_name as state_name')
            ->get();
        return view('rto.view', ['rto_data_view' => $rto_data_view]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {

        if (!hasAnyPermission(['edit_rto'])) {
            abort(403, "you don't have permission to access");
        }
        $rto_data_edit = Rto::where('rto_id', decrypt($id))->first();
        $states = State::all();

        return view('rto.edit', compact('rto_data_edit', 'states'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_rto'])) {
            abort(403, "you don't have permission to access");
        }

        $request->validate([
            'state_id' => 'required',
            'rto_type' => 'required',
            'pre_condition' => 'nullable',
            'pre_amount' => 'nullable|numeric',
            'percentage' => 'required|numeric|between:0,100',
            'post_condition' => 'nullable|different:pre_condition',
            'post_amount' => [
                'nullable',
                'numeric',
                function ($attribute, $value, $fail) use ($request) {
                    if ($value !== null && $value <= $request->pre_amount) {
                        $fail('Post Amount must be greater than Pre Amount');
                    }
                },
            ],
        ], [
            'state_id.required' => 'State is required',
            'rto_type.required' => 'RTO Type is required',
            // 'pre_condition.required' => 'Pre Condition is required',
            // 'pre_amount.required' => 'Pre Amount is required',
            'pre_amount.numeric' => 'Pre Amount must be a number',
            'post_amount.numeric' => 'Post Amount must be a number',
            'percentage.required' => 'Percentage is required',
            'percentage.numeric' => 'Percentage must be a number',
            'percentage.between' => 'The percentage must be between :min and :max.',
            'post_condition.different' => 'Post Condition must be different from Pre Condition',
        ]);
        try {

            $rto_data_updates = Rto::where('rto_id', decrypt($id))->first();
            if ($rto_data_updates) {
                $rto_data_updates->state_id = $request->state_id;
                $rto_data_updates->rto_type = $request->rto_type;
                $rto_data_updates->pre_condition = $request->pre_condition;
                $rto_data_updates->pre_amount = $request->pre_amount;
                $rto_data_updates->post_condition = $request->post_condition;
                $rto_data_updates->post_amount = $request->post_amount;
                $rto_data_updates->percentage = $request->percentage;
                $rto_data_updates->fuel_type = $request->fuel_type;
                $rto_data_updates->cc = $request->has('cc') ? "1" : "0";
                $rto_data_updates->update();
                DB::commit();
                session()->flash('success', 'RTO Data Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('rto.view');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_rto'])) {
            abort(403, "you don't have permission to access");
        }
        try {
            $rto_data_destroy = Rto::where('rto_id', decrypt($id))->first();

            if ($rto_data_destroy) {
                $rto_data_destroy->delete();
                DB::commit();

                session()->flash('success', 'RTO Data Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong!');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('rto.view');
    }


    public function fetchRecord(Request $request)
    {

        if($request->ajax()) {
            $limit = ($request->has('length') ? $request->input('length') : 10);
            $page = ($request->has('start') ? $request->input('start') : 0);
            $search = ($request->has('search') ? $request->input('search')['value'] : '');

            $rto_view = Rto::select(
                'cop_rto_ms.rto_id',
                'cop_rto_ms.rto_type',
                'cop_rto_ms.pre_condition',
                'cop_rto_ms.pre_amount',
                'cop_rto_ms.post_condition',
                'cop_rto_ms.post_amount',
                'cop_rto_ms.percentage',
                'cop_rto_ms.fuel_type',
                'cop_state_ms.state_name',
            )
            ->join('cop_state_ms','cop_state_ms.state_id','=','cop_rto_ms.state_id');

            if (!empty($search)) {
                // $searchRtoType = "";
                // $length = strlen($search);
                // for ($i = 0; $i < $length; $i++) {
                //     $searchCheck = substr($search, 0, $i + 1);

                //     if (strpos("Individual", $searchCheck) !== false) {
                //         $searchRtoType = 'I';
                //     }
                //     if (strpos("Corporate", $searchCheck) !== false) {
                //         $searchRtoType = 'C';
                //     }
                // }


                $rto_view->where(function ($query) use ($search) {
                    $query->orWhere('cop_rto_ms.rto_type', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_rto_ms.pre_condition', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_rto_ms.pre_amount', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_rto_ms.post_condition', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_rto_ms.post_amount', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_rto_ms.percentage', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_rto_ms.fuel_type', 'LIKE', '%' . $search . '%')
                          ->orWhere('cop_state_ms.state_name', 'LIKE', '%' . $search . '%');
                });
            }

            $cntFilter = clone $rto_view;
            $rto_view->offset($page)->limit($limit);
            $rto_view = $rto_view->get();

            $rtoTotal = DB::select("SELECT COUNT(*) AS count FROM cop_rto_ms")[0]->count;
            $data = [];
            $i = $page;
            foreach ($rto_view as $member) {
                $i++;
                if($member->rto_type == 'I'){$rto_type = 'Individual';}
                if($member->rto_type == 'C'){$rto_type = 'Corporate';}

                $action = "";
                if (auth()->user()->can('edit_rto')) {
                    $editRoute = route('rto.edit', encrypt($member->rto_id));
                    $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                            <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                }

                if (auth()->user()->can('delete_rto')) {
                    $action .= '<a href="javascript:void(0);"
                        data-href="' . route('rto.destroy', encrypt($member->rto_id)) . '"
                        class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                }
                $data[] = array("sr_no" => $i, "state_name" => $member->state_name, "rto_type" => $rto_type, "pre_condition" => $member->pre_condition, "pre_amount" => $member->pre_amount, "post_condition" => $member->post_condition, "post_amount" => $member->post_amount, "percentage" => $member->percentage, "fuel_type" => $member->fuel_type, "action" => $action);
            }
            return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $rtoTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));

        }
    }
}
