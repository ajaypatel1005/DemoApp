<?php

namespace App\Http\Controllers;

use App\Models\City;
use App\Models\State;
use App\Models\FuelStation;
use App\Rules\GoogleMapsURL;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Exception;

class FuelStationController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    public function fetchcities(Request $request)
    {
        $selectedStateId = $request->input('state_id');

        if ($selectedStateId) {
            $cities = City::where('state_id', $selectedStateId)
                ->active()
                ->get();
        } else {
            $cities = [];
        }

        return response()->json(['cities' => $cities]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_fuel_station', 'view_fuel_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $fuel_station_view = FuelStation::select('cop_f_stations_ms.*', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_city_ms', 'cop_f_stations_ms.city_id', '=', 'cop_city_ms.city_id')
            ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id')
            ->get();
        $states = DB::select('select * from cop_state_ms where status = 1');
        $city = DB::select('select * from cop_city_ms where status = 1');

        return view("fuel_station.create", compact("states", "city", "fuel_station_view"));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_fuel_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'f_station_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:2|max:30',
                'state_id' => 'required',
                'city_id' => 'required',
                'f_station_address' => 'required|min:15|max:1000|unique:cop_f_stations_ms,f_station_address',
                'f_station_location' => ['required', 'string', 'unique:cop_f_stations_ms,f_station_location', new GoogleMapsURL],
                'contact_no' => 'required|digits:10|numeric|unique:cop_f_stations_ms,contact_no',

            ],
            [
                'f_station_name.required' => 'The Fuel Station Name is required.',
                'f_station_name.regex' => 'The Fuel Station Name must contain only letters, numbers, and spaces.',
                'f_station_name.min' => 'The Fuel Station Name must be at least :min characters.',
                'f_station_name.max' => 'The Fuel Station Name must not exceed :max characters.',
                'f_station_name.unique' => 'The Fuel Station name is already taken, Please choose a different name.',

                'state_id.required' => 'The State Name is required.',
                'city_id.required' => 'The City Name is required.',

                'f_station_address.required' => 'The Fuel Station address is required.',
                'f_station_address.min' => 'The Fuel Station address must be at least :min characters.',
                'f_station_address.max' => 'The Fuel Station address must not exceed :max characters.',
                'f_station_address.unique' => 'The Fuel Station address has been already exist in another Fuel Station',

                'f_station_location.required' => 'The Fuel Station Location is required.',
                'f_station_location.unique' => 'The Fuel Station location has been already exist in another Fuel Station',
                'f_station_location.string' => 'The Fuel Station location must be a string.',

                'contact_no.required' => 'The Contact Number is required.',
                'contact_no.digits' => 'The Contact Number must be 10 digits.',
                'contact_no.numeric' => 'The Contact Number must be an number',
                'contact_no.unique' => 'The Contact Number has been already exist in another fuel station'

            ]
        );
        DB::beginTransaction();
        $fuel_station_store = new FuelStation();
        try {
            $state_id = DB::table('cop_city_ms')
                ->where('city_id', $request->city_id)
                ->value('state_id');
            $fuel_station_store->f_station_name = $request->f_station_name;
            $fuel_station_store->state_id = $state_id;
            $fuel_station_store->city_id = $request->city_id;
            $fuel_station_store->f_station_address = $request->f_station_address;
            $fuel_station_store->f_station_location = $request->f_station_location;
            $fuel_station_store->contact_no = $request->contact_no;
            $fuel_station_store->status = $request->has('status') ? 1 : 0;
            $fuel_station_store->created_by  = auth()->id();
            $fuel_station_store->save();
            DB::commit();
            session()->flash('success', 'Fuel Station Added Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('fuel_station.create');
    }

    /**
     * Display the specified resource.
     */
    public function view()
    {
        if (!hasAnyPermission(['create_fuel_station', 'view_fuel_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $fuel_station_view = FuelStation::select('cop_f_stations_ms.*', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_city_ms', 'cop_f_stations_ms.city_id', '=', 'cop_city_ms.city_id')
            ->leftJoin('cop_state_ms', 'cop_f_stations_ms.state_id', '=', 'cop_state_ms.state_id')
            ->get();

        return view('fuel_station.create', ['fuel_station_view' => $fuel_station_view]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_fuel_station', 'view_fuel_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $fuel_station_view = FuelStation::select('cop_f_stations_ms.*', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
            ->leftJoin('cop_city_ms', 'cop_f_stations_ms.city_id', '=', 'cop_city_ms.city_id')
            ->leftJoin('cop_state_ms', 'cop_f_stations_ms.state_id', '=', 'cop_state_ms.state_id')
            ->get();
        $fuel_station_edit = FuelStation::where('f_station_id', decrypt($id))->first();

        if ($fuel_station_edit) {

            $city_id = $fuel_station_edit->city_id;

            // dump('City ID:', $city_id);

            $selected_states = DB::table('cop_city_ms')->where('city_id', $city_id)->value('state_id');

            if ($selected_states) {

                $state_name = DB::table('cop_state_ms')->where('state_id', $selected_states)->value('state_name');

                //    dump('State Name:', $state_name);
            }


            $states = State::active()->get();
            $city = City::active()
                ->get();

            return view('fuel_station.edit', compact('fuel_station_view', 'fuel_station_edit', 'states', 'city', 'selected_states'));
        }
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_fuel_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $request->validate(
            [
                'f_station_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|min:2|max:30',
                'state_id' => 'required',
                'city_id' => 'required',
                'f_station_address' => 'required|min:15|max:1000|unique:cop_f_stations_ms,f_station_address,' . decrypt($id) . ',f_station_id',
                'f_station_location' => ['required', 'string', 'unique:cop_f_stations_ms,f_station_location,' . decrypt($id) . ',f_station_id', new GoogleMapsURL],
                'contact_no' => 'required|digits:10|numeric|unique:cop_f_stations_ms,contact_no,' . decrypt($id) . ',f_station_id',

            ],
            [
                'f_station_name.required' => 'The Fuel Station Name is required.',
                'f_station_name.regex' => 'The Fuel Station Name must contain only letters, numbers, and spaces.',
                'f_station_name.min' => 'The Fuel Station Name must be at least :min characters.',
                'f_station_name.max' => 'The Fuel Station Name must not exceed :max characters.',

                'state_id.required' => 'The State Name is required.',
                'city_id.required' => 'The City Name is required.',

                'f_station_address.required' => 'The Fuel Station address is required.',
                'f_station_address.min' => 'The Fuel Station address must be at least :min characters.',
                'f_station_address.max' => 'The Fuel Station address must not exceed :max characters.',
                'f_station_address.unique' => 'The Fuel Station address has been already exist in another Fuel Station',

                'f_station_location.required' => 'The Fuel Station Location is required.',
                'f_station_location.unique' => 'The Fuel Station location has been already exist in another Fuel Station',
                'f_station_location.string' => 'The Fuel Station location must be a string.',

                'contact_no.required' => 'The Contact Number is required.',
                'contact_no.digits' => 'The Contact Number must be 10 digits.',
                'contact_no.numeric' => 'The Contact Number must be an number',
                'contact_no.unique' => 'The Contact Number has been already exist in another fuel station'

            ],
        );

        DB::beginTransaction();
        $fuel_station_update = FuelStation::where('f_station_id', decrypt($id))->first();
        // dd($menu_update);
        try {
            $state_id = DB::table('cop_city_ms')
                ->where('city_id', $request->city_id)
                ->value('state_id');
            $fuel_station_update->f_station_name = $request->f_station_name;
            $fuel_station_update->state_id = $state_id;
            $fuel_station_update->city_id = $request->city_id;
            $fuel_station_update->f_station_address = $request->f_station_address;
            $fuel_station_update->f_station_location = $request->f_station_location;
            $fuel_station_update->contact_no = $request->contact_no;


            $fuel_station_update->status = $request->has('status') ? 1 : 0;
            $fuel_station_update->update();
            DB::commit();
            session()->flash('success', 'Fuel Station Updated Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('fuel_station.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_fuel_station'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $fuel_station_destroy = FuelStation::where('f_station_id', decrypt($id))->first();

            if (!empty($fuel_station_destroy)) {
                $fuel_station_destroy->delete();
                DB::commit();
                session()->flash('success', 'Fuel Station Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('fuel_station.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_f_stations_ms')
            ->where('f_station_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            try {
                $limit = ($request->has('length') ? $request->input('length') : 10);
                $page = ($request->has('start') ? $request->input('start') : 0);
                $search = ($request->has('search') ? $request->input('search')['value'] : '');
                $fuel_station_view = FuelStation::select('cop_f_stations_ms.f_station_id', 'cop_f_stations_ms.status', 'cop_f_stations_ms.f_station_name', 'cop_city_ms.city_name as city_name', 'cop_state_ms.state_name as state_name')
                    ->leftJoin('cop_city_ms', 'cop_f_stations_ms.city_id', '=', 'cop_city_ms.city_id')
                    ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id');
                if (!empty($search)) {
                    $fuel_station_view->where(function ($query) use ($search) {
                        $query->orWhere('cop_f_stations_ms.f_station_name', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_state_ms.state_name', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_city_ms.city_name', 'LIKE', '%' . $search . '%');
                    });
                }

                $cntFilter = clone $fuel_station_view;
                $fuel_station_view->offset($page)->limit($limit);
                $fuel_station_view = $fuel_station_view->get();

                $fuelStationTotal = DB::select("SELECT COUNT(*) AS count FROM cop_f_stations_ms")[0]->count;
                $data = [];
                $i = $page;
                foreach ($fuel_station_view as $member) {
                    $i++;
                    $status = $disable = "";
                    if ($member->status == 1) {
                        $status = 'checked';
                    }
                    $disable = (!auth()->user()->can('edit_fuel_station')) ? 'disabled' : '';

                    $model_status = '<div
                        class="form-check form-switch form-check-custom form-check-success form-check-solid">
                        <input class="form-check-input" name="status" type="checkbox" value="' . $member->f_station_id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>';
                    $action = "";
                    if (auth()->user()->can('edit_fuel_station')) {
                        $editRoute = route('fuel_station.edit', encrypt($member->f_station_id));
                        $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                                <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                    }
                    if (auth()->user()->can('delete_fuel_station')) {
                        $action .= '<a href="javascript:void(0);"
                            data-href="' . route('fuel_station.delete', encrypt($member->f_station_id)) . '"
                            class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                    }
                    $data[] = array("sr_no" => $i, "f_station_name" => $member->f_station_name, "state_name" => $member->state_name, "city_name" => $member->city_name, "status" => $model_status, "action" => $action);
                }
                return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $fuelStationTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            }
        }
    }
}
