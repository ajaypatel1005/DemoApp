<?php

namespace App\Http\Controllers;

use App\Exports\CarGraphicExport;
use App\Exports\ModelImageUrlExport;
use App\Models\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class ImageUrlController extends Controller
{
    public function index()
    {
        $model_view = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
            ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
            ->select(
                'cop_models.model_id',
                'cop_models.launch_date',
                'cop_models.model_year',
                'cop_models.model_image',
                'cop_models.cbu_status',
                'cop_models.model_name',
                'cop_models.status',
                'cop_cs_ms.cs_name',
                'cop_brands_ms.brand_name',
                'cop_models.brand_id',
                'cop_ct_ms.ct_name',
                DB::raw("CASE WHEN cop_models.model_type=0 THEN 'Non EV' WHEN cop_models.model_type=1 THEN 'EV' ELSE NULL END as model_type")
            )->where('cop_brands_ms.status', '=', 1)->where('cop_models.status', '=', '1'); // check brand is active

        $model_view = $model_view->get();
        return Excel::download(new ModelImageUrlExport, 'model_image_url.xlsx');
    }

    public function graphicsUrl()
    {
        return Excel::download(new CarGraphicExport, 'graphics_image_url.xlsx');
    }
}
