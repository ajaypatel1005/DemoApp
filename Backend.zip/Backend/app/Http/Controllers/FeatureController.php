<?php

namespace App\Http\Controllers;

use App\Models\Feature;
use App\Models\FeatureOption;
use App\Models\StandardUnit;
use App\Models\Specification;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class FeatureController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (!hasAnyPermission(['create_feature', 'view_feature'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        try {
            $StandardUnit = StandardUnit::get();
            $feature_option = FeatureOption::all();
            $spec_name = Specification::active()->get();
            $featureLists = Feature::select('cop_features_ms.*', 'cop_spec_ms.spec_name as spec_name', 'cop_fo_ms.fo_value as fo_value', 'cop_su_ms.su_name as su_name')
                ->leftJoin('cop_spec_ms', 'cop_features_ms.spec_id', '=', 'cop_spec_ms.spec_id')
                ->leftJoin('cop_fo_ms', 'cop_features_ms.fo_id', '=', 'cop_fo_ms.fo_id')
                ->leftJoin('cop_su_ms', 'cop_features_ms.su_id', '=', 'cop_su_ms.su_id')
                ->get();
            return view('feature.create', compact('featureLists', 'StandardUnit', 'feature_option', 'spec_name'));
        } catch (Exception $e) {
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_feature', 'view_feature'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $StandardUnit = StandardUnit::get();
        $feature_option = FeatureOption::all();
        $spec_name = Specification::active()->get();
        return view("feature.create", ['feature_option' => $feature_option, 'spec_name' => $spec_name, 'StandardUnit' => $StandardUnit]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_feature'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'fuel_type' => 'required',
                'spec_id' => 'required',
                'features_name' => 'required|min:2|max:30',
                'fo_id' => 'required',
                'features_image' => 'nullable|image|mimes:svg|max:2048',
            ],
            [
                'fuel_type.required' => 'The Fuel Type is required.',
                'spec_id.required' => 'The Specifications is required.',
                'features_name.required' => 'The Feature Name is required.',
                'features_name.min' => 'The Feature Name must be at least :min characters.',
                'features_name.max' => 'The Feature Name must not exceed :max characters.',
                'fo_id.required' => 'The Feature Option is required.',
                'features_image.image' => 'This must be an Image',
                'features_image.mimes' => 'Feature Image must be svg',
                'features_image.max' => 'Feature Image should not be greater than 2 MB',
            ]
        );

        DB::beginTransaction();
        try {

            $feature_store = new Feature;
            $feature_store->fuel_type = $request->fuel_type;
            $feature_store->spec_id = $request->spec_id;
            $feature_store->features_name = $request->features_name;
            $feature_store->su_id = $request->su_id;
            $feature_store->fo_id = $request->fo_id;
            $feature_store->status = $request->has('status') ? 1 : 0;
            $feature_store->save();

            $feature_id = $feature_store->feature_id;
            $features_image_Uploaded_File = $request->file('features_image');
            if (!empty($features_image_Uploaded_File)) {
                $feature_Uploaded_File = $request->file('features_image');
                $imageImageName = $feature_id . '.' . $feature_Uploaded_File->getClientOriginalExtension();
                $imagePath = 'Feature/' . $feature_id . '/' . $imageImageName;
                $content = file_get_contents($feature_Uploaded_File->getRealPath());
                Storage::disk('digitalocean')->put($imagePath, $content, [
                    'visibility' => 'public',
                    'ContentType' => 'image/svg+xml'
                ]);
                $feature_store->features_image = $imageImageName;
                $feature_store->update();
            }
            DB::commit();
            session()->flash('success', 'Feature Added Successfully.');
            return redirect()->route('feature.create');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('feature.create');
    }

    /**
     * Display the specified resource.
     */
    public function view()
    {
        if (!hasAnyPermission(['view_feature'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $feature_view = Feature::select('features.*', 'specifications.spec_name as spec_name', 'feature_options.feature_option_value as feature_option_value', 'standard_units.unit_name as unit_name')
            ->leftJoin('specifications', 'features.spec_id', '=', 'specifications.spec_id')
            ->leftJoin('feature_options', 'features.feature_option_id', '=', 'feature_options.feature_option_id')
            ->leftJoin('standard_units', 'features.unit_id', '=', 'standard_units.unit_id')
            ->get();
        return view('feature.view', ['feature_view' => $feature_view]);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['view_feature', 'edit_feature'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $feature_edit = Feature::where('feature_id', decrypt($id))->first();
        $feature_option = FeatureOption::all();
        $spec_name = Specification::active()->get();
        $StandardUnit = StandardUnit::get();
        $featureLists = Feature::select('cop_features_ms.*', 'cop_spec_ms.spec_name as spec_name', 'cop_fo_ms.fo_value as fo_value', 'cop_su_ms.su_name as su_name')
            ->leftJoin('cop_spec_ms', 'cop_features_ms.spec_id', '=', 'cop_spec_ms.spec_id')
            ->leftJoin('cop_fo_ms', 'cop_features_ms.fo_id', '=', 'cop_fo_ms.fo_id')
            ->leftJoin('cop_su_ms', 'cop_features_ms.su_id', '=', 'cop_su_ms.su_id')
            ->get();
        return view('feature.edit', compact('feature_edit', 'feature_option', 'spec_name', 'StandardUnit', 'featureLists'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_feature'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'fuel_type' => 'required',
                'spec_id' => 'required',
                'features_name' => 'required|min:2|max:50',
                'fo_id' => 'required',
                'features_image' => 'nullable|image|mimes:svg|unique:cop_features_ms,features_image,' . decrypt($id) . ',feature_id|max:2048',
            ],
            [
                'fuel_type.required' => 'The Fuel Type is required.',
                'spec_id.required' => 'The Specifications is required.',
                'features_name.required' => 'The Feature Name is required.',
                'features_name.min' => 'The Feature Name must be at least 2:min characters.',
                'features_name.max' => 'The Feature Name must not exceed 50:max characters.',
                'fo_id.required' => 'The Feature Option is required.',
                'features_image.image' => 'This must be an Image',
                'features_image.mimes' => 'Feature Image must be svg',
                'features_image.max' => 'Image should not be greater than 2 MB',
            ]
        );
        DB::beginTransaction();
        try {
            $feature_update = Feature::where('feature_id', decrypt($id))->first();
            $imagePath = 'Feature/' . $feature_update->feature_id;

            if ($feature_update) {
                if ($request->hasFile('features_image')) {
                    // Update brand_logo
                    Storage::disk('digitalocean')->deleteDirectory($imagePath);

                    $feature_Uploaded_File = $request->file('features_image');
                    $imageImageName = $feature_update->feature_id . '.' . $feature_Uploaded_File->getClientOriginalExtension();
                    $feature_update->features_image = $imageImageName;
                    // upload image in s3
                    $imagePath = 'Feature/' . $feature_update->feature_id . '/' . $imageImageName;
                    $content = file_get_contents($feature_Uploaded_File->getRealPath());
                    Storage::disk('digitalocean')->put($imagePath, $content, [
                        'visibility' => 'public',
                        'ContentType' => 'image/svg+xml'
                    ]);
                }

                $feature_update->fuel_type = $request->fuel_type;
                $feature_update->spec_id = $request->spec_id;
                $feature_update->features_name = $request->features_name;
                $feature_update->su_id = $request->su_id;
                $feature_update->fo_id = $request->fo_id;
                $feature_update->status = $request->has('status') ? 1 : 0;
                $feature_update->update();
                DB::commit();
                session()->flash('success', 'Feature Update Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('feature.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_feature'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $feature_destroy = Feature::where('feature_id', decrypt($id))->first();
            $imagePath = 'Feature/' . $feature_destroy->feature_id;
            if ($feature_destroy) {
                Storage::disk('digitalocean')->deleteDirectory($imagePath);
                $feature_destroy->delete();
                DB::commit();
                session()->flash('success', 'Feature Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('feature.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_features_ms')
            ->where('feature_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

    public function delete_image(Request $request)
    {
        $id = $request->feature_id;
        $new_image = '';

        // Get the current image path from the database
        $currentImagePath = DB::table('cop_features_ms')->where('feature_id', $id)->value('features_image');

        // Delete the image file if it exists
        if ($currentImagePath) {
            Storage::disk('digitalocean')->deleteDirectory($currentImagePath);
        }

        // Get the feature data for the folder path
        $feature_destroy = Feature::where('feature_id', $id)->first();

        // Delete the image folder if it exists
        $imagePath = 'Feature/' . $feature_destroy->feature_id;
        Storage::disk('digitalocean')->deleteDirectory($imagePath);

        // Update the features_image column to an empty string in the database
        DB::table('cop_features_ms')->where('feature_id', $id)->update(['features_image' => $new_image]);

        // Retrieve updated feature data
        $arr = Feature::where('feature_id', $id)->get();

        return view('feature.ajax_delete_image', ['new_feature_data' => $arr]);
    }

    public function fetchRecord(Request $request)
    {

        if ($request->ajax()) {
            try {
                $limit = ($request->has('length') ? $request->input('length') : 10);
                $page = ($request->has('start') ? $request->input('start') : 0);
                $search = ($request->has('search') ? $request->input('search')['value'] : '');
                $featureLists = Feature::select('cop_features_ms.feature_id', 'cop_features_ms.features_name', 'cop_features_ms.status', 'cop_spec_ms.spec_name', 'cop_fo_ms.fo_value', 'cop_su_ms.su_name', DB::raw('CASE WHEN cop_features_ms.fuel_type=0 THEN "Non-EV" WHEN cop_features_ms.fuel_type=1 THEN "EV" WHEN cop_features_ms.fuel_type=2 THEN "Both" END as fuel_type'))
                    ->leftJoin('cop_spec_ms', 'cop_features_ms.spec_id', '=', 'cop_spec_ms.spec_id')
                    ->leftJoin('cop_fo_ms', 'cop_features_ms.fo_id', '=', 'cop_fo_ms.fo_id')
                    ->leftJoin('cop_su_ms', 'cop_features_ms.su_id', '=', 'cop_su_ms.su_id');

                if (!empty($search)) {
                    $featureLists->where(function ($query) use ($search) {
                        $query->orWhere('cop_features_ms.features_name', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_spec_ms.spec_name', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_fo_ms.fo_value', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_su_ms.su_name', 'LIKE', '%' . $search . '%');
                    });
                }

                $cntFilter = clone $featureLists;
                $featureLists->offset($page)->limit($limit);
                $featureLists = $featureLists->get();

                $featuresTotal = DB::select("SELECT COUNT(*) AS count FROM cop_features_ms")[0]->count;
                $data = [];
                $i = $page;
                foreach ($featureLists as $member) {
                    $i++;
                    $status = $disable = "";
                    if ($member->status == 1) {
                        $status = 'checked';
                    }
                    $disable = (!auth()->user()->can('edit_feature')) ? 'disabled' : '';

                    $model_status = '<div
                        class="form-check form-switch form-check-custom form-check-success form-check-solid">
                        <input class="form-check-input" name="status" type="checkbox" value="' . $member->feature_id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>';
                    $action = "";
                    if (auth()->user()->can('edit_feature')) {
                        $editRoute = route('feature.edit', encrypt($member->feature_id));
                        $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                                <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                    }
                    if (auth()->user()->can('delete_feature')) {
                        $action .= '<a href="javascript:void(0);"
                            data-href="' . route('feature.delete', encrypt($member->feature_id)) . '"
                            class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                    }
                    $data[] = array("sr_no" => $i, "spec_name" => $member->spec_name, "features_name" => $member->features_name, "fuel_type" => $member->fuel_type, "status" => $model_status, "action" => $action);
                }
                return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $featuresTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            }
        }
    }
}
