<?php

namespace App\Http\Controllers;

use App\Models\B2BInquiry;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class B2BInquiryController extends Controller
{
    public function index(Request $request)
    {
        if (!hasAnyPermission(['view_b2b_inquiry', 'delete_b2b_inquiry'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        if ($request->ajax()) {
            $limit = ($request->has('length') ? $request->input('length') : 10);
            $page = ($request->has('start') ? $request->input('start') : 0);
            $search = ($request->has('search') ? $request->input('search')['value'] : '');
            $orderColumn = $request->input('order.0.column');
            $orderDirection = $request->input('order.0.dir');

            $inquiryList = B2BInquiry::select('full_name', 'dealer_id', 'contact_no', 'email', 'dealer_name', 'created_at');

            if (!empty($search)) {
                $inquiryList->where(function ($query) use ($search) {
                    $query->orWhere('b2b_dealer_inquiry.full_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('b2b_dealer_inquiry.contact_no', 'LIKE', '%' . $search . '%')
                        ->orWhere('b2b_dealer_inquiry.email', 'LIKE', '%' . $search . '%')
                        ->orWhere('b2b_dealer_inquiry.dealer_name', 'LIKE', '%' . $search . '%');
                });
            }

            $cntFilter = clone $inquiryList;

            $column = $columns[$orderColumn] ?? 'created_at';
            $inquiryList->orderBy($column, $orderDirection)->offset($page)->limit($limit);
            $inquiryList = $inquiryList->get();
            
            $featuresTotal = DB::select("SELECT COUNT(*) AS count FROM b2b_dealer_inquiry")[0]->count;
            $data = [];
            $i = $page;
            foreach ($inquiryList as $list) {
                $i++;
                $action = "";
                // if (auth()->user()->can('delete_b2b_inquiry')) {
                //     $action .= '<a href="javascript:void(0);"
                //     data-href="' . route('b2b-inquiry-delete', encrypt($list->dealer_id)) . '"
                //     class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                // }
                $createdAt = Carbon::parse($list->created_at)->format('d-m-Y');
                $data[] = array("sr_no" => $i, "created_at" => $createdAt, "full_name" => $list->full_name, "dealer_id" => $list->dealer_id, "contact_no" => $list->contact_no, "email" => $list->email, 'dealer_name' => $list->dealer_name);
            }
            return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $featuresTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
        }
        return view('b2b_inquiry.index');
    }


    public function delete($id)
    {
        if (!hasAnyPermission(['delete_b2b_inquiry'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $inquiry = B2BInquiry::where('dealer_id', decrypt($id))->first();
            if (!empty($inquiry)) {
                $inquiry->delete();
                DB::commit();
                session()->flash('success', 'B2B Inquiry has been deleted successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('b2b-inquiry');
    }
}
