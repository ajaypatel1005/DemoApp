<?php

namespace App\Http\Controllers;


use App\Models\Brand;
use App\Models\City;
use App\Models\Model;
use App\Models\PriceEntry;
use App\Models\Variant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Exception;


class PriceUpdateController extends Controller
{


    /**
     * Get active models of selected brand.
     * accept brand_id
     * @var int
     */

    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');
        if ($selectedBrandId) {
            $models = Model::where('brand_id', $selectedBrandId)
                ->active()
                ->get();
        } else {
            $models = [];
        }

        return response()->json(['models' => $models]);
    }

    public function create()
    {
        if (!hasAnyPermission(['create_price_entry', 'edit_price_entry', 'delete_price_entry', 'view_price_entry'])) {
            abort(403, "you don't have permission to access");
        }
        $brands = Brand::active()->get();
        return view("price_update.create", compact("brands"));
    }

    public function view(Request $request)
    {
        if (!hasAnyPermission(['create_price_entry', 'edit_price_entry', 'delete_price_entry', 'view_price_entry'])) {
            abort(403, "you don't have permission to access");
        }
        $valid=[];
        $valid_msg=[];
        $update_price_type = $request->input('update_price_type');
        // Check if update_price_type exists in the request before accessing it
        if ($update_price_type) {
            
            if ($update_price_type == "per") {
                // Apply validation rules for update_price_per if update_price_type is "per"
                $valid =[
                    'update_price_per' => 'required|numeric|between:0,100',
                ];
                $valid_msg = [
                    'update_price_per.required' => "Percentage is required",
                    'update_price_per.numeric' => "Percentage only accept numeric or float value",
                    'update_price_per.between' => "Percentage should be between 0 to 100"
                ];
            } else {
                // Apply validation rules for update_price_amt if update_price_type is not "per"
                $valid=[
                    'update_price_amt' => 'required|numeric'
                ];
                $valid_msg=[
                    'update_price_amt.required' => "Amount is required",
                    'update_price_per.numeric' => "Amount only accept numeric or float value",
                ];
            }
        }
        $validate=array_merge([
            'brand_id' => 'required',
            'tier' => 'required',
            'type' => 'required'
        ],$valid);
        $validate_msg=array_merge([
            'brand_id.required' => 'Brand Name is required',
            'tier.required' => 'Tier is required',
            'type.required' => 'Type is required',
        ],$valid_msg);
        $request->validate(
            $validate,
            $validate_msg
        );

        $brandId = $request->input('brand_id');
        $modelId = $request->input('model_id');
        $tier = $request->input('tier');
        $type = $request->input('type');
        
        
        $update_price_per = $request->input('update_price_per');
        $update_price_amt = $request->input('update_price_amt');

        $selectData = "";
        if ($update_price_type == "per") {
            $selectData = "cop_pe_ms.ex_showroom_price ".$type." (cop_pe_ms.ex_showroom_price*".$update_price_per."/100) as new_exshowroom";
        }else{
            $selectData = "(cop_pe_ms.ex_showroom_price ".$type."".$update_price_amt.") as new_exshowroom";
        }
        
        try{
            $variants = PriceEntry::select("cop_brands_ms.brand_name","cop_models.model_name","cop_variants.variant_id","cop_variants.variant_name","cop_pe_ms.ex_showroom_price","cop_city_ms.city_id",DB::raw($selectData))
            ->join("cop_brands_ms","cop_brands_ms.brand_id","=","cop_pe_ms.brand_id")
                        ->join("cop_models","cop_models.model_id","=","cop_pe_ms.model_id")
                        ->join("cop_variants","cop_variants.variant_id","=","cop_pe_ms.variant_id")
                        ->join("cop_city_ms","cop_city_ms.city_id","=","cop_pe_ms.city_id")
                        ->where([["cop_city_ms.tier","=",$tier],["cop_pe_ms.brand_id","=",$brandId]])               
                        ;
            if($modelId != ""){
                $variants->where('cop_pe_ms.model_id','=',$modelId);
            }
            // dd($variants->toSql());
            $variants = $variants->get();
            
            // $qry = "CASE WHEN cop_models.cbu_status = 1 THEN cop_state_ms.cbu_rto ELSE cop_state_ms.rto_per END as rto_tax";
            // ,DB::raw($qry)
            $getData = Variant::select("cop_brands_ms.brand_name","cop_models.model_name","cop_variants.variant_name","cop_pe_ms.ex_showroom_price","cop_city_ms.city_id","cop_city_ms.city_name","cop_state_ms.state_id",DB::raw($selectData))
            ->leftjoin("cop_pe_ms","cop_pe_ms.variant_id","=","cop_variants.variant_id")
            ->leftjoin("cop_models","cop_models.model_id","=","cop_variants.model_id")
            ->leftjoin("cop_brands_ms","cop_brands_ms.brand_id","=","cop_models.brand_id")
            ->leftjoin("cop_city_ms","cop_city_ms.city_id","=","cop_pe_ms.city_id")
            ->leftjoin("cop_state_ms","cop_state_ms.state_id","=","cop_city_ms.state_id")
            ->where([['cop_brands_ms.brand_id','=',$brandId],['cop_city_ms.tier','=',$tier]]);
            if($modelId != ""){
                $getData->where('cop_pe_ms.model_id','=',$modelId);
            }
            // dd($getData->toSql());
            $getData = $getData->get();
            return view("price_update.view", compact("variants","getData"));
        }catch (Exception $e) {
           Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('price_update.create');
    }

    
}
