<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\CarGraphic;
use App\Models\CarGraphicType;
use App\Models\CarStage;
use App\Models\CarType;
use App\Models\Model;
use App\Models\ModelSpecDisplay;
use App\Models\Rating;
use App\Models\RatingType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use DateTime;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use HTMLPurifier;
use HTMLPurifier_Config;

class ModelController extends Controller
{

    public function fetchupcoming(Request $request)
    {
        $selectedCarStageId = $request->input('cs_id');

        if ($selectedCarStageId) {
            $carStage = CarStage::where('cs_id', $selectedCarStageId)->first();
            if ($carStage && ($carStage->cs_name === 'Upcoming' || $carStage->cs_name === 'Unveiled')) {
                $currentDate = date('d-m-Y');
                $after5Years = date('d-m-Y', strtotime('+5 years', strtotime($currentDate)));

                $oldLaunchDate = old('launch_date', $request->launch_date ?? '');
                $formattedOldLaunchDate = $oldLaunchDate ? date('d-m-Y', strtotime($oldLaunchDate)) : '';

                $isUpcoming = '
                        <label for="carStageName1" class="mb-2 required">Select Launch Date:</label>
                        <div class="form-group col-lg-6">
                        <div class="input-group" id="kt_td_picker_localization" data-td-target-input="nearest" data-td-target-toggle="nearest">

                            <input type="text" class="form-control" data-td-target="#kt_td_picker_localization" name="launch_date" min="' . $currentDate . '" max="' . $after5Years . '"
                            value="' . $formattedOldLaunchDate . '" placeholder="DD-MM-YYYY" readonly/>
                            <span class="input-group-text" data-td-target="#kt_td_picker_localization" data-td-toggle="datetimepicker">
                                <i class="ki-duotone ki-calendar fs-2"><span class="path1"></span><span class="path2"></span></i>
                            </span>
                        </div>
                        </div>
                        <script>
                        new tempusDominus.TempusDominus(document.getElementById("kt_td_picker_localization"), {
                            localization: {
                                locale: "en",
                                startOfTheWeek: 1,
                                format: "dd-MM-yyyy",
                            },
                            restrictions: {
                                minDate: "' . $currentDate . '",
                                maxDate: "' . $after5Years . '",
                                }
                        });
                        </script>
                ';
                // <div class="form-group col-lg-6 mb-6">
                //                     <label for="carStageName1" class="mb-2">Select Date:</label>
                //                     <input type="date" id="carStageName1" class="form-control" name="launch_date"
                //                         min="' . $currentDate . '" max="' . $after5Years . '"
                //                         value="' . $formattedOldLaunchDate . '" />
                //                 </div>
            } else if ($carStage && $carStage->cs_name === 'Launched') {
                $currentDate = date('d-m-Y');
                $before15Years = date('d-m-Y', strtotime('-15 years', strtotime($currentDate)));

                $oldLaunchDate = old('launch_date', $request->launch_date ?? '');
                $formattedOldLaunchDate = $oldLaunchDate ? date('d-m-Y', strtotime($oldLaunchDate)) : '';

                $isUpcoming = '
                        <label for="carStageName1" class="mb-2 required">Select Launch Date:</label>
                        <div class="form-group col-lg-6">
                            <div class="input-group" id="kt_td_picker_localization" data-td-target-input="nearest" data-td-target-toggle="nearest">
                                <input type="text" class="form-control" data-td-target="#kt_td_picker_localization" name="launch_date" min="' . $before15Years . '" max="' . $currentDate . '"
                                value="' . $formattedOldLaunchDate . '" placeholder="DD-MM-YYYY" readonly/>
                                <span class="input-group-text" data-td-target="#kt_td_picker_localization" data-td-toggle="datetimepicker">
                                    <i class="ki-duotone ki-calendar fs-2"><span class="path1"></span><span class="path2"></span></i>
                                </span>
                            </div>
                        </div>
                        <script>
                        new tempusDominus.TempusDominus(document.getElementById("kt_td_picker_localization"), {
                            localization: {
                                locale: "en",
                                startOfTheWeek: 1,
                                format: "dd-MM-yyyy",
                            }
                        });
                        </script>';
            } else {
                $carStage = null;
                $isUpcoming = null;
            }
        } else {
            $carStage = null;
            $isUpcoming = null;
        }

        return response()->json(['car_stage' => $carStage, 'is_upcoming' => $isUpcoming]);
    }




    public function create()
    {

        if (!hasAnyPermission(['create_model'])) {
            abort(403, "you don't have permission to access");
        }
        $car_stages = CarStage::all();
        $car_types = DB::select('select * from cop_ct_ms');
        $brands = Brand::active()->get();
        return view('model.create', compact('car_stages', 'car_types', 'brands'));
    }

    public function store(Request $request)
    {

        Validator::extend('gt_or_equal', function ($attribute, $value, $parameters, $validator) {
            $minValue = $validator->getData()[$parameters[0]];
            return $value >= $minValue;
        });
        // dd($request->all());
        if (!hasAnyPermission(['edit_model'])) {
            abort(403, "you don't have permission to access");
        }
        // dd($request->all());
        $csId = $request->input('cs_id');
        $cs = CarStage::find($csId);
        $csName = $cs ? $cs->cs_name : null;
        $ratingValueRule = ($csName == 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required';
        // $modelYear = ($csName !== 'Upcoming') ? 'nullable' : 'nullable';
        // $lauchDate = ($csName == 'Upcoming') ? 'required' : 'nullable';
        // $modelDescription = ($csName == 'Upcoming') ? 'nullable' : 'required';
        $minPrice = ($csName == 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|numeric|min:200000|max:500000000';
        $maxPrice = ($csName == 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|numeric|min:200000|max:500000000|gt_or_equal:min_price';
        $modelType = ($csName == 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required';
        $modelEngine = ($csName == 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|min:1|max:20';
        $modelBhp = ($csName == 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|min:1|max:20';
        $modelTransmission = ($csName == 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|min:1|max:20';
        $modelMileage = ($csName == 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|min:1|max:20';
        $modelFuel = ($csName == 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|min:1|max:30';
        // $modelName = $request->model_type == 0 ? 'None Ev' : 'Ev';
        $modelRatingTypeRule = ($csName == 'Launched' || $csName === 'Unveiled')
            ? [
                'required',
                Rule::in(['NCAP', 'BCAP']), // Assuming you want to validate against specific values
            ]
            : 'nullable';

        $request->validate(
            [
                'cs_id' => 'required',
                'ct_id' => 'required',
                'brand_id' => 'required',

                'model_name' => [
                    'required',
                    'min:2',
                    'max:30',
                    Rule::unique('cop_models')->where(function ($q) use ($request) {
                        return $q->where('model_type', $request->model_type)
                            ->where('model_name', $request->model_name);
                    }),
                ],
                'model_image' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
                'model_image_mob' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
                // 'model_description_hidden' => 'required',
                'launch_date' => ['required', function ($attribute, $value, $fail) use ($csName) {
                    $launchDateGet = \Carbon\Carbon::createFromFormat('d-m-Y', $value);
                    $launchDate = $launchDateGet->toDateString();
                    $todayGet = \Carbon\Carbon::today();
                    $today = $todayGet->toDateString();

                    if (($csName === 'Upcoming' || $csName === 'Unveiled') && $launchDate <= $today) {
                        $fail('The launch date must be a future date for Upcoming.');
                    }

                    if ($csName === 'Launched' && $launchDate > $today) {
                        $fail('The launch date must be today or in the past for Launched.');
                    }
                }],
                // 'model_year' => $modelYear,
                'min_price' => $minPrice,
                'max_price' => $maxPrice,
                'model_type' => $modelType,
                'model_engine' => $modelEngine,
                'model_bhp' => $modelBhp,
                'model_transmission' => $modelTransmission,
                'model_mileage' => $modelMileage,
                'model_fuel' => $modelFuel,
                'rating_value' => $ratingValueRule,
                'model_rating_type' => $modelRatingTypeRule,
            ],

            [
                'cs_id.required' => 'Select Car Stage Field is required.',
                'ct_id.required' => 'Select Car Type Field is required.',
                'brand_id.required' => 'Select Brand Field is required.',
                'model_name.required' => 'Model Name is required.',
                'model_name.min' => 'The Model Name must be at least :min characters.',
                'model_name.max' => 'The Model Name must not exceed :max characters.',
                'model_name.regex' => 'The Model Name must contain only letters, numbers, and spaces.',
                // 'model_name.unique' => 'This Model Name already exists.',
                'model_image.required' => 'Model image is required.',
                'model_image.image' => 'Model image must be an image file.',
                'model_image.mimes' => 'Model image must be a PNG, JPG, JPEG, or WebP file.',
                'model_image.max' => 'The maximum size of the image should not exceed 2MB.',
                'model_image_mob.required' => 'Model image is required.',
                'model_image_mob.image' => 'Model image must be an image file.',
                'model_image_mob.mimes' => 'Model image must be a PNG, JPG, JPEG, or WebP file.',
                'model_image_mob.max' => 'The maximum size of the image should not exceed 2MB.',
                // 'model_description_hidden.required' => 'The Model Description is required.',
                // 'model_hidden_description.regex' => 'The Model Description must contain only letters, alphanumeric, and spaces.',
                // 'model_description.min' => 'The Model Description must be at least :min characters.',
                // 'model_description.max' => 'The Model Description must not exceed :max characters.',
                // 'model_description.unique' => 'Model Description has already been taken.',
                'launch_date.required' => 'Model Launch Date is required',
                'model_year.required' => 'Model Year is required',
                'min_price.required' => 'Minimum price is required.',
                'min_price.numeric' => 'Minimum price should be numeric.',
                'min_price.min' => 'The Minimum Price must be at least :min.',
                'min_price.max' => 'The Minimum Price must not exceed :max.',
                'max_price.required' => 'Maximum Price is required.',
                'max_price.numeric' => 'Maximum Price should be numeric.',
                'max_price.min' => 'The Maximum Price must be at least :min.',
                'max_price.max' => 'The Maximum Price must not exceed :max.',
                'max_price.gt_or_equal' => 'The Maximum Price must be greater than the Minimum Price.',
                'model_type.required' => 'Model type is required.',
                'model_engine.required' => 'This Field is required.',
                'model_engine.min' => 'This Field must be at least :min characters.',
                'model_engine.max' => 'This Field must not exceed :max characters.',
                'model_bhp.required' => 'This Field is required.',
                'model_bhp.min' => 'This Field must be at least :min characters.',
                'model_bhp.max' => 'This Field must not exceed :max characters.',
                'model_transmission.required' => 'This Field is required.',
                'model_transmission.min' => 'The Transmission must be at least :min characters.',
                'model_transmission.max' => 'The Transmission must not exceed :max characters.',
                'model_mileage.required' => 'This Field is required.',
                'model_mileage.min' => 'This Field must be at least :min characters.',
                'model_mileage.max' => 'The Field must not exceed :max characters.',
                'model_fuel.required' => 'This Field is required.',
                'model_fuel.min' => 'The Field must be at least :min characters.',
                'model_fuel.max' => 'The Field must not exceed :max characters.',
                'rating_value.required' => 'Model Rating Value field is required.',
                'model_rating_type.required' => 'Model Rating Type is required.',
                'model_ncap_rating.required_if' => 'Model NCAP rating is required when rating type is NCAP and Car stage is not Upcoming.',
                'model_bcap_rating.required_if' => 'Model BCAP rating is required when rating type is BCAP and Car stage is not Upcoming.',
                'max_price.gt' => 'The maximum price must be greater than the minimum price.',
            ]
        );

        DB::beginTransaction();
        try {
            $model_store = new Model;
            if ($model_store) {

                //code for model data store
                $model_store->cs_id = $request->cs_id;
                $model_store->launch_date = $request->launch_date;

                $launchDate = DateTime::createFromFormat('d-m-Y', $request->launch_date);
                if ($launchDate !== false) {
                    $model_store->launch_date = $launchDate->format('Y-m-d');
                }
                $model_store->ct_id = $request->ct_id;
                $model_store->brand_id = $request->brand_id;
                $model_store->model_name = $request->model_name;
                $model_store->image_alt = $request->image_alt;
                $model_store->image_title = $request->image_title;
                $model_store->model_description = $request->model_description_hidden;
                $model_store->min_price = $request->min_price;
                $model_store->max_price = $request->max_price;
                $carStage = CarStage::find($request->cs_id);
                $model_store->model_year = date('Y', strtotime($request->launch_date));
                // if ($carStage->cs_name === 'Upcoming') {
                //     $model_store->model_year = date('Y', strtotime($request->launch_date));
                // } else {
                //     $model_store->model_year = $request->model_year;
                // }
                $model_store->model_type = $request->model_type;
                $model_store->cbu_status = $request->has('cbu_status') || isset($request->cbu_status) ? 1 : 0;
                $model_store->created_by = auth()->id();
                $model_store->updated_by = auth()->id();
                $model_store->status = $request->has('status') || !isset($request->status) ? 1 : 0;
                $model_store->slug = \Illuminate\Support\Str::slug($request->model_name, '-');
                $model_store->save();

                //code for find model id
                $model_update = Model::find($model_store->model_id);
                $ncap = $request->input('model_rating_type');
                $rating = $request->input('rating_value');

                if ($csName === 'Launched') {
                    $rating_store = new Rating;

                    if ($rating_store) {
                        $rating_type_name = ($ncap == 'NCAP') ? 'NCAP' : 'BCAP';
                        $rating_type = RatingType::where('rating_type_name', $rating_type_name)->first();

                        if (!$rating_type) {
                            $rating_type = new RatingType(['rating_type_name' => $rating_type_name]);
                            $rating_type->status = $request->has('status') ? 1 : 0;
                            $rating_type->save();
                        }

                        $rating_store->brand_id = $model_update->brand_id;
                        $rating_store->model_id = $model_update->model_id;
                        $rating_store->rating_type_id = $rating_type->rating_type_id;
                        $rating_store->rating_value = $rating;
                        $rating_store->save();
                    }
                }


                // code for store model image using model id
                if ($model_update) {
                    $model_id = $model_update->model_id;
                    $uploadedImage = $request->file('model_image');
                    $webpImageName = $model_id . '.webp';

                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());

                    // read image from file system
                    // main image

                    $modelImage = $manager->read($uploadedImage);

                    $logoPathImg = 'brands/' . $model_update->brand_id . '/' . $model_update->model_id . '/' . $webpImageName;
                    Storage::disk('digitalocean')->put($logoPathImg, $modelImage->toWebp(), 'public');

                    $modelImage->resize(630, 420);

                    $logoPathImgThumb = 'brands/' . $model_update->brand_id . '/' . $model_update->model_id . '/thumb/' . $webpImageName;
                    Storage::disk('digitalocean')->put($logoPathImgThumb, $modelImage->toWebp(), 'public');

                    // Begin::Mobile Image
                    $uploadedImageMob = $request->file('model_image_mob');
                    $webpImageNameMob = $model_id . '_mob.webp';
                    $imageMob = $manager->read($uploadedImageMob);

                    $logoPathMobImg = 'brands/' . $model_update->brand_id . '/' . $model_update->model_id . '/' . $webpImageNameMob;
                    Storage::disk('digitalocean')->put($logoPathMobImg, $imageMob->toWebp(), 'public');
                    // End::Mobile Image

                    $model_update->model_image = $webpImageName;
                    $model_update->model_image_mob = $webpImageNameMob;
                    $model_update->update();


                    // code for store model spec values in cop_msd table
                    $modelspec_store = new ModelSpecDisplay;

                    if ($modelspec_store) {
                        $modelspec_store->model_id = $model_update->model_id;
                        $modelspec_store->model_engine = $request->model_engine;
                        $modelspec_store->model_bhp = $request->model_bhp;
                        $modelspec_store->model_transmission = $request->model_transmission;
                        $modelspec_store->model_mileage = $request->model_mileage;
                        $modelspec_store->model_fuel = $request->model_fuel;
                        $modelspec_store->save();
                    }
                    DB::commit();
                    session()->flash('success', 'Model Added Successfully.');
                    return redirect()->route('model.view');
                } else {
                    session()->flash('error', 'Model Not Found.');
                }
            } else {
                DB::rollBack();
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('model.view');
    }

    public function view()
    {
        if (!hasAnyPermission(['view_model'])) {
            abort(403, "you don't have permission to access");
        }

        $model_view = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
            ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
            ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
            ->leftJoin('cop_ratings', function ($join) {
                $join->on('cop_ratings.model_id', '=', 'cop_models.model_id')
                    ->where('cop_cs_ms.cs_name', '!=', 'Upcoming');
            })
            ->leftJoin('cop_rating_types', 'cop_ratings.rating_type_id', '=', 'cop_rating_types.rating_type_id')
            ->select(
                'cop_models.*',
                'cop_cs_ms.cs_name',
                'cop_brands_ms.brand_name',
                'cop_ct_ms.ct_name',
                DB::raw('COALESCE(cop_ratings.rating_value, "N/A") as rating_value'),
                'cop_rating_types.rating_type_name'
            )->where('cop_brands_ms.status', '=', 1) // check brand is active
            ->distinct()
            ->get();

        return view('model.view', ['model_view' => $model_view]);
    }


    public function edit($id)
    {
        if (!hasAnyPermission(['edit_model'])) {
            abort(403, "you don't have permission to access");
        }
        $model_edit = Model::where('model_id', decrypt($id))->first();
        $car_stages = CarStage::all();
        $car_types = CarType::all();
        $brands = Brand::active()->get();
        $msd = ModelSpecDisplay::where('model_id', decrypt($id))->first();

        $rating_edit = Rating::where('model_id', decrypt($id))->first();
        $rating_type_edit = null;

        if ($rating_edit) {
            $rating_type_edit = RatingType::where('rating_type_id', $rating_edit->rating_type_id)->first();
        } else {
            $rating_edit = [];
        }

        // dd($model_edit);
        return view('model.edit', compact('model_edit', 'car_stages', 'car_types', 'brands', 'rating_edit', 'msd', 'rating_type_edit'));
    }


    public function update(Request $request, $id)
    {
        Validator::extend('gt_or_equal', function ($attribute, $value, $parameters, $validator) {
            $minValue = $validator->getData()[$parameters[0]];
            return $value >= $minValue;
        });
        if (!hasAnyPermission(['edit_model'])) {
            abort(403, "you don't have permission to access");
        }

        // dd($request->all());
        $csId = $request->input('cs_id');
        $cs = CarStage::find($csId);
        $csName = $cs ? $cs->cs_name : null;

        $ratingValueRule = ($csName === 'Launched') ? 'required' : 'nullable';
        // $modelYear = ($csName !== 'Upcoming') ? 'required' : 'nullable';
        // $lauchDate = ($csName == 'Upcoming') ? 'required' : 'nullable';
        $modelDescription = ($csName === 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'nullable|min:2|max:1000';
        $minPrice = ($csName === 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|numeric|min:200000|max:500000000';
        $maxPrice = ($csName === 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|numeric|min:200000|max:500000000|gt_or_equal:min_price';
        $modelType = ($csName === 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required';
        $modelEngine = ($csName === 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|min:1|max:20';
        $modelBhp = ($csName === 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|min:1|max:20';
        $modelTransmission = ($csName === 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|min:1|max:20';
        $modelMileage = ($csName === 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|min:1|max:20';
        $modelFuel = ($csName === 'Upcoming' || $csName === 'Unveiled') ? 'nullable' : 'required|min:1|max:30';

        $modelRatingTypeRule = ($csName === 'Launched')
            ? [
                'required',
                Rule::in(['NCAP', 'BCAP']), // Assuming you want to validate against specific values
            ]
            : 'nullable';
        $model_id = decrypt($id);

        $request->validate([
            'cs_id' => 'required',
            'ct_id' => 'required',
            'brand_id' => 'required',
            'model_name' => [
                'required',
                'min:2',
                'max:30',
                Rule::unique('cop_models')->ignore(decrypt($id), 'model_id')->where(function ($q) use ($request) {
                    return $q->where('model_type', $request->model_type)->where('model_name', $request->model_name);
                })
            ],

            'launch_date' => ['required', function ($attribute, $value, $fail) use ($csName) {
                $launchDateGet = \Carbon\Carbon::createFromFormat('d-m-Y', $value);
                $launchDate = $launchDateGet->toDateString();
                $todayGet = \Carbon\Carbon::today();
                $today = $todayGet->toDateString();

                if (($csName === 'Upcoming' || $csName === 'Unveiled') && $launchDate <= $today) {
                    $fail('The launch date must be a future date for Upcoming.');
                }

                if ($csName === 'Launched' && $launchDate > $today) {
                    $fail('The launch date must be today or in the past for Launched.');
                }
            }],
            // 'model_year' => $modelYear,
            'model_image' => 'image|mimes:png,jpg,jpeg,webp|max:2048',
            'model_image_mob' => 'image|mimes:png,jpg,jpeg,webp|max:2048',
            'model_description_hidden' => $modelDescription,
            'min_price' => $minPrice,
            'max_price' => $maxPrice,
            'model_type' => $modelType,
            'model_engine' => $modelEngine,
            'model_bhp' => $modelBhp,
            'model_transmission' => $modelTransmission,
            'model_mileage' => $modelMileage,
            'model_fuel' => $modelFuel,
            'rating_value' => $ratingValueRule,
            'model_rating_type' => $modelRatingTypeRule,
        ], [
            'cs_id.required' => 'Select Car Stage Field is required.',
            'ct_id.required' => 'Select Car Type Field is required.',
            'brand_id.required' => 'Select Brand Field is required.',
            'model_name.required' => 'Model Name is required.',
            'model_name.min' => 'The Model Name must be at least :min characters.',
            'model_name.max' => 'The Model Name must not exceed :max characters.',
            'model_name.regex' => 'The Model Name must contain only letters, numbers, and spaces.',
            // 'model_name.unique' => 'This Model Name already exists.',
            // 'model_description_hidden.required' => 'The Model Description is required.',
            'model_description.regex' => 'The Model Description must contain only letters, alphanumeric, and spaces.',
            'model_description.min' => 'The Model Description must be at least :min characters.',
            'model_description.max' => 'The Model Description must not exceed :max characters.',
            // 'model_description.unique' => 'Model Description has already been taken.',
            'launch_date.required' => 'Model Launch Date is required',
            'model_year.required' => 'Model Year is required',
            'model_image.image' => 'Model image must be an image file.',
            'model_image.mimes' => 'Model image must be a PNG, JPG, JPEG, or WebP file.',
            'model_image.max' => 'The maximum size of the image should not exceed 2MB.',
            'model_image_mob.image' => 'Model image must be an image file.',
            'model_image_mob.mimes' => 'Model image must be a PNG, JPG, JPEG, or WebP file.',
            'model_image_mob.max' => 'The maximum size of the image should not exceed 2MB.',
            'min_price.required' => 'Minimum price is required.',
            'min_price.numeric' => 'Minimum price should be numeric.',
            'min_price.min' => 'The Minimum Price must be at least :min.',
            'min_price.max' => 'The Minimum Price must not exceed :max.',
            'max_price.required' => 'Maximum Price is required.',
            'max_price.numeric' => 'Maximum Price should be numeric.',
            'max_price.min' => 'The Maximum Price must be at least :min.',
            'max_price.max' => 'The Maximum Price must not exceed :max.',
            'max_price.gt_or_equal' => 'The Maximum Price must be greater than the Minimum Price.',
            'model_type.required' => 'Model type is required.',
            'model_engine.required' => 'This Field is required.',
            'model_engine.min' => 'This Field must be at least :min characters.',
            'model_engine.max' => 'This Field must not exceed :max characters.',
            'model_bhp.required' => 'This Field is required.',
            'model_bhp.min' => 'This Field must be at least :min characters.',
            'model_bhp.max' => 'This Field must not exceed :max characters.',
            'model_transmission.required' => 'This Field is required.',
            'model_transmission.min' => 'The Transmission must be at least :min characters.',
            'model_transmission.max' => 'The Transmission must not exceed :max characters.',
            'model_mileage.required' => 'This Field is required.',
            'model_mileage.min' => 'This Field must be at least :min characters.',
            'model_mileage.max' => 'The Field must not exceed :max characters.',
            'model_fuel.required' => 'This Field is required.',
            'model_fuel.min' => 'The Field must be at least :min characters.',
            'model_fuel.max' => 'The Field must not exceed :max characters.',
            'model_rating_type.required' => 'Model Rating Type is required.',
            'rating_value.required' => 'Model Rating Value field is required.',
            'model_ncap_rating.required_if' => 'Model NCAP rating is required when rating type is NCAP and Car stage is not Upcoming.',
            'model_bcap_rating.required_if' => 'Model BCAP rating is required when rating type is BCAP and Car stage is not Upcoming.',
            'max_price.gt' => 'The maximum price must be greater than the minimum price.',
        ]);
        DB::beginTransaction();
        try {

            $model_update = Model::where('model_id', decrypt($id))->first();
            $ncap = $request->input('model_rating_type');
            $rating = $request->rating_value;

            if (!empty($model_update)) {

                $csId = $request->input('cs_id');
                $cs = CarStage::find($csId);
                $csName = $cs ? $cs->cs_name : null;

                if ($csName === 'Upcoming' || $csName === 'Unveiled') {
                    $rating_store = Rating::where('brand_id', $model_update->brand_id)
                        ->where('model_id', $model_update->model_id)
                        ->first();

                    if ($rating_store) {
                        $rating_store->delete();
                    }
                } else {

                    $rating_type_name = ($ncap == 'NCAP') ? 'NCAP' : 'BCAP';
                    $rating_type = RatingType::where('rating_type_name', $rating_type_name)->first();
                    if (!$rating_type) {
                        $rating_type = new RatingType(['rating_type_name' => $rating_type_name]);
                        $rating_type->update();
                    }

                    Rating::updateOrcreate([
                        'brand_id' => $model_update->brand_id,
                        'model_id' => $model_update->model_id
                    ], [
                        'rating_type_id' => $rating_type->rating_type_id,
                        'rating_value' => $rating,
                    ]);
                }
            }

            if ($model_update) {

                // Begin::Mobile Image
                if ($request->model_image_mob) {
                    $previousImagePathMob = public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id . '/' . $model_update->model_image_mob;
                    Storage::disk('digitalocean')->delete($previousImagePathMob);

                    $model_id = $model_update->model_id;
                    $uploadedImageMob = $request->file('model_image_mob');
                    $webpImageNameMob = $model_id . '_mob.webp';
                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());

                    $imageMob = $manager->read($uploadedImageMob);

                    $logoPathMobImg = 'brands/' . $model_update->brand_id . '/' . $model_update->model_id . '/' . $webpImageNameMob;
                    Storage::disk('digitalocean')->put($logoPathMobImg, $imageMob->toWebp(), 'public');

                    $model_update->model_image_mob = $webpImageNameMob;
                }
                // End::Mobile Image

                if ($request->model_image) {
                    $previousImagePath = public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id . '/' . $model_update->model_image;
                    Storage::disk('digitalocean')->delete($previousImagePath);

                    $previousThumbImagePath = public_path('brands') . '/' . $model_update->brand_id . '/' . $model_update->model_id . '/thumb/' . $model_update->model_image;
                    Storage::disk('digitalocean')->delete($previousThumbImagePath);



                    $model_id = $model_update->model_id;
                    $uploadedImage = $request->file('model_image');
                    $webpImageName = $model_id . '.webp';

                    // create image manager with desired driver
                    $manager = new ImageManager(new Driver());

                    // main image
                    // read image from file system
                    $image = $manager->read($uploadedImage);

                    $logoPathImg = 'brands/' . $model_update->brand_id . '/' . $model_update->model_id . '/' . $webpImageName;
                    Storage::disk('digitalocean')->put($logoPathImg, $image->toWebp(), 'public');


                    $image->resize(630, 420);

                    $logoPathImgThumb = 'brands/' . $model_update->brand_id . '/' . $model_update->model_id . '/thumb/' . $webpImageName;
                    Storage::disk('digitalocean')->put($logoPathImgThumb, $image->toWebp(), 'public');

                    $model_update->model_image = $webpImageName;
                }

                $model_update->cs_id = $request->cs_id;
                // $model_update->launch_date = date('Y-m-d', strtotime($request->launch_date));
                $model_update->launch_date = $request->launch_date;
                $launchDate = DateTime::createFromFormat('d-m-Y', $request->launch_date);
                if ($launchDate !== false) {
                    $model_update->launch_date = $launchDate->format('Y-m-d');
                }
                $model_update->ct_id = $request->ct_id;
                $model_update->brand_id = $request->brand_id;
                $model_update->model_name = $request->model_name;
                $model_update->image_alt = $request->image_alt;
                $model_update->image_title = $request->image_title;
                $model_update->model_description = $request->model_description_hidden;
                $model_update->min_price = $request->min_price;
                $model_update->max_price = $request->max_price;
                $carStage = CarStage::find($request->cs_id);
                $model_update->model_year = date('Y', strtotime($request->launch_date));
                // if ($carStage->cs_name === 'Upcoming') {
                //     $model_update->model_year = date('Y', strtotime($request->launch_date));
                // } else {
                //     $model_update->model_year = $request->model_year;
                // }
                $model_update->model_type = $request->model_type;
                $model_update->cbu_status = $request->has('cbu_status') || isset($request->cbu_status) ? 1 : 0;
                $model_update->status = $request->has('status') ? 1 : 0;
                $model_update->slug = \Illuminate\Support\Str::slug($request->model_name, '-');


                $model_update->update();

                $modelspec_store = ModelSpecDisplay::where('model_id', $model_update->model_id)->first();

                if ($modelspec_store) {
                    $modelspec_store->model_engine = $request->model_engine;
                    $modelspec_store->model_bhp = $request->model_bhp;
                    $modelspec_store->model_transmission = $request->model_transmission;
                    $modelspec_store->model_mileage = $request->model_mileage;
                    $modelspec_store->model_fuel = $request->model_fuel;

                    $modelspec_store->save();
                }

                DB::commit();
                session()->flash('success', 'Model Updated Successfully.');
            } else {
                session()->flash('error', 'Model Not Found.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', $e->getLine(), $e->getMessage());
        }
        return redirect()->route('model.view');
    }

    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_model'])) {
            abort(403, "you don't have permission to access");
        }
        DB::beginTransaction();
        try {


            $model_destroy = Model::where('model_id', decrypt($id))->first();

            if ($model_destroy) {

                if ($model_destroy->variants->isNotEmpty() || $model_destroy->banners->isNotEmpty() || $model_destroy->car_graphics->isNotEmpty() || $model_destroy->car_listing_data->isNotEmpty() || $model_destroy->price_entry->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('model.view');
                }
                // $uploadedImageDirectory = public_path('brands') . '/' . $model_destroy->brand_id . '/' . $model_destroy->model_id;
                // if (File::exists($uploadedImageDirectory)) {
                //     File::deleteDirectory($uploadedImageDirectory);
                // }

                $bucketFolder = 'brands/' . $model_destroy->brand_id . '/' . $model_destroy->model_id;
                Storage::disk('digitalocean')->deleteDirectory($bucketFolder);

                // $model_destroy->delete();
                DB::commit();
                session()->flash('success', 'Model Deleted Successfully.');
            } else {
                session()->flash('error', 'Model Not Found Or Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('model.view');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_models')
            ->where('model_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
    public function toggleCbu(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_models')
            ->where('model_id', $id)
            ->update(['cbu_status' => DB::raw('IF(cbu_status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }


    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            try {
                $limit = ($request->has('length') ? $request->input('length') : 10);
                $page = ($request->has('start') ? $request->input('start') : 0);
                $search = ($request->has('search') ? $request->input('search')['value'] : '');

                $model_view = Model::join('cop_cs_ms', 'cop_models.cs_id', '=', 'cop_cs_ms.cs_id')
                    ->leftJoin('cop_brands_ms', 'cop_models.brand_id', '=', 'cop_brands_ms.brand_id')
                    ->leftJoin('cop_ct_ms', 'cop_models.ct_id', '=', 'cop_ct_ms.ct_id')
                    ->select(
                        'cop_models.model_id',
                        'cop_models.launch_date',
                        'cop_models.model_year',
                        'cop_models.model_image',
                        'cop_models.cbu_status',
                        'cop_models.model_name',
                        'cop_models.status',
                        'cop_cs_ms.cs_name',
                        'cop_brands_ms.brand_name',
                        'cop_models.brand_id',
                        'cop_ct_ms.ct_name',
                        DB::raw("CASE WHEN cop_models.model_type=0 THEN 'Non EV' WHEN cop_models.model_type=1 THEN 'EV' ELSE NULL END as model_type")
                    )->where('cop_brands_ms.status', '=', 1); // check brand is active
                if (!empty($search)) {
                    $model_view->where(function ($query) use ($search) {
                        $query->orWhere('cop_cs_ms.cs_name', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_ct_ms.ct_name', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_brands_ms.brand_name', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_models.model_name', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_models.launch_date', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_models.model_year', 'LIKE', '%' . $search . '%');
                    });
                }

                $cntFilter = clone $model_view;
                $model_view->offset($page)->limit($limit);
                $model_view = $model_view->get();

                $ModelTotal = DB::select("SELECT COUNT(*) AS count FROM cop_models")[0]->count;
                $data = [];
                $i = $page;
                foreach ($model_view as $member) {
                    $i++;
                    $status = $disable = "";
                    if ($member->status == 1) {
                        $status = 'checked';
                    }
                    $disable = (!auth()->user()->can('edit_model')) ? 'disabled' : '';

                    // dd($member->cs_name);
                    $launch_date = $member->launch_date;
                    // if ($member->cs_name == config('constant.LAUNCHED')) {
                    //     $launch_date = $member->model_year;
                    // } else if ($member->cs_name == config('constant.UPCOMING')) {
                    //     $launch_date = $member->launch_date;
                    // } else {
                    //     $launch_date = $member->launch_date;
                    // }
                    $model_status = '<div
                        class="form-check form-switch form-check-custom form-check-success form-check-solid">
                        <input class="form-check-input" name="status" type="checkbox" value="' . $member->model_id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>';

                    $action = "";
                    if (auth()->user()->can('edit_model')) {
                        $editRoute = route('model.edit', encrypt($member->model_id));
                        $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                                <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                    }
                    if (auth()->user()->can('delete_model')) {
                        $action .= '<a href="javascript:void(0);"
                            data-href="' . route('model.destroy', encrypt($member->model_id)) . '"
                            class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                    }

                    $cbu_checked = "";
                    if ($member->cbu_status == 1) {
                        $cbu_checked = "checked";
                    }
                    $cbu_status = '<div
                        class="form-check form-switch form-check-custom form-check-success form-check-solid">
                        <input class="form-check-input" name="cbu_status" type="checkbox"
                            value="' . $member->model_id . '" ' . $cbu_checked . ' ' . $disable . ' id="cbu_status" />
                        </div>';
                    $imagePath = config('constant.IMAGE_PATH');
                    $img = '<img src="' . $imagePath . '/brands/' . $member->brand_id . '/' . $member->model_id . '/' . $member->model_image . '"width="50px"
                        height="50px">';
                    $data[] = array("sr_no" => $i, "stage" => $member->cs_name, "launched_date" => $launch_date, "type" => $member->ct_name, "brand_name" => $member->brand_name, "model_name" => $member->model_name, "model_image" => $img, "model_type" => $member->model_type, "cbu_status" => $cbu_status, "status" => $model_status, "action" => $action);
                }
                return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $ModelTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            }
        }
    }


    public function createContent()
    {
        $brands = Brand::active()->get();
        $gtType = CarGraphicType::whereIn('gt_name', ['Car Safety', 'Car OverView', 'Car Interior', 'Car Exterior'])->get();

        return view('model.viewContent', compact('brands', 'gtType',));
    }


    public function uploadImageCK(Request $request)
    {
        // dd($request->file('upload'));
        // Validate the request
        $request->validate([
            'upload' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048', // Adjust validation rules as needed
            'brand_id' => 'required|integer',
            'gt_id' => 'required|integer',
            'model_id' => 'required|integer',
        ]);

        DB::beginTransaction();
        try {
            // Get the uploaded file
            $uploadedImage = $request->file('upload');
            $brand_id = $request->input('brand_id');
            $gt_id = $request->input('gt_id');
            $model_id = $request->input('model_id');

            $uniqueId = uniqid();
            // $webpImageName = $gt_id . '.webp';
            $webpImageName = $gt_id . '_' . $uniqueId . '.webp';

            // Create image manager with the GD driver
            $manager = new ImageManager(new Driver());

            $contentImage = $manager->read($uploadedImage);

            // Define the storage path
            $contentPathImg = 'model_overview/' . $brand_id . '/' . $model_id . '/' . $gt_id . '/' . time() . $webpImageName;

            Storage::disk('digitalocean')->put($contentPathImg, $contentImage->toWebp(), 'public');

            $url = Storage::disk('digitalocean')->url($contentPathImg);

            // Return the JSON response
            return response()->json([
                'uploaded' => 1,
                'url' => $url,
                'file_id' => $uniqueId,
                'file_path' => $contentPathImg
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', $e->getLine(), $e->getMessage());

            // Return an error response
            return response()->json([
                'uploaded' => 0,
                'error' => [
                    'message' => 'Image upload failed. Please try again.'
                ]
            ], 500);
        }
    }

    public function deleteImage(Request $request)
    {

        try {
            $filePath = $request->input('file_path');

            if (Storage::disk('digitalocean')->exists($filePath)) {
                Storage::disk('digitalocean')->delete($filePath);
                return response()->json(['success' => true]);
            }

            return response()->json(['success' => false, 'message' => 'File not found']);
        } catch (\Exception $e) {
            Log::error("Image deletion failed: " . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Deletion failed'], 500);
        }
    }

    public function storeContent(Request $request)
    {
        $request->validate([
            'brand_id' => 'required|integer|exists:cop_brands_ms,brand_id',
            'model_id' => 'required|integer|exists:cop_models,model_id',
            'gt_id' => 'required|integer|exists:cop_gt_ms,gt_id',
            'content' => 'required|string',
        ], [
            'brand_id.required' => 'The brand is required.',
            'brand_id.integer' => 'The brand ID must be an integer.',
            'brand_id.exists' => 'The selected brand is invalid.',
            'model_id.required' => 'The model is required.',
            'model_id.integer' => 'The model ID must be an integer.',
            'model_id.exists' => 'The selected model is invalid.',
            'gt_id.required' => 'The GT ID is required.',
            'gt_id.integer' => 'The GT ID must be an integer.',
            'gt_id.exists' => 'The selected GT ID is invalid.',
            'content.required' => 'Content cannot be empty.',
            'content.string' => 'Content must be a valid string.',
        ]);


        // Initialize HTMLPurifier
        $config = HTMLPurifier_Config::createDefault();
        $purifier = new HTMLPurifier($config);

        // Sanitize the CKEditor content
        $content = $purifier->purify($request->input('content'));

        // Save data in database (assuming you have a Model to store the data)
        CarGraphic::updateOrCreate(
            [
                'brand_id' => $request->input('brand_id'),
                'model_id' => $request->input('model_id'),
                'gt_id' => $request->input('gt_id'),
            ],
            [
                'graphic_file' => $content,
                'created_by' => auth()->id(),
            ]
        );


        return redirect()->back()->with('success', 'Data stored successfully!');
    }

    public function fetchContent(Request $request)
    {
        $carGraphicData = CarGraphic::where('model_id', $request->model_id)
            ->where('brand_id', $request->brand_id)
            ->where('gt_id', $request->gt_id)
            ->first();

        if ($carGraphicData) {
            $content = $carGraphicData->graphic_file;
            return response()->json(['content' => $content]);
        }

        return response()->json(['content' => '']);
    }
}
