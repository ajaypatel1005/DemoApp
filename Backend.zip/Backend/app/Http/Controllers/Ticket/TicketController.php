<?php

namespace App\Http\Controllers\Ticket;

use App\Events\ReplyTicketNotificationEvent;
use App\Models\BuyNow;
use App\Models\Customer;
use App\Models\Ticket;
use App\Models\TicketCategory;
use App\Models\TicketFileManager;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\TicketInstantMessage;
use App\Models\TicketNotes;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class TicketController extends Controller
{
    public function index()
    {
        $data = ['all_count' => 0, 'active_count' => 0, 'in_process_count' => 0, 'solved_count' => 0, 'recent_count' => 0, 'self_count' => 0, 'close_count' => 0];
        $data['active_count'] =  Ticket::whereIn('status', [0, 1, 3, 6])->count();
        $data['in_process_count'] = Ticket::where('status', 1)->count();
        $data['all_count'] = Ticket::count();
        $data['solved_count'] = Ticket::where('status', 5)->count();
        $data['recent_count'] = Ticket::where('status', 0)->count();
        $data['self_count'] = Ticket::where('assigned_to', auth()->id())->count();
        $data['close_count'] = Ticket::where('status', 4)->count();
        $data['tickets'] = $this->getList('0,1,3,6');
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        return view("tickets.ticket.dashboard", compact('data', 'status', 'priority'));
    }
    public function create()
    {
        if (!hasAnyPermission(['create_ticket', 'view_ticket'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $customers = Customer::all();
        $ticketCategory = TicketCategory::all();
        $priority = Ticket::PRIORITY;
        $agents = User::whereHas('roles', function ($query) {
            $query->where('name', 'agent');
        })->get();
        return view('tickets.ticket.create', compact('customers', 'ticketCategory', 'priority', 'agents'));
    }

    public function fetchHistory(Request $request)
    {
        $response = ['status' =>  false, 'msg' => '', 'data' => ''];

        $html = '<h4>Need help with?</h4>  <div class="row mw-500px mb-5 mt-5"  data-kt-buttons="true" data-kt-buttons-target=".form-check-image, .form-check-input" >
        ';
        $concern = $request->input('concern');
        $customer_id = $request->input('customer_id');
        if ($concern == 'buy_now') {
            $history = BuyNow::join('cop_models', 'cop_buy_now.model_id', '=', 'cop_models.model_id')
                ->join('cop_brands_ms', 'cop_brands_ms.brand_id', '=', 'cop_models.brand_id')
                ->join('cop_variants', 'cop_variants.variant_id', '=', 'cop_buy_now.variant_id')
                ->select('cop_models.model_id', 'cop_brands_ms.brand_id', 'model_name', 'model_image', 'variant_name', 'brand_name', DB::raw("cop_buy_now.buynow_id as id"))
                ->where('customer_id', $customer_id)
                ->get();
        } else {
            $history = DB::table('cop_book_test_drives')
                ->join('cop_brands_ms', 'cop_book_test_drives.brand_id', '=', 'cop_brands_ms.brand_id',)
                ->join('cop_models', 'cop_book_test_drives.model_id', '=', 'cop_models.model_id')
                ->select('cop_models.model_id', 'cop_brands_ms.brand_id', 'model_name', 'model_image',  'brand_name', DB::raw("cop_book_test_drives.btest_id as id"))
                ->where('customer_id', $customer_id)
                ->get();
        }
        if ($history->count() > 0) {
            $i = 0;
            foreach ($history as $data) {
                //    $a= ($i==0)?'active':'';
                //    $b= ($i==0)?'checked':'';

                $html .= '



            <div class="col-4">
            <label class="form-check-image">
                <div class="form-check-wrapper">
                    <img src="' . asset(('brands/' . $data->brand_id . '/' . $data->model_id . '/' . $data->model_image)) . '"/>
                </div>

                <div class="form-check form-check-custom form-check-solid">
                    <input class="form-check-input history" type="radio"  id="concernValue" value="' . $data->id . '" name="concernValue"/>
                    <div class="form-check-label">
                    ' . $data->brand_name . ' ' . $data->model_name . '
                    </div>
                </div>
            </label>
        </div>

           ';
                $i++;
            }
            $html .= '</div';
            $response = ['status' => true, 'msg' => 'Data found', 'data' => $html];
        }

        return response()->json($response);
    }
    public function uploadImage(Request $request)
    {
        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $filePath = $file->storeAs('uploads', $file->getClientOriginalName(), 'public');
        }
    }
    public function store(Request $request)
    {
        try {
            $ticket = new Ticket();
            $concern = $request->input('concern');
            if ($concern == 'buy_now') {
                $ticket->buynow_id = $request->concernValue;
            } else {
                $ticket->test_drive_id = $request->concernValue;
            }

            $ticket->title = $request->subject;
            $ticket->ticket_no = Ticket::generateInvoiceNumber($concern);
            $ticket->description = $request->description_hidden;
            $ticket->category_id = $request->ticketCategory;
            $ticket->created_by_agent = auth()->id();
            $ticket->created_by_customer = $request->customer_id;
            $ticket->assigned_to = (!empty($request->assigned_to) && $request->assigned_to != 'null')  ? $request->assigned_to :  null;
            $ticket->priority = (!empty($request->priority) && $request->priority != 'null')  ? $request->priority :  null;
            $ticket->status = 0;
            $ticket->save();
            $uploadedFiles = [];
            if ($request->hasFile('file')) {
                foreach ($request->file('file') as $file) {
                    $filePath = $file->store('uploads/tickets', 'public');
                    $uploadedFiles[] = $filePath;
                }
            }

            foreach ($uploadedFiles as $filePath) {
                $ticketFile = new TicketFileManager();
                $ticketFile->ticket_id = $ticket->id;
                $ticketFile->path = $filePath;
                $ticketFile->name = $filePath;

                $ticketFile->save();
            }
            // Flash a success message or return a response
            session()->flash('success', 'Ticket Created Successfully.');
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        if (!request()->wantsJson()) {
            return redirect()->route('ticket.list');
        }
    }
    public function list(Request $request)
    {
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        $data['tickets'] = $this->getList();
        return view('tickets.ticket.list', compact('data', 'status', 'priority'));
    }

    public function getAssignModel()
    {
        $ticket_id = request()->get('id');
        $value = request()->get('value');
        $agents = User::whereHas('roles', function ($query) {
            $query->where('name', 'agent');
        })->get();
        return view('tickets.ticket.assign_model', compact('agents', 'ticket_id'));
    }

    public function postAssignAgent(Request $request)
    {
        $response = ['status' => false, 'msg' => ''];
        try {
            $ticket_id = $request->ticket_id;
            $result = Ticket::where('id', $ticket_id)->first();
            if (!empty($result)) {
                $result->assigned_to = $request->agent_id;
                $result->update();
                $response = ['status' => true, 'msg' => 'Ticket has been assigned successfully.'];
            } else {
                $response['msg'] = 'No ticket found';
            }
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            $response['msg'] = 'Something Went Wrong.';
        }
        return $response;
    }

    /**
     * Recent Tickets
     */
    public function getRecentTicket()
    {
        $data['tickets'] = $this->getList('', false, false, true);
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        return view('tickets.ticket.recent_ticket', compact('data', 'status', 'priority'));
    }
    /**
     * Active Tickets
     */
    public function getActiveTicket()
    {
        $data['tickets'] = $this->getList('0,1,3,6');
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        return view('tickets.ticket.active_ticket', compact('data', 'status', 'priority'));
    }
    /**
     * Closed Tickets
     */
    public function getClosedTicket()
    {
        $data['tickets'] = $this->getList('4');
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        return view('tickets.ticket.closed_ticket', compact('data', 'status', 'priority'));
    }
    /**
     * Solved/Resolved Tickets
     */
    public function getSolvedTicket()
    {
        $data['tickets'] = $this->getList('5');
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        return view('tickets.ticket.resolved_ticket', compact('data', 'status', 'priority'));
    }
    /**
     * OnHold Tickets
     */
    public function getOnHoldTicket()
    {
        $data['tickets'] = $this->getList('3');
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        return view('tickets.ticket.onhold_ticket', compact('data', 'status', 'priority'));
    }
    /**
     * My Assigned Tickets
     */
    public function getMyAssignedTicket()
    {
        $data['tickets'] = $this->getList('', false, true);
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        return view('tickets.ticket.myAssigned_ticket', compact('data', 'status', 'priority'));
    }
    /**
     * Suspended/Cancelled Tickets
     */
    public function getCancelledTicket()
    {
        $data['tickets'] = $this->getList('2');
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        return view('tickets.ticket.cancelled_ticket', compact('data', 'status', 'priority'));
    }
    /**
     * Trashed Tickets
     */
    public function getTrashedTicket()
    {
        $data['tickets'] = $this->getList('', true);
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        return view('tickets.ticket.trashed_ticket', compact('data', 'status', 'priority'));
    }
    public function delete($id)
    {
        if (!hasAnyPermission(['delete_ticket'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        try {
            $ticket_delete = Ticket::where('id', decrypt($id))->first();
            if (!empty($ticket_delete)) {
                // Soft delete the ticket
                $ticket_delete->delete();
                session()->flash('success', 'Ticket has been deleted successfully..');
            }
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong');
        }
        return redirect()->route('ticket.index');
    }


    /**
     * Edit Ticket
     */

    public function edit($id)
    {
        $priority = Ticket::PRIORITY;
        $ticketInfo = Ticket::with(['customer', 'category', 'agent_created_by', 'conversation', 'notes'])->where('id', decrypt($id))->firstOrFail();
        $agents = User::whereHas('roles', function ($query) {
            $query->where('name', 'agent');
        })->select('id', 'name')->get();
        $conversations = $ticketInfo->conversation()->orderBy('created_at', 'desc')->paginate(5);
        $notes = $ticketInfo->notes()->orderBy('created_at', 'desc')->get();
        $ticketInfo->priority = !empty($priority[$ticketInfo->priority]) ? $priority[$ticketInfo->priority]['label'] : '';
        $status = Ticket::STATUS;
        $instantReply = TicketInstantMessage::select('id', 'title', 'messages')->where('status', true)->get();
        return view('tickets.ticket.edit', compact('agents', 'ticketInfo', 'conversations', 'notes', 'status', 'instantReply'));
    }

    /**
     * Save Ticket Replay
     * @param Request
     */
    public function saveReply(Request $request)
    {
        try {
            if (!empty($request->hidden_body)) {
                $ticket = Ticket::with('test_drive')->where('id', decrypt($request->ticket_id))->first();
                if (!empty($ticket)) {
                    $conversation = Conversation::create([
                        'ticket_id' => decrypt($request->ticket_id),
                        'body' => $request->hidden_body,
                        'agent_id' => auth()->id(),
                    ]);
                    $uploadedFiles = [];
                    if ($request->hasFile('file')) {
                        foreach ($request->file('file') as $file) {
                            $filePath = $file->store('uploads/tickets', 'public');
                            $uploadedFiles[] = $filePath;
                        }
                    }
                    if (!empty($uploadedFiles)) {
                        foreach ($uploadedFiles as $filePath) {
                            TicketFileManager::create(['conversation_id' => $conversation->id, 'path' => $filePath, 'name' => $filePath]);
                        }
                    }
                    $id=encryptor('e', $ticket->id);
                    $notificationData = [
                        'message' => "Click here to track its progress.",
                        'title' => "Ticket Reply",
                        'url' => "/myaccount/support/$id"
                    ];
                    createNotification($notificationData['title'], $notificationData['message'], $ticket->test_drive->customer_id, $notificationData['url']);
                    event(new ReplyTicketNotificationEvent('cop-channel-user-' . $ticket->test_drive->customer_id, $notificationData));
                    session()->flash('success', 'Conversation has been added successfully.');
                } else {
                    session()->flash('error', 'No ticket found.');
                }
            } else {
                session()->flash('error', 'The conversation details field is required.');
            }
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
    }

    /**
     * Get Category Model
     */
    public function getCategoryModel()
    {
        $ticket_id = request()->get('ticket_id');
        $ticket = Ticket::where('id', decrypt($ticket_id))->first();
        $category_id = $ticket->category_id;
        $category = TicketCategory::all();
        return view('tickets.ticket.category_model', compact('ticket_id', 'category_id', 'category'));
    }

    /**
     * Update Category
     */
    public function postCategoryModel(Request $request)
    {
        $response = ['status' => false, 'msg' => '', 'value' => ''];
        try {
            $ticket_id = $request->ticket_id;
            $category_id = $request->category_id;
            $result = Ticket::where('id', decrypt($ticket_id))->first();
            if (!empty($result)) {
                $result->category_id = $category_id;
                $result->update();
                $response = ['status' => true, 'msg' => 'Category has been updated successfully.', 'value' => $result->category->ticket_category_name ?? ''];
            } else {
                $response['msg'] = 'No ticket found';
            }
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            $response['msg'] = 'Something Went Wrong.';
        }
        return $response;
    }


    /**
     * Get Priority Model
     */
    public function getPriorityModel()
    {
        $ticket_id = request()->get('ticket_id');
        $ticketData = Ticket::where('id', decrypt($ticket_id))->first();;
        $priority_id = $ticketData->priority;
        $priority = Ticket::PRIORITY;
        return view('tickets.ticket.priority_model', compact('ticket_id', 'priority', 'priority_id'));
    }

    /**
     * Update Priority
     */
    public function postPriorityModel(Request $request)
    {
        $response = ['status' => false, 'msg' => '', 'value' => ''];
        try {
            $ticket_id = $request->ticket_id;
            $priority = $request->priority;
            $result = Ticket::where('id', decrypt($ticket_id))->first();
            if (!empty($result)) {
                $result->priority = $priority;
                $result->update();
                $allPriority = Ticket::PRIORITY;
                $response = ['status' => true, 'msg' => 'Priority has been updated successfully.', 'value' => $allPriority[$priority]['label'] ?? ''];
            } else {
                $response['msg'] = 'No ticket found';
            }
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            $response['msg'] = 'Something Went Wrong.';
        }
        return $response;
    }

    /**
     * Get Ticket Model
     */
    public function getTicketModel()
    {
        $ticket_id = request()->get('ticket_id');
        return view('tickets.ticket.ticket_notes_model', compact('ticket_id'));
    }
    /**
     * Update Priority
     */
    public function postNotes(Request $request)
    {
        $response = ['status' => false, 'msg' => '', 'value' => ''];
        try {
            $ticket_id = $request->ticket_id;
            $result = Ticket::where('id', decrypt($ticket_id))->first();
            if (!empty($result)) {
                TicketNotes::create([
                    'ticket_id' =>  decrypt($ticket_id),
                    'body' => $request->note,
                    'created_by' => auth()->id()
                ]);
                $response = ['status' => true, 'msg' => 'Note has been added successfully.'];
            } else {
                $response['msg'] = 'No ticket found';
            }
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            $response['msg'] = 'Something Went Wrong.';
        }
        return $response;
    }

    public function deleteNotes($id)
    {
        $response = ['status' => false, 'msg' => '', 'value' => ''];
        try {
            $deleteNote = TicketNotes::where('id', decrypt($id))->first();
            if (!empty($deleteNote)) {
                $deleteNote->delete();
                $response = ['status' => true, 'msg' => 'Note has been deleted successfully.'];
            } else {
                $response['msg'] = 'No Note found';
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return $response;
    }

    /**
     * edit note
     *
     */
    public function editNote($id)
    {
        $note = TicketNotes::where('id', decrypt($id))->first();
        return view('tickets.ticket.edit_ticket_note', compact('note'));
    }


    public function updateNote(Request $request)
    {
        $response = ['status' => false, 'msg' => '', 'value' => ''];
        try {
            $note_id = decrypt($request->note_id);
            $note = TicketNotes::where('id', $note_id)->first();
            if (!empty($note)) {
                $note->body = $request->note;
                $note->update();
                $response = ['status' => true];
                session()->flash('success', 'Note has been updated successfully.');
            } else {
                session()->flash('success', 'No ticket found.');
            }
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return $response;
    }

    public function updateStatus(Request $request)
    {
        $response = ['status' => false, 'msg' => '', 'value' => ''];
        try {
            $ticket_id = $request->ticket_id;
            $result = Ticket::where('id', decrypt($ticket_id))->first();
            if (!empty($result)) {
                $result->status = $request->ticket_status;
                $result->status_change_by_agent = auth()->id();
                $result->update();
                $response = ['status' => true];
                session()->flash('success', 'Status has been updated successfully.');
            } else {
                session()->flash('error', 'No ticket found.');
                $response['msg'] = '';
            }
        } catch (Exception $e) {
            Log::channel('ticket')->info("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return $response;
    }



    /**
     * Get Ticket List
     * @param $status
     * @param $trashed
     * @param $assigned
     * @param $is_recent
     *
     */

    public function getList($statusValues = '', $trashed = false, $assigned = false, $is_recent = false)
    {
        $status = Ticket::STATUS;
        $priority = Ticket::PRIORITY;
        $query = Ticket::with(['buy_now', 'customer', 'agent', 'test_drive', 'buy_now.car_model', 'buy_now.variant', 'test_drive.car_model', 'test_drive.brand'])
            ->selectRaw("ticket.*,DATE_FORMAT(ticket.created_at, '%d %b, %Y') AS formatted_date");
        if (!empty($statusValues)) {
            $statusVal = explode(",", $statusValues);
            $query->whereIn('status', $statusVal);
        }
        if ($trashed) {
            $query->onlyTrashed();
        }
        if ($assigned) {
            $query->where('assigned_to', auth()->id());
        }
        if ($is_recent) {
            $query->where('status', 0);
        }
        $result = $query->orderBy('id', 'desc')->get();
        return $result;
    }
}
