<?php

namespace App\Http\Controllers\Ticket;

use App\Http\Controllers\Controller;
use App\Models\TicketCategory;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CategoryController extends Controller
{

    public function index()
    {
        $categories = TicketCategory::select('*')->orderBy('created_at', 'desc')
            ->get();
        return view('tickets.category.index', compact('categories'));
    }


    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_ticket_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'ticket_category_name' => 'required|min:2|max:30|unique:ticket_category_ms,ticket_category_name',
            ],
            [
                'ticket_category_name.required' => 'Category Name Required',
            ]
        );
        try {
            $category_store = new TicketCategory();
            if ($category_store) {
                $category_store->ticket_category_name = $request->ticket_category_name;        //name
                $category_store->created_by = auth()->id();
                $category_store->status = $request->has('status') ? 1 : 0;
                $category_store->save();
                session()->flash('success', 'Category Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('category.index');
    }


    public function edit($id)
    {
        if (!hasAnyPermission(['edit_ticket_category', 'view_ticket_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $category_edit = TicketCategory::where('id', decrypt($id))->first();
        $category_view = TicketCategory::all();
        $categories = TicketCategory::select('*')->orderBy('created_at', 'desc')
            ->get();
        return view('tickets.category.edit', compact('categories', 'category_edit', 'category_view'));
    }

    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_ticket_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'ticket_category_name' => 'required|min:2|max:30|unique:ticket_category_ms,ticket_category_name,' . decrypt($id) . ',id',
            ],
            [
                'ticket_category_name.required' => 'Category Name Required',
            ]
        );
        try {
            $category_update = TicketCategory::WHERE('id', decrypt($id))->first();
            $id = $category_update->id;
            if (!empty($category_update)) {
                $category_update->ticket_category_name = $request->ticket_category_name;        //name
                $category_update->status = $request->has('status') ? 1 : 0;
                $category_update->created_by = auth()->id();
                $category_update->update();
                session()->flash('success', 'Category Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('category.index');
    }

    public function delete($id)
    {
        if (!hasAnyPermission(['delete_ticket_category'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $category_delete = TicketCategory::WHERE('id', decrypt($id))->first();
        try {
            if ($category_delete) {
                $category_delete->delete();
                session()->flash('success', 'Category has been Deleted successfully');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('category.index');
    }

    public function toggleStatus(Request $request)
    {

        $id = $request->input('id');

        TicketCategory::where('id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);

        return response()->json(['message', 'Status Updated Successfully']);
    }
}
