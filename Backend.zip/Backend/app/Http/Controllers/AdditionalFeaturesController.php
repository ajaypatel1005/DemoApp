<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Model;
use App\Models\Variant;
use Illuminate\Http\Request;
use App\Models\AdditionalFeatures;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
class AdditionalFeaturesController extends Controller
{
    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');
        if ($selectedBrandId) {
            $models = Model::where('brand_id', $selectedBrandId)->active()->get();
        } else {
            $models = [];
        }
        return response()->json(['models' => $models]);
    }

    public function fetchVariants(Request $request)
    {
        $selectedModelId = $request->input('model_id');

        if ($selectedModelId) {
            $variants = Variant::where('model_id', $selectedModelId)->active()->get();
        } else {
            $variants = [];
        }

        return response()->json(['variants' => $variants]);
    }
    public function fetchAFValue(Request $request)
    {
        $selectedVariantId = $request->input('variant_id');
        $afvalue1 = AdditionalFeatures::select('af_value','status')
        ->where('variant_id', $selectedVariantId)->get();
        if($afvalue1->count() > 0){
            $status = $afvalue1[0]->status;
            if (count($afvalue1)>0 ) {
                $afvalue = json_decode($afvalue1[0]['af_value'], true);

            }
        } else {
            $afvalue = [];
            $status = 1;
        }
        return response()->json(['afvalue' => $afvalue,'status'=>$status]);
    }
    public function create()
    {
        if(!hasAnyPermission(['additional_features'])){
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $brands = Brand::active()->get();
        return view('additional_features.create', compact('brands'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $request->validate(
            [
                'brand_id' => 'required',
                'model_id' => 'required',
                'variant_id' => 'required'
            ],
            [
                'brand_id.required' => 'Brand is Required',
                'model_id.required' => 'Model is Required',
                'variant_id.required' => 'Variant is Required',
            ]
        );
        DB::beginTransaction();
        try {
            $brand_id = $request->brand_id;
            $model_id = $request->model_id;
            $variant_id = $request->variant_id;
            $created_by = auth()->id();
            $status = ($request->has('status')) ? 1 : 0;
            $descriptions = explode(',',$request->description);
            AdditionalFeatures::updateOrCreate(
                [
                    'variant_id' => $variant_id,
                ], // Condition to find the product
                [
                    'brand_id' => $brand_id,
                    'model_id' => $model_id,
                    'af_value' => json_encode($descriptions),
                    'created_by' => $created_by,
                    'status'=>$status
                ]
            );
            DB::commit();
            session()->flash('success', 'Saved Successfully');
        } catch (Exception $e) {
            DB::commit();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }
}
