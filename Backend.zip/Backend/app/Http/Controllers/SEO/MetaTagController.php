<?php

namespace App\Http\Controllers\SEO;

use App\Http\Controllers\Controller;
use App\Models\SEO\MetaTag;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class MetaTagController extends Controller
{
    public function create()
    {
        if (!hasAnyPermission(['create_meta_tag','edit_meta_tag'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $meta_data = MetaTag::all();
        return view('seo.seo_meta_tag.create', compact('meta_data'));
    }


    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_meta_tag'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $request->validate(
            [
                'meta_tag_name' => 'required',
            ],
            [
                'meta_tag_name.required' => 'Meta Tag Name Required',
            ]
        );
        DB::beginTransaction();
        try {
            $meta_tag_store = new MetaTag;
            if ($meta_tag_store) {
                $meta_tag_store->meta_tag_name = $request->meta_tag_name;
                $meta_tag_store->meta_tag_type = $request->meta_tag_type;
                $meta_tag_store->status = $request->has('status') ? 1 : 0;
                $meta_tag_store->save();
                DB::commit();
                session()->flash('success', 'Meta Tag Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('meta_tag.create');
    }

    public function edit($id)
    {
        if (!hasAnyPermission(['edit_meta_tag'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $meta_data_edit = MetaTag::where('meta_tag_id', decrypt($id))->first();
        $meta_data = MetaTag::all();
        return view('seo.seo_meta_tag.edit', compact('meta_data_edit', 'meta_data'));
    }


    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_meta_tag'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $request->validate(
            [
                // 'brand_name' => 'required|min:2|max:30|unique:cop_brands_ms,brand_name,' . decrypt($id) . ',brand_id',
            ],
            [
                // 'brand_name.required' => 'Brand Name Required',
            ]
        );
        DB::beginTransaction();
        try {
            $meta_data_update = MetaTag::WHERE('meta_tag_id', decrypt($id))->first();
            if (!empty($meta_data_update)) {

                $meta_data_update->meta_tag_name = $request->meta_tag_name;
                $meta_data_update->meta_tag_type = $request->meta_tag_type;
                $meta_data_update->status = $request->has('status') ? 1 : 0;
                $meta_data_update->update();
                DB::commit();
                session()->flash('success', 'Meta Tag Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('meta_tag.create');
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_meta_tag'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        //
        try {
            $metaTage = MetaTag::where('meta_tag_id', decrypt($id))->first();

            if ($metaTage) {
                $metaTage->delete();
                session()->flash('success', 'Meta Tag Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }

            return redirect()->route('meta_tag.create');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }


    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');

        DB::table('cop_seo_meta_tags_ms')
        ->where('meta_tag_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);

        return response()->json(['message', 'Status Updated Successfully']);
    }


}
