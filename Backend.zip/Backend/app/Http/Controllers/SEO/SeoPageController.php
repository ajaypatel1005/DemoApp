<?php

namespace App\Http\Controllers\SEO;

use App\Http\Controllers\Controller;
use App\Models\SEO\Page;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class SeoPageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_seo_pages'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $pages = Page::get();
        return view('seo.seo_pages.create', compact('pages'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_seo_pages'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'page_name' => 'required|min:2|unique:cop_seo_pages_ms,page_name',
                'page_current_url' => 'required|min:2',
            ],
            [
                'page_name.required' => 'Page Name Required',
                'page_name.min' => 'The Page Name must be at least :min characters.',
                'page_name.unique' => 'Source Name has already been taken.',
                'page_current_url.required' => 'Page Current URL Required',
                'page_current_url.min' => 'The Page Current URL must be at least :min characters.',
            ]
        );
        try {
            $seo_pages = new Page;
            $seo_pages->page_name = $request->page_name;
            $seo_pages->page_current_url = $request->page_current_url;
            $seo_pages->page_slug = $request->page_slug;
            $seo_pages->status = $request->has('status') ? 1 : 0;
            $seo_pages->save();

            session()->flash('success', 'SEO Page Added Successfully.');

            return redirect()->route('pages.create');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Page $leadSource)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_seo_pages'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $pages = Page::get();
        $page = Page::where('page_id', decrypt($id))->first();
        return view('seo.seo_pages.edit', compact('pages', 'page'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_seo_pages'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'page_name' => 'required|min:2|unique:cop_seo_pages_ms,page_name,' . decrypt($id) . ',page_id',
                'page_current_url' => 'required|min:2',
            ],
            [
                'page_name.required' => 'Page Name Required',
                'page_name.min' => 'The Page Name must be at least :min characters.',
                'page_name.unique' => 'Source Name has already been taken.',
                'page_current_url.required' => 'Page Current URL Required',
                'page_current_url.min' => 'The Page Current URL must be at least :min characters.',
            ]
        );
        try {
            $seo_pages = Page::where('page_id', decrypt($id))->first();
            if ($seo_pages) {
                $seo_pages->page_name = $request->page_name;
                $seo_pages->page_current_url = $request->page_current_url;
                $seo_pages->page_slug = $request->page_slug;
                $seo_pages->status = $request->has('status') ? 1 : 0;
                $seo_pages->update();

                session()->flash('success', 'SEO Page Update Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('pages.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_seo_pages'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        try {
            $leadSource = Page::where('page_id', decrypt($id))->first();

            if ($leadSource) {
                $leadSource->delete();

                session()->flash('success', 'Seo Page Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            return redirect()->route('pages.create');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    /**
     * Toggle status field active/Inactive.
     */
    public function toggleStatus(Request $request)
    {
        //Begin::toggle page status
        $id = $request->input('id');
        $leadSource = Page::find($id);
        $leadSource->status = $leadSource->status == 1 ? 0 : 1;
        $leadSource->save();
        //End::toggle page status

        return response()->json(['message' => 'Status updated successfully']);
    }
}
