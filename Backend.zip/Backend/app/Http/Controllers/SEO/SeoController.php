<?php

namespace App\Http\Controllers\SEO;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Http\Resources\SEO\BrandResource;
use App\Http\Resources\SEO\MetaTagResource;
use App\Http\Resources\SEO\ModelResource;
use App\Http\Resources\SEO\PageResource;
use App\Http\Resources\SEO\SeoResource;
use App\Http\Resources\SEO\VariantResource;
use App\Models\Brand;
use App\Models\Model;
use App\Models\SEO\MetaTag;
use App\Models\SEO\Page;
use App\Models\SEO\Seo;
use App\Models\Variant;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class SeoController extends Controller
{
    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');
        //dump($selectedBrandId);
        if ($selectedBrandId) {
            $models = Model::where('brand_id', $selectedBrandId)
                ->where('status', 1)
                ->get();
        } else {
            $models = [];
        }

        return response()->json(['models' => $models]);
    }

    public function fetchVariants(Request $request)
    {
        $selectedModelId = $request->input('model_id');

        if ($selectedModelId) {
            $variants = Variant::where('model_id', $selectedModelId)
                ->where('status', 1)
                ->get();
        } else {
            $variants = [];
        }

        return response()->json(['variants' => $variants]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['view_seo'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $brand = Brand::where('status', 1)->get();
        $metaTags = MetaTag::where('status', 1)->get();
        $metaPages = Page::where('status', 1)->get();
        $permissions = ['edit_seo' => auth()->user()->can('edit_seo') ,'delete_seo' => auth()->user()->can('delete_seo')];
        return view('seo/seo.create', compact('brand', 'metaTags', 'metaPages','permissions'));
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        if (!hasAnyPermission(['create_seo'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $validator = Validator::make(
            $request->all(),
            [
                'seo_type' => 'required',
                'brand_id' => $request->filled('seo_type') && in_array($request->seo_type, [1, 2, 3]) ? 'required_if:seo_type,1,2,3' : '',
                'model_id' => $request->filled('seo_type') && in_array($request->seo_type, [2, 3]) ? 'required_if:seo_type,2,3' : '',
                'variant_id' => $request->filled('seo_type') && $request->seo_type == 3 ? 'required_if:seo_type,3' : '',
                'page_id' => 'nullable',
                'meta_tag_id' => 'required',
                'tag_content' => 'required|min:2',
            ],
            [
                'seo_type.required' => 'SEO Type is required.',
                'brand_id.required_if' => 'Brand is required',
                'model_id.required_if' => 'Model is required',
                'variant_id.required_if' => 'Variant is required',
                // 'page_id.required' => 'Page is required.',
                'meta_tag_id.required' => 'Meta Tag is required.',
                'tag_content.required' => 'Tag Content is required.',
                'tag_content.min' => 'The Tag Content must be at least :min characters.',
            ]
        );


        if ($validator->fails()) {
            return ResponseHelper::errorResponseSeo($validator->errors());
        }

        DB::beginTransaction();
        try {
            $seo = new Seo;
            $seo->brand_id = $request->brand_id;
            $seo->model_id = $request->model_id;
            $seo->variant_id = $request->variant_id;
            $seo->page_id = $request->page_id;
            $seo->meta_tag_id = $request->meta_tag_id;
            $seo->tag_content = $request->tag_content;
            $seo->seo_type = $request->seo_type;
            $seo->status = 1;
            $seo->save();

            DB::commit();

            if ($seo) {
                return ResponseHelper::responseMessageSeo('success', $seo, 'SEO Tag Added Successfully.');
            } else {
                return ResponseHelper::errorResponseSeo(['Error...While add SEO Tag.!!']);
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request)
    {
        if (!hasAnyPermission(['edit_seo','view_seo'])) {
            // abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
            return ResponseHelper::errorResponseSeo(['USER DOES NOT HAVE THE RIGHT PERMISSIONS'], 403);
        }
        $seo = Seo::where('seo_id', $request->seo_id)->get();
        return response()->json(['seoResult' => $seo]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        if (!hasAnyPermission(['edit_seo'])) {
            // abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
            return ResponseHelper::errorResponseSeo(['USER DOES NOT HAVE THE RIGHT PERMISSIONS'], 403);
        }

        $validator = Validator::make(
            $request->all(),
            [
                'seo_id' => 'required',
                'seo_type' => 'required',
                'brand_id' => $request->filled('seo_type') && in_array($request->seo_type, [1, 2, 3]) ? 'required_if:seo_type,1,2,3' : '',
                'model_id' => $request->filled('seo_type') && in_array($request->seo_type, [2, 3]) ? 'required_if:seo_type,2,3' : '',
                'variant_id' => $request->filled('seo_type') && $request->seo_type == 3 ? 'required_if:seo_type,3' : '',
                'page_id' => 'nullable',
                'meta_tag_id' => 'required',
                'tag_content' => 'required|min:2',
            ],
            [
                'seo_id.required' => 'SEO Data is not found.',
                'seo_type.required' => 'SEO Type is required.',
                'brand_id.required_if' => 'Brand is required',
                'model_id.required_if' => 'Model is required',
                'variant_id.required_if' => 'Variant is required',
                // 'page_id.required' => 'Page is required.',
                'meta_tag_id.required' => 'Meta Tag is required.',
                'tag_content.required' => 'Tag Content is required.',
                'tag_content.min' => 'The Tag Content must be at least :min characters.',
            ]
        );


        if ($validator->fails()) {
            return ResponseHelper::errorResponseSeo($validator->errors());
        }
        DB::beginTransaction();
        try {
            $seo = Seo::findOrFail($request->seo_id);
            $seo->brand_id = $request->brand_id;
            $seo->model_id = $request->model_id;
            $seo->variant_id = $request->variant_id;
            $seo->page_id = $request->page_id;
            $seo->meta_tag_id = $request->meta_tag_id;
            $seo->tag_content = $request->tag_content;
            $seo->seo_type = $request->seo_type;

            $seo->update();

            DB::commit();

            return ResponseHelper::responseMessageSeo('success',$seo, 'SEO Tag Updated Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponse(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    // Begin::Seo table data list
    public function list(Request $request)
    {
        // Begin::Fetch data table default provide value
        $draw = $request->input('draw');
        $start = $request->input('start');
        $length = $request->input('length');
        $search = $request->input('search.value');
        $orderColumn = $request->input('order.0.column');
        $orderDirection = $request->input('order.0.dir');
        // End::Fetch data table default provide value
        // dd($orderColumn);
        // Begin::Query
        $query = Seo::with(['brands', 'models_data', 'variants', 'page', 'meta_tag'])
            ->where('seo_type', $request->input('seo_type'))
            ->where('status', 1);

        // Begin::Search filter
        if ($search) {
            $query->where(function ($query) use ($search) {
                $query->where('tag_content', 'like', '%' . $search . '%')
                    ->orWhereHas('brands', function ($query) use ($search) {
                        $query->where('brand_name', 'like', '%' . $search . '%');
                    })
                    ->orWhereHas('models_data', function ($query) use ($search) {
                        $query->where('model_name', 'like', '%' . $search . '%');
                    })
                    ->orWhereHas('variants', function ($query) use ($search) {
                        $query->where('variant_name', 'like', '%' . $search . '%');
                    })
                    ->orWhereHas('page', function ($query) use ($search) {
                        $query->where('page_name', 'like', '%' . $search . '%');
                    })
                    ->orWhereHas('meta_tag', function ($query) use ($search) {
                        $query->where('meta_tag_name', 'like', '%' . $search . '%');
                    });
            });
        }

        // Apply ordering
    // if ($orderColumn !== null) {
    //     $column = $request->input('columns.'.$orderColumn.'.data');
    //     $query->orderBy($column, $orderDirection);
    // }

        $seoPaginated = $query->paginate($length);

        // End::Search filter

        // $seoPaginated=$seoPaginated ? new SeoResource($seoPaginated[0]) : null;

        $seoPaginated->getCollection()->transform(function ($item, $key) {
            // Begin::Extracting data and selecting specific columns
            $brandData=$item->brands ? new BrandResource($item->brands) : null;
            $modelsData=$item->models_data ? new ModelResource($item->models_data) : null;
            $variantsData=$item->variants ? new VariantResource($item->variants) : null;
            $pageData=$item->page ? new PageResource($item->page) : null;
            $metaTagData=$item->meta_tag ? new MetaTagResource($item->meta_tag) : null;
            // End::Extracting data and selecting specific columns

            // Begin::Building the modified item with selected data
            return [
                'sr_no' => $key + 1,
                'seo_id' => $item->seo_id,
                'brand_id' => $item->brand_id,
                'model_id' => $item->model_id,
                'variant_id' => $item->variant_id,
                'page_id' => $item->page_id,
                'meta_tag_id' => $item->meta_tag_id,
                'tag_content' => $item->tag_content,
                'seo_type' => $item->seo_type,
                'status' => $item->status,
                'created_at' => $item->created_at,
                'updated_at' => $item->updated_at,
                'brands' => $brandData,
                'models_data' => $modelsData,
                'variants' => $variantsData,
                'page' => $pageData,
                'meta_tag' => $metaTagData,
            ];
            // End::Building the modified item with selected data

        });
        // End::Query

        return response()->json(['seoResult' => $seoPaginated, 'draw' => $draw, "recordsTotal" => $seoPaginated->total(), "recordsFiltered" => $seoPaginated->total()]);
    }
    // End::Seo table data list


    /**
     * Remove the specified resource from storage.
     */
    public function delete(Request $request)
    {

        if (!hasAnyPermission(['delete_lead'])) {
            return ResponseHelper::errorResponseSeo(['USER DOES NOT HAVE THE RIGHT PERMISSIONS'], 403);
            // abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        try {
            // Find the seo by its ID
            $seoDelete = Seo::findOrFail($request->seo_id);

            // Delete the seo
            $seoDelete->delete();

            // Check if the seo was deleted successfully
            return ResponseHelper::responseMessageSeo('success', 'SEO Tag Deleted Successfully.');
        } catch (Exception $e) {
            // Log any errors that occur during the deletion process
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());

            // Return an error response
            return ResponseHelper::errorResponseSeo(['Something Went Wrong.' . $e->getMessage()]);
        }
    }
}
