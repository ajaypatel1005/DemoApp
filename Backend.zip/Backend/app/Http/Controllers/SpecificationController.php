<?php

namespace App\Http\Controllers;

use App\Models\SpecificationCategory;
use App\Models\Specification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Exception;
use Illuminate\Support\Facades\DB;

class SpecificationController extends Controller
{


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_specification', 'view_specification'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $specification_view = Specification::select('cop_spec_ms.*', 'cop_sc_ms.sc_name')
            ->leftJoin('cop_sc_ms', 'cop_spec_ms.sc_id', '=', 'cop_sc_ms.sc_id')
            ->get();

        $specification_categories = SpecificationCategory::active()->get();

        return view('specification.create', ['specification_categories' => $specification_categories], ['specification_view' => $specification_view]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_specification'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'spec_name' => 'required|regex:/^[A-Za-z&\s]+$/|min:2|max:25|unique:cop_spec_ms,spec_name',
                'sc_id' => 'required',
                'spec_image' => 'required|image|mimes:svg|max:2048|unique:cop_spec_ms,spec_image',

            ],
            [
                'spec_name.required' => 'The Specification Name is required.',
                'spec_name.unique' => 'The Specification Name Already Taken',
                'spec_name.regex' => 'The Specification Name must contain only letters and spaces.',
                'spec_name.min' => 'The Specification Name must be at least :min characters.',
                'spec_name.max' => 'The Specification Name must not exceed :max characters.',

                'sc_id.required' => 'Select Specification Category Field is required.',
                'spec_image.required' => 'The Specification Image is required.',
                'spec_image.mimes' => 'The Specification Image must be contain svg only.',
            ]
        );
        DB::beginTransaction();
        try {
            $specification_store = new Specification();
            $specification_store->spec_name = $request->spec_name;
            $specification_store->sc_id = $request->sc_id;
            $specification_store->status = $request->has('status') ? 1 : 0;
            $specification_store->save();

            $specification_update = Specification::find($specification_store->spec_id);

            if ($specification_update) {

                $spec_id = $specification_update->spec_id;
                $uploadedImage = $request->file('spec_image');
                $imageImageName = $spec_id . '.' . $uploadedImage->getClientOriginalExtension();

                $logoPathImg = 'Specification/' . $spec_id . '/' . $imageImageName;
                $content = file_get_contents($uploadedImage);
                Storage::disk('digitalocean')->put($logoPathImg, $content, 'public');

                $specification_update->spec_image = $imageImageName;
                $specification_update->update();
                DB::commit();
                session()->flash('success', 'Specification Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('specification.create');
    }

    /**
     * Display the specified resource.
     */
    public function show(Specification $specification)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_specification', 'view_specification'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $specification_view = Specification::select('cop_spec_ms.*', 'cop_sc_ms.sc_name')
            ->leftJoin('cop_sc_ms', 'cop_spec_ms.sc_id', '=', 'cop_sc_ms.sc_id')
            ->get();
        // dd($specification_view);
        $specification_edit = Specification::where('spec_id', decrypt($id))->first();
        $specification_categories = DB::select('select * from cop_sc_ms where status = 1');

        return view('specification.edit', compact('specification_categories', 'specification_view', 'specification_edit'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request,  $id)
    {
        if (!hasAnyPermission(['edit_specification'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'spec_name' => 'required|regex:/^[A-Za-z&\s]+$/|min:2|max:25|unique:cop_spec_ms,spec_name,' . decrypt($id) . ',spec_id',
                'sc_id' => 'required',
                'spec_image' => 'nullable|image|mimes:svg|max:2048|unique:cop_spec_ms,spec_image',
            ],
            [
                'spec_name.required' => 'Specification Name is required.',
                'spec_name.unique' => 'Specification Name must be unique.',
                'spec_name.regex' => 'The Specification Name must contain only letters and spaces.',
                'spec_name.min' => 'The Specification Name must be at least :min characters.',
                'spec_name.max' => 'The Specification Name must not exceed :max characters.',
                'sc_id.required' => 'The Specification Category Name is required.',
                'spec_image.required' => 'The Specification Image is required.',
                'spec_image.mimes' => 'The Specification Image must be contain svg only.',
            ]
        );
        DB::beginTransaction();
        try {
            $specification_update = Specification::where('spec_id', decrypt($id))->first();
            $imagePath = 'Specification/' . $specification_update->spec_id;

            if (isset($request->spec_image)) {
                Storage::disk('digitalocean')->deleteDirectory($imagePath);

                $spec_id = $specification_update->spec_id;
                $uploadedImage = $request->file('spec_image');
                $imageImageName = $spec_id . '.' . $uploadedImage->getClientOriginalExtension();

                $logoPathImg = 'Specification/' . $spec_id . '/' . $imageImageName;
                $content = file_get_contents($uploadedImage);
                Storage::disk('digitalocean')->put($logoPathImg, $content, 'public');

                $specification_update->spec_image = $imageImageName;
                $specification_update->update();
            }

            $specification_update->spec_name = $request->spec_name;
            $specification_update->sc_id = $request->sc_id;
            $specification_update->status = $request->has('status') ? 1 : 0;
            $specification_update->update();
            DB::commit();
            session()->flash('success', 'Specification Update Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('specification.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_specification'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $specification_delete = Specification::where('spec_id', decrypt($id))->first();
            $imagePath = 'Specification/' . $specification_delete->spec_id;
            // dd($imagePath);


            if (!empty($specification_delete)) {
                if ($specification_delete->feature->isNotEmpty()) {
                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('specification.create');
                }

                $specFolderPath = 'Specification/' . $specification_delete->spec_id;
                if (Storage::disk('digitalocean')->exists($specFolderPath)) {
                    Storage::disk('digitalocean')->deleteDirectory($specFolderPath);
                }

                $specification_delete->delete();
                DB::commit();
                session()->flash('success', 'Specification Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('specification.create');
    }


    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_spec_ms')
            ->where('spec_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            try {
                $limit = ($request->has('length') ? $request->input('length') : 10);
                $page = ($request->has('start') ? $request->input('start') : 0);
                $search = ($request->has('search') ? $request->input('search')['value'] : '');
                $specification_view = Specification::select('cop_spec_ms.spec_id', 'cop_spec_ms.spec_name', 'cop_spec_ms.spec_image', 'cop_spec_ms.status', 'cop_sc_ms.sc_name')
                    ->leftJoin('cop_sc_ms', 'cop_spec_ms.sc_id', '=', 'cop_sc_ms.sc_id');

                if (!empty($search)) {
                    $specification_view->where(function ($query) use ($search) {
                        $query->orWhere('cop_spec_ms.spec_name', 'LIKE', '%' . $search . '%')
                            ->orWhere('cop_sc_ms.sc_name', 'LIKE', '%' . $search . '%');
                    });
                }

                $cntFilter = clone $specification_view;
                $specification_view->offset($page)->limit($limit);
                $specification_view = $specification_view->get();

                $specCatTotal = DB::select("SELECT COUNT(*) AS count FROM cop_spec_ms")[0]->count;
                $data = [];
                $i = $page;
                foreach ($specification_view as $member) {
                    $i++;
                    $status = $disable = "";
                    if ($member->status == 1) {
                        $status = 'checked';
                    }
                    $disable = (!auth()->user()->can('edit_specification')) ? 'disabled' : '';

                    $model_status = '<div class="form-check form-switch form-check-custom form-check-success form-check-solid"> <input class="form-check-input" name="status" type="checkbox" value="' . $member->spec_id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>';
                    $action = "";
                    if (auth()->user()->can('edit_specification')) {
                        $editRoute = route('specification.edit', encrypt($member->spec_id));
                        $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                                <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                    }
                    if (auth()->user()->can('delete_specification')) {
                        $action .= '<a href="javascript:void(0);"
                            data-href="' . route('specification.delete', encrypt($member->spec_id)) . '"
                            class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                    }

                    $image = "";
                    if ($member->spec_image) {
                        $image = '<img src="' . config('constant.IMAGE_PATH') . '/Specification/' . $member->spec_id . '/' . $member->spec_image . '" alt="" style="width: 50px; height: 50px;">';
                    } else {
                        $image = '-';

                    }

                    $data[] = array("sr_no" => $i, "spec_name" => $member->spec_name, "sc_name" => $member->sc_name, "image" => $image, "status" => $model_status, "action" => $action);
                }
                return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $specCatTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            }
        }
    }
}
