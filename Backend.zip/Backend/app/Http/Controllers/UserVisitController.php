<?php

namespace App\Http\Controllers;

use App\Models\UserVisit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class UserVisitController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function view()
    {
        if (!hasAnyPermission(['view_user_visit'])) {
            abort(403, "you don't have permission to access");
        }
        $user_visit_view = UserVisit::select('cop_uvisit.*', 'users.name as name')
            ->leftJoin('users', 'cop_uvisit.id', '=', 'users.id')
            ->get();

        return view('user_visit.view', ['user_visit_view' => $user_visit_view]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_uvisit')
            ->where('visit_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
}
