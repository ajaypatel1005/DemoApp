<?php

namespace App\Http\Controllers;

use App\Models\Customers;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CustomersController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $customers = Customers::select([
            'cop_customers.first_name',
            'cop_customers.last_name',
            'cop_customers.email',
            'cop_customers.contact_no',
            'cop_customers.city_id',
            'cop_city_ms.city_name'
        ])
            ->leftJoin('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_customers.city_id')
            ->get();
        return view('customers.view', compact('customers'));
    }

    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            try {
                $limit = $request->input('length', 10);
                $page = $request->input('start', 0);
                $search = $request->input('search')['value'] ?? '';
                $orderColumn = $request->input('order.0.column');
                $orderDirection = $request->input('order.0.dir');

                $customers_view = Customers::select(['cop_customers.first_name', 'cop_customers.last_name', 'cop_customers.email', 'cop_customers.contact_no', 'cop_customers.city_id', 'cop_customers.created_at', 'cop_city_ms.city_name'])
                    ->leftJoin('cop_city_ms', 'cop_city_ms.city_id', '=', 'cop_customers.city_id')
                    ->getQuery();

                if (!empty($search)) {
                    $customers_view->where(function ($query) use ($search) {
                        $query->orWhere('cop_customers.first_name', 'LIKE', '%' . encryptor('e',$search) . '%');
                        $query->orWhere('cop_customers.last_name', 'LIKE', '%' . encryptor('e',$search) . '%');
                        $query->orWhere('cop_customers.email', 'LIKE', '%' . encryptor('e',$search) . '%');
                        $query->orWhere('cop_customers.contact_no', 'LIKE', '%' . encryptor('e',$search) . '%');
                        $query->orWhere('cop_city_ms.city_name', 'LIKE', '%' . $search . '%');
                    });
                }


                $cntFilter = clone $customers_view;
                $column = $columns[$orderColumn] ?? 'created_at';
                $customers_view->orderBy($column, $orderDirection)->offset($page)->limit($limit);
                $customers_view = $customers_view->get();
                $customersTotal = DB::table('cop_customers')->count();

                $recordsFiltered = $cntFilter->count();

                $data = [];
                $i = $page;
                foreach ($customers_view as $member) {
                    $i++;
                    $data[] = [
                        "sr_no" => $i,
                        "created_at" => Carbon::parse($member->created_at)->format('d-m-Y'),
                        "name" => $member->first_name ? encryptor('d',$member->first_name) . ' ' . encryptor('d',$member->last_name) : '-',
                        "email" => $member->email ? encryptor('d',$member->email) : '-',
                        "contact_no" => $member->contact_no ? encryptor('d',$member->contact_no) : '-',
                        "city" => $member->city_name ?? '-'
                    ];
                }

                return response()->json([
                    "draw" => $request->input('draw'),
                    "recordsTotal" => $customersTotal,
                    "recordsFiltered" => $recordsFiltered,
                    'data' => $data
                ]);
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            }
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
