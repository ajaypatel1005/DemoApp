<?php

namespace App\Http\Controllers\exports;

use App\Exports\FeatureValueExport;
use App\Exports\FeatureValueExport1;
use App\Exports\FeatureValues;
use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\Model;
use App\Models\SpecificationCategory;
use App\Models\Variant;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class FeatureValueExportController extends Controller
{
    public function downloadInvoices()
    {
        return Excel::download(new FeatureValueExport, 'feature_value.xlsx');
    }

    public function downloadFeatureValue(Request $request)
    {
        $validatedData = request()->validate([
            'brand_id' => 'required',
            'model_id' => 'required',
            'sc_id' => 'required',
        ]);
        $brand_id = request()->input('brand_id');
        $model_id = request()->input('model_id');
        $variant_id = request()->input('variant_id');
        $spec_cat_id = request()->input('sc_id');
        $sc_name=SpecificationCategory::select('sc_name')->where('sc_id',$spec_cat_id)->first()->sc_name;

        if (!empty($variant_id)) {
            $name = Variant::with(['model','model.brand'])->select('slug','model_id','brand_id')->where('variant_id', $variant_id)->first();
            $name=$name->model->brand->slug.'_'. $name->model->slug.'_'.$name->slug.'_'.$sc_name;
        } else {
            $name = Model::with(['brand'])->select('model_name','brand_id')->where('model_id', $model_id)->first();
            $name=$name->brand->brand_name.' '. $name->model_name.' '.$sc_name;
        }
        $name=$name.'.xlsx';
        Session::flash('success', 'Excel file downloaded successfully.');

        return Excel::download(new FeatureValues(), $name);

        // Flash success message to the session

        // // Redirect back
        // return back();
    }

    public function view()
    {

        $brands = Brand::select('brand_name', 'brand_id')->where('status', 1)->get();
        $spec_cat = SpecificationCategory::select('sc_name', 'sc_id')->where('status', 1)->get();
        return view('exports.feature_value_view', compact('brands', 'spec_cat'));
    }

    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');
        //dump($selectedBrandId);
        if ($selectedBrandId) {
            $models = Model::select('model_id', 'model_name')->where('brand_id', $selectedBrandId)
                ->active()
                ->get();
        } else {
            $models = [];
        }

        return response()->json(['models' => $models]);
    }

    public function fetchVariants(Request $request)
    {
        $selectedModelId = $request->input('model_id');
        //dump($selectedBrandId);
        if ($selectedModelId) {
            $variants = Variant::select('variant_id', 'variant_name')->where('model_id', $selectedModelId)
                ->active()
                ->get();
        } else {
            $variants = [];
        }

        return response()->json(['variants' => $variants]);
    }

    // public function downlo(Request $request)
    // {
    //     $spec_cat_id = $request->input('spec_cat');
    //     //dump($selectedBrandId);
    //     if ($spec_cat_id) {
    //         $spec_cat = SpecificationCategory::select('spec_cat_id','spec_cat_name')->where('spec_cat_id', $spec_cat_id)
    //             ->active()
    //             ->get();
    //     } else {
    //         $spec_cat = [];
    //     }

    //     return response()->json(['spec_cat' => $spec_cat]);
    // }

}
