<?php

namespace App\Http\Controllers\exports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Exports\BookTestDriveExport;
use Maatwebsite\Excel\Facades\Excel;
use Carbon\Carbon;

class BookTestDriveDataExport extends Controller
{

    public function exportTestDrives(Request $request)
    {
        $filterType = $request->input('filter_type');
        $startDate = null;
        $endDate = null;

        // Determine the date range based on the selected filter type
        switch ($filterType) {
            case 'today':
                $startDate = Carbon::today();
                $endDate = Carbon::today();
                break;
            case 'weekly':
                $startDate = Carbon::now()->startOfWeek();
                $endDate = Carbon::now()->endOfWeek();
                break;
            case 'monthly':
                $startDate = Carbon::now()->startOfMonth();
                $endDate = Carbon::now()->endOfMonth();
                break;
            case 'yearly':
                $startDate = Carbon::now()->startOfYear();
                $endDate = Carbon::now()->endOfYear();
                break;
            case 'custom':
                $startDate = $request->input('start_date');
                $endDate = $request->input('end_date');
                break;
            default:
                // Handle unexpected input or default case
                $startDate = Carbon::today();
                $endDate = Carbon::today();
                break;
        }

        // Pass the dates to the export class
        return Excel::download(new BookTestDriveExport($startDate, $endDate), 'book_test_drives.xlsx');
    }

    public function create()
    {
        return view('exports.book_test_drive');
    }
}
