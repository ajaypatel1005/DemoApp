<?php

namespace App\Http\Controllers\exports;
use App\Exports\PriceExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Brand;
use Illuminate\Support\Facades\Session;

class PriceExportController extends Controller
{
    public function export(Request $request)
    {
        $validatedData = request()->validate([
            'brand_name' => 'required',
        ]);
        $brandId = $request->input('brand_name');
        return Excel::download(new PriceExport($brandId), $brandId.'.xlsx');
    }
    public function create()  {
        $brands=Brand::where('status',1)->get();
        return view('exports.price',compact('brands'));
    }
}
