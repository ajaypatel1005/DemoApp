<?php

namespace App\Http\Controllers\exports;

use App\Exports\VariantsExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class VariantExportController extends Controller
{
    public function downloadInvoices(Request $request)
    {
        if ($request->has('liveVariants')) {
            // Handle live variants export
            return Excel::download(new VariantsExport('live'), 'live_variants.xlsx');
        }
    
        if ($request->has('discontinueVariants')) {
            // Handle discontinued variants export
            return Excel::download(new VariantsExport('discontinued'), 'discontinued_variants.xlsx');
        }
    
        if ($request->has('allVariants')) {
            // Handle all variants export
            return Excel::download(new VariantsExport('all'), 'all_variants.xlsx');
        }
        return Excel::download(new VariantsExport, 'variants.xlsx');
    }
    public function create()  {
        return view('exports.variants');
    }
}
