<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\LogView;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ActivityLogController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $logTypes=LogView::orderBy('log_name', 'asc')->get();
        return view('activity_log.list',compact('logTypes'));
    }

    public function filterActivityLog(Request $request)
    {
        $filterFromDate = $request->input('filter_from_date');
        $filterToDate = $request->input('filter_to_date');
        $filterEvent = $request->input('filter_event');
        $filterSubject = 'App\\Models\\' . $request->input('filter_subject');
        $subject = $request->input('filter_subject');
        $limit=10;
        $page=($request->has('start')?$request->input('start'):0);
        $search=($request->has('search')?$request->input('search')['value']:'');


        $activityLogs = Activity::leftJoin('users', 'activity_log.causer_id', '=', 'users.id')
            ->select('activity_log.*', 'users.name as user_name', 'users.email as user_email');

        // If all three filters are selected, apply conditions for all
        if ($filterFromDate && $filterToDate && $filterEvent && $subject) {
            $activityLogs->where('activity_log.event', '=', $filterEvent)
                ->where('activity_log.subject_type', '=', $filterSubject)
                ->where(function ($query) use ($filterFromDate, $filterToDate) {
                    $query->whereDate('activity_log.created_at', '>=', $filterFromDate)
                        ->whereDate('activity_log.created_at', '<=', $filterToDate);
                });
        } else {
            // If only two of the filters are selected, apply conditions for those two
            if ($filterFromDate && $filterEvent) {
                $activityLogs->where(function ($query) use ($filterFromDate, $filterToDate) {
                    $query->whereDate('activity_log.created_at', '>=', $filterFromDate)
                        ->whereDate('activity_log.created_at', '<=', $filterToDate);
                })
                    ->where('activity_log.event', '=', $filterEvent);
            } elseif ($filterFromDate && $filterToDate && $subject) {
                $activityLogs->where(function ($query) use ($filterFromDate, $filterToDate) {
                    $query->whereDate('activity_log.created_at', '>=', $filterFromDate)
                        ->whereDate('activity_log.created_at', '<=', $filterToDate);
                })
                    ->where('activity_log.subject_type', '=', $filterSubject);
            } elseif ($filterEvent && $subject) {
                $activityLogs->where('activity_log.event', '=', $filterEvent)
                    ->where('activity_log.subject_type', '=', $filterSubject);
            } else {
                // If only one of the filters is selected, apply conditions for that one
                if ($filterFromDate && $filterToDate) {
                    $activityLogs->where(function ($query) use ($filterFromDate, $filterToDate) {
                        $query->whereDate('activity_log.created_at', '>=', $filterFromDate)
                            ->whereDate('activity_log.created_at', '<=', $filterToDate);
                    });
                }

                if ($filterEvent) {
                    if ($filterEvent === 'login') {
                        $activityLogs->whereIn('activity_log.event', ['login', 'logout']);
                    } else {
                        $activityLogs->where('activity_log.event', '=', $filterEvent);
                    }
                }

                if ($subject) {
                    $activityLogs->where('activity_log.subject_type', '=', $filterSubject);
                }
            }
        }
        if(!empty($search)){
            $activityLogs->where('log_name','LIKE','%'.$search.'%');
        }
        // If none of the filters are selected, retrieve the last 500 records
        if (!$filterFromDate && $filterToDate && !$filterEvent && !$filterSubject) {
            $activityLogs->orderBy('activity_log.created_at', 'desc');
        }
        $cntFilter=clone $activityLogs;
        $activityLogs->offset($page)->limit($limit);
        $activityLogs = $activityLogs->get();
        
        $activityLogsTotal = DB::select("SELECT COUNT(*) AS count FROM activity_log")[0]->count;
            
        $data = [];
        $i=$page;
        foreach($activityLogs as $member){
            $i++;
            $created = $member->created_at->format('Y-m-d H:i:s');
            // $status = ($member->status == 1)?'Active':'Inactive';
            $data[] = array("sr_no"=>$i, "created_at"=>$created, "log_name"=>$member->log_name,"description"=> $member->description, "subject_type"=>$member->subject_type, "event"=>$member->event,"causer_type"=>$member->causer_type, "causer_id"=>$member->causer_id,"properties"=>$member->properties);
        }
        return response()->json(array("draw" => $_POST['draw'],"recordsTotal"=>$activityLogsTotal,"recordsFiltered"=>$cntFilter->count(),'data' => $data));

    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
