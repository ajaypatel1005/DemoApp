<?php

namespace App\Http\Controllers;


use App\Models\LogView;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Exception;


class LogController extends Controller
{

    public function create()
    {
        if (!hasAnyPermission(['create_log_view', 'view_log_view'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $log_view = LogView::all();
        return view('log_v.create', compact('log_view'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_log_view'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        //        dd($request->log_name);
        $request->validate([
            'log_name' => 'required|regex:/^[A-Za-z0-9\s]+$/|max:50|unique:cop_logs_ms,log_name',
            'model_name'=>'required|max:50'
        ], [
            'log_name.required' => 'Log name is required',
            'log_name.max' => 'Log name Maximum :max character is required',
            'model_name.required' => 'Log model name is required',
            'model_name.max' => 'Log model name Maximum :max character is required',
            // 'log_name.regex' => 'Log name allow only alphanumeric character',
            // 'log_name.min' => 'Minimum 5 character is required',
            // 'log_name.max' => 'Maximum 20 character is required',
            // 'log_name.unique' => 'Log name already exist',
        ]);

        try {
            LogView::create([
                'log_name' => $request->log_name,
                'model_name' => $request->model_name,
                // 'status' => $request->has('status') ? 1 : 0,
            ]);
            session()->flash('success', 'Log added successfully.');
        } catch (Exception $e) {
            LOG::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('log_v.create');
    }

    /**
     * Display the specified resource.
     */
    //    public function view()
    //    {
    //        $log_view = LogView::select('cop_logs_ms.*', 'cop_brands_ms.brand_name as brand_name', 'cop_ml_ms.lang_name as lang_name')
    //            ->leftJoin('cop_brands_ms', 'cop_logs_ms.brand_id', '=', 'cop_brands_ms.brand_id')
    //            ->leftJoin('cop_ml_ms', 'cop_logs_ms.lang_id', '=', 'cop_ml_ms.lang_id')
    //            ->get();
    //
    ////        $log_view = LogView::get();
    //        return view('log_v.view', ['log_view' => $log_view]);
    //    }

    // public function view()
    // {

    //     return view('activity_log.view');
    // }
    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_log_view', 'view_log_view'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $log_edit = LogView::where('log_id', decrypt($id))->first();
        $log_view = LogView::all();
        return view('log_v.edit', ['log_edit' => $log_edit], ['log_view' => $log_view]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_log_view'])) {
            abort(403, "you don't have permission to access");
        }
        $request->validate(
            [
                'log_name' => 'required|max:50|unique:cop_logs_ms,log_name,' . decrypt($id) . ',log_id',
                'model_name'=>'required|max:50'
            ],
            [
                'log_name.required' => 'Log name is required',
                'log_name.max' => 'Log name Maximum :max character is required',
                'model_name.required' => 'Log model name is required',
                'model_name.max' => 'Log model name Maximum :max character is required',
               
            ]
        );
        try {
            $log_update = LogView::where('log_id', decrypt($id))->first();
           
            if ($log_update) {
                $log_update->log_name = $request->log_name;
                $log_update->model_name = $request->model_name;
                $log_update->save();

                session()->flash('success', 'Log updated successfully.');
            } else {
                session()->flash('error', 'Something went wrong.');
            }
        } catch (Exception $e) {
            LOG::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('log_v.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_log_view'])) {
            abort(403, "you don't have permission to access");
        }
        try {
            $log_destroy = LogView::where('log_id', decrypt($id))->first();
            if (!empty($log_destroy)) {
                $log_destroy->delete();
                session()->flash('success', 'Log deleted successfully.');
            } else {
                session()->flash('error', 'Something went wrong.');
            }
        } catch (Exception $e) {
            LOG::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('log_v.create');
    }

    // public function toggleStatus(Request $request)
    // {
    //     $id = $request->input('id');
    //     DB::table('cop_logs_ms')
    //         ->where('log_id', $id)
    //         ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
    //     return response()->json(['message' => 'Status updated successfully']);
    // }
}
