<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Customer;
use App\Models\Model;
use App\Models\Review;
use Exception;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ReivewController extends Controller
{
    public function view(){

        return view('review.view');
    }

    public function viewDetails(Request $request){
        
        $review_id = decrypt($request->review_id);

        if($review_id){
            $review_details = Review::with(['brands','models'])->where('id',$review_id)->first();

            if ($review_details) {
                return response()->json(['review_details' => $review_details, 'review_id' => $request->review_id]);
            } else {
                return response()->json(['message' => 'Review not found'], 404);
            }
        } else {
            return response()->json(['message' => 'Review ID is required'], 400);
        }
    }

    public function updateDetails(Request $request){

        try {

            $request->validate([
                'review_status' => 'required',
            ], [
                'review_status' => 'Please select the review status.',
            ]);

            $review_id = decrypt($request->review_id);
    
            if ($review_id) {
                $review_update = Review::where('id', $review_id)->update(['status' => $request->review_status]);
    
                if ($review_update) {
                    return response()->json(['success' => true, 'message' => 'Review Status has been updated successfully.']);
                } else {
                    return response()->json(['success' => false, 'message' => 'Failed to update the review status.']);
                }
            } else {
                return response()->json(['success' => false, 'message' => 'Something went wrong']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function fetchRecord(Request $request){
        
        $limit = ($request->has('length') ? $request->input('length') : 10);
        $page = ($request->has('start') ? $request->input('start') : 0);
        $search = ($request->has('search') ? $request->input('search')['value'] : '');

        $review_view = Review::select(
            'cop_brands_ms.brand_name',
            'cop_models.model_name',
            'cop_reviews.id as review_id',
            'cop_reviews.rating',
            'cop_reviews.review',
            'cop_reviews.status'
        )
        ->join('cop_models','cop_reviews.model_id','=','cop_models.model_id')
        ->join('cop_brands_ms','cop_reviews.brand_id','=','cop_brands_ms.brand_id');

        if (!empty($search)) {
            $review_view->where(function ($query) use ($search) {
                $query->orWhere('cop_brands_ms.brand_name', 'LIKE', '%' . $search . '%')
                      ->orWhere('cop_models.model_name', 'LIKE', '%' . $search . '%');
            });
        }

        $cntFilter = clone $review_view;
        $review_view->offset($page)->limit($limit);
        $review_view = $review_view->get();

        $reviewTotal = DB::select("SELECT COUNT(*) AS count FROM cop_reviews INNER JOIN cop_brands_ms ON cop_brands_ms.brand_id = cop_reviews.brand_id INNER JOIN cop_models ON cop_models.model_id = cop_reviews.model_id")[0]->count;

        $data = [];
        $i = $page;
        foreach($review_view as $item) {
            $i++;
            if(is_null($item->status)){
                $review_status = '<span style="color: orange; font-weight: bold;">Pending</span>';
            }else if($item->status == 0){
                $review_status = '<span style="color: red; font-weight: bold;">Reject</span>';
            }else if($item->status == 1){
                $review_status = '<span style="color: green; font-weight: bold;">Approved</span>';
            }
            
            $rating = '';
            for($s=1; $s<=5; $s++){
                if($s <= $item->rating){
                    $rating .= '<i class="fas fa-star text-warning mr-5"></i>';
                } else {
                    $rating .= '<i class="fas fa-star mr-5"></i>';
                }
            }
            

            $action = "";
            if (auth()->user()->can('edit_review')) {
                // $editRoute = route('review.edit', encrypt($item->id));
                $action .= '<a href="javascript:void(0)" class=" btn-primary" id="changeReviewStatus" view-id="'.encrypt($item->review_id).'">
                <i class="fas fa-pen fs-4 text-primary"></i> </a>';
            }
            
            $data[] = array("sr_no" => $i, "brand_name" => $item->brand_name, "model_name" => $item->model_name, "rating" => $rating, "status" => $review_status, "action" => $action);
        }
        return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $reviewTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
    }

    public function create(){

        $customers = Customer::select('customer_id','first_name','last_name')->where('status',1)->get();
        $brands = Brand::active()->get();

        return view('review.create', compact('customers', 'brands'));
    }

    public function store(Request $request){

        if (!hasAnyPermission(['create_review'])) {
            abort(403, "you don't have permission to access");
        }

        $request->validate([
            'customer_id' => 'required',
            'brand_id' => [
                'required',
                Rule::unique('cop_reviews')->where(function ($query) use ($request) {
                    return $query->where('brand_id', $request->brand_id)
                        ->where('model_id', $request->model_id)
                        ->where('created_by', $request->customer_id);
                }),
            ],
            'model_id' => 'required',
            'rating' => 'required',
            'review' => 'required',
        ],[
            'brand_id.unique' => 'The review for this brand and model by this user already exists.',
        ]);

        DB::beginTransaction();
        try {
            
            $review_check = Review::where('brand_id',$request->brand_id)->where('model_id',$request->model_id)->where('created_by',$request->customer_id)->first();

            if($review_check){
                
            }
            $review_store = new Review;

            if($review_store) {
                $review_status = 1;
                $review_store->brand_id = $request->brand_id;
                $review_store->model_id = $request->model_id;
                $review_store->rating = $request->rating;
                $review_store->review = $request->review;
                $review_store->status = $review_status;
                $review_store->created_by = $request->customer_id;
                $review_store->updated_by = $request->customer_id;

                $review_store->save();

                DB::commit();
                session()->flash('success', 'Variant Added Successfully.');
            } else {
                DB::rollBack();
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            // dd($e->getMessage());
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('review.view');
    }

    public function fetchModels(Request $request){
        $selectedBrandId = $request->input('brand_id');

        if ($selectedBrandId) {

            $models = Model::where('brand_id', $selectedBrandId)
                ->active()
                ->get();
        } else {
            $models = [];
        }

        return response()->json(['models' => $models]);
    }
}
