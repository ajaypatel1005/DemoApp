<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use Exception;
use Illuminate\Http\Request;
use App\Models\PostCategoryData;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use Illuminate\Support\Facades\Storage;


class PostCategoryDataController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $post_view = PostCategoryData::select('cop_post.*', 'cop_pct_ms.post_cat_name as post_cat_name')
            ->leftJoin('cop_pct_ms', 'cop_post.post_cat_id', '=', 'cop_pct_ms.post_cat_id')
            ->get();
        $post_cat_type = DB::select('select * from cop_pct_ms where status = 1');
        $brandList = Brand::active()->get();
        return view('post.create', compact('post_cat_type',  'post_view', 'brandList'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //  dd($request->all());

        if (!hasAnyPermission(['create_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'post_cat_id' => 'nullable',
            'brand_id' => 'nullable',
            'title' => 'required|min:2',
            'heading' => 'nullable',
            'content_hidden' => 'required|min:2',
            'post_image' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048',
            'author' => 'nullable|regex:/^[A-Za-z\s]+$/|min:2|max:50',
            'author_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'tags' => 'nullable',
            'post_date' => 'required',
        ], [
            // 'post_cat_id.required' => 'Select Post Category Name is required',
            'title.required' => 'Title is required',
            'title.min' => 'The title must be at least :min characters',
            'content_hidden.required' => 'The Content is required',
            'content_hidden.min' => 'The Content must be at least :min characters.',
            'content_hidden.max' => 'The Content must not exceed :max characters.',
            'post_image.required' => 'Post Image is required',
            'post_image.max' => 'Post Image cannot be greater than 2 MB',
            'post_image.mimes' => 'Post Image must be a PNG, JPG, JPEG, or WebP file.',
            'author.required' => 'Author is required',
            'author.regex' => 'Author is invalid',
            'author_image.nullable' => 'Author Image is required',
            'author_image.max' => 'Author Image cannot be greater than 2 MB',
            'author_image.mimes' => 'Author Image must be a PNG, JPG, JPEG, or WebP file.',
            'post_date.required' => 'Post date is requried',
        ]);
        DB::beginTransaction();
        try {
            $slug = \Illuminate\Support\Str::slug(strtolower($request->slug), '-') ?: \Illuminate\Support\Str::slug(strtolower($request->title), '-');
            // dd($slug);
            $post_store = new PostCategoryData();
            $post_store->post_cat_id = $request->post_cat_id ?? null;
            $post_store->brand_id = $request->brand_id ?? null;
            $post_store->title = $request->title;
            $post_store->content = $request->content_hidden;
            $post_store->heading = $request->heading ?? null;
            $post_store->author = !$request->brand_id && $request->author ? $request->author : null;
            $post_store->tags = $request->tags ?? null;
            $post_store->post_style = $request->post_style ?? null;
            $post_store->post_js = $request->post_js ?? null;
            $post_store->post_date = $request->post_date;
            $post_store->is_popular = $request->has('is_popular') ? 1 : 0;
            // $post_store->is_trending = $request->has('is_trending') ? 1 : 0;
            $post_store->status = $request->has('status') ? 1 : 0;
            $post_store->slug = $slug;
            $post_store->created_by = auth()->id();     //description
            $post_store->save();

            $post_update = PostCategoryData::find($post_store->post_id);

            if ($post_update) {
                $uploadedImage = $request->file('post_image');
                $postImageName = $post_update->post_id . '_post.webp';

                $managerPost = new ImageManager(new Driver());
                $imagePost = $managerPost->read($uploadedImage);

                    // store in digital_ocean_spaces
                    $DoPath = 'post'.'/' . $post_update->post_id . '/post_image/' . $postImageName;
                    Storage::disk('digitalocean')->put($DoPath, $imagePost->toWebp(), 'public');

                $post_update->post_image = $postImageName;

                if (!$request->brand_id && $request->hasFile('author_image')) {
                    $uploadedAutherImage = $request->file('author_image');
                    $authorImageName = $post_update->post_id . '_author.webp';

                    $managerAuther = new ImageManager(new Driver());
                    $imageAuther = $managerAuther->read($uploadedAutherImage);

                        // store in digital_ocean_spaces
                        $DoPathAuther = 'post'.'/' . $post_update->post_id . '/author_image/' . $authorImageName;
                        Storage::disk('digitalocean')->put($DoPathAuther, $imageAuther->toWebp(), 'public');

                    $post_update->author_image = $authorImageName;
                }
                $post_update->update();

                session()->flash('success', 'Post Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.' . $e);
        }

        return redirect()->route('post.view');
    }

    /**
     * View.
     */
    public function view(Request $request)
    {
        if (!hasAnyPermission(['view_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        return view('post.list');
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_post', 'view_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $post_view = PostCategoryData::select('cop_post.*', 'cop_pct_ms.post_cat_name as post_cat_name')
            ->leftJoin('cop_pct_ms', 'cop_post.post_cat_id', '=', 'cop_pct_ms.post_cat_id')
            ->get();

        $post_edit = PostCategoryData::where('post_id', decrypt($id))->first();
        $post_cat_type = DB::select('select * from cop_pct_ms where status = 1');
        $brandList = Brand::active()->get();
        return view('post.edit', compact('post_edit', 'post_cat_type',  'post_view', 'brandList'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'post_cat_id' => 'nullable',
            'brand_id' => 'nullable',
            'title' => 'required|min:2',
            'heading' => 'nullable',
            'content_hidden' => 'required|min:2',
            'post_image' => 'image|mimes:png,jpg,jpeg,webp|max:2048',
            'author' => 'nullable|regex:/^[A-Za-z\s]+$/|min:2|max:50',
            'author_image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'tags' => 'nullable',
            'post_date' => 'required',
        ], [
            // 'post_cat_id.required' => 'Select Post Category Name is required',
            'title.required' => 'Title is required',
            'title.regex' => 'Title is invalid',
            'content_hidden.required' => 'The Content is required.',
            'content_hidden.min' => 'The Content must be at least :min characters.',
            'content_hidden.max' => 'The Content must not exceed :max characters.',
            'post_image.max' => 'Post Image cannot be greater than 2 MB',
            'post_image.mimes' => 'Post Image must be a PNG, JPG, JPEG, or WebP file.',
            'author.required' => 'Author is required',
            'author.regex' => 'Author is invalid',
            'author_image.nullable' => 'Author Image is required',
            'author_image.max' => 'Author Image cannot be greater than 2 MB',
            'author_image.mimes' => 'Author Image must be a PNG, JPG, JPEG, or WebP file.',
            'post_date.required' => 'Post date is requried',
        ]);

        DB::beginTransaction();
        try {
            $post_update = PostCategoryData::where('post_id', decrypt($id))->first();

            if ($post_update) {
                // Handle Post Image update
                if (isset($request->post_image)) {
                    $uploadedImage = $request->file('post_image');
                    $postImageName = $post_update->post_id . '_post.webp';

                    $managerPost = new ImageManager(new Driver());
                    $imagePost = $managerPost->read($uploadedImage);

                        // store in digital_ocean_spaces
                        $DoPath = 'post'.'/' . $post_update->post_id . '/post_image/' . $postImageName;
                        Storage::disk('digitalocean')->put($DoPath, $imagePost->toWebp(), 'public');

                    $post_update->post_image = $postImageName;
                }

                // Handle Author Image update
                if (!$request->brand_id && isset($request->author_image)) {
                    $uploadedAutherImage = $request->file('author_image');
                    $authorImageName = $post_update->post_id . '_author.webp';

                    $managerAuther = new ImageManager(new Driver());
                    $imageAuther = $managerAuther->read($uploadedAutherImage);

                        // store in digital_ocean_spaces
                        $DoPathAuther = 'post'.'/' . $post_update->post_id . '/author_image/' . $authorImageName;
                        Storage::disk('digitalocean')->put($DoPathAuther, $imageAuther->toWebp(), 'public');

                    $post_update->author_image = $authorImageName;
                }
                if ($request->brand_id && $post_update->author_image !== null) {
                    // delete full directory from digital_ocean_spaces
                    $postAuthorImageFolder='post'.'/' . $post_update->post_id . '/author_image';
                    Storage::disk('digitalocean')->deleteDirectory($postAuthorImageFolder);

                    $post_update->author_image = null;
                }

                // Update other fields

                $slug = \Illuminate\Support\Str::slug(strtolower($request->slug), '-') ?: \Illuminate\Support\Str::slug(strtolower($request->title), '-');

                $post_update->post_cat_id = $request->post_cat_id ?? null;
                $post_update->brand_id = $request->brand_id ?? null;
                $post_update->title = $request->title;
                $post_update->content = $request->content_hidden;
                $post_update->heading = $request->heading ?? null;
                $post_update->author = !$request->brand_id && $request->author ? $request->author : null;
                $post_update->tags = $request->tags ?? null;
                $post_update->post_date = $request->post_date;
                $post_update->post_style = $request->post_style ?? null;
                $post_update->post_js = $request->post_js ?? null;
                $post_update->is_popular = $request->has('is_popular') ? 1 : 0;
                // $post_update->is_trending = $request->has('is_trending') ? 1 : 0;
                $post_update->status = $request->has('status') ? 1 : 0;
                $post_update->slug = $slug;
                $post_update->updated_by = auth()->id();
                $post_update->update();

                session()->flash('success', 'Post Updated Successfully.');
            } else {
                session()->flash('error', 'Record Not Found.');
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }

        return redirect()->route('post.view');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_post'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        DB::beginTransaction();
        try {
            $post_destroy = PostCategoryData::where('post_id', decrypt($id))->first();

            if (!empty($post_destroy)) {

                // delete full directory from digital_ocean_spaces
                $postIdFolder='post'.'/' . $post_destroy->post_id;
                Storage::disk('digitalocean')->deleteDirectory($postIdFolder);

                $post_destroy->delete();
                DB::commit();

                session()->flash('success', 'Post Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong!');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('post.view');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_post')
            ->where('post_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            $limit = ($request->has('length') ? $request->input('length') : 10);
            $page = ($request->has('start') ? $request->input('start') : 0);
            $search = ($request->has('search') ? $request->input('search')['value'] : '');

            $post_view = PostCategoryData::select('cop_post.title', 'cop_post.author', 'cop_post.post_date', 'cop_post.post_id', 'cop_post.status', 'cop_pct_ms.post_cat_name')
                ->leftJoin('cop_pct_ms', 'cop_post.post_cat_id', '=', 'cop_pct_ms.post_cat_id');
            // ->get();
            if (!empty($search)) {
                $post_view->where(function ($query) use ($search) {
                    $query->orWhere('cop_post.title', 'LIKE', '%' . $search . '%')
                        ->orWhere('cop_post.author', 'LIKE', '%' . $search . '%')
                        ->orWhere('cop_post.post_date', 'LIKE', '%' . $search . '%')
                        ->orWhere('cop_pct_ms.post_cat_name', 'LIKE', '%' . $search . '%');
                });
            }

            $cntFilter = clone $post_view;
            $post_view->offset($page)->limit($limit);
            $post_view = $post_view->get();

            $brandTotal = DB::select("SELECT COUNT(*) AS count FROM cop_post")[0]->count;
            $data = [];
            $i = $page;
            foreach ($post_view as $member) {
                $i++;
                $status = $disable = "";
                if ($member->status == 1) {
                    $status = 'checked';
                }
                $disable = (!auth()->user()->can('edit_post')) ? 'disabled' : '';

                $model_status = '<div
                    class="form-check form-switch form-check-custom form-check-success form-check-solid">
                    <input class="form-check-input" name="status" type="checkbox" value="' . $member->post_id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>';
                $action = "";
                if (auth()->user()->can('edit_post')) {
                    $editRoute = route('post.edit', encrypt($member->post_id));
                    $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                            <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                }
                if (auth()->user()->can('delete_post')) {
                    $action .= '<a href="javascript:void(0);"
                        data-href="' . route('post.destroy', encrypt($member->post_id)) . '"
                        class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                }
                $data[] = array("sr_no" => $i, "post_cat_name" => $member->post_cat_name ?? '-', "title" => $member->title  ?? '-', "author" => $member->author ?? '-', "post_date" => $member->post_date ?? '-', "status" => $model_status, "action" => $action);
            }
            return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $brandTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
        }
    }
}
