<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CRM\Lead;
use App\Models\CRM\LeadHistory;
use App\Models\CRM\LeadNotes;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class LeadNotesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    public function list(Request $request)
    {
        //
        try {
            // Attempt to decrypt the lead_id from the request
            $decryptedLeadId = decrypt($request->id);

            // Fetch notes with the specified lead_id
            $notes = LeadNotes::with(['created_user' => function ($query) {
                $query->select('id', 'name');
            }])
                ->where('lead_id', $decryptedLeadId)
                ->orderByDesc('created_at')
                ->get()->map(function ($leadnote) {
                    $leadnote['notes_id'] = encrypt($leadnote['ln_id']); // Encrypt lead_id and assign it to id
                    unset($leadnote['ln_id']); // Remove lead_id
                    return $leadnote;
                });

            $notes->each(function ($note) {
                if ($note->created_user) {
                    unset($note->created_user->id);
                    unset($note->lead_id);
                    // encrypt($note->ln_id)

                    $note->formatted_created_at = Carbon::parse($note->created_at)->format('F j, Y H:i');
                }
            });
            // Return the notes as a JSON response
            return response()->json(['notes' => $notes]);
        } catch (Exception $e) {
            // Handle decryption errors
            return response()->json(['error' => 'Decryption failed.'], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $validator = Validator::make(
            $request->all(),
            [
                'note_remark' => 'required|min:2|max:500',
            ],
            [
                'note_remark.required' => 'The Notes is required.',
                'note_remark.min' => 'The Notes must be at least :min characters.',
                'note_remark.max' => 'The Notes must not exceed :max characters.',
            ]
        );

        // Check validation
        if ($validator->fails()) {
            return ResponseHelper::errorResponseLead($validator->errors());
        }

        try {

            $notes = new LeadNotes;
            $notes->ln_notes = $request->note_remark;
            $notes->lead_id = decrypt($request->id);
            $notes->created_by = Auth::user()->id;
            $notes->save();

            if ($notes) {

                    $leadDetail = Lead::where('lead_id',$notes->lead_id)->first();
                    $leadHistory = new LeadHistory();
                    $leadHistory->lead_id = $leadDetail->lead_id;
                    $leadHistory->lp_id =$leadDetail->lp_id;
                    $leadHistory->lps_id =$leadDetail->lps_id;
                    $leadHistory->ls_status_id = $leadDetail->ls_status_id;
                    $leadHistory->lt_id = $leadDetail->lt_id;
                    $leadHistory->ln_id = $notes->ln_id;
                    $leadHistory->created_by = Auth::user()->id;
                    $leadHistory->lh_type = "notes";
                    $leadHistory->save();

                return ResponseHelper::responseMessageLead('success', 'Notes Added Successfully.');
            } else {
                return ResponseHelper::errorResponseLead(['Error...While add Activity.!!']);
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            // session()->flash('error', 'Something Went Wrong.');
            return ResponseHelper::errorResponseLead(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request)
    {
        //

        $notes = LeadNotes::where('ln_id', decrypt($request->notes_id))->get();
        $notes[0]['notes_id'] = encrypt($notes[0]->ln_id);
        unset($notes[0]['ln_id']);
        return response()->json(['notes' => $notes]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        //
        $validator = Validator::make(
            $request->all(),
            [
                'note_remark' => 'required|min:2|max:500',
            ],
            [
                'note_remark.required' => 'The Notes is required.',
                'note_remark.min' => 'The Notes must be at least :min characters.',
                'note_remark.max' => 'The Notes must not exceed :max characters.',
            ]
        );

        // Check validation
        if ($validator->fails()) {
            return ResponseHelper::errorResponseLead($validator->errors());
        }

        try {
            $note = LeadNotes::findOrFail(decrypt($request->notes_id));;
            // Check if the note exists
            if (!$note) {
                return ResponseHelper::errorResponseLead(['Note not found']);
            }

            // Update the note attributes
            $note->ln_notes = $request->note_remark;
            $note->updated_by = Auth::user()->id;
            $note->save();

            return ResponseHelper::responseMessageLead('success', 'Note Updated Successfully.');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponseLead(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        //
        try {
            // Find the activity by its ID
            $notes = LeadNotes::findOrFail(decrypt($request->notes_id));

            // Delete the activity
            $notes->delete();

            // Check if the activity was deleted successfully
            return ResponseHelper::responseMessageLead('success', 'Notes Deleted Successfully.');
        } catch (Exception $e) {
            // Log any errors that occur during the deletion process
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());

            // Return an error response
            return ResponseHelper::errorResponseLead(['Something Went Wrong.' . $e->getMessage()]);
        }
    }
}
