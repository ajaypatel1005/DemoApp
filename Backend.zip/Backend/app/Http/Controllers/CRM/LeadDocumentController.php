<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Exception;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CRM\LeadDocument;

class LeadDocumentController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validation rules with custom messages
        $validator = Validator::make(
            $request->all(),
            [
                'edit_activty_lead_id' => $request->has('edit_activty_lead_id') ? 'required' : '',
                'dt_id' => 'required',
                'lead_documents' => 'required|file|mimes:jpeg,png,pdf,webp|max:2048',
            ],
            [
                'edit_activty_lead_id.required' => 'Select the Lead.',
                'dt_id.required' => 'Select the Activity Type.',
                'lead_documents.required' => 'Please upload a document.',
                'lead_documents.file' => 'The uploaded file must be a valid file.',
                'lead_documents.mimes' => 'The uploaded file must be a JPEG, PNG, PDF, or WEBP.',
                'lead_documents.max' => 'The uploaded file may not be greater than :max kilobytes in size.',
            ]
        );

        // Check validation
        if ($validator->fails()) {
            return ResponseHelper::errorResponseLead($validator->errors());
        }

        try {
            $document_store = new LeadDocument;
            $document_store->lead_id = $request->edit_activty_lead_id;
            $document_store->dt_id = $request->dt_id;
            $document_store->save();

            $document_update = LeadDocument::find($document_store->lead_doc_id);
            if (!empty($document_update)) {
                $lead_doc_id = $document_update->lead_doc_id;
                $uploadedFile = $request->file('lead_documents');

                // Check if the uploaded file is an image
                if ($uploadedFile->getClientOriginalExtension() === 'pdf') {
                    $pdfFileName = $lead_doc_id . "PDF_" . strtotime(now()) . '.pdf';
                    $uploadedFile->move(public_path('lead_documents'), $pdfFileName);
                    $document_update->lead_documents = $pdfFileName;
                } else {
                    $document_update = LeadDocument::find($document_store->lead_doc_id);
                    if (!empty($document_update)) {
                        $lead_doc_id = $document_update->lead_doc_id;
                        $uploadedImage = $request->file('lead_documents');
                        $webpImageName = $lead_doc_id . "IMG_" . strtotime(now()) . '.webp';
                        $uploadedImage->move(public_path('lead_documents'), $webpImageName);
                        $document_update->lead_documents = $webpImageName;
                    }
                }
                $document_update->update();
                session()->flash('success', 'Document Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }

            return ResponseHelper::responseMessageLead('success', 'Document Added Successfully.');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponseLead(['Something Went Wrong.' . $e->getMessage()]);
        }
    }


    public function leadDocumentList(Request $request)
    {
        try {
            $leadDocument = LeadDocument::with(['document_type'])
                ->where('lead_id', '=', decrypt($request->id))
                ->get();

            return response()->json(['leadDocument' => $leadDocument]);
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            // session()->flash('error', 'Something Went Wrong.');
            return ResponseHelper::errorResponseLead(['Something Went Wrong.']);
        }
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {

        try {
            $lead_delete = LeadDocument::findOrFail($request->documentId);

            if ($lead_delete) {
                $fileName = $lead_delete->lead_documents;

                $filePath = public_path('lead_documents') . '/' . $fileName;

                if (File::exists($filePath)) {
                    File::delete($filePath);
                }

                $lead_delete->delete();

                // Check if the document was deleted successfully
                return ResponseHelper::responseMessageLead('success', 'Document Deleted Successfully.');
            } else {
                // Return an error response if document not found
                return ResponseHelper::errorResponseLead(['Document Not Found.']);
            }
        } catch (Exception $e) {
            // Log any errors that occur during the deletion process
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());

            // Return an error response
            return ResponseHelper::errorResponseLead(['Something Went Wrong.' . $e->getMessage()]);
        }

    }
}
