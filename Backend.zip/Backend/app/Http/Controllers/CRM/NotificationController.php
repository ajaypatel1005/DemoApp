<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\CRM\LeadActivity;
use App\Models\CRM\LeadNotification;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

class NotificationController extends Controller
{
    //

    public function index()
    {

    }

    public function fetchNotifications()
    {

        $currentDateTime = Carbon::now()->format('Y-m-d H:i');
        // $notifications = LeadNotification::where(DB::raw("DATE_FORMAT(reminder_date, '%Y-%m-%d %H:%i')"), '<=', $currentDateTime)
        //     ->get();
        $notifications = LeadNotification::with(['lead'])
            ->where(DB::raw("DATE_FORMAT(reminder_date, '%Y-%m-%d %H:%i')"), '<=', $currentDateTime)
            ->where('status', 0)
            ->where('created_by', Auth::user()->id)
            ->get();

            foreach ($notifications as $notification) {
                // $notification->lead_id = Crypt::encryptString($notification->lead_id);
                $notification->lead_id = encrypt($notification->lead_id);
            }

           $notifications->map(function ($notification) {
                    $notification->formatted_date = date('jS F Y \a\t h:i A', strtotime($notification->reminder_date));
                    return $notification;
                });

        // $notifications = LeadActivity::where(DB::raw("DATE_FORMAT(reminder_datetime, '%Y-%m-%d %H:%i')"), $currentDateTime)
        //     ->get();
        // $notifications=LeadActivity::get();

        return response()->json($notifications);
    }

    public function updateNotifications(Request $request)
    {
        $lr_id = $request->input('lr_id');
        // die($lr_id);
        if($lr_id){
        LeadNotification::where('lr_id', $lr_id)->update(['status' => 1]);

        return response()->json(['success' => true, 'message' => 'Notification updated successfully']);
        } else {
            return response()->json(['success' => false, 'message' => 'Notification not found'], 404);
        }
    }


}
