<?php

namespace App\Http\Controllers\CRM;
use App\Http\Controllers\Controller;

use App\Models\CRM\LeadStatus;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LeadStatusController extends Controller
{
    //
    public function index()
    {
        //

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_lead_source', 'view_lead_source'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $all_leadStatus = LeadStatus::get();
        return view('crm.lead_status.create', compact('all_leadStatus'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_lead_source'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $request->validate(
            [
                'ls_status_name' => 'required|min:2|max:50|unique:cop_lead_status_ms,ls_status_name',
            ],
            [
                'ls_status_name.required' => 'Status Name Required',
                'ls_status_name.min' => 'The Status Name must be at least :min characters.',
                'ls_status_name.max' => 'The Status Name must not exceed :max characters.',
                'ls_status_name.unique' => 'Status Name has already been taken.',

            ]
        );
        try
        {
            $leadSource = new LeadStatus;
            $leadSource->ls_status_name=$request->ls_status_name;
            $leadSource->status = $request->has('status') ? 1 : 0;
            $leadSource->save();

            session()->flash('success', 'Lead Status Added Successfully.');

            return redirect()->route('lead_status.create');
        }
        catch(Exception $e)
        {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    // /**
    //  * Display the specified resource.
    //  */
    public function show(LeadStatus $leadSource)
    {
        //
    }

    // /**
    //  * Show the form for editing the specified resource.
    //  */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_lead_source', 'view_lead_source'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $all_leadStatus=LeadStatus::get();
        $leadstatus = LeadStatus::where('ls_status_id', decrypt($id))->first();
        return view('crm.lead_status.edit',compact('all_leadStatus','leadstatus'));
    }

    // /**
    //  * Update the specified resource in storage.
    //  */
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_lead_source', 'view_lead_source'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'ls_status_name' => 'required|min:2|max:50|unique:cop_lead_status_ms,ls_status_name,'.decrypt($id).',ls_status_id',
            ],
            [
                'ls_status_name.required' => 'Status Name Required',
                'ls_status_name.min' => 'The Status Name must be at least :min characters.',
                'ls_status_name.max' => 'The Status Name must not exceed :max characters.',
                'ls_status_name.unique' => 'Status Name has already been taken.',

            ]
        );
        try {
            $leadstatus = LeadStatus::where('ls_status_id', decrypt($id))->first();
            if ($leadstatus) {
                $leadstatus->ls_status_name = $request->ls_status_name;
                $leadstatus->status = $request->has('status') ? 1 : 0;
                $leadstatus->update();

                session()->flash('success', 'Lead Status Update Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('lead_status.create');
    }

    // /**
    //  * Remove the specified resource from storage.
    //  */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_lead_source'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        try {
            $leadStatus = LeadStatus::where('ls_status_id', decrypt($id))->first();

            if ($leadStatus) {
                $leadStatus->delete();

                session()->flash('success', 'Lead Status Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            return redirect()->route('lead_status.create');

        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

    // /**
    //  * Toggle status feild active/Inactive.
    //  */
    public function toggleStatus(Request $request)
    {
        //Begin::toggle lead source status
        $id = $request->input('id');
        $leadStatus = LeadStatus::find($id);
        $leadStatus->status = $leadStatus->status == 1 ? 0 : 1;
        $leadStatus->save();
        //End::toggle lead source status

        return response()->json(['message' => 'Status updated successfully']);
    }
}
