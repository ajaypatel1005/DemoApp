<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\CRM\Lead;
use App\Models\CRM\LeadActivity;
use App\Models\CRM\LeadSource;
use App\Models\CRM\LeadStatus;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    // public function show()
    // {
    //     if (!hasAnyPermission(['crm_dashboard'])) {
    //         abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
    //     }

    //     //for total lead card
    //     $total_lead_count = Lead::count();

    //     //for active lead card
    //     $active_lead_count = Lead::whereHas('lead_status', function ($query) {
    //         $query->where('ls_status_name', 'In Progress');
    //     })->count();

    //     //for Fresh lead card
    //     $unassign_lead_count = Lead::where(function ($query) {
    //         $query->where('assign_id', '=', null)
    //             ->where('lps_id', '=', null);
    //     })
    //         ->whereHas('lead_status', function ($query) {
    //             $query->where('ls_status_name', 'New')
    //                 ->orWhere('ls_status_name', 'Assigned');
    //         })
    //         ->count();

    //     //for win lead card
    //     $win_lead_count = Lead::whereHas('lead_status', function ($query) {
    //         $query->where('ls_status_name', 'Win');
    //     })->count();

    //     // For pie chart data
    //     $dataPieChart = Lead::select('cop_lead_source_ms.ls_name AS Name', DB::raw('COUNT(*) AS lead_count'))
    //         ->leftJoin('cop_lead_source_ms', 'cop_leads.ls_id', '=', 'cop_lead_source_ms.ls_id')
    //         ->groupBy('cop_leads.ls_id', 'cop_lead_source_ms.ls_name')
    //         ->get();

    //     //For Bar Chart data
    //     $currentYear = date('Y');
    //     $Bar_Chart_Data = Lead::selectRaw(
    //         'YEAR(cop_leads.created_at) as year,
    //                  COUNT(*) as total_leads,
    //                  SUM(CASE WHEN ls.ls_status_name = "In Progress" THEN 1 ELSE 0 END) as active_leads,
    //                  SUM(CASE WHEN ls.ls_status_name = "Win" THEN 1 ELSE 0 END) as win_leads,
    //                  SUM(CASE WHEN ls.ls_status_name = "Lost" THEN 1 ELSE 0 END) as lost_leads,
    //                  SUM(CASE WHEN ls.ls_status_name = "On Hold" THEN 1 ELSE 0 END) as hold_leads',
    //     )
    //         ->leftJoin('cop_lead_status_ms as ls', 'cop_leads.ls_status_id', '=', 'ls.ls_status_id')
    //         ->whereYear('cop_leads.created_at', '>=', $currentYear - 3)
    //         ->groupBy('year')
    //         ->get();

    //     //For Manager Table data
    //     $leadCountsByManager = Lead::leftJoin('cop_lead_status_ms as in_progress_status', function ($join) {
    //         $join->on('cop_leads.ls_status_id', '=', 'in_progress_status.ls_status_id')
    //             ->where('in_progress_status.ls_status_name', '=', 'In Progress');
    //     })
    //         ->leftJoin('cop_lead_status_ms as win_status', function ($join) {
    //             $join->on('cop_leads.ls_status_id', '=', 'win_status.ls_status_id')
    //                 ->where('win_status.ls_status_name', '=', 'Win');
    //         })
    //         ->leftJoin('cop_lead_status_ms as lost_status', function ($join) {
    //             $join->on('cop_leads.ls_status_id', '=', 'lost_status.ls_status_id')
    //                 ->where('lost_status.ls_status_name', '=', 'Lost');
    //         })
    //         // Add left join for 'Fresh' status with the given condition
    //         ->leftJoin('cop_lead_status_ms as fresh_status', function ($join) {
    //             $join->on('cop_leads.ls_status_id', '=', 'fresh_status.ls_status_id')
    //                 ->where(function ($query) {
    //                     $query->where('assign_id', '=', null)
    //                         ->orwhere('lps_id', '=', null);
    //                 })
    //                 ->where(function ($query) {
    //                     $query->where('fresh_status.ls_status_name', '=', 'New')
    //                         ->orWhere('fresh_status.ls_status_name', '=', 'Assigned');
    //                 });
    //         })
    //         ->join('users', 'cop_leads.manager_user_id', '=', 'users.id')
    //         ->leftJoin('cop_brands_ms as brand', 'cop_leads.brand_id', '=', 'brand.brand_id')
    //         ->groupBy('cop_leads.manager_user_id', 'users.name', 'brand.brand_name')
    //         ->select(
    //             'users.name',
    //             DB::raw('COUNT(cop_leads.lead_id) as total_lead_count'),
    //             'brand.brand_name as brand_name',
    //             DB::raw('COUNT(in_progress_status.ls_status_id) as active_lead_count'),
    //             DB::raw('COUNT(win_status.ls_status_id) as win_lead_count'),
    //             DB::raw('COUNT(lost_status.ls_status_id) as lost_lead_count'),
    //             DB::raw('COUNT(fresh_status.ls_status_id) as fresh_lead_count')
    //         )
    //         ->get()
    //         ->toArray();


    //     //for telecaller data

    //     $leadCountsByTelecaller = Lead::leftJoin('cop_lead_status_ms as in_progress_status', function ($join) {
    //         $join->on('cop_leads.ls_status_id', '=', 'in_progress_status.ls_status_id')
    //             ->where('in_progress_status.ls_status_name', '=', 'In Progress');
    //     })
    //         ->leftJoin('cop_lead_status_ms as win_status', function ($join) {
    //             $join->on('cop_leads.ls_status_id', '=', 'win_status.ls_status_id')
    //                 ->where('win_status.ls_status_name', '=', 'Win');
    //         })
    //         ->leftJoin('cop_lead_status_ms as lost_status', function ($join) {
    //             $join->on('cop_leads.ls_status_id', '=', 'lost_status.ls_status_id')
    //                 ->where('lost_status.ls_status_name', '=', 'Lost');
    //         })
    //         // Add left join for 'Fresh' status with the given condition
    //         ->leftJoin('cop_lead_status_ms as fresh_status', function ($join) {
    //             $join->on('cop_leads.ls_status_id', '=', 'fresh_status.ls_status_id')
    //                 ->where(function ($query) {
    //                     $query->Where('lps_id', '=', null);
    //                 })
    //                 ->where(function ($query) {
    //                     $query->Where('fresh_status.ls_status_name', '=', 'Assigned');
    //                 });
    //         })
    //         ->join('users', 'cop_leads.assign_id', '=', 'users.id')
    //         ->leftJoin('cop_brands_ms as brand', 'cop_leads.brand_id', '=', 'brand.brand_id')
    //         ->groupBy('cop_leads.assign_id', 'users.name', 'brand.brand_name')
    //         ->select(
    //             'users.name',
    //             DB::raw('COUNT(cop_leads.lead_id) as total_lead_count'),
    //             'brand.brand_name as brand_name',
    //             DB::raw('COUNT(in_progress_status.ls_status_id) as active_lead_count'),
    //             DB::raw('COUNT(win_status.ls_status_id) as win_lead_count'),
    //             DB::raw('COUNT(lost_status.ls_status_id) as lost_lead_count'),
    //             DB::raw('COUNT(fresh_status.ls_status_id) as fresh_lead_count')
    //         )
    //         ->get()
    //         ->toArray();

    //     //For recently created leads
    //     $recently_created = Lead::join('users', 'cop_leads.manager_user_id', '=', 'users.id')
    //         ->leftJoin('cop_brands_ms as brand', 'cop_leads.brand_id', '=', 'brand.brand_id')
    //         ->leftJoin('cop_lead_pipeline_stage_ms as stage', 'cop_leads.lps_id', '=', 'stage.lps_id')
    //         ->select(
    //             'users.name as manager_name',
    //             // 'stage.lps_name',
    //             DB::raw('IFNULL(stage.lps_name, "Not Active") as lps_name'),
    //             'cop_leads.lead_name',
    //             // 'cop_leads.created_at',
    //             DB::raw("DATE_FORMAT(cop_leads.created_at, '%m/%d/%y') AS date"),
    //             'brand.brand_name as brand_name'
    //         )
    //         ->orderBy('cop_leads.created_at', 'desc')
    //         ->get()
    //         ->toArray();

    //     //for lead source conversion rate
    //     $source_conversion = Lead::join('cop_lead_source_ms as lead_source', 'cop_leads.ls_id', '=', 'lead_source.ls_id')
    //         ->leftJoin('cop_lead_status_ms as win_status', function ($join) {
    //             $join->on('cop_leads.ls_status_id', '=', 'win_status.ls_status_id')
    //                 ->where('win_status.ls_status_name', '=', 'Win');
    //         })
    //         ->groupBy('cop_leads.ls_id', 'lead_source.ls_name')
    //         ->select(
    //             'lead_source.ls_name',
    //             // DB::raw('COUNT(CASE WHEN cop_leads.ls_status_id = 4 THEN 1 ELSE NULL END) as count'),
    //             DB::raw('COUNT(cop_leads.lead_id) as all_count'),
    //             DB::raw('CONCAT(ROUND((COUNT(win_status.ls_status_id)/COUNT(cop_leads.lead_id))*100,2)," %") as conversion_rate')
    //         )
    //         ->get()
    //         ->toArray();

    //     $activity_telecaller = LeadActivity::join('cop_leads', 'cop_lead_activity.lead_id', '=', 'cop_leads.lead_id')
    //         ->join('cop_activity_type', 'cop_lead_activity.at_id', '=', 'cop_activity_type.at_id')
    //         ->join('cop_brands_ms', 'cop_leads.brand_id', '=', 'cop_brands_ms.brand_id')
    //         ->select(
    //             'cop_leads.lead_name',
    //             'cop_lead_activity.la_title',
    //             'cop_activity_type.at_name',
    //             'cop_brands_ms.brand_name',
    //             DB::raw("DATE_FORMAT(cop_lead_activity.created_at, '%m/%d/%y') AS date"),
    //         )
    //         ->orderBy('cop_lead_activity.created_at', 'desc')
    //         ->get()
    //         ->toArray();
    //     return view('crm.dashboard.demo', compact('total_lead_count', 'active_lead_count', 'unassign_lead_count', 'win_lead_count', 'dataPieChart', 'leadCountsByManager', 'Bar_Chart_Data', 'recently_created', 'source_conversion', 'activity_telecaller', 'leadCountsByTelecaller'));
    // }


    public function LeadData(Request $request)
    {
        // Lead Count Data show and Total lead count
        $daterange = explode(' - ', $request->date_range);
        $fromDate = Carbon::createFromFormat('d/m/Y', $daterange[0])->format('Y-m-d');
        $toDate = Carbon::createFromFormat('d/m/Y', $daterange[1])->format('Y-m-d');

        $leadStatusCounts = LeadStatus::select(
            'cop_lead_status_ms.ls_status_id',
            'cop_lead_status_ms.ls_status_name',
            DB::raw("(select count(cop_leads.ls_status_id) from cop_leads where (DATE(cop_leads.created_at) between '$fromDate' and '$toDate') and cop_lead_status_ms.ls_status_id = cop_leads.ls_status_id) as lead_count")
        )
            ->get();

        $statusCounts = [];
        foreach ($leadStatusCounts as $leadStatus) {
            $statusCounts[$leadStatus->ls_status_name] = $leadStatus->lead_count;
        }

        $totalLeads = $leadStatusCounts->sum('lead_count');
        
        return response()->json(['todayStatusCounts' => $statusCounts, 'todayTotalLeads' => $totalLeads]);
    }

    public function SourceData(Request $request)
    {

        // Pass lead source data for arm chart
        $daterange = explode(' - ', $request->date_range);
        $fromDate = Carbon::createFromFormat('d/m/Y', $daterange[0])->startOfDay();
        $toDate = Carbon::createFromFormat('d/m/Y', $daterange[1])->endOfDay();
        $leadSourceData = LeadSource::leftJoin('cop_leads', 'cop_leads.ls_id', '=', 'cop_lead_source_ms.ls_id')
            ->where(function ($query) use ($fromDate, $toDate) {
                $query->whereBetween('cop_leads.created_at', [$fromDate, $toDate])
                    ->orWhereNull('cop_leads.created_at');
            })
            ->groupBy('cop_lead_source_ms.ls_id', 'cop_lead_source_ms.ls_name')
            ->select(
                'cop_lead_source_ms.ls_id',
                'cop_lead_source_ms.ls_name',
                DB::raw('count(cop_leads.ls_id) as lead_count')
            )
            ->get();
            
        // Pass Telecaller Data and total Leads assign by manager
        $leadStatusArr =[config('constant.LEAD_STATUS.IN_PROGRESS'),config('constant.LEAD_STATUS.ON_HOLD'),config('constant.LEAD_STATUS.WIN'),config('constant.LEAD_STATUS.LOST'),config('constant.LEAD_STATUS.ASSIGNED')];
        $leadStatus= implode(',', array_map(function ($item) {
            return "'" . $item . "'";
        }, $leadStatusArr));

        $leadCountsByTelecaller=Lead::select(DB::raw('DISTINCT cop_leads.assign_id'),'cop_manager_ms.first_name as name',DB::raw("(SELECT CONCAT('[',GROUP_CONCAT(JSON_OBJECT(
                        'lead_status',cop_lead_status_ms.ls_status_id,
                        'cnt',(SELECT count(child_lead.lead_id) from cop_leads as child_lead where child_lead.ls_status_id=cop_lead_status_ms.ls_status_id and child_lead.assign_id=cop_leads.assign_id)
                    )
        ),']')
            from cop_lead_status_ms
            where cop_lead_status_ms.ls_status_id in(".$leadStatus.") ) as json_resp,(SELECT count(tot_cp_lead.lead_id) from cop_leads as tot_cp_lead where tot_cp_lead.assign_id=cop_leads.assign_id) as total_lead_count")
        )
        ->join('cop_manager_ms','cop_manager_ms.user_id','=','cop_leads.assign_id')
        ->get()->map(function($data){
                $json_arr = json_decode($data->json_resp,true);
                $result = call_user_func_array('array_merge_recursive', $json_arr);
                $finalData = array_combine($result['lead_status'],$result['cnt']);
            return ['name'=>$data->name,
                    'total_lead_count'=>$data->total_lead_count,
                    "fresh_lead_count"=>$finalData[config("constant.LEAD_STATUS.ASSIGNED")],
                    "active_lead_count"=>$finalData[config("constant.LEAD_STATUS.IN_PROGRESS")],
                    "onhold_lead_count"=>$finalData[config("constant.LEAD_STATUS.ON_HOLD")],
                    "win_lead_count"=>$finalData[config("constant.LEAD_STATUS.WIN")],
                    "lost_lead_count"=>$finalData[config("constant.LEAD_STATUS.LOST")],
                ];
        });
    
        // Pass Manager Data and total Lead
            $leadCountsByManager=Lead::select(DB::raw('DISTINCT cop_leads.manager_user_id'),'cop_manager_ms.first_name as name',DB::raw("(SELECT CONCAT('[',GROUP_CONCAT(JSON_OBJECT(
                            'lead_status',cop_lead_status_ms.ls_status_id,
                            'cnt',(SELECT count(child_lead.lead_id) from cop_leads as child_lead where child_lead.ls_status_id=cop_lead_status_ms.ls_status_id and child_lead.manager_user_id=cop_leads.manager_user_id)
                        )
                ),']')
                from cop_lead_status_ms
                where cop_lead_status_ms.ls_status_id in(".$leadStatus.") ) as json_resp,(SELECT count(tot_cp_lead.lead_id) from cop_leads as tot_cp_lead where tot_cp_lead.manager_user_id=cop_leads.manager_user_id) as total_lead_count")
                )
                ->join('cop_manager_ms','cop_manager_ms.user_id','=','cop_leads.manager_user_id')
                ->get()->map(function($data){
                    $json_arr = json_decode($data->json_resp,true);
                    $result = call_user_func_array('array_merge_recursive', $json_arr);
                    $finalData = array_combine($result['lead_status'],$result['cnt']);
                return ['name'=>$data->name,
                        'total_lead_count'=>$data->total_lead_count,
                        "fresh_lead_count"=>$finalData[config("constant.LEAD_STATUS.ASSIGNED")],
                        "active_lead_count"=>$finalData[config("constant.LEAD_STATUS.IN_PROGRESS")],
                        "onhold_lead_count"=>$finalData[config("constant.LEAD_STATUS.ON_HOLD")],
                        "win_lead_count"=>$finalData[config("constant.LEAD_STATUS.WIN")],
                        "lost_lead_count"=>$finalData[config("constant.LEAD_STATUS.LOST")],
                    ];
                });

        return response()->json(['leadSourceData' => $leadSourceData, 'leadCountsByTelecaller' => $leadCountsByTelecaller, 'leadCountsByManager' => $leadCountsByManager]);
    }



    public function index()
    {


        // Pass lead count for CountUp animation
        $fromDate = Carbon::today();
        $toDate = Carbon::today();

        $leadStatusCounts = LeadStatus::select(
            'cop_lead_status_ms.ls_status_id',
            'cop_lead_status_ms.ls_status_name',
            DB::raw("(select count(cop_leads.ls_status_id) from cop_leads where (DATE(cop_leads.created_at) between '{$fromDate->toDateString()}' and '{$toDate->toDateString()}') and cop_lead_status_ms.ls_status_id = cop_leads.ls_status_id) as lead_count")
        )
            ->get();

        $statusCounts = [];
        foreach ($leadStatusCounts as $leadStatus) {
            $statusCounts[$leadStatus->ls_status_name] = $leadStatus->lead_count;
        }
        $totalLeads = $leadStatusCounts->sum('lead_count');
        return view('crm.dashboard.crm_dashboard', compact('totalLeads', 'statusCounts'));
    }


    public function new_dashboard()
    {
        // Pass lead count for CountUp animation
        $fromDate = Carbon::today();
        $toDate = Carbon::today();

        $leadStatusCounts = LeadStatus::select(
            'cop_lead_status_ms.ls_status_id',
            'cop_lead_status_ms.ls_status_name',
            DB::raw("(select count(cop_leads.ls_status_id) from cop_leads where (DATE(cop_leads.created_at) between '{$fromDate->toDateString()}' and '{$toDate->toDateString()}') and cop_lead_status_ms.ls_status_id = cop_leads.ls_status_id) as lead_count")
        )
            ->get();

        $statusCounts = [];
        foreach ($leadStatusCounts as $leadStatus) {
            $statusCounts[$leadStatus->ls_status_name] = $leadStatus->lead_count;
        }
        $todayTotalLeads = $leadStatusCounts->sum('lead_count');

        $totLeadStatusCounts = LeadStatus::select(
            'cop_lead_status_ms.ls_status_id',
            'cop_lead_status_ms.ls_status_name',
            DB::raw("(select count(cop_leads.ls_status_id) from cop_leads where cop_lead_status_ms.ls_status_id = cop_leads.ls_status_id) as lead_count")
            )
            ->groupBy('cop_lead_status_ms.ls_status_id','cop_lead_status_ms.ls_status_name')
            ->get();

        $totalStatusCounts = [];
        foreach ($totLeadStatusCounts as $leadStatus) {
            $totalStatusCounts[$leadStatus->ls_status_name] = $leadStatus->lead_count;
        }

        $totalLeads = $totLeadStatusCounts->sum('lead_count');

        return view('crm.dashboard.admin_crm_dashboard', compact('statusCounts', 'todayTotalLeads','totalStatusCounts','totalLeads'));
    }
}
