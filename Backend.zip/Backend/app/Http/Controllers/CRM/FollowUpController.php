<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\CRM\Lead;
use App\Models\CRM\LeadStatus;
use App\Models\CRM\SpocPerson;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\Brand;
use App\Models\CRM\DealerHistory;
use App\Models\Model;
use App\Models\User;
use App\Models\Variant;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rules\RequiredIf;

use Illuminate\Validation\Rule;

class FollowUpController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    public function fetchModels(Request $request)
    {
        $selectedBrandId = $request->input('brand_id');

        if ($selectedBrandId) {
            $models = Model::select('model_id', 'model_name')->where('brand_id', $selectedBrandId)
                ->active()
                ->get();
        } else {
            $models = [];
        }

        return response()->json(['models' => $models]);
    }

    // fetch variants
    public function fetchVariants(Request $request)
    {
        $selectedModelId = $request->input('model_id');

        if ($selectedModelId) {
            $variants = Variant::select('variant_id', 'variant_name')->where('model_id', $selectedModelId)
                ->active()
                ->get();
        } else {
            $variants = [];
        }

        return response()->json(['variants' => $variants]);
    }

    public function fetchDealerLeads()
    {

        $leads = null;

        $allStatuses = [
            config('constant.LEAD_STATUS.ASSIGNED'),
            config('constant.LEAD_STATUS.IN_PROGRESS'),

        ];


        // COP SPOC Leads
        if (Auth::user()->hasRole(config('constant.CRM_ROLE.COP_SPOC_PERSON'))) {

            $leads = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_pipeline_stage', 'car_brand', 'dealer_status'])
                ->where('ls_status_id', config('constant.LEAD_STATUS.WIN'))
                ->where('dealer_status_id', config('constant.LEAD_STATUS.TRANSFER'))
                ->where('spoc_id', Auth::user()->id)
                ->get()
                ->map(function ($lead) {
                    $lead->encrypted_id = encrypt($lead->lead_id);
                    return $lead;
                });
        }

        // Dealer SPOC Leads
        if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER_SPOC_PERSON'))) {

            $leads = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_pipeline_stage', 'car_brand', 'dealer_status'])
                ->where('ls_status_id', config('constant.LEAD_STATUS.WIN'))
                ->where('dealer_status_id', config('constant.LEAD_STATUS.TRANSFER'))
                ->where('dealer_spoc_id', Auth::user()->id)
                ->get()
                ->map(function ($lead) {
                    $lead->encrypted_id = encrypt($lead->lead_id);
                    return $lead;
                });
        }

        // Dealer Leads
        if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER'))) {
            $leads = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_pipeline_stage', 'car_brand', 'dealer_status'])
                ->where('ls_status_id', config('constant.LEAD_STATUS.WIN'))
                ->where('dealer_status_id', config('constant.LEAD_STATUS.TRANSFER'))
                ->where('dealer_id', Auth::user()->id)
                ->get()
                ->map(function ($lead) {
                    $lead->encrypted_id = encrypt($lead->lead_id);
                    return $lead;
                });
        }

        // Salesman Leads
        if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER_SALESMAN'))) {
            $leads = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_pipeline_stage', 'car_brand', 'dealer_status'])
                ->where('ls_status_id', config('constant.LEAD_STATUS.WIN'))
                ->whereIn('dealer_status_id', $allStatuses)
                ->where('dealer_salesman_id', Auth::user()->id)
                ->get()
                ->map(function ($lead) {
                    $lead->encrypted_id = encrypt($lead->lead_id);
                    return $lead;
                });
        }

        return response()->json(['Leads' => $leads]);
    }


    public function specLeadData()
    {

        return view('crm.dealer.spoc_leads');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {

        $leads = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_pipeline_stage', 'car_brand', 'car_models', 'car_variant', 'user_dealer:id,name', 'user_dealer.dealer', 'user_copspoc:id,name', 'user_copspoc.spocs_data', 'user_dealerspoc.spocs_data', 'user_dealersalesman.spocs_data', 'dealer_status'])
            ->where('lead_id', decrypt($id))
            ->first();

        $brands = Brand::all();

        $leadStatus = LeadStatus::whereIn('ls_status_id', [
            config('constant.LEAD_STATUS.TEST_DRIVE'),
            config('constant.LEAD_STATUS.BOOKING'),
            config('constant.LEAD_STATUS.PURCHASE'),
            config('constant.LEAD_STATUS.ONLY_RESEARCH'),
            config('constant.LEAD_STATUS.OTHER')
        ])->get();

        $salesman = SpocPerson::getSpocSalesMan(auth()->id());

        return view('crm.dealer.lead_edit', compact('leads', 'leadStatus', 'salesman', 'brands'));
    }




    public function storeFollowUp(Request $request)
    { {

            // dd($request->all());

            $validator = Validator::make(
                $request->all(),
                [
                    'followUp_type' => 'required',
                    'remarks' => 'required|min:2|max:1000',
                    'attachment' => 'sometimes|mimes:jpeg,png,jpg,webp,pdf|max:10240',



                    // 'brand_id' => 'required_if:yes_or_no,1|required_if:followUp_type,9',
                    // 'model_id' => 'required_if:yes_or_no,1|required_if:followUp_type,9',
                    // 'variant_id' => 'required_if:yes_or_no,1|required_if:followUp_type,9'.

                    // 'brand_id' => [
                    //     'required',
                    //     Rule::requiredIf(function () use ($request) {
                    //         return $request->yes_or_no === "1" && $request->followUp_type === "9";
                    //     }),
                    // ],
                    // 'model_id' => [
                    //     'required',
                    //     Rule::requiredIf(function () use ($request) {
                    //         return $request->yes_or_no === "1" && $request->followUp_type === "9";
                    //     }),
                    // ],
                    // 'variant_id' => [
                    //     'required',
                    //     Rule::requiredIf(function () use ($request) {
                    //         return $request->yes_or_no === "1" && $request->followUp_type === "9";
                    //     }),
                    // ],
                ],
                [
                    'followUp_type.required' => 'Followup type is required.',
                    'remarks.required' => 'Remarks are required.',
                    'remarks.min' => 'The remarks must be at least 2 characters.',
                    'remarks.max' => 'The remarks may not be greater than 1000 characters.',
                    'attachment.mimes' => 'The attachment must be a JPEG, PNG, JPG, WEBP, or PDF file.',
                    'attachment.max' => 'The attachment may not be greater than 10 MB in size.',
                    // 'brand_id.required' => 'Brand Field is required.',
                    // 'model_id.required' => 'Model Field is required.',
                    // 'variant_id.required' => 'Variant Field is required.',
                ]
            );


            if ($validator->fails()) {
                return ResponseHelper::errorResponseLead($validator->errors());
            }
            try {


                $store_followUp = new DealerHistory();

                $store_followUp->lead_id = decrypt($request->input('lead_id'));
                $store_followUp->followup_status_id = $request->followUp_type;

                if ($request->followUp_type == config('constant.LEAD_STATUS.TEST_DRIVE') && $request->yes_or_no == '1') {
                    $store_followUp->brand_id = $request->brand_id;
                    $store_followUp->model_id = $request->model_id;
                    $store_followUp->variant_id = $request->variant_id;
                    $store_followUp->followup_code = Lead::generateUniqCode('test_drive_code');
                }
                if ($request->followUp_type == config('constant.LEAD_STATUS.BOOKING') && $request->yes_or_no == '1') {
                    $store_followUp->brand_id = $request->brand_id;
                    $store_followUp->model_id = $request->model_id;
                    $store_followUp->variant_id = $request->variant_id;

                    $purchaseDate = $request->purchase_date;
                    $timestamp = strtotime($purchaseDate);
                    $formattedDatetime = date('Y-m-d H:i:s', $timestamp);
                    $store_followUp->delivered_date = $formattedDatetime;
                    $store_followUp->followup_code = Lead::generateUniqCode('booking_code');
                }

                if ($request->followUp_type == config('constant.LEAD_STATUS.PURCHASE') && $request->yes_or_no == '1') {
                    $store_followUp->followup_code = Lead::generateUniqCode('purchase_code');
                }

                $store_followUp->remarks = $request->remarks;
                $store_followUp->followup_outcome = $request->yes_or_no;
                $store_followUp->dealer_status_id = config('constant.LEAD_STATUS.IN_PROGRESS');
                $store_followUp->created_by  = Auth::user()->id;
                $store_followUp->updated_by   = Auth::user()->id;


                if ($request->yes_or_no == '1') {
                    if ($request->followUp_type == config('constant.LEAD_STATUS.TEST_DRIVE') && $request->yes_or_no == '1') {
                        $lead_update = Lead::findOrFail(decrypt($request->input('lead_id')));
                        $lead_update->test_drive_code = Lead::generateUniqCode('test_drive_code');
                        $lead_update->is_test_drive = true;
                    } elseif ($request->followUp_type == config('constant.LEAD_STATUS.BOOKING') && $request->yes_or_no == '1') {
                        $lead_update = Lead::findOrFail(decrypt($request->input('lead_id')));
                        $lead_update->booking_code = Lead::generateUniqCode('booking_code');
                        $lead_update->is_booking = true;
                    }
                    $lead_update->update();
                }



                $attachmentFile = $request->file('attachment');
                if ($attachmentFile) {

                    if ($attachmentFile->getClientOriginalExtension() === 'pdf') {
                        $pdfFileName =  decrypt($request->input('lead_id')) . "PDF_" . strtotime(now()) . '.pdf';
                        $attachmentFile->move(public_path('b2b_attachment'), $pdfFileName);
                        $store_followUp->attachment = $pdfFileName;
                    } else {
                        $uploadedImage = $request->file('attachment');
                        $webpImageName = decrypt($request->input('lead_id')) . "IMG_" . strtotime(now()) . '.webp';
                        $uploadedImage->move(public_path('b2b_attachment'), $webpImageName);
                        $store_followUp->attachment = $webpImageName;
                    }
                }
                $store_followUp->save();

                // Check if the activity was saved successfully

                return ResponseHelper::responseMessageLead('success', null, 'Follow Up Store Successfully.');
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
                return ResponseHelper::errorResponseLead(['Something Went Wrong.' . $e->getMessage()]);
            }
        }
    }




    public function fetchAllDealerHistory(Request $request)
    {
        try {


            $leadHistory = Lead::with(['lead_dealer_history', 'dealer_status', 'dealer_follow_status'])
                ->where('lead_id', decrypt($request->id))->get();

            $leadDealerHistory = DealerHistory::with(['dealer_status', 'followup_status', 'create_by:id,name'])
                ->where('lead_id', decrypt($request->id))
                ->orderBy('dlh_id', 'DESC')
                ->get();



            return response()->json(['leadHistory' => $leadHistory, 'leadDealerHistory' =>  $leadDealerHistory]);
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            // session()->flash('error', 'Something Went Wrong.');
            return ResponseHelper::errorResponseLead(['Something Went Wrong.']);
        }
    }

    public function storeInProgress(Request $request)
    {
        try {

            // btnval = inProgress(3)

            $lead_update = Lead::findOrFail(decrypt($request->lead_id));
            if ((Auth::user()->hasRole(config('constant.CRM_ROLE.COP_SPOC_PERSON')))) {
                $lead_update->spoc_status_id = $request->copStatusId;
            } else {
                $lead_update->dealer_status_id = $request->btnvalue;
            }
            $lead_update->update();


            $store_inprogress = new DealerHistory();
            $store_inprogress->lead_id = decrypt($request->lead_id);
            $store_inprogress->dealer_status_id = $request->btnvalue;
            $store_inprogress->followup_status_id  = config('constant.LEAD_STATUS.IN_PROGRESS');
            $store_inprogress->created_by = Auth::user()->id;
            $store_inprogress->updated_by = Auth::user()->id;
            $store_inprogress->save();

            return response()->json(['message' => 'Dealer history saved successfully'], 200);
        } catch (Exception $e) {
            Log::error("Error saving dealer history: " . $e->getMessage());
            return response()->json(['error' => 'Something went wrong while saving dealer history'], 500);
        }
    }



    public function storePurchase(Request $request)
    {

        try {

            $store_inprogress = new DealerHistory();
            $store_inprogress->lead_id = decrypt($request->input('lead_id'));

            $store_inprogress->dealer_status_id = config('constant.LEAD_STATUS.PURCHASE');
            $store_inprogress->followup_status_id  = config('constant.LEAD_STATUS.PURCHASE');
            $store_inprogress->followup_outcome  = '1';
            $store_inprogress->remarks = $request->purchaseRemarks;
            $store_inprogress->created_by = Auth::user()->id;
            $store_inprogress->updated_by = Auth::user()->id;
            $store_inprogress->save();


            $lead_update = Lead::findOrFail(decrypt($request->input('lead_id')));
            $lead_update->dealer_status_id = config('constant.LEAD_STATUS.PURCHASE');
            $lead_update->followup_status_id = config('constant.LEAD_STATUS.PURCHASE');
            $lead_update->purchase_code = Lead::generateUniqCode('purchase_code');
            $lead_update->is_purchase = true;
            $lead_update->update();


            return response()->json(['message' => 'Dealer history saved successfully'], 200);
        } catch (Exception $e) {
            Log::error("Error saving dealer history: " . $e->getMessage());
            return response()->json(['error' => 'Something went wrong while saving dealer history'], 500);
        }
    }

    public function storeLost(Request $request)
    {

        $validator = Validator::make(
            $request->all(),
            [
                'lostRemarks' => 'required|min:2|max:1000',
            ],
            [
                'lostRemarks.required' => 'Lost Remark is required.',
                'lostRemarks.min' => 'The lead name must be at least 2 characters.',
                'lostRemarks.max' => 'The lead name may not be greater than 200 characters.',
            ]
        );

        if ($validator->fails()) {
            return ResponseHelper::errorResponseLead($validator->errors());
        }

        try {

            $store_inprogress = new DealerHistory();
            $store_inprogress->lead_id = decrypt($request->input('lead_id'));

            $store_inprogress->dealer_status_id = config('constant.LEAD_STATUS.LOST');
            $store_inprogress->followup_status_id  = config('constant.LEAD_STATUS.LOST');
            $store_inprogress->remarks = $request->lostRemarks;
            $store_inprogress->created_by = Auth::user()->id;
            $store_inprogress->updated_by = Auth::user()->id;
            $store_inprogress->save();



            $lead_update = Lead::findOrFail(decrypt($request->input('lead_id')));
            $lead_update->dealer_status_id = config('constant.LEAD_STATUS.LOST');
            $lead_update->followup_status_id = config('constant.LEAD_STATUS.LOST');
            $lead_update->update();


            return response()->json(['message' => 'Dealer history saved successfully'], 200);
        } catch (Exception $e) {
            Log::error("Error saving dealer history: " . $e->getMessage());
            return response()->json(['error' => 'Something went wrong while saving dealer history'], 500);
        }
    }

    public function fetchAllSalesman()
    {

        try {

            $rmUserIds = User::role(config('constant.CRM_ROLE.DEALER_SALESMAN'))->pluck('id');

            $salesman = User::whereIn('id', $rmUserIds)->get();

            return response()->json(['salesmans' => $salesman]);
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponseLead(['Something Went Wrong.' . $e->getMessage()]);
        }
    }



    public function assignSalesman(Request $request)
    {

        // dd($request->all());

        $validator = Validator::make(
            $request->all(),
            [
                'lead_ids' => 'required',
                'filter_salesman_user_id' => 'required',

            ],
            [
                'lead_ids.required' => 'Please Select Leads',
                'filter_salesman_user_id.required' => 'Please select Salesman',

            ]
        );

        if ($validator->fails()) {
            return ResponseHelper::errorResponseLead($validator->errors());
        }

        try {
            $date = Carbon::now();
            $currentDate = $date->format('Y-m-d H:i:s');

            $leadIds = $request->input('lead_ids');

            if (count($leadIds) <= 0) {
            } else {
                $assignLead = Lead::whereIn('lead_id', $leadIds)
                    ->update([
                        'dealer_salesman_id' => $request->filter_salesman_user_id,
                        'dealer_status_id' => config('constant.LEAD_STATUS.ASSIGNED'),
                        'salesman_assign_date' => $currentDate
                    ]);

                $leadStatus = LeadStatus::where('ls_status_id', config('constant.LEAD_STATUS.ASSIGNED'))
                    ->select('ls_status_id')
                    ->first();


                foreach ($leadIds as $leadId) {
                    DealerHistory::createOrFirst([
                        'lead_id' => $leadId,
                        'salesman_id' => $request->filter_salesman_user_id,
                        'dealer_status_id' => $leadStatus->ls_status_id,
                        'created_by' => auth()->id(),
                        'updated_by' => auth()->id(),
                    ]);
                }


                if ($assignLead) {
                    return ResponseHelper::responseMessageLead('success', array(), 'Lead Assigned Successfully.');
                } else {
                    return ResponseHelper::errorResponseLead(['Something Went Wrong.']);
                }
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponseLead(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    public function transferToSalesman(Request $request)
    {

        // dd($request->all());

        $validator = Validator::make(
            $request->all(),
            [
                'lead_id' => 'required',
                'salesman_id' => 'required',

            ],
            [
                'lead_id.required' => 'Please Select Leads',
                'salesman_id.required' => 'Please select Salesman',

            ]
        );

        if ($validator->fails()) {
            return ResponseHelper::errorResponseLead($validator->errors());
        }

        try {
            $date = Carbon::now();
            $currentDate = $date->format('Y-m-d H:i:s');

            $leadIds = decrypt($request->lead_id);


            if ($leadIds <= 0) {
                return ResponseHelper::errorResponseLead(['Something Went Wrong.']);
            } else {

                $assignLead = Lead::where('lead_id', $leadIds)
                    ->update([
                        'dealer_salesman_id' => $request->salesman_id,
                        'dealer_status_id' => config('constant.LEAD_STATUS.ASSIGNED'),
                        'salesman_assign_date' => $currentDate
                    ]);



                $leadStatus = LeadStatus::where('ls_status_id', config('constant.LEAD_STATUS.ASSIGNED'))
                    ->select('ls_status_id')
                    ->first();


                DealerHistory::createOrFirst([
                    'lead_id' => $leadIds,
                    'salesman_id' => $request->salesman_id,
                    'dealer_status_id' => $leadStatus->ls_status_id,
                    'created_by' => auth()->id(),
                    'updated_by' => auth()->id(),
                ]);


                if ($assignLead) {
                    return ResponseHelper::responseMessageLead('success', array(), 'Lead Transfer Successfully.');
                } else {
                    return ResponseHelper::errorResponseLead(['Something Went Wrong.']);
                }
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponseLead(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
