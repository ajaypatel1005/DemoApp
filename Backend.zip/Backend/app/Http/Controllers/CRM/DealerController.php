<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\City;
use App\Models\CRM\Dealer;
use App\Models\CRM\Lead;
use App\Models\CRM\LeadCount;
use App\Models\CRM\LeadStatus;
use App\Models\CRM\SpocPerson;
use App\Models\State;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class DealerController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    public function fetchDealerLeads()
    {
        $leads = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_pipeline_stage', 'car_brand'])
            ->where('ls_status_id', 4)
            ->get()
            ->map(function ($lead) {
                $lead->encrypted_id = encrypt($lead->lead_id);
                return $lead;
            });

        return response()->json(['Leads' => $leads]);
    }




    public function specLeadData()
    {

        return view('crm.dealer.spoc_leads');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function index()
    {
        $fromDate = Carbon::today();
        $toDate = Carbon::today();
        $userId = Auth::user()->id;

        //  $spocData = SpocPerson::select('user_id', 's_name', 's_email')
        // ->with('spocLeads')
        // ->where('spoc_type', config('constant.SPOC_TYPE.DEALER_SPOC_PERSON'))
        // ->where('parent_id', Auth::user()->id)
        // ->get();


        $allStatuses = [
            config('constant.LEAD_STATUS.ASSIGNED'),
            config('constant.LEAD_STATUS.PURCHASE'),
            config('constant.LEAD_STATUS.TRANSFER'),
            config('constant.LEAD_STATUS.IN_PROGRESS'),
            config('constant.LEAD_STATUS.LOST')
        ];

        // $leadStatusCounts = LeadStatus::select(
        //     'cop_lead_status_ms.ls_status_id',
        //     'cop_lead_status_ms.ls_status_name',
        //     DB::raw("(select COUNT(DISTINCT cop_lead_dealer_history.lead_id) from cop_leads
        //                   inner join cop_lead_dealer_history on cop_leads.lead_id = cop_lead_dealer_history.lead_id
        //                   where cop_lead_status_ms.ls_status_id = cop_lead_dealer_history.dealer_status_id
        //                   and cop_leads.dealer_id = '{$userId}'
        //                   and cop_leads.dealer_status_id = cop_lead_dealer_history.dealer_status_id
        //                   and DATE(cop_lead_dealer_history.created_at) between '{$fromDate->toDateString()}' and '{$toDate->toDateString()}'
        //                 ) as lead_count")
        // )
        //     ->whereIn('cop_lead_status_ms.ls_status_id', $allStatuses)
        //     ->get();

        $leadStatusCounts = LeadStatus::select(
            'cop_lead_status_ms.ls_status_id',
            'cop_lead_status_ms.ls_status_name',
            DB::raw("(select COUNT(DISTINCT cop_leads.lead_id) from cop_leads
                          where
                           cop_leads.dealer_id = '{$userId}'
                          and cop_lead_status_ms.ls_status_id = cop_leads.dealer_status_id
                          and DATE(cop_leads.dealer_transfer_date) between '{$fromDate->toDateString()}' and '{$toDate->toDateString()}'
                        ) as lead_count")
        )
            ->whereIn('cop_lead_status_ms.ls_status_id', $allStatuses)
            ->get();

        // dd($leadStatusCounts);

        $statusCounts = [];
        foreach ($leadStatusCounts as $leadStatus) {
            $statusCounts[$leadStatus->ls_status_id] = $leadStatus->lead_count;
        }
        $totalLeads = $leadStatusCounts->sum('lead_count');

        return view('crm.dealer.dashboard', compact('totalLeads', 'statusCounts'));
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $states = State::active()->get();
        $parentDealers = Dealer::whereNull('parent_id')->get();
        $brands = Brand::select('brand_id', 'brand_name')->active()->get();

        $dealersAll = Dealer::with(['city:city_id,state_id,city_name','groupUser:id,name'])
            ->get();
        // Begin::Brand get
        $dealersData = $dealersAll->map(function ($dealer) use ($brands) {
            $brandIds = explode(',', $dealer->brand_ids);
            $dealerBrands = $brands->filter(function ($brand) use ($brandIds) {
                return in_array($brand->brand_id, $brandIds);
            });
            $dealer->brands = $dealerBrands;

            return $dealer;
        });

        return view('crm.dealer.create', compact('brands', 'dealersData', 'states','parentDealers'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function fetchCity(Request $request)
    {
        $selectedStateId = $request->input('state_id');
        if ($selectedStateId) {
            $cities = City::where('state_id', $selectedStateId)
                ->where('status', 1)
                ->get();
        } else {
            $cities = [];
        }
        return response()->json(['cities' => $cities]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        if (!hasAnyPermission(['create_dealer'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            'brand_id' => 'required|array',
            'dealer_name' => 'required|min:2|max:200',
            'dealer_email' => 'required|email|unique:cop_dealers_ms,dealer_email|unique:users,email',
            'dealer_contact_no' => 'required|min:10|max:10|regex:/^[0-9]+$/|unique:cop_dealers_ms,dealer_contact_no',
            'state_id' => 'required',
            'city_id' => 'required',
            'pincode' => 'nullable|min:6|max:6',
            'dealer_address' => 'required|min:2|max:400',
            'apette_grivience_email' => 'nullable|email',
            'nodalemail' => 'nullable|email',
        ], [
            'brand_id.required' => 'Select Brand is required',
            'dealer_name.required' => 'Dealer Name is required',
            'dealer_email.required' => 'Email is required',
            'dealer_email.email' => 'Please enter a valid email address',
            'dealer_email.unique' => 'This Email has already been taken.',
            'dealer_contact_no.required' => 'Contact is required',
            'dealer_contact_no.unique' => 'Contact No. has already been taken.',
            'dealer_contact_no.min' => 'The Contact Number must be at least :min characters.',
            'dealer_contact_no.max' => 'The Contact Number must not exceed :max characters.',
            'state_id.required' => 'State is required',
            'city_id.required' => 'City is required',
            'pincode.min' => 'The Pincode must be at least :min characters.',
            'pincode.max' => 'The Pincode must not exceed :max characters.',
            'dealer_address.required' => 'Address is required',
            'dealer_address.min' => 'The Address must be at least :min characters.',
            'dealer_address.max' => 'The Address must not exceed :max characters.',
            'apette_grivience_email.email' => 'Please enter a valid email address',
            'nodalemail.email' => 'Please enter a valid email address',
        ]);
        DB::beginTransaction();
        try {
            $dealer = new Dealer();
            $dealer->parent_id = $request->parent_id;
            $dealer->brand_ids = implode(',', $request->brand_id);
            $dealer->city_id = $request->city_id;
            $dealer->dealer_name = $request->dealer_name;
            $dealer->dealer_email = $request->dealer_email;
            $dealer->dealer_contact_no = $request->dealer_contact_no;
            $dealer->dealer_address = $request->dealer_address;
            $dealer->gstin = $request->gstin;
            $dealer->pincode = $request->pincode;
            $dealer->customer_care_no = $request->customer_care_no;
            $dealer->apette_grivience_email = $request->apette_grivience_email;
            $dealer->apette_name = $request->apette_name;
            $dealer->nodalemail = $request->nodalemail;
            $dealer->nodalname = $request->nodalname;
            $dealer->status = $request->has('status') ? 1 : 0;
            $dealer->created_by = Auth::user()->id;
            $dealer->save();

            $dealer_update = Dealer::find($dealer->dealer_id);
            if ($dealer_update) {
                $user = User::create([
                    'name' => $request->dealer_name,
                    'email' => $request->dealer_email,
                    'password' => Hash::make($request->dealer_contact_no),
                ]);
                $user->assignRole(config('constant.CRM_ROLE.DEALER'));

                $dealer_update->user_id = $user->id;
                $dealer_update->dealer_code = LeadCount::generateUniqCode('dealer_code');
                $dealer_update->update();

                session()->flash('success', 'Dealer Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.' . $e);
        }

        return redirect()->route('dealer.create');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        return view('crm.dealer.lead_edit');
    }

    public function editDealer($id)
    {
        if (!hasAnyPermission(['edit_dealer', 'view_dealer'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $parentDealers = Dealer::whereNull('parent_id')->get();

        $states = State::active()->get();
        $brands = Brand::select('brand_id', 'brand_name')->active()->get();

        $dealersAll = Dealer::with(['city:city_id,state_id,city_name','groupUser:id,name'])
            ->get();
        // Begin::Brand get
        $dealersData = $dealersAll->map(function ($dealer) use ($brands) {
            $brandIds = explode(',', $dealer->brand_ids);
            $dealerBrands = $brands->filter(function ($brand) use ($brandIds) {
                return in_array($brand->brand_id, $brandIds);
            });
            $dealer->brands = $dealerBrands;

            return $dealer;
        });

        $dealerEdit = Dealer::with('city')->where('dealer_id', decrypt($id))->first();
        $dealerEdit->brand_ids = explode(',', $dealerEdit->brand_ids);
        $dealerEdit->user_id = encrypt($dealerEdit->user_id);

        return view('crm.dealer.edit', compact('states', 'brands', 'dealersData', 'dealerEdit','parentDealers'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        //
        if (!hasAnyPermission(['edit_dealer'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([

            'brand_id' => 'required|array',
            'dealer_name' => 'required|min:2|max:200',
            'dealer_email' => 'required|email|unique:cop_dealers_ms,dealer_email,' . decrypt($id) . ',dealer_id|unique:users,email,' . decrypt($request->user_id) . ',id',
            'dealer_contact_no' => 'required|min:10|max:10|regex:/^[0-9]+$/|unique:cop_dealers_ms,dealer_contact_no,' . decrypt($id) . ',dealer_id',
            'state_id' => 'required',
            'city_id' => 'required',
            'pincode' => 'nullable|min:6|max:6',
            'dealer_address' => 'required|min:2|max:400',
            'apette_grivience_email' => 'nullable|email',
            'nodalemail' => 'nullable|email',

        ], [
            'brand_id.required' => 'Select Brand is required',
            'dealer_name.required' => 'Dealer Name is required',
            'dealer_email.required' => 'Email is required',
            'dealer_email.email' => 'Please enter a valid email address',
            'dealer_email.unique' => 'This Email has already been taken.',
            'dealer_contact_no.required' => 'Contact is required',
            'dealer_contact_no.unique' => 'Contact No. has already been taken.',
            'dealer_contact_no.min' => 'The Contact Number must be at least :min characters.',
            'dealer_contact_no.max' => 'The Contact Number must not exceed :max characters.',
            'state_id.required' => 'State is required',
            'city_id.required' => 'City is required',
            'pincode.min' => 'The Pincode must be at least :min characters.',
            'pincode.max' => 'The Pincode must not exceed :max characters.',
            'dealer_address.required' => 'Address is required',
            'dealer_address.min' => 'The Address must be at least :min characters.',
            'dealer_address.max' => 'The Address must not exceed :max characters.',
            'apette_grivience_email.email' => 'Please enter a valid email address',
            'nodalemail.email' => 'Please enter a valid email address',
        ]);


        DB::beginTransaction();

        try {
            $dealer = Dealer::where('dealer_id', decrypt($id))->first();

            if ($dealer) {

                // Update other fields
                $dealer->brand_ids = implode(',', $request->brand_id);
                $dealer->parent_id = $request->parent_id;
                $dealer->city_id = $request->city_id;
                $dealer->dealer_name = $request->dealer_name;
                $dealer->dealer_email = $request->dealer_email;
                $dealer->dealer_contact_no = $request->dealer_contact_no;
                $dealer->dealer_address = $request->dealer_address;
                $dealer->gstin = $request->gstin;
                $dealer->pincode = $request->pincode;
                $dealer->customer_care_no = $request->customer_care_no;
                $dealer->apette_grivience_email = $request->apette_grivience_email;
                $dealer->apette_name = $request->apette_name;
                $dealer->nodalemail = $request->nodalemail;
                $dealer->nodalname = $request->nodalname;
                $dealer->status = $request->has('status') ? 1 : 0;

                $dealer->updated_by = Auth::user()->id;

                $dealer->update();

                if ($dealer) {
                    $user = User::findOrFail($dealer->user_id);
                    $user->name = $request->dealer_name;
                    $user->email = $request->dealer_email;
                    $user->save();
                    $user->syncRoles(config('constant.CRM_ROLE.DEALER'));
                }

                session()->flash('success', 'Dealer Updated Successfully.');
            } else {
                session()->flash('error', 'Record Not Found.');
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.' . $e);
        }

        return redirect()->route('dealer.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_dealer'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        try {
            $dealer = Dealer::where('dealer_id', decrypt($id))->firstOrFail();

            $user = User::findOrFail($dealer->user_id);

            DB::beginTransaction();

            $dealer->delete();
            $user->delete();

            DB::commit();

            session()->flash('success', 'Dealer Deleted Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Failed to delete dealer.');
        }

        return redirect()->route('dealer.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_dealers_ms')
            ->where('dealer_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }

    public function getSpocSalesmanData(Request $request)
    {
        $userId = Auth::user()->id;

        $daterange = explode(' - ', $request->date_range);
        $fromDate = Carbon::createFromFormat('d/m/Y', $daterange[0])->startOfDay();
        $toDate = Carbon::createFromFormat('d/m/Y', $daterange[1])->endOfDay();



        $allStatuses = [
            config('constant.LEAD_STATUS.ASSIGNED'),
            config('constant.LEAD_STATUS.PURCHASE'),
            config('constant.LEAD_STATUS.TRANSFER'),
            config('constant.LEAD_STATUS.IN_PROGRESS'),
            config('constant.LEAD_STATUS.LOST')
        ];

        // Begin::Dealer SPOC Data
        $spocStatus = [
            config('constant.LEAD_STATUS.ASSIGNED'),
            config('constant.LEAD_STATUS.PURCHASE'),
            config('constant.LEAD_STATUS.TRANSFER'),
            config('constant.LEAD_STATUS.IN_PROGRESS'),
            config('constant.LEAD_STATUS.LOST')
        ];

        // Begin::this query is join with dealer_lead_history table

    //     $spocData = DB::table('cop_spoc_salesman_ms')
    //         ->where('cop_spoc_salesman_ms.parent_id', Auth::user()->id)
    //         ->where('cop_spoc_salesman_ms.spoc_type', config('constant.SPOC_TYPE.DEALER_SPOC_PERSON'))
    //         ->select(
    //             'cop_spoc_salesman_ms.s_name',
    //             'cop_spoc_salesman_ms.s_contact_no',
    //             'cop_spoc_salesman_ms.s_email',
    //             DB::raw(
    //                 "(SELECT CONCAT('[',GROUP_CONCAT(JSON_OBJECT('status_id',cop_lead_status_ms.ls_status_id,'status_name',cop_lead_status_ms.ls_status_name,
    //                 'total',(SELECT COUNT(DISTINCT cop_leads.lead_id)
    //                  FROM cop_leads
    //                 INNER JOIN cop_lead_dealer_history ON cop_leads.lead_id=cop_lead_dealer_history.lead_id
    //                 WHERE cop_leads.dealer_status_id=cop_lead_status_ms.ls_status_id
    //                 AND cop_spoc_salesman_ms.user_id=cop_leads.dealer_spoc_id AND DATE(cop_lead_dealer_history.created_at) BETWEEN '{$fromDate->toDateString()}' and '{$toDate->toDateString()}'
    //                     )
    // )),']') from cop_lead_status_ms where ls_status_id IN (" . implode(',', $spocStatus) . ")) as lead_data"
    //             )
    //         )
    //         ->get();

    // End::this query is join with dealer_lead_history table

    // Begin::this query is join without dealer_lead_history table
        $spocData = DB::table('cop_spoc_salesman_ms')
            ->where('cop_spoc_salesman_ms.parent_id', Auth::user()->id)
            ->where('cop_spoc_salesman_ms.spoc_type', config('constant.SPOC_TYPE.DEALER_SPOC_PERSON'))
            ->select(
                'cop_spoc_salesman_ms.s_name',
                'cop_spoc_salesman_ms.s_contact_no',
                'cop_spoc_salesman_ms.s_email',
                DB::raw(
                    "(SELECT CONCAT('[',GROUP_CONCAT(JSON_OBJECT('status_id',cop_lead_status_ms.ls_status_id,'status_name',cop_lead_status_ms.ls_status_name,
                    'total',(SELECT COUNT(DISTINCT cop_leads.lead_id)
                     FROM cop_leads
                    WHERE cop_leads.dealer_status_id=cop_lead_status_ms.ls_status_id
                    AND cop_spoc_salesman_ms.user_id=cop_leads.dealer_spoc_id AND DATE(cop_leads.dealer_transfer_date) BETWEEN '{$fromDate->toDateString()}' and '{$toDate->toDateString()}'
                        )
    )),']') from cop_lead_status_ms where ls_status_id IN (" . implode(',', $spocStatus) . ")) as lead_data"
                )
            )
            ->get();
    // End::this query is join without dealer_lead_history table

        $mappedSpocData = [];

        foreach ($spocData as $spoc) {
            // Decode the JSON lead_data field into an array
            $leadDataJson = json_decode($spoc->lead_data, true);

            // Initialize totals array
            $totals = [
                'assigned' => 0,
                'transfer' => 0,
                'in_progress' => 0,
                'lost' => 0,
                'purchase' => 0
            ];
            // Check if leadDataJson is an array
            if (is_array($leadDataJson)) {
                // Loop through each lead status in the JSON data
                foreach ($leadDataJson as $leadStatus) {
                    // Extract status properties

                    $status_name = $leadStatus['status_name'];
                    $total = intval($leadStatus['total']);
                    // Update the corresponding total in the totals array
                    switch ($status_name) {
                        case 'Assigned':
                            $totals['assigned'] += $total;
                            break;
                        case 'Transfer':
                            $totals['transfer'] += $total;
                            break;
                        case 'In Progress':
                            $totals['in_progress'] += $total;
                            break;
                        case 'Lost':
                            $totals['lost'] += $total;
                            break;
                        case 'Purchase':
                            $totals['purchase'] += $total;
                            break;
                        default:
                            // Handle other statuses if needed
                            break;
                    }
                }
            }

            // Append data for each salesperson to $mappedData
            $mappedSpocData[] = [
                's_name' => $spoc->s_name,
                's_contact_no' => $spoc->s_contact_no,
                's_email' => $spoc->s_email,
                'total_leads' => $totals['assigned'] + $totals['transfer'] + $totals['in_progress'] + $totals['purchase'] + $totals['lost'],
                'assigned' => $totals['assigned'],
                'transfer' => $totals['transfer'],
                'in_progress' => $totals['in_progress'],
                'purchase' => $totals['purchase'],
                'lost' => $totals['lost'],
            ];
        }

        // End::Dealer SPOC Data

        // dd($mappedSpocData);

        // Begin::Dealer Salesman Data
        $spocSalesmanStatus = [
            config('constant.LEAD_STATUS.ASSIGNED'),
            config('constant.LEAD_STATUS.IN_PROGRESS'),
            config('constant.LEAD_STATUS.PURCHASE'),
            config('constant.LEAD_STATUS.LOST')
        ];


        // Begin::this query is join with dealer_lead_history table

        //     $salesmanData = DB::table('cop_spoc_salesman_ms')
        //     ->where('cop_spoc_salesman_ms.parent_id', Auth::user()->id)
        //     ->where('cop_spoc_salesman_ms.spoc_type', config('constant.SPOC_TYPE.DEALER_SALESMAN'))
        //     ->select('cop_spoc_salesman_ms.user_id','cop_spoc_salesman_ms.s_name','cop_spoc_salesman_ms.s_contact_no','cop_spoc_salesman_ms.s_email',
        //         DB::raw("(SELECT CONCAT('[',GROUP_CONCAT(JSON_OBJECT('status_id',cop_lead_status_ms.ls_status_id,'status_name',cop_lead_status_ms.ls_status_name,
        //                 'total',(SELECT COUNT(DISTINCT cop_leads.lead_id)
        //                  FROM cop_leads
        //                 INNER JOIN cop_lead_dealer_history ON cop_leads.lead_id=cop_lead_dealer_history.lead_id
        //                 WHERE cop_leads.dealer_status_id=cop_lead_status_ms.ls_status_id
        //                 AND cop_spoc_salesman_ms.user_id=cop_leads.dealer_salesman_id AND DATE(cop_lead_dealer_history.created_at) BETWEEN '{$fromDate->toDateString()}' and '{$toDate->toDateString()}'
        //                     )
        // )),']') from cop_lead_status_ms where ls_status_id IN (" . implode(',', $spocSalesmanStatus) . ")) as lead_data"
        //         )
        //     )
        //     ->get();

        // End::this query is join with dealer_lead_history table


        // Begin::this query is join without dealer_lead_history table
        $salesmanData = DB::table('cop_spoc_salesman_ms')
            ->where('cop_spoc_salesman_ms.parent_id', Auth::user()->id)
            ->where('cop_spoc_salesman_ms.spoc_type', config('constant.SPOC_TYPE.DEALER_SALESMAN'))
            ->select(
                'cop_spoc_salesman_ms.user_id',
                'cop_spoc_salesman_ms.s_name',
                'cop_spoc_salesman_ms.s_contact_no',
                'cop_spoc_salesman_ms.s_email',
                DB::raw(
                    "(SELECT CONCAT('[',GROUP_CONCAT(JSON_OBJECT('status_id',cop_lead_status_ms.ls_status_id,'status_name',cop_lead_status_ms.ls_status_name,
                    'total',(SELECT COUNT(DISTINCT cop_leads.lead_id)
                     FROM cop_leads
                    WHERE cop_leads.dealer_status_id=cop_lead_status_ms.ls_status_id
                    AND cop_spoc_salesman_ms.user_id=cop_leads.dealer_salesman_id AND DATE(cop_leads.dealer_transfer_date) BETWEEN '{$fromDate->toDateString()}' and '{$toDate->toDateString()}'
                        )
    )),']') from cop_lead_status_ms where ls_status_id IN (" . implode(',', $spocSalesmanStatus) . ")) as lead_data"
                )
            )
            ->get();

        // End::this query is join without dealer_lead_history table


        $mappedSalesmanData = [];

        foreach ($salesmanData as $spoc) {
            // Decode the JSON lead_data field into an array
            $leadDataJson = json_decode($spoc->lead_data, true);

            // Initialize totals array
            $totals = [
                'assigned' => 0,
                'in_progress' => 0,
                'lost' => 0,
                'purchase' => 0
            ];
            // Check if leadDataJson is an array
            if (is_array($leadDataJson)) {
                // Loop through each lead status in the JSON data
                foreach ($leadDataJson as $leadStatus) {
                    // Extract status properties

                    $status_name = $leadStatus['status_name'];
                    $total = intval($leadStatus['total']);
                    // Update the corresponding total in the totals array
                    switch ($status_name) {
                        case 'Assigned':
                            $totals['assigned'] += $total;
                            break;
                        case 'In Progress':
                            $totals['in_progress'] += $total;
                            break;
                        case 'Lost':
                            $totals['lost'] += $total;
                            break;
                        case 'Purchase':
                            $totals['purchase'] += $total;
                            break;
                        default:
                            // Handle other statuses if needed
                            break;
                    }
                }
            }

            // Append data for each salesperson to $mappedData
            $mappedSalesmanData[] = [
                'user_id' => $spoc->user_id,
                's_name' => $spoc->s_name,
                's_contact_no' => $spoc->s_contact_no,
                's_email' => $spoc->s_email,
                'total_leads' => $totals['assigned'] + $totals['in_progress'] + $totals['purchase'] + $totals['lost'],
                'assigned' => $totals['assigned'],
                'in_progress' => $totals['in_progress'],
                'purchase' => $totals['purchase'],
                'lost' => $totals['lost'],
            ];
        }

        // dd($mappedSalesmanData);

        $leadStatusCounts = LeadStatus::select(
            'cop_lead_status_ms.ls_status_id',
            'cop_lead_status_ms.ls_status_name',
            DB::raw("(select COUNT(DISTINCT cop_leads.lead_id) from cop_leads
                      where cop_leads.dealer_id = '{$userId}'
                      and cop_lead_status_ms.ls_status_id = cop_leads.dealer_status_id
                      and DATE(cop_leads.dealer_transfer_date) between '{$fromDate->toDateString()}' and '{$toDate->toDateString()}'
                    ) as lead_count")
        )
            ->whereIn('cop_lead_status_ms.ls_status_id', $allStatuses)
            ->get();
        // dd($leadStatusCounts);

        $statusCounts = [];
        foreach ($leadStatusCounts as $leadStatus) {
            $statusCounts[$leadStatus->ls_status_id] = $leadStatus->lead_count;
        }
        $totalLeads = $leadStatusCounts->sum('lead_count');

        return response()->json(['spocData' => $mappedSpocData, 'salesmanData' => $mappedSalesmanData, 'statusCounts' => $statusCounts, 'totalLeads' => $totalLeads]);
    }
}
