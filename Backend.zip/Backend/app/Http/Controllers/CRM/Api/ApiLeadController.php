<?php

namespace App\Http\Controllers\CRM\Api;

use App\Http\Controllers\Controller;
use App\Models\CRM\Lead;
use Illuminate\Http\Request;
use App\Traits\LeadTraits;
class ApiLeadController extends Controller
{
    use LeadTraits;
    public function assignManager(Request $request)
    {
        $response = $this->setLeadManager($request->lead_id);
        return $response;
    }
}
