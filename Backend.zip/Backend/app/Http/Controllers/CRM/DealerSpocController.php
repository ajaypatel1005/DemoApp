<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CRM\Lead;
use App\Models\CRM\LeadStatus;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class DealerSpocController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $fromDate = Carbon::today();
        $toDate = Carbon::today();

        // $fromDate = Carbon::today()->startOfMonth();
        // $toDate = Carbon::today()->endOfMonth();

        $userId = Auth::user()->id;

        $allStatuses = [
            config('constant.LEAD_STATUS.ASSIGNED'),
            config('constant.LEAD_STATUS.IN_PROGRESS'),
            config('constant.LEAD_STATUS.TRANSFER'),
            config('constant.LEAD_STATUS.PURCHASE'),
            config('constant.LEAD_STATUS.LOST')
        ];

        $leadStatusCounts = LeadStatus::select(
            'cop_lead_status_ms.ls_status_id',
            'cop_lead_status_ms.ls_status_name',
            DB::raw("(select COUNT(DISTINCT cop_leads.lead_id) from cop_leads
                          where
                           cop_leads.dealer_spoc_id = '{$userId}'
                          and cop_lead_status_ms.ls_status_id = cop_leads.dealer_status_id
                          and DATE(cop_leads.dealer_transfer_date) between '{$fromDate->toDateString()}' and '{$toDate->toDateString()}'
                        ) as lead_count")
        )
            ->whereIn('cop_lead_status_ms.ls_status_id', $allStatuses)
            ->get();
        // dd($leadStatusCounts);
        $statusCounts = [];
        foreach ($leadStatusCounts as $leadStatus) {
            $statusCounts[$leadStatus->ls_status_id] = $leadStatus->lead_count;
        }
        $totalLeads = $leadStatusCounts->sum('lead_count');

        return view('crm.spoc.dealer_spoc_dashboard', compact('totalLeads', 'statusCounts'));
    }

    public function newLeadList(Request $request)
    {
        // $daterange = explode(' - ', $request->date_range);
        // $fromDate = Carbon::createFromFormat('d/m/Y', $daterange[0])->startOfDay();
        // $toDate = Carbon::createFromFormat('d/m/Y', $daterange[1])->endOfDay();

        try {


            $newLeads = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_pipeline_stage', 'car_brand', 'dealer_status'])
                ->where('ls_status_id', config('constant.LEAD_STATUS.WIN'))
                ->where('dealer_status_id', config('constant.LEAD_STATUS.TRANSFER'))
                ->where('dealer_spoc_id', Auth::user()->id)
                ->get()
                ->map(function ($lead) {
                    $lead->encrypted_id = encrypt($lead->lead_id);
                    return $lead;
                });

                $assignedLeads = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_pipeline_stage', 'car_brand', 'dealer_status'])
                ->where('ls_status_id', config('constant.LEAD_STATUS.WIN'))
                ->where('dealer_status_id', config('constant.LEAD_STATUS.ASSIGNED'))
                ->where('dealer_spoc_id', Auth::user()->id)
                ->get()
                ->map(function ($lead) {
                    $lead->encrypted_id = encrypt($lead->lead_id);
                    return $lead;
                });

            $inProgressLeads = Lead::with(['lead_type', 'lead_pipeline', 'lead_status', 'lead_pipeline_stage', 'car_brand', 'dealer_status'])
                ->where('ls_status_id', config('constant.LEAD_STATUS.WIN'))
                ->where('dealer_status_id', config('constant.LEAD_STATUS.IN_PROGRESS'))
                ->where('dealer_spoc_id', Auth::user()->id)
                ->get()
                ->map(function ($lead) {
                    $lead->encrypted_id = encrypt($lead->lead_id);
                    return $lead;
                });

            return response()->json(['newLeads' => $newLeads,'assignedLeads'=>$assignedLeads, 'inProgressLeads' => $inProgressLeads]);
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            return ResponseHelper::errorResponseLead(['Something Went Wrong.' . $e->getMessage()]);
        }
    }

    /**
     * Show the lead counting on dashboard.
     */

    public function countLead(Request $request)
    {
        $allStatuses = [
            config('constant.LEAD_STATUS.ASSIGNED'),
            config('constant.LEAD_STATUS.IN_PROGRESS'),
            config('constant.LEAD_STATUS.TRANSFER'),
            config('constant.LEAD_STATUS.PURCHASE'),
            config('constant.LEAD_STATUS.LOST')
        ];

        $userId = Auth::user()->id;
        $daterange = explode(' - ', $request->date_range);
        $fromDate = Carbon::createFromFormat('d/m/Y', $daterange[0])->startOfDay();
        $toDate = Carbon::createFromFormat('d/m/Y', $daterange[1])->endOfDay();


        $leadStatusCounts = LeadStatus::select(
            'cop_lead_status_ms.ls_status_id',
            'cop_lead_status_ms.ls_status_name',
            DB::raw("(select COUNT(DISTINCT cop_leads.lead_id) from cop_leads
                          where
                           cop_leads.dealer_spoc_id = '{$userId}'
                          and cop_lead_status_ms.ls_status_id = cop_leads.dealer_status_id
                          and DATE(cop_leads.dealer_transfer_date) between '{$fromDate->toDateString()}' and '{$toDate->toDateString()}'
                        ) as lead_count")
        )
            ->whereIn('cop_lead_status_ms.ls_status_id', $allStatuses)
            ->get();

        $statusCounts = [];
        foreach ($leadStatusCounts as $leadStatus) {
            $statusCounts[$leadStatus->ls_status_id] = $leadStatus->lead_count;
        }
        $totalLeads = $leadStatusCounts->sum('lead_count');

        return response()->json(['statusCounts' => $statusCounts, 'totalLeads' => $totalLeads]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
