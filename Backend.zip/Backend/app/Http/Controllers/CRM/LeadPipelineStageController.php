<?php

namespace App\Http\Controllers\CRM;
use App\Http\Controllers\Controller;

use App\Models\CRM\LeadPipeline;
use App\Models\CRM\LeadPipelineStage;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LeadPipelineStageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_lead_pipeline_stage', 'view_lead_pipeline_stage'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $leadPipelineStageList = LeadPipelineStage::with('pipeline')->get();
        $leadPipelineList = LeadPipeline::where('status',1)->get();
        return view('crm.lead_pipeline_stage.create', compact('leadPipelineStageList','leadPipelineList'));
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate(
            [
                'lp_id' => 'required',
                'lps_name' => 'required|max:50|unique:cop_lead_pipeline_stage_ms,lps_name',
                'win_probability' => 'required',
            ],
            [
                'lp_id.required' => 'Select Pipeline Required',
                'lps_name.required' => 'Pipeline Stage Name Required',
                'win_probability.required' => 'Win Probability Required',
                'lps_name.max' => 'The Pipeline Stage Name must not exceed :max characters.',
                'lps_name.unique' => 'Lead pipeline Stage Name has already been taken.'
            ]
        );
        try
        {
            $maxDisplayOrder=0;
            $maxDisplayOrder = LeadPipelineStage::where('lp_id', $request->lp_id)
            ->max('display_order');
            $leadPipelineStage = new LeadPipelineStage;
            $leadPipelineStage->lp_id=$request->lp_id;
            $leadPipelineStage->lps_name=$request->lps_name;
            $leadPipelineStage->win_probability=$request->win_probability;
            $leadPipelineStage->display_order=$maxDisplayOrder+1;
            $leadPipelineStage->status = $request->has('status') ? 1 : 0;
            $leadPipelineStage->save();

            session()->flash('success', 'Lead Pipeline Stage Added Successfully.');

            return redirect()->route('lead_pipeline_stage.create');
        }
        catch(Exception $e)
        {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.'.$e);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_lead_pipeline_stage', 'view_lead_pipeline_stage'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $leadPipelineList = LeadPipeline::where('status',1)->get();
        $leadPipelineStageList=LeadPipelineStage::get();
        $leadPipelineStage = LeadPipelineStage::where('lps_id', decrypt($id))->first();
        return view('crm.lead_pipeline_stage.edit',compact('leadPipelineStageList','leadPipelineList','leadPipelineStage'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (!hasAnyPermission(['edit_lead_pipeline_stage', 'view_lead_pipeline_stage'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'lp_id' => 'required',
                'lps_name' => 'required|max:50|unique:cop_lead_pipeline_stage_ms,lps_name',
                'win_probability' => 'required:max:4',
            ],
            [
                'lp_id.required' => 'Select Pipeline Required',
                'lps_name.required' => 'Pipeline Stage Name Required',
                'win_probability.required' => 'Win Probability Required',
                'lps_name.max' => 'The Pipeline Stage Name must not exceed :max characters.',
                'win_probability.max' => 'The Win Probability must not exceed :max characters.',
                'lps_name.unique' => 'Lead pipeline Stage Name has already been taken.'
            ]
        );
        try {
            $leadPipelineStage = LeadPipelineStage::where('lps_id', decrypt($id))->first();
            if ($leadPipelineStage) {
                $leadPipelineStage->lps_name=$request->lps_name;
                $leadPipelineStage->win_probability=$request->win_probability;
                $leadPipelineStage->status = $request->has('status') ? 1 : 0;
                $leadPipelineStage->update();
                session()->flash('success', 'Lead Pipeline Stage Update Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.'.$e);
        }
        return redirect()->route('lead_pipeline_stage.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        if (!hasAnyPermission(['delete_lead_pipeline_stage'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        try {
            $leadPipelineStage = LeadPipelineStage::where('lps_id', decrypt($id))->first();

            if ($leadPipelineStage) {
                $leadPipelineStage->delete();

                session()->flash('success', 'Lead Pipeline Stage Delete Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            return redirect()->route('lead_pipeline_stage.create');

        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
    }

     /**
     * Toggle status feild active/Inactive.
     */
    public function toggleStatus(Request $request)
    {
        //Begin::toggle status
        $id = $request->input('id');
        $leadPipelineStage = LeadPipelineStage::find($id);
        $leadPipelineStage->status = $leadPipelineStage->status == 1 ? 0 : 1;
        $leadPipelineStage->save();
        //End::toggle status

        return response()->json(['message' => 'Status updated successfully']);
    }
}
