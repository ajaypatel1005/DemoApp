<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Helpers\ResponseHelper;
use App\Models\CRM\CallLog;
use App\Models\CRM\Lead;
use App\Models\CRM\LeadHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Exception;


class LeadCallLogController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    // Start::Call Log Insert
    public function store(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'lco_id' => 'required',
                'call_date' => 'required',
                'call_remark' => 'required | min:2',
            ],
            [
                'lco_id.required' => 'Select the Call Outcome.',
                'call_date.required' => 'Call date is required.',
                'call_remark.required' => 'Call remark is required.',
                'call_remark.min' => 'The call reamrk must be at least :min characters.',
            ]
        );

        // Check validation
        if ($validator->fails()) {
            return ResponseHelper::errorResponseLead($validator->errors());
        }
        try {
            // Create a new call log entry
            $calllog = new CallLog();
            $calllog->lead_id = decrypt($request->lead_id);
            $calllog->lco_id = $request->lco_id;
            $calllog->call_remarks = $request->call_remark;
            $calllog->call_date = date('Y-m-d H:i:s', strtotime($request->call_date));
            $calllog->created_by = Auth::user()->id;
            // Save the model to the database
            $calllog->save();

            if ($calllog) {
                $leadDetail = Lead::where('lead_id', $calllog->lead_id)->first();
                $leadHistory = new LeadHistory();
                $leadHistory->lead_id = $leadDetail->lead_id;
                $leadHistory->lp_id = $leadDetail->lp_id;
                $leadHistory->lps_id = $leadDetail->lps_id;
                $leadHistory->ls_status_id = $leadDetail->ls_status_id;
                $leadHistory->lt_id = $leadDetail->lt_id;
                $leadHistory->lcl_id = $calllog->lcl_id;
                $leadHistory->created_by = Auth::user()->id;
                $leadHistory->lh_type = "call_log";
                $leadHistory->save();
            }

            return ResponseHelper::responseMessageLead('success', 'Call Log Insert Successfully.');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    // End::Call Log Insert

    // Start::Call Log Data Fetch
    public function show(Request $request)
    {
        try {
            $id = decrypt($request->id);
            // $calllog = CallLog::where('lead_id', $id)->get();
            $calllog = CallLog::with(['call_outcome', 'created_user'])
                ->where('lead_id', $id)
                ->get();


            // Return the notes as a JSON response
            return response()->json(['data' => $calllog]);
        } catch (Exception $e) {
            // Handle decryption errors
            return response()->json(['error' => 'Decryption failed.'], 500);
        }
    }
    // End::Call Log Data Fetch


    // Begin::Call Log Data Edit
    public function edit(Request $request)
    {
        // Retrieve the CallLog record by ID
        $calllog = CallLog::with(['call_outcome'])
            ->where('lcl_id', $request->id)
            ->first();

        if (!$calllog) {
            // Handle case where the record is not found
            return response()->json(['error' => 'Record not found'], 404);
        }

        return response()->json(['calllog' => $calllog]);
    }
    // Begin::Call Log Data Edit

    // Start::Call Log Update
    public function update(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'lco_id' => 'required',
                'call_date' => 'required',
                'call_remark' => 'required | min:2',
            ],
            [
                'lco_id.required' => 'Select the Call Outcome.',
                'call_date.required' => 'Call date is required.',
                'call_remark.required' => 'Call remark is required.',
                'call_remark.min' => 'The call reamrk must be at least :min characters.',
            ]
        );
        // Check validation
        if ($validator->fails()) {
            return ResponseHelper::errorResponseLead($validator->errors());
        }
        try {

            // Create a Update call log entry
            $calllog = CallLog::find($request->lcl_id);
            $calllog->lco_id = $request->lco_id;
            $calllog->call_remarks = $request->call_remark;
            $calllog->call_date =date('Y-m-d H:i:s', strtotime($request->call_date));
            $calllog->created_by = Auth::user()->id;
            $calllog->save();

            return ResponseHelper::responseMessageLead('success', 'Call Log Update Successfully.');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    // End::Call Log Data Update

    // Start::Call Log Data Delete
    public function destroy(Request $request)
    {
        try {
            CallLog::destroy($request->id);
            return ResponseHelper::responseMessageLead('success', 'Call Log Delete Successfully.');
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    // End::Call Log Data Delete
}
