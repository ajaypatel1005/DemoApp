<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Imports\LeadImport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Maatwebsite\Excel\Facades\Excel;

class LeadImportController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        if (!hasAnyPermission(['lead_import'])) {
            abort(403, "you don't have permission to access");
        }
        return view('crm.import.lead_import');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        // Validate the request
        $request->validate([
            'file' => 'required|mimes:xlsx,csv', // Adjust the allowed file types if needed
        ]);

        // Check if file exists in the request
        if ($request->hasFile('file')) {
            $file = $request->file('file');

            // Create a new instance of the import class
            $import = new LeadImport();
            // Import data from the Excel file
            Excel::import($import, $file);

            // dd("hello22");
            // Retrieve validation errors from the import instance
            $validationErrors = $import->getValidationErrors();

            // Redirect back with validation errors if any
            // return Redirect::back()->with('success', "Successfuly Imported..!!");
            return Redirect::back()->with('validationErrors', $validationErrors);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
