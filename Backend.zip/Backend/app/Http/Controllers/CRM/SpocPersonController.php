<?php

namespace App\Http\Controllers\CRM;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\CRM\LeadCount;
use App\Models\CRM\LeadStatus;
use App\Models\CRM\SpocPerson;
use App\Models\Model;
use App\Models\State;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class SpocPersonController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('crm.spoc.cop_spoc_dashboard');
    }

    public function dashboardSalesman()
    {
        $fromDate = Carbon::today();
        $toDate = Carbon::today();
        $userId = Auth::user()->id;

        $allStatuses = [
            config('constant.LEAD_STATUS.ASSIGNED'),
            config('constant.LEAD_STATUS.IN_PROGRESS'),
            config('constant.LEAD_STATUS.TRANSFER'),
            config('constant.LEAD_STATUS.PURCHASE'),
            config('constant.LEAD_STATUS.LOST')
        ];

        $leadStatusCounts = LeadStatus::select(
            'cop_lead_status_ms.ls_status_id',
            'cop_lead_status_ms.ls_status_name',
            DB::raw("(select COUNT(DISTINCT cop_leads.lead_id) from cop_leads
                          where
                           cop_leads.dealer_salesman_id = '{$userId}'
                          and cop_lead_status_ms.ls_status_id = cop_leads.dealer_status_id
                          and DATE(cop_leads.dealer_transfer_date) between '{$fromDate->toDateString()}' and '{$toDate->toDateString()}'
                        ) as lead_count")
        )
            ->whereIn('cop_lead_status_ms.ls_status_id', $allStatuses)
            ->get();
            // dd($leadStatusCounts);
            $statusCounts = [];
            foreach ($leadStatusCounts as $leadStatus) {
                $statusCounts[$leadStatus->ls_status_id] = $leadStatus->lead_count;
            }
            $totalLeads = $leadStatusCounts->sum('lead_count');

        return view('crm.spoc.dashboard_salesman', compact('totalLeads', 'statusCounts'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        $spocTitle = config('constant.SPOC_VALUE.SPOC');
        if (Auth::user()->hasRole(config('constant.CRM_ROLE.RELATIONSHIP_MANAGER'))) {
            $spocTitle = config('constant.SPOC_VALUE.SPOC');
        }

        if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER'))) {
            $spocTitle = config('constant.SPOC_VALUE.SPOC');
        }
        if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER_SPOC_PERSON'))) {
            $spocTitle = config('constant.SPOC_VALUE.SALESMAN');
        }

        //
        $states = State::active()->get();
        $brands = Brand::select('brand_id', 'brand_name')->active()->get();

        $spocAll = SpocPerson::with(['city:city_id,state_id,city_name']);

        if (Auth::user()->hasRole(config('constant.CRM_ROLE.SUPER_ADMIN')) || Auth::user()->hasRole(config('constant.CRM_ROLE.RELATIONSHIP_MANAGER'))) {
            $spocAll=$spocAll->get();
        }

        if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER'))) {
            $spocAll->where('parent_id',Auth::user()->id);
            $spocAll=$spocAll->get();
        }
        // Dealer spoc login
        if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER_SPOC_PERSON'))) {
            // $getDealerSpoc = SpocPerson::where('user_id', Auth::user()->id)->first();
            $spocAll->where('created_by',Auth::user()->id);
            $spocAll=$spocAll->get();
        }


        // Begin::Brand get
        $spocData = $spocAll->map(function ($spoc) use ($brands) {
            $brandIds = explode(',', $spoc->brand_ids);
            $spocBrands = $brands->filter(function ($brand) use ($brandIds) {
                return in_array($brand->brand_id, $brandIds);
            });
            $spoc->brands = $spocBrands;

            return $spoc;
        });

        return view('crm.spoc.create', compact('brands', 'spocData', 'states', 'spocTitle'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        if (!hasAnyPermission(['create_spoc'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate([
            's_name' => 'required|min:2|max:200',
            's_email' => 'required|email|unique:cop_spoc_salesman_ms,s_email|unique:users,email',
            's_contact_no' => 'required|min:10|max:10|regex:/^[0-9]+$/|unique:cop_spoc_salesman_ms,s_contact_no',
            'state_id' => 'required',
            'city_id' => 'required',
            's_address' => 'required|min:2|max:400'
        ], [

            's_name.required' => 'SPOC Name is required',
            's_email.required' => 'Email is required',
            's_email.email' => 'Please enter a valid email address',
            's_email.unique' => 'This Email has already been taken.',
            's_contact_no.required' => 'Contact is required',
            's_contact_no.unique' => 'Contact Number has already been taken.',
            's_contact_no.min' => 'The Contact Number must be at least :min characters.',
            's_contact_no.max' => 'The Contact Number must not exceed :max characters.',
            'state_id.required' => 'State is required',
            'city_id.required' => 'City is required',
            's_address.required' => 'Address is required',
            's_address.min' => 'The Address must be at least :min characters.',
            's_address.max' => 'The Address must not exceed :max characters.',

        ]);
        DB::beginTransaction();
        try {
            $spoc = new SpocPerson();
            $spoc->brand_ids = $request->brand_id ? implode(',', $request->brand_id) : null;
            $spoc->city_id = $request->city_id;
            $spoc->s_name = $request->s_name;
            $spoc->s_email = $request->s_email;
            $spoc->s_address = $request->s_address;
            $spoc->s_contact_no = $request->s_contact_no;


            // RM/Superadmin login time COP SPOC
            if (Auth::user()->hasRole(config('constant.CRM_ROLE.RELATIONSHIP_MANAGER')) || Auth::user()->hasRole(config('constant.CRM_ROLE.SUPER_ADMIN'))) {
                $spoc->spoc_type = config('constant.SPOC_TYPE.COP_SPOC_PERSON');
                $spoc->parent_id = Auth::user()->id;
            }

            // dealer login time dealer SPOC set parent_id
            if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER'))) {
                $spoc->spoc_type = config('constant.SPOC_TYPE.DEALER_SPOC_PERSON');
                $spoc->parent_id = Auth::user()->id;
            }

            // Dealer SPOC login time dealer SPOC set parent_id as her dealer
            if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER_SPOC_PERSON'))) {
                $spoc->spoc_type = config('constant.SPOC_TYPE.DEALER_SALESMAN');
                $getDealerSpoc = SpocPerson::where('user_id', Auth::user()->id)->first();
                $spoc->parent_id = $getDealerSpoc->parent_id;
                //get dealer id
            }

            $spoc->status = $request->has('status') ? 1 : 0;
            $spoc->created_by = Auth::user()->id;
            $spoc->save();

            $spocUpdate = SpocPerson::find($spoc->spoc_id);
            if ($spocUpdate) {

                $user = User::create([
                    'name' => $request->s_name,
                    'email' => $request->s_email,
                    'password' => Hash::make($request->s_contact_no),
                ]);

                if (Auth::user()->hasRole(config('constant.CRM_ROLE.RELATIONSHIP_MANAGER')) || Auth::user()->hasRole(config('constant.CRM_ROLE.SUPER_ADMIN'))) {
                    $user->assignRole(config('constant.CRM_ROLE.COP_SPOC_PERSON'));
                }

                if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER'))) {
                    $user->assignRole(config('constant.CRM_ROLE.DEALER_SPOC_PERSON'));
                }
                if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER_SPOC_PERSON'))) {
                    $user->assignRole(config('constant.CRM_ROLE.DEALER_SALESMAN'));
                }

                $spocUpdate->user_id = $user->id;
                $spocUpdate->spoc_code = LeadCount::generateUniqCode('spoc_code');
                $spocUpdate->update();

                session()->flash('success', 'SPOC Added Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.' . $e);
        }

        return redirect()->route('spoc.create');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        //
        if (!hasAnyPermission(['edit_spoc', 'view_spoc'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $spocTitle = config('constant.SPOC_VALUE.SPOC');
        if (Auth::user()->hasRole(config('constant.CRM_ROLE.RELATIONSHIP_MANAGER')) || Auth::user()->hasRole(config('constant.CRM_ROLE.SUPER_ADMIN'))) {
            $spocTitle = config('constant.SPOC_VALUE.SPOC');
        }

        if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER'))) {
            $spocTitle = config('constant.SPOC_VALUE.SPOC');
        }
        if (Auth::user()->hasRole(config('constant.CRM_ROLE.DEALER_SPOC_PERSON'))) {
            $spocTitle = config('constant.SPOC_VALUE.SALESMAN');
        }

        $states = State::active()->get();
        $brands = Brand::select('brand_id', 'brand_name')->active()->get();

        $spocsAll = SpocPerson::with(['city:city_id,state_id,city_name'])
            ->get();
        // Begin::Brand get
        $spocData = $spocsAll->map(function ($spoc) use ($brands) {
            $brandIds = explode(',', $spoc->brand_ids);
            $spocBrands = $brands->filter(function ($brand) use ($brandIds) {
                return in_array($brand->brand_id, $brandIds);
            });
            $spoc->brands = $spocBrands;
            return $spoc;
        });

        $spocEdit = SpocPerson::with('city')->where('spoc_id', decrypt($id))->first();

        $spocEdit->brand_ids = $spocEdit->brand_ids ? explode(',', $spocEdit->brand_ids) : '';
        $spocEdit->user_id = encrypt($spocEdit->user_id);

        return view('crm.spoc.edit', compact('states', 'brands', 'spocData', 'spocEdit', 'spocTitle'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        if (!hasAnyPermission(['edit_spoc'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        $request->validate([
            's_name' => 'required|min:2|max:200',
            's_email' => 'required|email|unique:cop_spoc_salesman_ms,s_email,' . decrypt($id) . ',spoc_id|unique:users,email,' . decrypt($request->user_id) . ',id',
            's_contact_no' => 'required|min:10|max:10|regex:/^[0-9]+$/|unique:cop_spoc_salesman_ms,s_contact_no,' . decrypt($id) . ',spoc_id',
            'state_id' => 'required',
            'city_id' => 'required',
            's_address' => 'required|min:2|max:400',
        ], [
            's_name.required' => 'Name is required',
            's_email.required' => 'Email is required',
            's_email.email' => 'Please enter a valid email address',
            's_email.unique' => 'This Email has already been taken.',
            's_contact_no.required' => 'Contact is required',
            's_contact_no.unique' => 'Contact No. has already been taken.',
            's_contact_no.min' => 'The Contact Number must be at least :min characters.',
            's_contact_no.max' => 'The Contact Number must not exceed :max characters.',
            'state_id.required' => 'State is required',
            'city_id.required' => 'City is required',
            's_address.required' => 'Address is required',
            's_address.min' => 'The Address must be at least :min characters.',
            's_address.max' => 'The Address must not exceed :max characters.',
        ]);


        DB::beginTransaction();

        try {
            $spoc = SpocPerson::where('spoc_id', decrypt($id))->first();

            if ($spoc) {
                // Update other fields
                $spoc->brand_ids = $request->brand_id ? implode(',', $request->brand_id) : null;
                $spoc->city_id = $request->city_id;
                $spoc->s_name = $request->s_name;
                $spoc->s_email = $request->s_email;
                $spoc->s_address = $request->s_address;
                $spoc->s_contact_no = $request->s_contact_no;
                $spoc->status = $request->has('status') ? 1 : 0;
                $spoc->updated_by = Auth::user()->id;
                $spoc->update();

                if ($spoc) {
                    $user = User::findOrFail($spoc->user_id);
                    $user->name = $request->s_name;
                    $user->email = $request->s_email;
                    $user->save();
                }

                session()->flash('success', 'SPOC Updated Successfully.');
            } else {
                session()->flash('error', 'Record Not Found.');
            }
            DB::commit();
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.' . $e);
        }

        return redirect()->route('spoc.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        if (!hasAnyPermission(['delete_spoc'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }

        try {
            $spoc = SpocPerson::where('spoc_id', decrypt($id))->firstOrFail();

            $user = User::findOrFail($spoc->user_id);

            DB::beginTransaction();

            $spoc->delete();
            $user->delete();

            DB::commit();

            session()->flash('success', 'SPOC Deleted Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Failed to delete SPOC.');
        }

        return redirect()->route('spoc.create');
    }

    public function toggleStatus(Request $request)
    {
        $id = $request->input('id');
        DB::table('cop_spoc_salesman_ms')
            ->where('spoc_id', $id)
            ->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
        return response()->json(['message' => 'Status updated successfully']);
    }
}
