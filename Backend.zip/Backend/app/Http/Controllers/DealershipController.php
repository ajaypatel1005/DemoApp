<?php

namespace App\Http\Controllers;

use App\Http\Requests\{SaveDealershipRequest, updateDealerShipRequest};
use App\Models\{Brand, Dealership, State};
use Illuminate\Support\Facades\{DB, Log};
use Illuminate\Http\Request;
use Exception;

class DealershipController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (!hasAnyPermission(['view_dealer'])) {
            abort(403, "You don't have permission to access");
        }
        return view('dealership.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_dealer'])) {
            abort(403, "You don't have permission to access");
        }
        $brands = Brand::where('status', 1)->get();
        $states = State::where('status', 1)->get();
        return view('dealership.create', compact('brands', 'states'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(SaveDealershipRequest $request)
    {
        try {
            DB::beginTransaction();
            $data = $request->only(['company_name', 'dealer_name', 'state_id', 'city_id', 'brand_id', 'address']);
            if (!empty($request->map_location)) {
                $data['map_location'] = $request->map_location;
            }
            $data['phone_no'] = $request->phone_no ?? '';
            $data['email'] = $request->email ?? '';
            Dealership::create($data);
            DB::commit();
            session()->flash('success', 'Dealership has been added successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('dealership.index');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!hasAnyPermission(['edit_dealer'])) {
            abort(403, "You don't have permission to access");
        }
        $dealership = Dealership::findOrFail(decrypt($id));
        $brands = Brand::where('status', 1)->get();
        $states = State::where('status', 1)->get();
        return view('dealership.edit', compact('dealership', 'brands', 'states'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(updateDealerShipRequest $request, string $id)
    {
        try {
            DB::beginTransaction();
            $dealer = Dealership::findOrFail(decrypt($id));
            $data = $request->only(['company_name', 'dealer_name', 'state_id', 'city_id', 'brand_id', 'address']);
            $data['email'] = $request->email ?? '';
            $data['phone_no'] = $request->phone_no ?? '';
            $data['map_location'] = $request->map_location;
            $dealer->update($data);
            DB::commit();
            session()->flash('success', 'Dealership has been updated successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }

        return redirect()->route('dealership.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function deleteDealer($id)
    {
        if (!hasAnyPermission(['delete_dealer'])) {
            abort(403, "You don't have permission to access");
        }
        try {
            $dealer = Dealership::findOrFail(decrypt($id));
            $dealer->delete();
            session()->flash('success', 'Dealership has been deleted successfully.');
        } catch (Exception $e) {
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something went wrong.');
        }
        return redirect()->route('dealership.index');
    }


    public function fetchRecord()
    {
        if (request()->ajax()) {
            $limit = (request()->has('length') ? request()->input('length') : 10);
            $page = (request()->has('start') ? request()->input('start') : 0);
            $search = (request()->has('search') ? request()->input('search')['value'] : '');
            $dealershipData = Dealership::select('cop_dealer.id', 'cop_dealer.brand_id', 'company_name', 'dealer_name', 'city_name', 'brand_name', 'phone_no', 'cop_dealer.status')
                ->leftJoin('cop_brands_ms', 'cop_dealer.brand_id', '=', 'cop_brands_ms.brand_id')
                ->leftJoin('cop_city_ms', 'cop_dealer.city_id', '=', 'cop_city_ms.city_id')
                ->leftJoin('cop_state_ms', 'cop_city_ms.state_id', '=', 'cop_state_ms.state_id');

            if (!empty($search)) {
                $dealershipData->where(function ($query) use ($search) {
                    $query->orWhere('cop_dealer.dealer_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('cop_dealer.company_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('cop_state_ms.state_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('cop_city_ms.city_name', 'LIKE', '%' . $search . '%')
                        ->orWhere('cop_brands_ms.brand_name', 'LIKE', '%' . $search . '%');
                });
            }

            $cntFilter = clone $dealershipData;
            $dealershipData->offset($page)->limit($limit);
            $dealership = $dealershipData->get();

            $serviceStationTotal = DB::select("SELECT COUNT(*) AS count FROM cop_s_stations_ms")[0]->count;
            $data = [];
            $i = $page;
            foreach ($dealership as $member) {
                $i++;
                $status = $disable = "";
                if ($member->status == 1) {
                    $status = 'checked';
                }
                $disable = (!auth()->user()->can('edit_dealer')) ? 'disabled' : '';

                $model_status = '<div
            class="form-check form-switch form-check-custom form-check-success form-check-solid">
            <input class="form-check-input" name="status" type="checkbox" value="' . $member->id . '" ' . $disable . ' ' . $status . ' id="status" /> </div>';
                $action = "";
                if (auth()->user()->can('edit_dealer')) {
                    $editRoute = route('dealership.edit', encrypt($member->id));
                    $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                    <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                }
                if (auth()->user()->can('delete_dealer')) {
                    $action .= '<a href="javascript:void(0);"
                data-href="' . route('delete_dealership', encrypt($member->id)) . '"
                class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                }
                $data[] = array("sr_no" => $i, "brand_name" => $member->brand_name, "phone_no" => $member->phone_no,  "dealer_name" => $member->dealer_name, "company_name" => $member->company_name,  "city_name" => $member->city_name, "status" => $model_status, "action" => $action);
            }
            return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $serviceStationTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
        }
    }

    public function updateStatus(Request $request)
    {
        if ($request->ajax()) {
            $id = $request->input('id');
            Dealership::where('id', $id)->update(['status' => DB::raw('IF(status = 1, 0, 1)')]);
            return response()->json(['message' => 'Status updated successfully']);
        }
    }
}
