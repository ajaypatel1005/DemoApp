<?php

namespace App\Http\Controllers;

use App\Models\CarStage;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class CarStageController extends Controller
{
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!hasAnyPermission(['create_car_stage', 'view_car_stage'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $car_stage_view = CarStage::all();
        return view('car_stage.create', compact('car_stage_view'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!hasAnyPermission(['create_car_stage'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'cs_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:20|unique:cop_cs_ms,cs_name'
            ],
            [
                'cs_name.required' => 'Car Stage Name is required',
                'cs_name.regex' => 'Car Stage Name is invalid',
                'cs_name.unique' => 'Car Stage Name already exist',
                'cs_name.min' => 'Minimum 2 characters are required',
                'cs_name.max' => 'Maximum 20 characters are allowed'
            ]
        );
        DB::beginTransaction(); // Begin transaction
        try {
            CarStage::create([
                'cs_name' => $request->cs_name
            ]);
            DB::commit();
            session()->flash('success', 'Car Stage Added Successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_stage.create');
    }



    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        if (!hasAnyPermission(['edit_car_stage', 'view_car_stage'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $car_stage_edit = CarStage::where('cs_id', decrypt($id))->first();
        $car_stage_view = CarStage::all();
        return view('car_stage.edit', compact('car_stage_edit', 'car_stage_view'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!hasAnyPermission(['edit_car_stage'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $request->validate(
            [
                'cs_name' => 'required|regex:/^[A-Za-z\s]+$/|min:2|max:20|unique:cop_cs_ms,cs_name,' . decrypt($id) . ',cs_id'
            ],
            [
                'cs_name.required' => 'Car Stage Name is required',
                'cs_name.regex' => 'Car Stage Name is invalid',
                'cs_name.unique' => 'Car Stage Name already exist',
                'cs_name.min' => 'Minimum 2 characters are required',
                'cs_name.max' => 'Maximum 20 characters are allowed'
            ]
        );
        DB::beginTransaction();
        try {
            $car_stage_update = CarStage::where('cs_id', decrypt($id))->first();
            if (!empty($car_stage_update)) {
                $car_stage_update->cs_name = $request->cs_name;
                $car_stage_update->save();
                DB::commit();
                session()->flash('success', 'Car Stage Updated Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_stage.create');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!hasAnyPermission(['delete_car_stage'])) {
            abort(403, 'USER DOES NOT HAVE THE RIGHT PERMISSIONS');
        }
        $car_stage_destroy = CarStage::where('cs_id', decrypt($id))->first();
        DB::beginTransaction();
        try {
            if (!empty($car_stage_destroy)) {
                if ($car_stage_destroy->models->isNotEmpty()) {

                    session()->flash('error', 'This Field Value Cannot Be Deleted Because Other Records Are Using It.');
                    return redirect()->route('car_stage.create');
                }
                $car_stage_destroy->delete();
                DB::commit();
                session()->flash('success', 'Car Stage Deleted Successfully.');
            } else {
                session()->flash('error', 'Something Went Wrong.');
            }
        } catch (Exception $e) {
            DB::rollBack();
            Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            session()->flash('error', 'Something Went Wrong.');
        }
        return redirect()->route('car_stage.create');
    }

    public function fetchRecord(Request $request)
    {
        if ($request->ajax()) {
            try {
                $limit = ($request->has('length') ? $request->input('length') : 10);
                $page = ($request->has('start') ? $request->input('start') : 0);
                $search = ($request->has('search') ? $request->input('search')['value'] : '');
                $car_stage_view = CarStage::select('cop_cs_ms.cs_id', 'cop_cs_ms.cs_name');

                if (!empty($search)) {
                    $car_stage_view->where(function ($query) use ($search) {
                        $query->orWhere('cop_cs_ms.cs_name', 'LIKE', '%' . $search . '%');
                    });
                }

                $cntFilter = clone $car_stage_view;
                $car_stage_view->offset($page)->limit($limit);
                $car_stage_view = $car_stage_view->get();

                $carStageTotal = DB::select("SELECT COUNT(*) AS count FROM cop_cs_ms")[0]->count;
                $data = [];
                $i = $page;
                foreach ($car_stage_view as $member) {
                    $i++;
                    $action = "";
                    if (auth()->user()->can('edit_car_stage')) {
                        $editRoute = route('car_stage.edit', encrypt($member->cs_id));
                        $action .= '<a href="' . $editRoute . '" class=" btn-primary">
                                <i class="fas fa-pen fs-4 text-primary"></i> </a>';
                    }
                    if (auth()->user()->can('delete_car_stage')) {
                        $action .= '<a href="javascript:void(0);"
                            data-href="' . route('car_stage.destroy', encrypt($member->cs_id)) . '"
                            class="delete_record btn-danger"> <i class="fas fa-trash fs-4 text-danger"></i></a>';
                    }
                    $data[] = array("sr_no" => $i, "cs_name" => $member->cs_name, "action" => $action);
                }
                return response()->json(array("draw" => $_POST['draw'], "recordsTotal" => $carStageTotal, "recordsFiltered" => $cntFilter->count(), 'data' => $data));
            } catch (Exception $e) {
                Log::emergency("File: " . $e->getFile() . " LN No:" . $e->getLine() . " Msg : " . $e->getMessage());
            }
        }
    }
}
