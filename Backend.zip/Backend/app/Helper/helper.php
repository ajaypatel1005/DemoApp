<?php

use App\Models\Notification;
use Illuminate\Support\Facades\Auth;

if (!function_exists('hasAnyPermission')) {
    /**
     * Check if the authenticated user has any permission from the given array.
     *
     * @param array $permissions
     * @return bool
     */
    function hasAnyPermission(array $permissions)
    {
        // Get the authenticated user
        $user = auth()->user();

        // Check if the user has any of the given permissions
        return $user && $user->hasAnyPermission($permissions);
    }
}

//////// Do Not Edit Above /////////
if (!function_exists('encryptor')) {
    function encryptor($action, $string)
    {
        $secret_key = 'iWPPtLfcVTZtb1rJlGY2eL958g9dfhQpt797BU8LMfS2WvEkwI';
        $secret_iv = 'm4iSFgKgxwVMWuTyOjUUTCGjJSJKJShH';

        $output = false;
        $encrypt_method = "AES-256-CBC";
        // hash
        $key = hash('sha256', $secret_key);
        // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        $iv = substr(hash('sha256', $secret_iv), 0, 16);

        //do the encyption given text/string/number
        if ($action == 'e') {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output = base64_encode($output);
        } else if ($action == 'd') {
            //decrypt the given text/string/number
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        }

        return $output;
    }
}

if (!function_exists('checkUserRole')) {
    function checkUserRole($role) {
        // Get the currently authenticated user
        $user = auth()->user();
        // Check if the user is authenticated
        if ($user) {
            // Check if the user has the specified role
            return $user->role === $role;
        }
        return
            false;
    }
}
if (!function_exists('createNotification')) {
    function createNotification($title, $message, $customer_id, $url, $data = [])
    {
        $notification = new Notification();
        $notification->title = $title;
        $notification->message = $message;
        $notification->customer_id = $customer_id;
        $notification->url = $url;
        $notification->is_read = '0';
        $notification->created_by = 1;

        $notification->save();
        return $notification;
    }
}
