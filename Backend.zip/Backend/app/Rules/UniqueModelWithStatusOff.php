<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;
use App\Models\Banner;

class UniqueModelWithStatusOff implements Rule
{
    protected $bannerId;

    public function __construct($bannerId)
    {
        $this->bannerId = $bannerId;
    }

    public function passes($attribute, $value)
    {
        $existingModel = Banner::where('model_id', $value)
            ->join('cop_bc_ms', 'cop_bc_ms.bc_id', '=', 'cop_banners.bc_id')
            ->where('cop_bc_ms.bc_name', 'EV Banner')
            ->first();
        if ($existingModel) {
            if ($existingModel->status == 1) {
                return false;
            } else {
                return true;
            }
        }
        return true;
    }

    public function message()
    {
        return 'The selected model is already in use with status 1 and cannot be used again.';
    }
}
