<?php


namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\Rule;
use App\Models\Manager;
use App\Models\User;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Support\Facades\DB;
class ValidManager implements ValidationRule
{
    protected $manager;
    public function __construct($manager = null)
    {
        $this->manager = $manager;
    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
{
    if ($this->manager === null ) {
        return;
    }
    if ($this->manager !== null && $attribute === 'first_name' ) {
        $manager = Manager::where('first_name', 'LIKE', trim($value))->exists();

        if (!$manager) {
            $fail("manager Name does not exist or disabled");
        }
    }
}
}

