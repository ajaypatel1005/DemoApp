<?php
 
namespace App\Rules;
 
use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
 
class ValidImagePath implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @param  \Closure  $fail
     * @return void
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if (filter_var($value, FILTER_VALIDATE_URL) !== false) {
            $headers = get_headers($value, 1);
            if(isset($headers['Content-Type'])){
                $headerContentType=$headers['Content-Type'];
            }else{
                $headerContentType=$headers['content-type'];
 
            }
            if (isset($headerContentType)) {
                $validImageTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
 
 
                if (is_array($headerContentType)) {
                    foreach ($headerContentType as $contentType) {
                        if (!in_array($contentType, $validImageTypes)) {
                            $fail('The :attribute must be a valid image URL of type jpeg, jpg, png, or webp.');
                        }
                    }
                } else {
 
                    if (!in_array($headerContentType, $validImageTypes)) {
                        $fail('The :attribute must be a valid image URL of type jpeg, jpg, png, or webp.');
                    }
                }
 
                if(isset($headers['content-length'])){
                    // dd($headerContentType,'if2');
                    $headerContentLength=$headers['content-length'];
                }else if(isset($headers['Content-Length'])){
                    // dd($headerContentType,'else2');
                    $headerContentLength=$headers['Content-Length'];
                }else{
                    $fail('The :attribute url is not valid.');
                }
 
                if (isset($headerContentLength)) {
                    // dd($headerContentLength);
                    $maxSizeInBytes = 5 * 1024 * 1024;
                    $imageSizeInBytes = (int)$headerContentLength;
 
                    if ($imageSizeInBytes > $maxSizeInBytes) {
                        $fail('The :attribute size not exceeding 2 MB.');
                    }
                }
            } else {
                // dd($headerContentType,'else3');
                $fail('The :attribute url is not valid.');
            }
 
        } else {
 
            $fail('The :attribute must be an URL ');
        }
    }
}
