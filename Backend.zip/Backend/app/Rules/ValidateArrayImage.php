<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class ValidateArrayImage implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        
        if (strpos($value, ' ') !== false) {
            $fail("Space is not allow between 2 URLs, Please use coma(,) sepration between 2 URLs.");
        }

        $values_final = str_replace(' ', '', $value);
        // Explode the input value into an array of URLs
        $urls = explode(',', $values_final);

        $count = count($urls);

        for ($i = 0; $i < $count; $i++) {

            // $url_trim = $urls[$i];
            $url_trim = str_replace(' ', '', $urls[$i]);

            // Validate each URL
            $url = filter_var($url_trim, FILTER_VALIDATE_URL);

            if ($url !== false) {
                $allImagePath = get_headers($url, 1);

                if(isset($allImagePath['Content-Type'])){
                    $headerContentType=$allImagePath['Content-Type'];
                }
                if(isset($allImagePath['content-type'])){
                    $headerContentType=$allImagePath['content-type'];
                }
                if(isset($allImagePath['Content-Length'])){
                    $headerContentLength=$allImagePath['Content-Type'];
                }
                if(isset($allImagePath['content-length'])){
                    $headerContentLength=$allImagePath['content-type'];
                }

                if (isset($headerContentType)) {
                    $validImageTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];

                    if (is_array($headerContentType)) {
                        foreach ($headerContentType as $contentType) {
                            if (!in_array($contentType, $validImageTypes)) {
                                $fail("The :attribute must be a valid image URL of type jpeg, jpg, png, or webp for the URL: $url");
                            }
                        }
                    } else {
                        if (!in_array($headerContentType, $validImageTypes)) {
                            $fail("The :attribute must be a valid image URL of type jpeg, jpg, png, or webp for the URL: $url");
                        }
                    }

                    if (isset($headerContentType)) {
                        $maxSizeInBytes = 2 * 1024 * 1024;
                        $imageSizeInBytes = (int)$headerContentLength;

                        if ($imageSizeInBytes > $maxSizeInBytes) {
                            $fail("The :attribute size not exceeding 2 MB for the URL: $url");
                        }
                    }
                } else {
                    $fail("The :attribute failed to fetch for the URL: $url");
                }
            } else {
                $fail("The :attribute must be a valid images URL for the URL: $url_trim");
            }
        }
    }
}
