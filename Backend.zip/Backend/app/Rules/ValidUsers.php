<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\Rule;
use App\Models\Manager;
use App\Models\User;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Support\Facades\DB;
class ValidUsers implements ValidationRule
{
    protected $username;
    public function __construct($username = null)
    {
        $this->username = $username;

    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
{

    if ($this->username === null ) {
        return;
    }


    if ($this->username !== null && $attribute === 'manager_name' ) {
        $User = User::where('name', 'LIKE', trim($value))->exists();

        if (!$User) {
            $fail("Manager Name does not exist or disabled");
        }
    }
    if ($this->username !== null && $attribute === 'assign_to' ) {

        $User = User::where('name', 'LIKE', trim($value))->exists();

        if (!$User) {
            $fail("User Name does not exist or disabled");
        }
    }
}

}
