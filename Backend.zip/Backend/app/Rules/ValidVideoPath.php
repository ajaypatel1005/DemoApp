<?php
 
namespace App\Rules;
 
use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
 
class ValidVideoPath implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        // $imageExtensions = ['mp4','avi','mov','mkv'];

        // if (!file_exists($value)) {
        //     $fail("The $attribute path is invalid.");
        // }

        // $extension = pathinfo($value, PATHINFO_EXTENSION);
        // dd($extension);
        // if (!in_array(strtolower($extension), $imageExtensions)) {
        //     $fail("The $attribute must be mp4,avi,mov,mkv.");
        // }

        if (filter_var($value, FILTER_VALIDATE_URL) !== false) {

            $headers = get_headers($value, 1);

            if(isset($headers['content-type'])){
                $content_type = $headers['content-type'];
            } else {
                $content_type = $headers['Content-Type'];
            }

            if(isset($content_type)){
                $validVideoTypes = ['video/mp4', 'video/avi', 'video/mov', 'video/mkv'];

                if(is_array($content_type)){
                    foreach($content_type as $contentType){
                        if (!in_array($contentType, $validVideoTypes)) {
                            $fail('The :attribute must be a valid video URL of type mp4, avi, mov, mkv.');
                        }
                    }
                } else {
                    if (!in_array($content_type, $validVideoTypes)) {
                        $fail('The :attribute must be a video URL of type mp4, avi, mov, mkv.');
                    }
                }
            }else{
                $fail('The :attribute failed to fetch.');
            }
        
        } else {
    
            $fail('The :attribute must be an URL ');
        }

        
    }
}
 