<?php

namespace App\Rules;

use App\Models\Customer;
use Closure;
use Illuminate\Contracts\Validation\Rule;
use App\Models\Manager;
use App\Models\User;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Support\Facades\DB;

class ValidCustomer implements ValidationRule
{
    protected $firstName;

    protected $brandName;
    protected $modelName;
    public function __construct($first_name = null,$brandName = null, $modelName = null)
    {
        $this->firstName = $first_name;
        $this->brandName = $brandName;
        $this->modelName = $modelName;

    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {

        if ($this->firstName !== null) {
            $Customer = Customer::where('first_name', 'LIKE', trim($this->firstName))->where('last_name', 'LIKE', trim($value))->exists();

            if (!$Customer) {
                $fail("Customer does not exist or disabled");
            }
        }

    }
}
